HUONG DAN
Giai nen toan bo ZIP, giu nguyen cau truc thu muc. Mo index.html hoac dua ca thu muc len hosting. CDN va Firebase/PeerJS van theo cau hinh goc.

Cac module duoc nap theo thu tu goc, dung classic scripts de giu bien va ham dung chung. Du lieu nhung giu trong index.html. export-sources.js chi nap khi xuat HTML doc lap, chua ma nguon goc de file xuat khong phu thuoc thu muc js/css.

Da kiem tra cu phap JavaScript bang Node.js; chua kiem thu tuong tac trinh duyet, dang nhap, dong bo hay nop bai thuc te.

js/01-code88-reload-home.js
js/02-host-detection.js
css/01-host-visibility.css
js/03-library-loader.js
js/04-library-fallback.js
css/02-main-ui.css
css/03-code77-style.css
js/05-code77-sakb.js
css/04-code79-editor-font.css
css/05-empty-header.css
css/06-code83-home-style.css
css/07-code117-style.css
css/08-code153-css.css
css/09-code157-css.css
css/10-code158-css.css
css/11-code160-style.css
css/12-tailwind-generated.css
css/13-live-quiz.css
css/14-code99-css.css
css/15-horizontal-top-toolbar-css.css
css/16-top-banner-css.css
css/17-banner-ratio-and-subject-tabs-css.css
css/18-banner-exact-reference-ratio-final.css
js/06-live-quiz.js
js/07-cloudsync-module.js
js/08-hs-auth-module.js
js/09-core-app.js
js/10-mobile-score-collapse.js
js/11-classnet-module.js
js/12-code83-home-js.js
js/13-code94-mathtype.js
js/14-code93-mix.js
js/15-code99-avatar.js
js/16-code121-english.js
js/17-code103-reload-home.js
js/18-code126-bank.js
js/19-code129-bank.js
js/20-code153-bank-import.js
js/21-code162-bank-word.js
js/22-code164-designer.js
css/19-teacher-del-hs-styles.css
js/23-teacher-del-hs-script.js
js/24-subject-tabs-bar-script.js
css/20-guest-home.css
js/25-publication-guest-home.js