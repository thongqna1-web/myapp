
/* ============================================================
   [CODE121] NHẬP FILE WORD ENGLISH
   Quy ước file Word (xem file mẫu "ĐỀ MẪU ANH"):
     - Đáp án đúng: GẠCH CHÂN (cả chữ A./B./C./D. hoặc nội dung đáp án).
     - Câu hỏi nhóm: toàn bộ nhóm (đề dẫn + đoạn văn + các câu + lời giải) nằm trong cặp dấu [ ... ].
         · Dạng 1 – dòng dẫn có cụm "Read the" : GIỮ NGUYÊN số thứ tự câu, chỉ đảo vị trí đáp án A, B, C, D.
         · Dạng 2 – các nhóm còn lại           : đảo cả thứ tự câu (trong nhóm) lẫn thứ tự đáp án.
     - Câu hỏi: "Question n." + (đề) + A. B. C. D. ; hướng dẫn nằm sau từ "Answer:".
   Các câu lưu: q.gid (mã nhóm), q.ginfo (đề dẫn + đoạn văn, ở câu đầu nhóm), q.gm = 'k' (giữ số câu) | 's' (đảo câu).
   ============================================================ */
(function () {
    'use strict';
    var EN = window.CODE121EN = { active: false };

    var Q_START = /^\s*(?:Question|Câu)\s*(\d+)\s*[\.\:\)\-]?\s*/i;
    var ANS_RE = /^\s*Answer\s*[:：]\s*/i;
    var END_RE = /^[\s\-–—=_*]*THE\s+END\b|^\s*[-–]\s*Thí\s+sinh|^\s*[-–]\s*Giám\s+thị|^\s*Mã\s+đề\s+thi/i;
    var ROMAN_RE = /^\[(?:I{1,3}|IV|V)\]/;      // [I] [II] [III] [IV] : ô chèn câu, KHÔNG phải dấu nhóm
    var READ_RE = /\bread\s+the\b/i;
    var WS_RE = /^[\s\u00A0\u200B\uFEFF]*$/;

    function plain(p) { var s = ''; for (var i = 0; i < p.length; i++) s += p[i].ch; return s; }
    function isWs(c) { return WS_RE.test(c.ch); }
    function trimChars(a) {
        var i = 0, j = a.length;
        while (i < j && isWs(a[i])) i++;
        while (j > i && isWs(a[j - 1])) j--;
        return a.slice(i, j);
    }
    function nl() { return { ch: '\n', b: false, u: false, vert: null }; }
    // đảm bảo mỗi phần tử = đúng 1 ký tự UTF-16 để chỉ số chuỗi = chỉ số mảng
    function normalizeLine(line) {
        var out = [];
        for (var i = 0; i < line.length; i++) {
            var c = line[i];
            if (!c || c.ch == null) continue;
            if (c.ch.length === 1) { out.push(c); continue; }
            for (var k = 0; k < c.ch.length; k++) { var d = {}; for (var key in c) d[key] = c[key]; d.ch = c.ch.charAt(k); out.push(d); }
        }
        return out;
    }

    /* ---- chuỗi định dạng: giữ in đậm / gạch chân / chỉ số trên-dưới (tùy chọn) ---- */
    function fmt(chars, o) {
        o = o || {};
        var out = '', cb = false, cu = false, ci = false, cv = null;
        function closeAll() {
            if (ci) out += '</i>';
            if (cu) out += '</u>';
            if (cb) out += '</b>';
            if (cv === 'sub') out += '</sub>'; else if (cv === 'sup') out += '</sup>';
            cb = cu = ci = false; cv = null;
        }
        for (var i = 0; i < chars.length; i++) {
            var c = chars[i], ch = c.ch;
            if (ch === '\t') ch = ' ';
            if (!isWs(c) || ch === '\n') {
                if (ch === '\n' || c.inMath) {
                    if (cb || cu || ci || cv) closeAll();
                } else {
                    var b = !!(o.keepB && c.b), u = !!(o.keepU && c.u), it = !!(o.keepI && c.i), v = c.vert || null;
                    if (b !== cb || u !== cu || it !== ci || v !== cv) {
                        closeAll();
                        if (v === 'sub') out += '<sub>'; else if (v === 'sup') out += '<sup>';
                        if (b) out += '<b>';
                        if (u) out += '<u>';
                        if (it) out += '<i>';
                        cb = b; cu = u; ci = it; cv = v;
                    }
                }
            }
            out += ch;
        }
        closeAll();
        return out.replace(/<(b|u|i|sub|sup)>(\s*)<\/\1>/g, '$2').replace(/[ ]{2,}/g, ' ');
    }
    function fmtParas(paras, o) {
        return paras.map(function (p) { return fmt(trimChars(p), o); }).filter(function (s) { return s.trim(); }).join('\n').trim();
    }

    /* ---- dấu [ ] (bỏ qua [I] [II] [III] [IV]) ---- */
    function scanBrackets(s) {
        var ev = [];
        for (var i = 0; i < s.length; i++) {
            var c = s.charAt(i);
            if (c === '[') {
                var m = ROMAN_RE.exec(s.substr(i, 6));
                if (m) { i += m[0].length - 1; continue; }
                ev.push({ i: i, t: '[' });
            } else if (c === ']') ev.push({ i: i, t: ']' });
        }
        return ev;
    }
    function segmentByBrackets(paras, report) {
        var depth = 0, segs = [], cur = null;
        paras.forEach(function (p) {
            var s = plain(p), ev = scanBrackets(s), rm = {}, d0 = depth, opened = false;
            ev.forEach(function (e) {
                if (e.t === '[') { if (depth === 0) { rm[e.i] = 1; opened = true; } depth++; }
                else if (depth > 0) { depth--; if (depth === 0) rm[e.i] = 1; }
            });
            var q = p;
            if (Object.keys(rm).length) q = p.filter(function (c, i) { return !rm[i]; });
            var belongs = d0 > 0 || opened;
            if (belongs) {
                if (!cur || !cur.group || (opened && d0 === 0)) { cur = { group: true, paras: [] }; segs.push(cur); }
            } else if (!cur || cur.group) { cur = { group: false, paras: [] }; segs.push(cur); }
            if (!WS_RE.test(plain(q))) cur.paras.push(q);
            if (belongs && depth === 0) cur = null;
        });
        if (depth > 0) report.warnings.push('⚠ Có dấu "[" mở nhóm nhưng chưa có dấu "]" đóng nhóm — hãy kiểm tra cuối nhóm trong file Word.');
        return segs;
    }

    /* ---- tìm A. B. C. D. ---- */
    function findOptionChain(s) {
        var re = /(^|[\s\u00A0])([A-D])\s*[\.\)]\s*/g, m, cand = [];
        while ((m = re.exec(s))) {
            cand.push({ L: m[2], start: m.index + m[1].length, end: m.index + m[0].length });
            if (m[0].length === 0) re.lastIndex++;
        }
        for (var a = cand.length - 1; a >= 0; a--) {
            if (cand[a].L !== 'A') continue;
            var chain = [cand[a]], need = ['B', 'C', 'D'], pos = a, ok = true;
            for (var n = 0; n < 3 && ok; n++) {
                var f = -1;
                for (var k = pos + 1; k < cand.length; k++) if (cand[k].L === need[n] && cand[k].start >= chain[chain.length - 1].end) { f = k; break; }
                if (f < 0) ok = false; else { chain.push(cand[f]); pos = f; }
            }
            if (ok) return chain;
        }
        return null;
    }
    function underRatio(chars) {
        var n = 0, u = 0;
        for (var i = 0; i < chars.length; i++) { if (isWs(chars[i])) continue; n++; if (chars[i].u) u++; }
        return n ? u / n : 0;
    }

    function snip(s, n) { s = String(s || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; }

    function parseQuestion(block, g, report, out) {
        var m0 = Q_START.exec(plain(block[0])), num = m0 ? parseInt(m0[1], 10) : 0;
        var endIdx = block.findIndex(function (p, i) { return i > 0 && END_RE.test(plain(p)); });
        if (endIdx > 0) block = block.slice(0, endIdx);
        var ansIdx = -1;
        for (var i = 0; i < block.length; i++) if (ANS_RE.test(plain(block[i]))) { ansIdx = i; break; }
        var bodyParas = ansIdx < 0 ? block.slice() : block.slice(0, ansIdx);
        var solParas = ansIdx < 0 ? [] : block.slice(ansIdx);

        // bỏ nhãn "Question n."
        bodyParas[0] = bodyParas[0].slice(m0 ? m0[0].length : 0);
        var body = [];
        bodyParas.forEach(function (p, idx) {
            if (WS_RE.test(plain(p))) return;
            if (body.length) body.push(nl());
            for (var k = 0; k < p.length; k++) body.push(p[k]);
        });
        var s = plain(body);
        var chain = findOptionChain(s);
        if (!chain) { report.skipped.push('Question ' + num + ': không tìm thấy đủ 4 đáp án A. B. C. D. — đã bỏ qua.'); return; }

        var stem = trimChars(body.slice(0, chain[0].start));
        var opts = [], ratios = [];
        for (var k = 0; k < 4; k++) {
            var to = k < 3 ? chain[k + 1].start : body.length;
            var txt = trimChars(body.slice(chain[k].end, to));
            opts.push({ text: fmt(txt, { keepB: false, keepU: false }) });
            ratios.push(underRatio(body.slice(chain[k].start, to)));
        }

        // lời giải = nội dung sau "Answer:"
        var solChars = [];
        if (solParas.length) {
            solParas[0] = solParas[0].slice(ANS_RE.exec(plain(solParas[0]))[0].length);
            solParas.forEach(function (p) { if (!WS_RE.test(plain(p))) { if (solChars.length) solChars.push(nl()); for (var k = 0; k < p.length; k++) solChars.push(p[k]); } });
        }
        var solution = fmtParas(solParas, { keepB: false, keepU: false });

        // đáp án đúng: gạch chân; dự phòng "Chọn X" trong phần Answer
        var best = -1, bestR = 0, cntU = 0;
        ratios.forEach(function (r, k) { if (r > 0) cntU++; if (r > bestR) { bestR = r; best = k; } });
        var fromAns = -1, am = /(?:chọn|đáp\s*án(?:\s*đúng)?(?:\s*là)?)\s*[:\-]?\s*([A-D])(?![A-Za-zÀ-ỹ0-9])/i.exec(plain(solChars));
        if (am) fromAns = 'ABCD'.indexOf(am[1].toUpperCase());
        var ci = best;
        if (best < 0 && fromAns >= 0) { ci = fromAns; report.warnings.push('Question ' + num + ': không thấy đáp án gạch chân — lấy theo "Answer: Chọn ' + 'ABCD'[fromAns] + '".'); }
        else if (best >= 0 && fromAns >= 0 && best !== fromAns) report.warnings.push('Question ' + num + ': đáp án gạch chân (' + 'ABCD'[best] + ') khác "Chọn ' + 'ABCD'[fromAns] + '" ở phần Answer — app lấy theo GẠCH CHÂN, hãy kiểm tra lại.');
        if (cntU > 1) report.warnings.push('Question ' + num + ': có ' + cntU + ' đáp án bị gạch chân — app lấy đáp án gạch chân nhiều nhất (' + 'ABCD'[best] + ').');
        if (ci < 0) report.warnings.push('Question ' + num + ': chưa xác định được đáp án đúng (không có gạch chân) — hãy bấm chọn A/B/C/D.');
        if (!solution) report.warnings.push('Question ' + num + ': không có phần "Answer:" nên không có nút Instructions.');

        var q = {
            type: 'mc', text: fmt(stem, { keepB: true, keepU: true, keepI: true }), options: opts,
            correctIndex: ci >= 0 ? ci : 0, detectedByStyle: ci >= 0, solution: solution, enNum: num, en: true
        };
        if (g) { q.gid = g.gid; q.gm = g.gm; if (g.first) { q.ginfo = g.ginfo; g.first = false; } }
        out.push(q);
    }

    function parseSegment(seg, report, out, info) {
        var paras = seg.paras, qi = [];
        paras.forEach(function (p, i) { if (Q_START.test(plain(p))) qi.push(i); });
        if (!qi.length) {
            if (seg.group && paras.length) report.warnings.push('⚠ Nhóm "' + snip(plain(paras[0]), 60) + '" không có câu "Question n." nào — đã bỏ qua.');
            return;
        }
        var g = null;
        if (seg.group) {
            var pre = paras.slice(0, qi[0]);
            var directive = pre.length ? plain(pre[0]) : '';
            var keep = READ_RE.test(directive);
            g = { gid: 'g_' + Math.random().toString(36).slice(2, 8), gm: keep ? 'k' : 's', first: true, ginfo: fmtParas(pre, { keepB: true, keepU: true, keepI: true }) };
            if (!pre.length) report.warnings.push('⚠ Nhóm bắt đầu từ Question ' + (Q_START.exec(plain(paras[qi[0]]))[1]) + ' không có dòng dẫn/đoạn văn.');
            var before = out.length;
            for (var k = 0; k < qi.length; k++) parseQuestion(paras.slice(qi[k], k + 1 < qi.length ? qi[k + 1] : paras.length), g, report, out);
            var n = out.length - before;
            // nếu câu đầu nhóm bị bỏ qua, chuyển đề dẫn sang câu còn lại đầu tiên
            if (n > 0 && g.first) out[before].ginfo = g.ginfo;
            info.groups.push({ from: before + 1, to: out.length, keep: keep, n: n, head: snip(directive, 70) });
        } else {
            for (var k2 = 0; k2 < qi.length; k2++) parseQuestion(paras.slice(qi[k2], k2 + 1 < qi.length ? qi[k2 + 1] : paras.length), null, report, out);
        }
    }

    EN.parse = function (richLines) {
        var report = { skipped: [], warnings: [] };
        var src = (typeof resolveTableLines === 'function') ? resolveTableLines(richLines) : richLines;
        var paras = [];
        (src || []).forEach(function (line) {
            if (!line || line.isTable) return;
            var sub = [];
            for (var i = 0; i < line.length; i++) {
                var c = line[i];
                if (c && c.ch === '\n') { if (sub.length) paras.push(normalizeLine(sub)); sub = []; } else sub.push(c);
            }
            if (sub.length) paras.push(normalizeLine(sub));
        });
        paras = paras.filter(function (p) { return !WS_RE.test(plain(p)); });

        var segs = segmentByBrackets(paras, report), out = [], info = { groups: [] };
        segs.forEach(function (seg) { parseSegment(seg, report, out, info); });

        // kiểm tra số thứ tự câu trong file
        var prev = 0, gaps = [];
        out.forEach(function (q) { if (q.enNum && prev && q.enNum !== prev + 1) gaps.push(prev + '→' + q.enNum); if (q.enNum) prev = q.enNum; });
        if (gaps.length) report.warnings.push('Số thứ tự câu trong file không liên tục: ' + gaps.slice(0, 8).join(', ') + ' — kiểm tra xem có câu bị thiếu không.');

        if (out.length) {
            var withSol = out.filter(function (q) { return q.solution; }).length;
            var ok = out.filter(function (q) { return q.detectedByStyle; }).length;
            report.warnings.unshift('📘 English: nhận diện ' + out.length + ' câu • ' + ok + ' câu đã có đáp án đúng (gạch chân) • ' + withSol + ' câu có Instructions • ' + info.groups.length + ' nhóm [ ].');
            info.groups.forEach(function (g, i) {
                report.warnings.push('Nhóm ' + (i + 1) + ' (Question ' + g.from + (g.to > g.from ? '–' + g.to : '') + '): ' + (g.keep ? 'DẠNG 1 "Read the" → GIỮ số thứ tự câu, chỉ đảo A-B-C-D' : 'DẠNG 2 → đảo cả thứ tự câu và đáp án') + ' — ' + g.head);
            });
        }
        out.report = report;
        return out;
    };

    /* ---- mở khung nhập (dùng lại khung "Nhập từ File Word") ---- */
    var TXT = {
        title: 'Nhập Câu Hỏi Từ File Word ENGLISH',
        badge: 'Đáp án gạch chân • Nhóm [ ] • Answer: → Instructions',
        hint: 'Đáp án đúng GẠCH CHÂN • câu hỏi nhóm đặt trong [ ] (có "Read the" = giữ số câu) • hướng dẫn sau "Answer:"'
    };
    function setTexts(on) {
        var m = document.getElementById('word-import-modal'); if (!m) return;
        var h2 = m.querySelector('h2'), bd = h2 && h2.nextElementSibling;
        if (h2) { if (!h2.dataset.vi) h2.dataset.vi = h2.textContent; h2.textContent = on ? TXT.title : h2.dataset.vi; }
        if (bd) { if (!bd.dataset.vi) bd.dataset.vi = bd.textContent; bd.textContent = on ? TXT.badge : bd.dataset.vi; }
        var st = document.getElementById('word-buffer-status');
        if (st && on) st.textContent = TXT.hint;
    }
    EN.open = function () {
        if (typeof openWordImportModal !== 'function') return;
        openWordImportModal();
        EN.active = true;
        setTexts(true);
        var sel = document.getElementById('edit-subject');
        if (sel && sel.value !== 'Tiếng Anh') { try { sel.value = 'Tiếng Anh'; sel.dispatchEvent(new Event('change')); } catch (e) { } }
        var qa = document.getElementById('word-quick-answer-input'); if (qa) qa.value = '';
    };
    EN.off = function () { EN.active = false; setTexts(false); };
    // [CODE123] Mở khung nhập English từ mục TRỘN ĐỀ THI (không đụng tới bộ đề đang soạn)
    EN.openForMix = function () {
        if (typeof openWordImportModal !== 'function') return false;
        openWordImportModal();      // hàm này tự tắt chế độ English, nên bật lại ngay bên dưới
        EN.active = true;
        setTexts(true);
        var qa = document.getElementById('word-quick-answer-input'); if (qa) qa.value = '';
        return true;
    };
    // Sau khi bấm "Đưa vào bộ câu hỏi" ở chế độ English: bật sẵn xáo câu + xáo đáp án Phần I (giáo viên vẫn có thể bỏ chọn)
    function hookApply() {
        var orig = window.applyWordImportToEditor;
        if (typeof orig !== 'function' || orig.__en121) return;
        var wrapped = function () {
            var wasEn = EN.active, hadDraft = false;
            try { hadDraft = typeof wordImportDraft !== 'undefined' && wordImportDraft.length > 0; } catch (e) { }
            var r = orig.apply(this, arguments);
            if (wasEn && hadDraft) {
                ['edit-shq-mc', 'edit-sho-mc'].forEach(function (id) { var el = document.getElementById(id); if (el) el.checked = true; });
            }
            return r;
        };
        wrapped.__en121 = true;
        window.applyWordImportToEditor = wrapped;
    }
    hookApply();

    /* ---- chế độ hiển thị English ---- */
    EN.isQ = function (q) {
        if (q && q.gm) return true;
        try { return typeof currentSubject !== 'undefined' && currentSubject === 'Tiếng Anh'; } catch (e) { return false; }
    };
    EN.noPartHeader = function () {
        try {
            if (typeof currentSubject !== 'undefined' && currentSubject === 'Tiếng Anh') return true;
            if (typeof questionsData !== 'undefined' && questionsData.some(function (q) { return q.gm; })) return true;
            if (window.LV && Array.isArray(window.LV.qs) && window.LV.qs.some(function (q) { return q.gm; })) return true;
        } catch (e) { }
        return false;
    };
    EN.label = function (q) { return EN.isQ(q) ? 'Question' : 'Câu'; };
    // "from 1 to 6" trong dòng dẫn tự khớp số câu thực tế
    EN.fixRange = function (info, from, to) {
        return String(info || '').replace(/(\bfrom\s+(?:<[^>]+>)*)\d+((?:<[^>]+>)*\s+to\s+(?:<[^>]+>)*)\d+/i, '$1' + from + '$2' + to);
    };
    // Xáo câu: nhóm 'k' (Read the) cố định vị trí & thứ tự câu; nhóm 's' đảo câu trong chính các vị trí của nhóm; câu lẻ đảo tự do
    EN.shuffleList = function (arr, shuf) {
        var free = arr.filter(function (q) { return !q.gid; });
        var res = arr.slice();
        var fs = shuf(free), k = 0;
        for (var i = 0; i < res.length; i++) if (!res[i].gid) res[i] = fs[k++];
        var byG = {};
        arr.forEach(function (q, i) { if (q.gid && q.gm === 's') (byG[q.gid] = byG[q.gid] || []).push(i); });
        Object.keys(byG).forEach(function (gid) {
            var pos = byG[gid], mem = pos.map(function (i) { return arr[i]; });
            var info = ''; mem.forEach(function (q) { if (!info && q.ginfo) info = q.ginfo; });
            var sm = shuf(mem).map(function (q) { var c = {}; for (var key in q) c[key] = q[key]; delete c.ginfo; return c; });   // sao chép để không sửa dữ liệu gốc
            if (info) sm[0].ginfo = info;
            pos.forEach(function (p, j) { res[p] = sm[j]; });
        });
        return res;
    };
})();

