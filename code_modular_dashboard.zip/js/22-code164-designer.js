
/* [CODE164] "Design: <tên>" trên trang chủ và màn hình đăng nhập = tên GIÁO VIÊN ĐĂNG NHẬP LẦN ĐẦU TIÊN.
   - Chưa có giáo viên nào đăng nhập: hiển thị mặc định "Design: ThS Trần Thông".
   - Lần đăng nhập giáo viên đầu tiên: lưu tên (localStorage) và đẩy 1 lần lên Firebase s/meta/designer (chỉ vài chục byte) để máy khác / máy học sinh cùng thấy.
   - Tiết kiệm Firebase: đã đồng bộ xong thì KHÔNG đọc/ghi thêm; máy chưa có tên chỉ kiểm tra tối đa 6 giờ/lần. Tên đã lưu không bị đổi khi giáo viên sửa họ tên sau này. */
(function () {
    'use strict';
    var LS = 'matrix_designer_v1', LSC = 'matrix_designer_chk_v1', DEFAULT = 'ThS Trần Thông', PATH = 'meta/designer', GAP = 6 * 3600e3, busy = false;
    function ls(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
    function lss(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
    function clean(n) { return String(n == null ? '' : n).replace(/\s+/g, ' ').trim().slice(0, 80); }
    function rec() { var r = ls(LS); return r && r.n ? r : null; }
    function name() { var r = rec(); return r ? r.n : DEFAULT; }
    function line() { return 'Design: ' + name(); }
    function api() { return window.CloudSync && window.CloudSync.api ? window.CloudSync.api : null; }
    function connected() { try { var a = api(); return !!(a && a.effStu()); } catch (e) { return false; } }
    function paint() {
        try { var p = document.getElementById('login-design-line'); if (p) p.textContent = 'QUẢN LÝ ĐỀ THI - ' + line(); } catch (e) {}
        try { if (window.CODE83Home) window.CODE83Home.refresh(); } catch (e) {}
    }
    function setLocal(n, t, pushed) { lss(LS, { n: n, t: t || Date.now(), p: pushed ? 1 : 0 }); paint(); }
    function sync(canPush) {
        var a = api(), r = rec();
        if (!a || busy || !connected()) return;
        if (r && r.p) return;   // đã đồng bộ xong: không đọc / ghi thêm
        if (!canPush && !r) { var c = ls(LSC); if (c && Date.now() - c < GAP) return; }
        busy = true;
        a.req('GET', 's', PATH).then(function (remote) {
            if (remote && remote.n) { setLocal(clean(remote.n), remote.t, true); return; }   // máy chủ đã có tên: dùng tên đó cho mọi máy
            if (canPush && r) return a.req('PUT', 's', PATH + '?print=silent', { n: r.n, t: r.t }).then(function () { setLocal(r.n, r.t, true); });
            lss(LSC, Date.now());
        }).catch(function () { lss(LSC, Date.now() - GAP + 600e3); }).then(function () { busy = false; });
    }
    function claim(fullName) {   // gọi khi giáo viên đăng nhập; chỉ lưu nếu CHƯA có tên
        var n = clean(fullName); if (!n) return;
        if (!rec()) setLocal(n, Date.now(), false);
        sync(true);
    }
    function init() {
        paint();
        setTimeout(function () { sync(false); }, 3000);
        window.addEventListener('online', function () { sync(false); });
    }
    window.CODE164Designer = { claim: claim, line: line, name: name, sync: sync, paint: paint };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
