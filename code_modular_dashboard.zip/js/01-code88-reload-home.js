
/* [CODE88] Bấm nút TẢI LẠI TRANG (F5 / Ctrl+R / nút ⟳ của trình duyệt) => luôn trở về TRANG CHỦ.
   Chỉ khi mở link lần đầu (link đề ?id=..., #hs=..., ?hs=...) thì app mới mở đúng đề đó; khi tải lại, các tham số mở đề bị gỡ
   khỏi địa chỉ để không bị kéo ngược vào đề cũ. Giữ lại ?mode=hs & mã kết nối lớp (cl) để học sinh vẫn vào đúng chế độ/lớp. */
(function () {
    try {
        if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
        var nav = (performance.getEntriesByType && performance.getEntriesByType('navigation') || [])[0];
        var isReload = nav ? nav.type === 'reload' : (performance.navigation && performance.navigation.type === 1);
        if (!isReload) return;
        var u = new URL(location.href), changed = false;
        ['id', 'hs'].forEach(function (k) { if (u.searchParams.has(k)) { u.searchParams.delete(k); changed = true; } });
        if (/^#hs=/.test(u.hash)) { u.hash = ''; changed = true; }
        if (changed) history.replaceState(null, '', u.pathname + (u.search || '') + u.hash);
        window.__RELOAD_HOME__ = true;
    } catch (e) {}
})();
