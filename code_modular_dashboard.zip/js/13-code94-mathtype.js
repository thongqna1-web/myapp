
/* ============================================================
   [CODE94] Bộ tạo công thức MathType thật (đối tượng nhúng OLE "Equation.DSMT4")
   Phần A: LaTeX -> MathML (KaTeX) -> cây trung gian IR -> MTEF v5 -> tệp OLE2 (Compound File)
   ============================================================ */
(function (root) {
    'use strict';
    var MT = {};

    /* ---------- 1. MathML (KaTeX) -> IR ---------- */
    var tn = function (el) { return String((el && (el.localName || el.nodeName)) || '').toLowerCase(); };
    var kids = function (el) { return Array.prototype.filter.call(el.childNodes, function (n) { return n.nodeType === 1 && !/^annotation/.test(tn(n)); }); };
    var txt = function (el) { return el ? (el.textContent || '') : ''; };

    var GREEK_LC = /[\u03B1-\u03C9\u03D1\u03D5\u03D6\u03F0\u03F1\u03F5]/;
    var GREEK_UC = /[\u0391-\u03A9]/;
    var BB = { R: '\u211D', Z: '\u2124', N: '\u2115', Q: '\u211A', C: '\u2102', H: '\u210D', P: '\u2119' };
    var REL = '=\u2260<>\u2264\u2265\u2248\u2261\u2208\u2209\u220B\u2282\u2283\u2286\u2287\u2284\u2192\u2190\u2194\u21D2\u21D0\u21D4\u21CC\u2225\u22A5\u223C\u221D\u2243\u2245\u226A\u226B\u27F9\u27FA\u21A6\u2220\u2271\u2270';
    var BIN = '+\u2212\u00B1\u2213\u00D7\u00F7\u222A\u2229\u00B7\u22C5\u2227\u2228\u2216\u2218\u2219\u2295\u2297\u2217*';
    var BIGOP = '\u222B\u222C\u222D\u222E\u2211\u220F\u2210\u22C3\u22C2';
    var LIMFN = /^(lim|max|min|sup|inf|limsup|liminf|det|gcd|Pr)$/;

    function faceOf(c) {
        if (/[0-9]/.test(c)) return 'n';
        if (/[A-Za-z]/.test(c)) return 'v';
        if (GREEK_LC.test(c)) return 'lg';
        if (GREEK_UC.test(c)) return 'ug';
        if (c === ' ' || c === '\u00A0' || c === '\u2009' || c === '\u2002' || c === '\u2003') return 't';
        if (/[,.;:!?()\[\]'"%|\/\u00B0\u2032\u2033]/.test(c)) return 'n';
        if (/[\u00C0-\u1EF9]/.test(c) && !/[\u00D7\u00F7\u00B1\u00B7]/.test(c)) return 't';
        return 'sy';
    }
    var CH = function (c, f) { return { k: 'ch', s: c, f: f || faceOf(c) }; };
    var chars = function (s, f) { var o = []; Array.from(String(s)).forEach(function (c) { o.push(CH(c, f)); }); return o; };

    function isFenceMo(n) { return tn(n) === 'mo' && n.getAttribute('fence') === 'true'; }
    function unwrap(o) { while (o && /^(mstyle|mpadded|mrow)$/.test(tn(o)) && kids(o).length === 1) o = kids(o)[0]; return o; }
    function deep(o) { while (o && /^(mstyle|mpadded|mrow|mo|mi)$/.test(tn(o)) && kids(o).length === 1) o = kids(o)[0]; return o; }
    function listOf(nodes) { var out = []; nodes.forEach(function (n) { conv(n).forEach(function (x) { out.push(x); }); }); return out; }
    function seqOf(el) { return { k: 'seq', c: el ? conv(el) : [] }; }
    function seqOfNodes(nodes) { return { k: 'seq', c: listOf(nodes) }; }
    function wrapSeq(a) { return { k: 'seq', c: a }; }

    function tableOf(el, fenceL) {
        var rows = kids(el).filter(function (r) { return tn(r) === 'mtr'; });
        var grid = rows.map(function (r) { return kids(r).map(function (c) { return wrapSeq(listOf(kids(c).length ? [c] : [])); }); });
        var cols = grid.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
        var ca = el.getAttribute('columnalign') || '';
        if (cols <= 1) return { k: 'pile', rows: grid.map(function (r) { return r[0] || wrapSeq([]); }), al: 'c' };
        var asCases = fenceL === '{' || /^left/.test(ca) && cols === 2 && !fenceL;
        var aligned = cols === 2 && /^right/.test(ca);
        if (asCases || aligned) {   // gộp các cột thành 1 dòng
            return { k: 'pile', al: 'l', rows: grid.map(function (r) {
                var c = [];
                r.forEach(function (cell, i) { if (i) c.push({ k: 'sp', w: aligned ? 0 : 0.6 }); cell.c.forEach(function (x) { c.push(x); }); });
                return wrapSeq(c);
            }) };
        }
        grid.forEach(function (r) { while (r.length < cols) r.push(wrapSeq([])); });
        return { k: 'mat', rows: grid, cols: cols };
    }

    function accentKind(a) {
        if (/^[\u2192\u20D7\u27F6]$/.test(a)) return 'vec';
        if (/^[\u2190\u20D6]$/.test(a)) return 'lvec';
        if (/^[\u2194\u20E1]$/.test(a)) return 'dvec';
        if (/^[\u005E\u02C6\u0302]$/.test(a)) return 'hat';
        if (/^[~\u02DC\u0303]$/.test(a)) return 'tilde';
        if (/^[\u02D9\u0307\u22C5]$/.test(a)) return 'dot';
        if (/^[\u00A8\u0308]$/.test(a)) return 'ddot';
        if (/^[\u00AF\u203E\u2015\u2212\-_\u2012\u2013\u2014]$/.test(a)) return 'bar';
        if (/^[\u2322\u23DC\u0311]$/.test(a)) return 'arc';
        if (/^[\u02C7\u030C]$/.test(a)) return 'hat';
        return '';
    }
    var ARROWS = /^[\u2192\u2190\u2194\u21CC\u21C4\u21D2\u21D0\u21D4\u27F6\u27F5\u27F9\u21CB]$/;

    function arrowOf(el) {   // mover/munder có gốc là mũi tên và có chữ trên/dưới
        var t = tn(el), k = kids(el), base = deep(k[0]), top = null, bot = null, a = null;
        if (t === 'mover' && base && tn(base) === 'munder') {
            var kb = kids(base); a = deep(kb[0]);
            if (a && tn(a) === 'mo' && ARROWS.test(txt(a).trim())) return { k: 'arr', ch: txt(a).trim(), top: seqOf(k[1]), bot: seqOf(kb[1]) };
        }
        if (base && tn(base) === 'mo' && ARROWS.test(txt(base).trim())) {
            if (t === 'mover') return { k: 'arr', ch: txt(base).trim(), top: seqOf(k[1]), bot: null };
            if (t === 'munder') return { k: 'arr', ch: txt(base).trim(), top: null, bot: seqOf(k[1]) };
            if (t === 'munderover') return { k: 'arr', ch: txt(base).trim(), top: seqOf(k[2]), bot: seqOf(k[1]) };
        }
        return null;
    }

    function conv(el) {
        var t = tn(el), k, s;
        switch (t) {
            case 'math': case 'semantics': case 'mstyle': case 'mpadded': case 'mtd': case 'mtr': case 'merror': case 'menclose':
                return listOf(kids(el));
            case 'mphantom': case 'annotation': case 'annotation-xml': return [];
            case 'mrow': {
                k = kids(el);
                if (k.length >= 2 && isFenceMo(k[0]) && isFenceMo(k[k.length - 1])) return [mkFence(txt(k[0]).trim(), txt(k[k.length - 1]).trim(), k.slice(1, -1))];
                if (k.length >= 2 && isFenceMo(k[0]) && /^[{\[(|\u2016\u27E8]$/.test(txt(k[0]).trim())) return [mkFence(txt(k[0]).trim(), '', k.slice(1))];
                if (k.length >= 2 && isFenceMo(k[k.length - 1]) && /^[}\])|\u2016\u27E9]$/.test(txt(k[k.length - 1]).trim())) return [mkFence('', txt(k[k.length - 1]).trim(), k.slice(0, -1))];
                return listOf(k);
            }
            case 'mi': {
                if (kids(el).length) return listOf(kids(el));
                s = txt(el);
                var mv = el.getAttribute('mathvariant') || '';
                if (mv === 'double-struck' && BB[s]) return [CH(BB[s], 'sy')];
                if (s.length > 1 && !/^[\uD835]/.test(s)) return chars(s, 'fn');
                if (mv === 'normal' && /[A-Za-z]/.test(s)) return [CH(s, 'fn')];
                if (mv === 'bold' && /[A-Za-z]/.test(s)) return [CH(s, 'bv')];
                return chars(s);
            }
            case 'mn': return chars(txt(el).replace(/\s+/g, ''), 'n');
            case 'mo': {
                if (kids(el).length) return listOf(kids(el));
                s = txt(el).replace(/\s+/g, '');
                if (s.length > 1 && /^[A-Za-z]+$/.test(s)) return chars(s, 'fn');
                return chars(s);
            }
            case 'mtext': return chars(txt(el).replace(/\u00A0/g, ' '), 't');
            case 'mspace': return /^-/.test(el.getAttribute('width') || '') ? [] : [{ k: 'sp', w: 0.17 }];
            case 'mfrac': {
                k = kids(el);
                var lt = el.getAttribute('linethickness');
                var nb = lt !== null && /^0(\.0*)?(px|em|ex|pt)?$/.test(lt.trim());
                return [{ k: 'frac', n: seqOf(k[0]), d: seqOf(k[1] || k[0]), bar: !nb }];
            }
            case 'msqrt': return [{ k: 'rad', b: seqOfNodes(kids(el)), i: null }];
            case 'mroot': k = kids(el); return [{ k: 'rad', b: seqOf(k[0]), i: seqOf(k[1]) }];
            case 'msup': k = kids(el); return [mkScr(k[0], null, k[1])];
            case 'msub': k = kids(el); return [mkScr(k[0], k[1], null)];
            case 'msubsup': k = kids(el); return [mkScr(k[0], k[1], k[2])];
            case 'munder': case 'mover': case 'munderover': return mkOver(el);
            case 'mtable': return [tableOf(el, '')];
            default: return listOf(kids(el));
        }
    }

    function mkFence(l, r, nodes) {
        var inner;
        var ks = nodes.filter(function (n) { return true; });
        if (ks.length === 1 && tn(unwrap(ks[0])) === 'mtable') {
            var tb = tableOf(unwrap(ks[0]), l);
            inner = tb;
        } else inner = seqOfNodes(ks);
        return { k: 'fen', l: l, r: r, b: inner };
    }
    function mkScr(b, sub, sup) {
        var baseNodes = conv(b);
        var bs = txt(unwrap(b)).trim();
        // lim, max, min với chỉ số dưới -> template giới hạn
        if (sub && !sup && baseNodes.length && baseNodes.every(function (x) { return x.k === 'ch' && x.f === 'fn'; }) && LIMFN.test(baseNodes.map(function (x) { return x.s; }).join(''))) {
            return { k: 'lim', b: wrapSeq(baseNodes), lo: seqOf(sub) };
        }
        var isBig = tn(unwrap(b)) === 'mo' && bs.length === 1 && BIGOP.indexOf(bs) >= 0;
        if (isBig && baseNodes[0]) baseNodes[0].big = true;
        var base = baseNodes.length === 1 ? baseNodes[0] : wrapSeq(baseNodes);
        var node = { k: 'scr', b: base, sub: sub ? seqOf(sub) : null, sup: sup ? seqOf(sup) : null };
        return node;
    }
    function mkOver(el) {
        var t = tn(el), k = kids(el);
        var ar = arrowOf(el);
        if (ar) return [ar];
        var base = unwrap(k[0]);
        var bs = txt(base).trim();
        if (t === 'munderover' || ((t === 'munder' || t === 'mover') && base && tn(base) === 'mo' && bs.length === 1 && BIGOP.indexOf(bs) >= 0)) {
            var bn = conv(k[0]); if (bn[0]) bn[0].big = true;
            var sub = (t === 'munder' || t === 'munderover') ? seqOf(k[1]) : null;
            var sup = t === 'munderover' ? seqOf(k[2]) : (t === 'mover' ? seqOf(k[1]) : null);
            return [{ k: 'scr', b: bn.length === 1 ? bn[0] : wrapSeq(bn), sub: sub, sup: sup }];
        }
        if (t === 'munder') {
            var bn2 = conv(k[0]);
            if (bn2.length && bn2.every(function (x) { return x.k === 'ch' && x.f === 'fn'; }) && LIMFN.test(bn2.map(function (x) { return x.s; }).join(''))) return [{ k: 'lim', b: wrapSeq(bn2), lo: seqOf(k[1]) }];
            var u = unwrap(k[1]);
            if (u && tn(u) === 'mo' && accentKind(txt(u).trim()) === 'bar') return [{ k: 'und', b: seqOf(k[0]) }];
            return [{ k: 'lim', b: seqOf(k[0]), lo: seqOf(k[1]) }];
        }
        // mover: dấu trên đầu
        var o = unwrap(k[1]);
        var kind = (o && tn(o) === 'mo') ? accentKind(txt(o).trim()) : '';
        if (kind) {
            var inner = conv(k[0]);
            var single = inner.length === 1 && inner[0].k === 'ch';
            return [{ k: 'ovr', kind: kind, b: wrapSeq(inner), single: single }];
        }
        return [{ k: 'lim', b: seqOf(k[0]), up: seqOf(k[1]) }];
    }

    MT.latexToIR = function (latex) {
        var s = String(latex || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim();
        s = s.replace(/[\u211D\u2124\u2115\u211A\u2102]/g, function (ch) { var m = { '\u211D': 'R', '\u2124': 'Z', '\u2115': 'N', '\u211A': 'Q', '\u2102': 'C' }; return '\\mathbb{' + m[ch] + '}'; });
        s = s.replace(/(\d),(?=\d)/g, '$1{,}');
        var fallback = function () { return wrapSeq(chars(s, 't')); };
        if (!s) return wrapSeq([]);
        if (typeof katex === 'undefined') return fallback();
        try {
            var html = katex.renderToString(s, { throwOnError: false, strict: false, output: 'mathml' });
            var doc = new DOMParser().parseFromString(html, 'text/html');
            var math = doc.querySelector('math');
            if (!math) return fallback();
            var ir = wrapSeq(conv(math));
            return ir.c.length ? ir : fallback();
        } catch (e) { return fallback(); }
    };

    /* ---------- 2. IR -> MTEF v5 ---------- */
    var TF = { TEXT: 1, FUNCTION: 2, VARIABLE: 3, LCGREEK: 4, UCGREEK: 5, SYMBOL: 6, VECTOR: 7, NUMBER: 8, EXPAND: 22 };
    function Enc() { this.b = []; }
    Enc.prototype.w = function () { for (var i = 0; i < arguments.length; i++) this.b.push(arguments[i] & 0xFF); return this; };
    Enc.prototype.u16 = function (v) { this.b.push(v & 0xFF, (v >> 8) & 0xFF); return this; };
    Enc.prototype.str = function (s) { for (var i = 0; i < s.length; i++) this.b.push(s.charCodeAt(i) & 0xFF); this.b.push(0); return this; };

    var FACE_TF = { v: TF.VARIABLE, n: TF.NUMBER, t: TF.TEXT, fn: TF.FUNCTION, lg: TF.LCGREEK, ug: TF.UCGREEK, sy: TF.SYMBOL, bv: TF.VARIABLE };
    var FENCE_SEL = { '(': [1, '(', ')'], '[': [3, '[', ']'], '{': [2, '{', '}'], '|': [4, '|', '|'], '\u2016': [5, '\u2016', '\u2016'], '\u2225': [5, '\u2016', '\u2016'],
        '\u27E8': [0, '\u27E8', '\u27E9'], '\u2329': [0, '\u27E8', '\u27E9'], '\u230A': [6, '\u230A', '\u230B'], '\u2308': [7, '\u2308', '\u2309'], '<': [0, '\u27E8', '\u27E9'] };
    var CLOSE_OF = { ')': '(', ']': '[', '}': '{', '\u27E9': '\u27E8', '\u232A': '\u27E8', '\u230B': '\u230A', '\u2309': '\u2308', '>': '<', '\u2016': '\u2016', '|': '|', '\u2225': '\u2016' };
    var FENCE_CODE = { '(': 0x28, ')': 0x29, '[': 0x5B, ']': 0x5D, '{': 0x7B, '}': 0x7D, '|': 0x7C, '\u2016': 0x2016, '\u27E8': 0x2329, '\u27E9': 0x232A, '\u230A': 0x230A, '\u230B': 0x230B, '\u2308': 0x2308, '\u2309': 0x2309 };

    function fenceInfo(n) {   // trả về {sel, var} nếu là cặp ngoặc hợp lệ cho template, ngược lại null
        var l = n.l, r = n.r;
        if (!l && !r) return null;
        var key = l || CLOSE_OF[r];
        var def = FENCE_SEL[key];
        if (!def) return null;
        if (l && r && CLOSE_OF[r] !== key && !(l === r && (l === '|' || l === '\u2016'))) {
            if (!(def[2] === r || CLOSE_OF[r] === key)) return null;
        }
        if (l && r && def[2] !== r && !(CLOSE_OF[r] === key)) return null;
        return { sel: def[0], lc: def[1], rc: def[2], v: (l && r) ? 0 : (l ? 1 : 2), hasL: !!l, hasR: !!r };
    }

    function eChar(e, face, code, embs) {
        var tf = typeof face === 'number' ? face : FACE_TF[face];
        var ascii = !(MT.opts&&MT.opts.no8) && code < 0x80 && (tf === TF.VARIABLE || tf === TF.NUMBER || tf === TF.TEXT || tf === TF.FUNCTION || tf === TF.SYMBOL);
        var o = (ascii ? 0x04 : 0) | (embs && embs.length ? 0x01 : 0);
        e.w(2, o, tf + 128).u16(code);
        if (ascii) e.w(code);
        if (embs && embs.length) { embs.forEach(function (t) { e.w(6, 0, t); }); e.w(0); }
    }
    function eLine(e, fn, sizeTag) { e.w(1, 0); if (sizeTag) e.w(sizeTag); fn(); e.w(0); }
    function eNullLine(e) { e.w(1, 1); }
    function eTmpl(e, sel, vari, fn) { e.w(3, 0, sel, vari, 0); fn(); e.w(0); }

    function codeOf(n) {
        var c = n.s.codePointAt(0);
        return c > 0xFFFF ? 0x3F : c;
    }
    var EMB = { dot: 2, ddot: 3, hat: 9, tilde: 8, vec: 11, lvec: 12, dvec: 13, bar: 17 };

    function eNode(e, n, lvl) {
        var sz = lvl === 1 ? 11 : lvl >= 2 ? 12 : 0;
        switch (n.k) {
            case 'seq': n.c.forEach(function (x) { eNode(e, x, lvl); }); break;
            case 'ch': eChar(e, n.f === 'bv' ? TF.VARIABLE : n.f, codeOf(n)); break;
            case 'sp': eChar(e, TF.TEXT, 0x20); break;
            case 'frac':
                eTmpl(e, 11, 0, function () { eLine(e, function () { eNode(e, n.n, lvl); }); eLine(e, function () { eNode(e, n.d, lvl); }); });
                break;
            case 'rad':
                eTmpl(e, 10, n.i ? 1 : 0, function () {
                    eLine(e, function () { eNode(e, n.b, lvl); });
                    if (n.i) eLine(e, function () { eNode(e, n.i, lvl + 1); }, lvl + 1 === 1 ? 11 : 12);
                });
                break;
            case 'scr': {
                eNode(e, n.b, lvl);
                var nl = lvl + 1, tag = nl === 1 ? 11 : 12;
                if (n.sub && n.sup) eTmpl(e, 29, 0, function () { eLine(e, function () { eNode(e, n.sub, nl); }, tag); eLine(e, function () { eNode(e, n.sup, nl); }, tag); });
                else if (n.sub) eTmpl(e, 27, 0, function () { eLine(e, function () { eNode(e, n.sub, nl); }, tag); });
                else if (n.sup) eTmpl(e, 28, 0, function () { eLine(e, function () { eNode(e, n.sup, nl); }, tag); });
                break;
            }
            case 'lim':
                eTmpl(e, 23, 0, function () {
                    eLine(e, function () { eNode(e, n.b, lvl); });
                    if (n.lo) eLine(e, function () { eNode(e, n.lo, lvl + 1); }, lvl + 1 === 1 ? 11 : 12); else eNullLine(e);
                    if (n.up) eLine(e, function () { eNode(e, n.up, lvl + 1); }, lvl + 1 === 1 ? 11 : 12); else eNullLine(e);
                });
                break;
            case 'und': eTmpl(e, 12, 0, function () { eLine(e, function () { eNode(e, n.b, lvl); }); }); break;
            case 'ovr':
                if (n.single && n.b.c.length === 1 && EMB[n.kind] && n.b.c[0].k === 'ch') {
                    eChar(e, n.b.c[0].f === 'bv' ? TF.VARIABLE : n.b.c[0].f, codeOf(n.b.c[0]), [EMB[n.kind]]);
                } else if (n.kind === 'bar') eTmpl(e, 13, 0, function () { eLine(e, function () { eNode(e, n.b, lvl); }); });
                else if (n.kind === 'vec' || n.kind === 'lvec' || n.kind === 'dvec') eTmpl(e, 31, n.kind === 'vec' ? 0x0A : n.kind === 'lvec' ? 0x09 : 0x0B, function () { eLine(e, function () { eNode(e, n.b, lvl); }); });
                else if (n.kind === 'tilde') eTmpl(e, 32, 0, function () { eLine(e, function () { eNode(e, n.b, lvl); }); });
                else if (n.kind === 'hat') eTmpl(e, 33, 0, function () { eLine(e, function () { eNode(e, n.b, lvl); }); });
                else if (n.kind === 'arc') eTmpl(e, 34, 0, function () { eLine(e, function () { eNode(e, n.b, lvl); }); });
                else eNode(e, n.b, lvl);
                break;
            case 'arr': {
                var code = n.ch.codePointAt(0), v = 0x0020, dbl = false;
                if (/[\u21CC\u21CB]/.test(n.ch)) { v = 0x0030 | 0x0002; dbl = true; }
                else if (/[\u2194\u21D4\u27FA]/.test(n.ch)) v = 0x0030;
                else if (/[\u2190\u21D0\u27F5]/.test(n.ch)) v = 0x0010;
                if (n.top) v |= 0x0004; if (n.bot) v |= 0x0008;
                eTmpl(e, 14, v, function () {
                    var sl = lvl + 1, tg = sl === 1 ? 11 : 12;
                    if (n.top) eLine(e, function () { eNode(e, n.top, sl); }, tg);
                    if (n.bot) eLine(e, function () { eNode(e, n.bot, sl); }, tg);
                    if (dbl) { eChar(e, TF.EXPAND, 0x21C0); eChar(e, TF.EXPAND, 0x21BD); }
                    else eChar(e, TF.EXPAND, code === 0x27F6 ? 0x2192 : code);
                });
                break;
            }
            case 'fen': {
                var fi = fenceInfo(n);
                if (!fi) {   // cặp ngoặc lạ -> ký tự rời
                    if (n.l) eChar(e, TF.NUMBER, (FENCE_CODE[n.l] || n.l.codePointAt(0)));
                    eNode(e, n.b, lvl);
                    if (n.r) eChar(e, TF.NUMBER, (FENCE_CODE[n.r] || n.r.codePointAt(0)));
                    break;
                }
                eTmpl(e, fi.sel, fi.v, function () {
                    if (n.b.k === 'pile') ePile(e, n.b, lvl); else eLine(e, function () { eNode(e, n.b, lvl); });
                    if (fi.hasL) eChar(e, TF.EXPAND, FENCE_CODE[fi.lc]);
                    if (fi.hasR) eChar(e, TF.EXPAND, FENCE_CODE[fi.rc]);
                });
                break;
            }
            case 'pile': ePile(e, n, lvl, true); break;
            case 'mat': eMat(e, n, lvl); break;
        }
    }
    function ePile(e, n, lvl, wrapLine) {
        var body = function () {
            e.w(4, 0, n.al === 'l' ? 1 : n.al === 'r' ? 3 : 2, 0);
            n.rows.forEach(function (r) { eLine(e, function () { eNode(e, r, lvl); }); });
            e.w(0);
        };
        if (wrapLine) eLine(e, body); else body();
    }
    function eMat(e, n, lvl) {
        var nr = n.rows.length, nc = n.cols;
        e.w(5, 0, 0, 2, 0, nr, nc);
        var rp = Math.floor(((nr + 1) * 2 + 7) / 8), cp = Math.floor(((nc + 1) * 2 + 7) / 8);
        for (var i = 0; i < rp + cp; i++) e.w(0);
        n.rows.forEach(function (r) { r.forEach(function (c) { eLine(e, function () { eNode(e, c, lvl); }); }); });
        e.w(0);
    }
    function dimNibbles(list) {   // [{u:2,v:'12'}] -> nibble stream
        var nib = [];
        list.forEach(function (d) {
            nib.push(d.u);
            String(d.v).split('').forEach(function (c) { nib.push(c === '.' ? 10 : c === '-' ? 11 : +c); });
            nib.push(15);
        });
        if (nib.length % 2) nib.push(15);
        var out = [];
        for (var i = 0; i < nib.length; i += 2) out.push((nib[i] << 4) | nib[i + 1]);
        return out;
    }

    MT.irToMtef = function (ir) {
        var e = new Enc();
        e.w(5, 1, 0, 6, 9).str('DSMT4').w(MT.opts&&MT.opts.opt!==undefined?MT.opts.opt:1);                 // tiêu đề: MTEF v5, Windows, MathType 6.9, khóa DSMT4, công thức trong dòng
        // EQN_PREFS: cỡ chữ (12, 7, 5, 18, 12 pt), khoảng cách, kiểu chữ
        if (!(MT.opts&&MT.opts.noPrefs)) { e.w(18, 0);
        var sizes = [{ u: 2, v: '12' }, { u: 2, v: '7' }, { u: 2, v: '5' }, { u: 2, v: '18' }, { u: 2, v: '12' }];
        e.w(sizes.length); dimNibbles(sizes).forEach(function (b) { e.w(b); });
        var spaces = [{ u: 4, v: '150' }, { u: 4, v: '150' }, { u: 4, v: '100' }, { u: 4, v: '45' }, { u: 4, v: '25' }, { u: 4, v: '25' }, { u: 4, v: '100' }, { u: 4, v: '100' }];
        e.w(spaces.length); dimNibbles(spaces).forEach(function (b) { e.w(b); });
        e.w(0); }
        eLine(e, function () { eNode(e, ir, 0); });
        e.w(0);                                                // END công thức
        return new Uint8Array(e.b);
    };

    /* ---------- 3. Tệp OLE2 (Compound File) ---------- */
    function u32(a, off, v) { a[off] = v & 255; a[off + 1] = (v >>> 8) & 255; a[off + 2] = (v >>> 16) & 255; a[off + 3] = (v >>> 24) & 255; }
    function u16w(a, off, v) { a[off] = v & 255; a[off + 1] = (v >>> 8) & 255; }
    var ENDC = 0xFFFFFFFE, FREE = 0xFFFFFFFF, FATS = 0xFFFFFFFD, NOSTREAM = 0xFFFFFFFF;
    var CLSID_EQ = [0x02, 0xCE, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x46];   // {0002CE02-0000-0000-C000-000000000046}

    MT.buildCFB = function (streams, clsid) {
        var SS = 512, MS = 64, CUT = 4096;
        var small = [], large = [];
        streams.forEach(function (s) { (s.data.length < CUT ? small : large).push(s); });
        // mini stream
        var miniBytes = 0, miniFat = [];
        small.forEach(function (s) {
            var n = Math.max(1, Math.ceil(s.data.length / MS));
            s.miniStart = miniFat.length;
            for (var i = 0; i < n; i++) miniFat.push(i === n - 1 ? ENDC : miniFat.length + 1);
            miniBytes += n * MS;
        });
        var mini = new Uint8Array(miniBytes), mo = 0;
        small.forEach(function (s) { mini.set(s.data, mo); mo += Math.max(1, Math.ceil(s.data.length / MS)) * MS; });
        var nMiniFatSec = miniFat.length ? Math.ceil(miniFat.length * 4 / SS) : 0;
        var nMiniSec = miniBytes ? Math.ceil(miniBytes / SS) : 0;
        var entryCount = streams.length + 1;
        var nDirSec = Math.ceil(entryCount * 128 / SS);
        var largeSec = large.map(function (s) { return Math.ceil(s.data.length / SS); });
        var nLargeSec = largeSec.reduce(function (a, b) { return a + b; }, 0);
        var nFat = 1;
        for (;;) { var tot = nFat + nDirSec + nMiniFatSec + nMiniSec + nLargeSec; if (nFat * 128 >= tot) break; nFat++; }
        var total = nFat + nDirSec + nMiniFatSec + nMiniSec + nLargeSec;
        var fat = new Array(nFat * 128).fill(FREE);
        var sec = 0, i, firstFat = 0;
        for (i = 0; i < nFat; i++) fat[sec++] = FATS;
        var dirStart = sec; for (i = 0; i < nDirSec; i++) { fat[sec] = i === nDirSec - 1 ? ENDC : sec + 1; sec++; }
        var mfStart = nMiniFatSec ? sec : ENDC; for (i = 0; i < nMiniFatSec; i++) { fat[sec] = i === nMiniFatSec - 1 ? ENDC : sec + 1; sec++; }
        var msStart = nMiniSec ? sec : ENDC; for (i = 0; i < nMiniSec; i++) { fat[sec] = i === nMiniSec - 1 ? ENDC : sec + 1; sec++; }
        large.forEach(function (s, li) {
            s.start = sec;
            for (var j = 0; j < largeSec[li]; j++) { fat[sec] = j === largeSec[li] - 1 ? ENDC : sec + 1; sec++; }
        });
        var out = new Uint8Array((total + 1) * SS);
        // header
        var H = out; H.set([0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1], 0);
        u16w(H, 24, 0x003E); u16w(H, 26, 0x0003); u16w(H, 28, 0xFFFE); u16w(H, 30, 9); u16w(H, 32, 6);
        u32(H, 44, nFat); u32(H, 48, dirStart); u32(H, 56, CUT); u32(H, 60, mfStart); u32(H, 64, nMiniFatSec); u32(H, 68, ENDC); u32(H, 72, 0);
        for (i = 0; i < 109; i++) u32(H, 76 + i * 4, i < nFat ? i : FREE);
        // FAT
        for (i = 0; i < fat.length; i++) u32(out, SS + firstFat * SS + i * 4, fat[i]);
        var secOff = function (n) { return SS + n * SS; };
        // mini FAT
        for (i = 0; i < miniFat.length; i++) u32(out, secOff(mfStart) + i * 4, miniFat[i]);
        for (i = miniFat.length; i < nMiniFatSec * 128; i++) u32(out, secOff(mfStart) + i * 4, FREE);
        // mini stream
        if (nMiniSec) out.set(mini, secOff(msStart));
        large.forEach(function (s) { out.set(s.data, secOff(s.start)); });
        // directory (cây nhị phân theo thứ tự tên: độ dài, rồi chữ hoa)
        var cmp = function (a, b) { if (a.name.length !== b.name.length) return a.name.length - b.name.length; var x = a.name.toUpperCase(), y = b.name.toUpperCase(); return x < y ? -1 : x > y ? 1 : 0; };
        var sorted = streams.slice().sort(cmp);
        var ent = [{ name: 'Root Entry', type: 5, left: NOSTREAM, right: NOSTREAM, child: NOSTREAM, start: msStart, size: miniBytes, clsid: clsid }];
        sorted.forEach(function (s) { ent.push({ name: s.name, type: 2, left: NOSTREAM, right: NOSTREAM, child: NOSTREAM, start: s.data.length < CUT ? s.miniStart : s.start, size: s.data.length, clsid: null }); });
        var build = function (lo, hi) { if (lo > hi) return NOSTREAM; var mid = (lo + hi) >> 1; var me = ent[mid + 1]; me.left = build(lo, mid - 1); me.right = build(mid + 1, hi); return mid + 1; };
        ent[0].child = build(0, sorted.length - 1);
        ent.forEach(function (d, idx) {
            var o = secOff(dirStart) + idx * 128;
            for (var c = 0; c < d.name.length; c++) u16w(out, o + c * 2, d.name.charCodeAt(c));
            u16w(out, o + 64, (d.name.length + 1) * 2);
            out[o + 66] = d.type; out[o + 67] = 1;
            u32(out, o + 68, d.left); u32(out, o + 72, d.right); u32(out, o + 76, d.child);
            if (d.clsid) out.set(d.clsid, o + 80);
            u32(out, o + 116, d.start); u32(out, o + 120, d.size); u32(out, o + 124, 0);
        });
        for (var z = ent.length; z < nDirSec * 4; z++) { var o2 = secOff(dirStart) + z * 128; u32(out, o2 + 68, NOSTREAM); u32(out, o2 + 72, NOSTREAM); u32(out, o2 + 76, NOSTREAM); }
        return out;
    };

    function lenStr(s) { var b = []; var n = s.length + 1; b.push(n & 255, (n >> 8) & 255, 0, 0); for (var i = 0; i < s.length; i++) b.push(s.charCodeAt(i)); b.push(0); return b; }
    MT.buildOle = function (mtef) {
        var comp = [0x01, 0x00, 0xFE, 0xFF, 0x03, 0x0A, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF].concat(CLSID_EQ)
            .concat(lenStr('MathType 6.0 Equation')).concat([0, 0, 0, 0]).concat(lenStr('Equation.DSMT4')).concat([0xF4, 0x39, 0xB2, 0x71, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
        var ole = [0x01, 0x00, 0x00, 0x02, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        var hdr = new Uint8Array(28);
        u16w(hdr, 0, 28); u32(hdr, 2, 0x00020000); u16w(hdr, 6, 0xC19E); u32(hdr, 8, mtef.length);
        var eq = new Uint8Array(28 + mtef.length); eq.set(hdr, 0); eq.set(mtef, 28);
        return MT.buildCFB([
            { name: '\u0001CompObj', data: new Uint8Array(comp) },
            { name: '\u0001Ole', data: new Uint8Array(ole) },
            { name: 'Equation Native', data: eq }
        ], new Uint8Array(CLSID_EQ));
    };

    MT._tn = tn; MT._kids = kids;
    root.MT93 = MT;
})(typeof window !== 'undefined' ? window : globalThis);

/* ============================================================
   [CODE94] Phần B: dàn trang công thức (giống kiểu MathType: Times New Roman) và vẽ ảnh xem trước PNG
   ============================================================ */
(function (root) {
    'use strict';
    var MT = root.MT93;
    var FAM = '"Times New Roman","Liberation Serif","Nimbus Roman","Noto Serif","DejaVu Serif",serif';
    var AXIS = 0.25, REL = '=\u2260<>\u2264\u2265\u2248\u2261\u2208\u2209\u220B\u2282\u2283\u2286\u2287\u2284\u2192\u2190\u2194\u21D2\u21D0\u21D4\u21CC\u2225\u22A5\u223C\u221D\u2243\u2245\u226A\u226B\u27F9\u27FA\u2220',
        BIN = '+\u2212\u00B1\u2213\u00D7\u00F7\u222A\u2229\u22C5\u2227\u2228\u2216\u2218\u2295\u2297*\u00B7';
    var cvs = null, mctx = null, cache = {};
    function mc() { if (!cvs) { cvs = document.createElement('canvas'); cvs.width = 10; cvs.height = 10; mctx = cvs.getContext('2d'); } return mctx; }
    function fontOf(face, px) {
        var it = (face === 'v' || face === 'lg') ? 'italic ' : '', b = face === 'bv' ? 'bold italic ' : '';
        return (b || it) + px + 'px ' + FAM;
    }
    function glyph(s, face, sc, big) {   // đo ký tự: đơn vị em của cỡ chữ gốc
        var key = s + '|' + face + '|' + (big || 1), m = cache[key];
        if (!m) {
            var c = mc(); c.font = fontOf(face, 100 * (big || 1));
            var r = c.measureText(s);
            m = cache[key] = { w: r.width / 100, a: (r.actualBoundingBoxAscent || 66 * (big || 1)) / 100, d: Math.max(0, (r.actualBoundingBoxDescent || 0) / 100) };
        }
        return { w: m.w * sc, a: m.a * sc, d: m.d * sc };
    }
    function box(w, a, d, draw) { return { w: w, a: a, d: d, draw: draw || function () { } }; }

    function layChar(n, sc) {
        var big = n.big ? (/[\u222B\u222C\u222D\u222E]/.test(n.s) ? 1.9 : 1.5) : 1;
        var g = glyph(n.s, n.f, sc, big), off = 0;
        var a = Math.max(g.a, 0.5 * sc * (big > 1 ? 1 : 1)), d = g.d;
        if (big > 1) { off = AXIS * sc - (g.a - g.d) / 2; a = g.a + off; d = Math.max(0, g.d - off); }
        var isSpace = n.s === ' ' || n.s === '\u00A0';
        return box(isSpace ? 0.25 * sc : g.w, a, d, function (ctx, u, x, y) {
            ctx.font = fontOf(n.f, sc * big * u); ctx.fillText(n.s, x, y - off * u);
        });
    }
    function isRel(n) { return n && n.k === 'ch' && REL.indexOf(n.s) >= 0; }
    function isBin(n) { return n && n.k === 'ch' && BIN.indexOf(n.s) >= 0 && n.f === 'sy'; }
    function laySeq(list, sc) {
        var parts = [], x = 0, a = 0, d = 0, prev = null;
        for (var i = 0; i < list.length; i++) {
            var n = list[i], sp = 0, ba = null;
            var nxt = list[i + 1];
            if (n.k === 'sp') { var b0 = box(n.w * sc, 0, 0); parts.push({ b: b0, x: x }); x += b0.w; prev = n; continue; }
            if (isRel(n) && i > 0 && nxt) sp = 0.28 * sc;
            else if (isBin(n) && i > 0 && nxt && !(isRel(prev) || isBin(prev) || (prev && prev.k === 'ch' && /[(\[{,;]/.test(prev.s)) )) sp = 0.22 * sc;
            // chuỗi hàm (sin, cos...) cách một chút với thành phần sau
            var afterFn = prev && prev.k === 'ch' && prev.f === 'fn' && !(n.k === 'ch' && n.f === 'fn') && n.k !== 'scr';
            if (afterFn && !(n.k === 'ch' && /[,.;:)\]]/.test(n.s))) x += 0.17 * sc;
            if (prev && prev.k === 'ch' && /[,;]/.test(prev.s) && prev.f === 'n' && n.k !== 'sp') x += 0.14 * sc;
            x += sp;
            var b = layNode(n, sc);
            parts.push({ b: b, x: x }); x += b.w + sp;
            a = Math.max(a, b.a); d = Math.max(d, b.d);
            prev = n;
        }
        return box(x, a, d, function (ctx, u, X, Y) { parts.forEach(function (p) { p.b.draw(ctx, u, X + p.x * u, Y); }); });
    }
    function layNode(n, sc) {
        switch (n.k) {
            case 'seq': return laySeq(n.c, sc);
            case 'ch': return layChar(n, sc);
            case 'sp': return box(n.w * sc, 0, 0);
            case 'frac': return layFrac(n, sc);
            case 'rad': return layRad(n, sc);
            case 'scr': return layScr(n, sc);
            case 'lim': return layLim(n, sc);
            case 'und': { var bu = layNode(n.b, sc), gu = 0.1 * sc; return box(bu.w, bu.a, bu.d + gu + 0.04 * sc, function (c, u, x, y) { bu.draw(c, u, x, y); ln(c, u, x, y + (bu.d + gu) * u, x + bu.w * u, y + (bu.d + gu) * u, sc * 0.05); }); }
            case 'ovr': return layOvr(n, sc);
            case 'arr': return layArr(n, sc);
            case 'fen': return layFen(n, sc);
            case 'pile': return layPile(n, sc);
            case 'mat': return layMat(n, sc);
        }
        return box(0, 0, 0);
    }
    function ln(ctx, u, x1, y1, x2, y2, wid) { ctx.lineWidth = Math.max(1, wid * u); ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); }

    function layFrac(n, sc) {
        var nu = layNode(n.n, sc), de = layNode(n.d, sc);
        var w = Math.max(nu.w, de.w) + 0.2 * sc, th = 0.05 * sc, gap = 0.12 * sc, ax = AXIS * sc;
        var yn = ax + th / 2 + gap + nu.d, yd = ax - th / 2 - gap - de.a;
        return box(w, yn + nu.a, de.d - yd, function (ctx, u, x, y) {
            nu.draw(ctx, u, x + (w - nu.w) / 2 * u, y - yn * u);
            de.draw(ctx, u, x + (w - de.w) / 2 * u, y - yd * u);
            if (n.bar) ln(ctx, u, x + 0.04 * sc * u, y - ax * u, x + (w - 0.04 * sc) * u, y - ax * u, th);
        });
    }
    function layRad(n, sc) {
        var b = layNode(n.b, sc), ix = n.i ? layNode(n.i, sc * 0.6) : null;
        var W = 0.75 * sc, top = b.a + 0.14 * sc, bot = b.d + 0.04 * sc, extra = ix ? Math.max(0, ix.w - 0.4 * W) : 0;
        var a = top + 0.03 * sc, d = bot;
        return box(extra + W + b.w + 0.1 * sc, a, d, function (ctx, u, x, y) {
            var x0 = x + extra * u, th = 0.05 * sc;
            ctx.lineWidth = Math.max(1, th * u); ctx.lineJoin = 'miter'; ctx.beginPath();
            var ym = -(bot - 0.45 * (top + bot));
            ctx.moveTo(x0, y - ym * u); ctx.lineTo(x0 + 0.14 * W * u, y - (ym + 0.05 * sc) * u);
            ctx.lineTo(x0 + 0.45 * W * u, y + bot * u); ctx.lineTo(x0 + W * u, y - top * u); ctx.lineTo(x0 + (W + b.w + 0.1 * sc) * u, y - top * u); ctx.stroke();
            b.draw(ctx, u, x0 + W * u, y);
            if (ix) ix.draw(ctx, u, x, y - (top * 0.55) * u);
        });
    }
    function layScr(n, sc) {
        var B = layNode(n.b, sc), s2 = Math.max(0.5, sc * 0.7);
        var S = n.sup ? layNode(n.sup, s2) : null, U = n.sub ? layNode(n.sub, s2) : null;
        var big = n.b.k === 'ch' && n.b.big;
        var supY = 0, subY = 0;
        if (S) supY = big ? B.a - S.a * 0.55 : Math.max(0.4 * sc, B.a * 0.8 - 0.1 * sc) + 0 * S.d;
        if (S && !big) supY = Math.max(supY, S.d + 0.15 * sc);
        if (U) subY = big ? B.d + U.a * 0.5 : Math.max(0.2 * sc, B.d - 0.1 * sc);
        if (S && U && (supY - S.d) - (-subY + U.a) < 0.08 * sc) { subY = U.a + supY - S.d - 0.08 * sc; }
        var w = B.w + Math.max(S ? S.w : 0, U ? U.w : 0) + 0.02 * sc;
        var a = Math.max(B.a, S ? supY + S.a : 0), d = Math.max(B.d, U ? subY + U.d : 0);
        return box(w, a, d, function (ctx, u, x, y) {
            B.draw(ctx, u, x, y);
            var xs = x + (B.w + 0.02 * sc) * u;
            if (S) S.draw(ctx, u, xs, y - supY * u);
            if (U) U.draw(ctx, u, xs, y + subY * u);
        });
    }
    function layLim(n, sc) {
        var B = layNode(n.b, sc), s2 = sc * 0.7;
        var L = n.lo ? layNode(n.lo, s2) : null, T = n.up ? layNode(n.up, s2) : null;
        var w = Math.max(B.w, L ? L.w : 0, T ? T.w : 0), g = 0.08 * sc;
        var a = B.a + (T ? g + T.a + T.d : 0), d = B.d + (L ? g + L.a + L.d : 0);
        return box(w, a, d, function (ctx, u, x, y) {
            B.draw(ctx, u, x + (w - B.w) / 2 * u, y);
            if (L) L.draw(ctx, u, x + (w - L.w) / 2 * u, y + (B.d + g + L.a) * u);
            if (T) T.draw(ctx, u, x + (w - T.w) / 2 * u, y - (B.a + g + T.d) * u);
        });
    }
    function layOvr(n, sc) {
        var B = layNode(n.b, sc), kind = n.kind, h = 0.16 * sc, w = B.w;
        var base = Math.max(B.a, 0.66 * sc) + 0.05 * sc;
        if (kind === 'vec' && n.single) base = Math.max(B.a, 0.66 * sc) + 0.03 * sc;
        return box(w, base + h, B.d, function (ctx, u, x, y) {
            B.draw(ctx, u, x, y);
            var yy = y - (base + h * 0.4) * u, x0 = x + 0.05 * sc * u, x1 = x + (w - 0.02 * sc) * u;
            ctx.lineWidth = Math.max(1, 0.045 * sc * u); ctx.lineJoin = 'miter';
            if (kind === 'bar') { ln(ctx, u, x, y - (base + 0.05 * sc) * u, x + w * u, y - (base + 0.05 * sc) * u, 0.045 * sc); return; }
            if (kind === 'vec' || kind === 'lvec' || kind === 'dvec') {
                ctx.beginPath(); ctx.moveTo(x0, yy); ctx.lineTo(x1, yy); ctx.stroke();
                var hs = 0.09 * sc * u;
                if (kind !== 'lvec') { ctx.beginPath(); ctx.moveTo(x1 - hs, yy - hs * 0.75); ctx.lineTo(x1, yy); ctx.lineTo(x1 - hs, yy + hs * 0.75); ctx.stroke(); }
                if (kind !== 'vec') { ctx.beginPath(); ctx.moveTo(x0 + hs, yy - hs * 0.75); ctx.lineTo(x0, yy); ctx.lineTo(x0 + hs, yy + hs * 0.75); ctx.stroke(); }
            } else if (kind === 'hat') {
                var cx = x + w / 2 * u, hh = 0.1 * sc * u; ctx.beginPath(); ctx.moveTo(cx - hh * 1.2, yy + hh * 0.6); ctx.lineTo(cx, yy - hh * 0.6); ctx.lineTo(cx + hh * 1.2, yy + hh * 0.6); ctx.stroke();
            } else if (kind === 'tilde') {
                var cx2 = x + w / 2 * u, tw = Math.min(w * u / 2, 0.25 * sc * u), q = 0.045 * sc * u; ctx.beginPath(); ctx.moveTo(cx2 - tw, yy + q); ctx.bezierCurveTo(cx2 - tw / 2, yy - 2 * q, cx2 - tw / 4, yy - 2 * q, cx2, yy); ctx.bezierCurveTo(cx2 + tw / 4, yy + 2 * q, cx2 + tw / 2, yy + 2 * q, cx2 + tw, yy - q); ctx.stroke();
            } else if (kind === 'dot' || kind === 'ddot') {
                var cx3 = x + w / 2 * u, r = 0.03 * sc * u; var xs = kind === 'dot' ? [cx3] : [cx3 - 0.07 * sc * u, cx3 + 0.07 * sc * u];
                xs.forEach(function (px) { ctx.beginPath(); ctx.arc(px, yy, r * 1.3, 0, 7); ctx.fill(); });
            } else if (kind === 'arc') {
                ctx.beginPath(); ctx.moveTo(x + 0.03 * sc * u, yy + 0.05 * sc * u); ctx.quadraticCurveTo(x + w / 2 * u, yy - 0.12 * sc * u, x + (w - 0.03 * sc) * u, yy + 0.05 * sc * u); ctx.stroke();
            }
        });
    }
    function layArr(n, sc) {
        var T = n.top ? layNode(n.top, sc * 0.7) : null, L = n.bot ? layNode(n.bot, sc * 0.7) : null;
        var len = Math.max(0.9 * sc, (T ? T.w : 0) + 0.3 * sc, (L ? L.w : 0) + 0.3 * sc), g = 0.1 * sc, ax = AXIS * sc;
        var a = ax + 0.1 * sc + (T ? g + T.a + T.d : 0), d = Math.max(0, (L ? L.a + L.d + g - ax + 0.05 * sc : 0));
        var ch = n.ch;
        return box(len + 0.2 * sc, a, d, function (ctx, u, x, y) {
            var x0 = x + 0.1 * sc * u, x1 = x + (len + 0.1 * sc) * u, yy = y - ax * u, hs = 0.09 * sc * u;
            ctx.lineWidth = Math.max(1, 0.05 * sc * u); ctx.lineJoin = 'miter';
            var head = function (xx, y0, dir, half) {
                ctx.beginPath(); ctx.moveTo(xx - dir * hs, y0 + (half === 'u' ? 0 : -hs * 0.75)); ctx.lineTo(xx, y0);
                if (half !== 'd' && half !== 'u') ctx.lineTo(xx - dir * hs, y0 + hs * 0.75); ctx.stroke();
            };
            if (/[\u21CC\u21CB\u21C4]/.test(ch)) {
                var y1 = yy - 0.05 * sc * u, y2 = yy + 0.05 * sc * u;
                ln(ctx, u, x0, y1, x1, y1, 0.05 * sc); ln(ctx, u, x0, y2, x1, y2, 0.05 * sc);
                ctx.beginPath(); ctx.moveTo(x1 - hs, y1 - hs * 0.8); ctx.lineTo(x1, y1); ctx.stroke();
                ctx.beginPath(); ctx.moveTo(x0 + hs, y2 + hs * 0.8); ctx.lineTo(x0, y2); ctx.stroke();
            } else {
                var dbl = /[\u21D2\u21D0\u21D4\u27F9]/.test(ch);
                var L1 = /[\u2190\u21D0\u2194\u21D4\u27F5]/.test(ch), R1 = !/[\u2190\u21D0\u27F5]/.test(ch);
                if (dbl) { ln(ctx, u, x0, yy - 0.04 * sc * u, x1, yy - 0.04 * sc * u, 0.045 * sc); ln(ctx, u, x0, yy + 0.04 * sc * u, x1, yy + 0.04 * sc * u, 0.045 * sc); }
                else ln(ctx, u, x0, yy, x1, yy, 0.05 * sc);
                if (R1) head(x1, yy, 1); if (L1) head(x0, yy, -1);
            }
            if (T) T.draw(ctx, u, x + (len + 0.2 * sc - T.w) / 2 * u, y - (ax + 0.1 * sc + g + T.d) * u + 0);
            if (L) L.draw(ctx, u, x + (len + 0.2 * sc - L.w) / 2 * u, y + (L.a + g - ax + 0.02 * sc) * u);
        });
    }
    function delimW(c, sc) { return ({ '(': 0.33, ')': 0.33, '[': 0.3, ']': 0.3, '{': 0.42, '}': 0.42, '|': 0.16, '\u2016': 0.26, '\u27E8': 0.3, '\u27E9': 0.3, '\u230A': 0.3, '\u230B': 0.3, '\u2308': 0.3, '\u2309': 0.3, '\u2225': 0.26, '<': 0.3, '>': 0.3 }[c] || 0.3) * sc; }
    function drawDelim(ctx, u, c, x, y, top, bot, sc) {   // top/bot: em, so với đường cơ sở (top > 0)
        var w = delimW(c, sc) * u, yt = y - top * u, yb = y + bot * u, xl = x + 0.06 * u * sc, xr = x + w - 0.06 * u * sc, ym = (yt + yb) / 2, q = Math.min(0.14 * sc * u, (yb - yt) / 6);
        ctx.lineWidth = Math.max(1, 0.05 * sc * u); ctx.lineJoin = 'miter'; ctx.beginPath();
        switch (c) {
            case '(': ctx.moveTo(xr, yt); ctx.quadraticCurveTo(xl - (xr - xl) * 0.3, ym, xr, yb); break;
            case ')': ctx.moveTo(xl, yt); ctx.quadraticCurveTo(xr + (xr - xl) * 0.3, ym, xl, yb); break;
            case '[': ctx.moveTo(xr, yt); ctx.lineTo(xl, yt); ctx.lineTo(xl, yb); ctx.lineTo(xr, yb); break;
            case ']': ctx.moveTo(xl, yt); ctx.lineTo(xr, yt); ctx.lineTo(xr, yb); ctx.lineTo(xl, yb); break;
            case '{': { var xm = (xl + xr) / 2 + 0.03 * sc * u; ctx.moveTo(xr, yt); ctx.quadraticCurveTo(xm, yt, xm, yt + q); ctx.lineTo(xm, ym - q); ctx.quadraticCurveTo(xm, ym, xl, ym); ctx.quadraticCurveTo(xm, ym, xm, ym + q); ctx.lineTo(xm, yb - q); ctx.quadraticCurveTo(xm, yb, xr, yb); break; }
            case '}': { var xm2 = (xl + xr) / 2 - 0.03 * sc * u; ctx.moveTo(xl, yt); ctx.quadraticCurveTo(xm2, yt, xm2, yt + q); ctx.lineTo(xm2, ym - q); ctx.quadraticCurveTo(xm2, ym, xr, ym); ctx.quadraticCurveTo(xm2, ym, xm2, ym + q); ctx.lineTo(xm2, yb - q); ctx.quadraticCurveTo(xm2, yb, xl, yb); break; }
            case '|': ctx.moveTo((xl + xr) / 2, yt); ctx.lineTo((xl + xr) / 2, yb); break;
            case '\u2016': case '\u2225': ctx.moveTo(xl + (xr - xl) * 0.25, yt); ctx.lineTo(xl + (xr - xl) * 0.25, yb); ctx.moveTo(xl + (xr - xl) * 0.75, yt); ctx.lineTo(xl + (xr - xl) * 0.75, yb); break;
            case '\u27E8': case '<': ctx.moveTo(xr, yt); ctx.lineTo(xl, ym); ctx.lineTo(xr, yb); break;
            case '\u27E9': case '>': ctx.moveTo(xl, yt); ctx.lineTo(xr, ym); ctx.lineTo(xl, yb); break;
            case '\u230A': ctx.moveTo(xl, yt); ctx.lineTo(xl, yb); ctx.lineTo(xr, yb); break;
            case '\u230B': ctx.moveTo(xr, yt); ctx.lineTo(xr, yb); ctx.lineTo(xl, yb); break;
            case '\u2308': ctx.moveTo(xr, yt); ctx.lineTo(xl, yt); ctx.lineTo(xl, yb); break;
            case '\u2309': ctx.moveTo(xl, yt); ctx.lineTo(xr, yt); ctx.lineTo(xr, yb); break;
        }
        ctx.stroke();
    }
    function layFen(n, sc) {
        var b = layNode(n.b, sc);
        var ax = AXIS * sc, half = Math.max(b.a - ax, b.d + ax, 0.45 * sc) + 0.06 * sc, top = ax + half, bot = half - ax;
        var wl = n.l ? delimW(n.l, sc) : 0, wr = n.r ? delimW(n.r, sc) : 0;
        return box(wl + b.w + wr, top, bot, function (ctx, u, x, y) {
            if (n.l) drawDelim(ctx, u, n.l, x, y, top, bot, sc);
            b.draw(ctx, u, x + wl * u, y);
            if (n.r) drawDelim(ctx, u, n.r, x + (wl + b.w) * u, y, top, bot, sc);
        });
    }
    function layPile(n, sc) {
        var rows = n.rows.map(function (r) { return layNode(r, sc); });
        var w = rows.reduce(function (m, r) { return Math.max(m, r.w); }, 0), ys = [], y = 0, gap = 0.3 * sc;
        rows.forEach(function (r, i) { if (i === 0) y = 0; else y += rows[i - 1].d + gap + r.a; ys.push(y); });
        var h = ys[ys.length - 1] || 0, shift = h / 2 - AXIS * sc * 0;   // căn giữa quanh trục
        var a = rows[0].a + shift, d = rows[rows.length - 1].d + h - shift;
        return box(w, a, d, function (ctx, u, x, yb) {
            rows.forEach(function (r, i) {
                var dx = n.al === 'l' ? 0 : n.al === 'r' ? (w - r.w) : (w - r.w) / 2;
                r.draw(ctx, u, x + dx * u, yb + (ys[i] - shift) * u);
            });
        });
    }
    function layMat(n, sc) {
        var cells = n.rows.map(function (r) { return r.map(function (c) { return layNode(c, sc); }); });
        var cw = [], i, j;
        for (j = 0; j < n.cols; j++) cw[j] = cells.reduce(function (m, r) { return Math.max(m, r[j].w); }, 0);
        var gapX = 0.8 * sc, gapY = 0.3 * sc, ys = [], y = 0, ra = [], rd = [];
        cells.forEach(function (r, ri) { ra[ri] = Math.max.apply(null, r.map(function (c) { return c.a; })); rd[ri] = Math.max.apply(null, r.map(function (c) { return c.d; })); if (ri === 0) y = 0; else y += rd[ri - 1] + gapY + ra[ri]; ys.push(y); });
        var h = ys[ys.length - 1] || 0, shift = h / 2;
        var w = cw.reduce(function (a, b) { return a + b; }, 0) + gapX * (n.cols - 1);
        return box(w, ra[0] + shift, rd[rd.length - 1] + h - shift, function (ctx, u, x, yb) {
            cells.forEach(function (r, ri) {
                var xx = x;
                r.forEach(function (c, ci) { c.draw(ctx, u, xx + (cw[ci] - c.w) / 2 * u, yb + (ys[ri] - shift) * u); xx += (cw[ci] + gapX) * u; });
            });
        });
    }

    /* ---------- Vẽ ra PNG ---------- */
    var PT = 12, K = 6;   // cỡ chữ 12 pt, mỗi pt = 6 điểm ảnh
    MT.preview = function (ir) {
        var bx = layNode(ir, 1), pad = 0.05;
        var W = bx.w + 2 * pad, H = bx.a + bx.d + 2 * pad;
        var u = PT * K, cw = Math.max(2, Math.ceil(W * u)), ch = Math.max(2, Math.ceil(H * u));
        var c = document.createElement('canvas'); c.width = cw; c.height = ch;
        var ctx = c.getContext('2d');
        ctx.fillStyle = '#000'; ctx.strokeStyle = '#000'; ctx.textBaseline = 'alphabetic';
        bx.draw(ctx, u, pad * u, (bx.a + pad) * u);
        var url = c.toDataURL('image/png'), b64 = url.split(',')[1], bin = atob(b64), png = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) png[i] = bin.charCodeAt(i);
        return { png: png, wPt: W * PT, hPt: H * PT, dPt: (bx.d + pad) * PT };
    };
    MT.layout = function (ir) { return layNode(ir, 1); };

    var CACHE = {};
    MT.make = function (latex) {
        var r = CACHE[latex];
        if (r) return r;
        var ir = MT.latexToIR(latex), mtef = MT.irToMtef(ir), pv = MT.preview(ir);
        r = CACHE[latex] = { ole: MT.buildOle(mtef), png: pv.png, wPt: pv.wPt, hPt: pv.hPt, dPt: pv.dPt, mtef: mtef };
        return r;
    };
})(typeof window !== 'undefined' ? window : globalThis);

