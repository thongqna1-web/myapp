
/* [CODE162] XUẤT FILE WORD TỪ NGÂN HÀNG ĐỀ
   - Ở NGÂN HÀNG ĐỀ (giáo viên): nút "📄 Xuất file word" nằm ở THƯ MỤC CHÍNH (môn học + khối, ví dụ Hóa học 12), không còn ở từng chương / bài. Trang xuất tự chọn sẵn toàn bộ bài đã có câu hỏi; giáo viên tích chọn lại chương / bài cần xuất.
   - Trang xuất: chọn Chương / Bài của Môn - Khối đang mở, lấy toàn bộ hoặc theo số câu từng Phần I-II-III (mức độ tự động theo Bộ GD&ĐT 4:3:3, chia đều chương -> bài), nhập thông tin trang đầu của đề,
     rồi xuất Word đúng định dạng của TRỘN ĐỀ THI (Phần I/II/III, MathType, bảng Auto Fit, đáp án...).
   - Chạy hoàn toàn trên trình duyệt (GitHub Pages): đọc câu hỏi từ bộ nhớ ngân hàng đã có sẵn trên máy, KHÔNG thêm lượt đọc/ghi Firebase nào. */
(function () {
    'use strict';
    var LV = ['NB', 'TH', 'VD', 'VDC'];
    var PART = [['mc', 'Phần I'], ['tf', 'Phần II'], ['sa', 'Phần III']];
    var LSK = 'matrix_xw_cfg_v1', DOCX = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    var INFO = ['sgd', 'school', 'exam', 'subject', 'grade', 'year', 'time'];
    var S = { sj: '', g: 0, sel: {}, col: {}, touched: {}, busy: false, built: false };

    function $(id) { return document.getElementById(id); }
    function bank() { return window.CODE129Bank && window.CODE129Bank.lessonsOf ? window.CODE129Bank : null; }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function norm(s) { s = String(s || '').toLowerCase(); try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {} return s.replace(/đ/g, 'd'); }
    function val(id) { var e = $(id); return e ? String(e.value || '').trim() : ''; }
    function chk(id) { var e = $(id); return !!(e && e.checked); }
    function safe(s, def) { var r = norm(s).replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40); return r || def; }

    /* ===================== CSS ===================== */
    var CSS = '' +
        '.bk-xw{background:linear-gradient(90deg,#2563eb,#4f46e5);color:#fff}' +
        'body.layout-portrait #bank-modal .bk-ls .bk-xw{flex:1 0 100%}' +
        '.xw-modal{position:fixed;inset:0;z-index:85;background:rgba(0,0,0,.75);display:flex;transition:opacity .25s;font-family:Roboto,Arial,sans-serif}' +
        '.xw-modal.xw-off{display:none}.xw-modal.xw-fade{opacity:0}' +
        '.xw-panel{background:#f8fafc;width:100%;height:100%;display:flex;flex-direction:column;overflow:hidden;position:relative;color:#0f172a}' +
        '.xw-head{flex:none;display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 20px;color:#fff;background:linear-gradient(90deg,#2563eb,#4f46e5)}' +
        '.xw-head h2{margin:0;font-size:21px;font-weight:900;text-transform:uppercase;letter-spacing:.02em;min-width:0}' +
        '.xw-head .xw-tag{background:#fde047;color:#0f172a;font-size:13px;font-weight:900;border-radius:999px;padding:2px 10px;margin-left:8px;white-space:nowrap}' +
        '.xw-x{border:0;border-radius:999px;background:rgba(255,255,255,.2);color:#fff;font-weight:900;font-size:15px;padding:7px 16px;cursor:pointer;white-space:nowrap}.xw-x:hover{background:rgba(255,255,255,.35)}' +
        '.xw-f label{display:block;margin-bottom:3px;font-size:13px;font-weight:900;color:#334155;text-transform:uppercase}' +
        '.xw-f select,.xw-f input[type=text],.xw-f input[type=number]{width:100%;box-sizing:border-box;border:2px solid #cbd5e1;border-radius:12px;padding:8px 10px;font-size:16px;font-weight:700;color:#0f172a;background:#fff;outline:none}' +
        '.xw-f select:focus,.xw-f input:focus{border-color:#4f46e5}' +
        '.xw-info{flex:none;margin:10px 20px 0;background:#fff;border:1px solid #dbe3ef;border-radius:16px;padding:8px 16px 12px;box-shadow:0 1px 4px rgba(15,23,42,.06)}' +
        '.xw-info>summary{cursor:pointer;list-style:none;font-size:17px;font-weight:900;color:#4338ca;text-transform:uppercase;padding:4px 0}' +
        '.xw-info>summary::-webkit-details-marker{display:none}.xw-info>summary:after{content:" ▾";font-size:14px}.xw-info:not([open])>summary:after{content:" ▸"}' +
        '.xw-grid{display:grid;grid-template-columns:1.3fr 1.5fr 1.5fr 1fr .55fr .95fr .95fr;gap:8px;align-items:end;margin-top:6px}' +
        '.xw-grid .xw-f{min-width:0}.xw-grid .xw-f label{font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
        '.xw-grid .xw-f input[type=text]{font-size:15.5px;padding:8px 9px;background:#f8fafc}' +
        '.xw-main{flex:1;min-height:0;display:flex;margin-top:10px;border-top:1px solid #e2e8f0}' +
        '.xw-left{flex:1;min-width:0;min-height:0;display:flex;flex-direction:column;border-right:1px solid #e2e8f0;background:#fff}' +
        '.xw-bar{flex:none;display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:8px 14px;background:#f1f5f9;border-bottom:1px solid #e2e8f0}' +
        '.xw-bar label{display:flex;align-items:center;gap:6px;font-size:14px;font-weight:900;color:#1e293b;cursor:pointer}' +
        '.xw-pill{margin-left:auto;border:1px solid #a5b4fc;background:#fff;color:#3730a3;border-radius:999px;font-size:13px;font-weight:900;padding:4px 12px;cursor:pointer}.xw-pill+.xw-pill{margin-left:0}' +
        '.xw-tree{flex:1;min-height:0;overflow-y:auto;padding:10px 12px;-webkit-overflow-scrolling:touch}' +
        '.xw-chap{display:flex;align-items:center;gap:8px;margin:8px 0 4px;padding:7px 10px;border-radius:12px;background:linear-gradient(90deg,#e0e7ff,#fae8ff);border:1px solid #c7d2fe}' +
        '.xw-chap button{flex:1;min-width:0;text-align:left;background:none;border:0;padding:0;cursor:pointer;font-weight:900;font-size:15px;color:#312e81;text-transform:uppercase}' +
        '.xw-ls{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:10px;cursor:pointer;font-size:15px;font-weight:700;color:#1e293b}.xw-ls:hover{background:#eef2ff}' +
        '.xw-ls.ind{margin-left:18px}.xw-ls.off{opacity:.5;cursor:not-allowed}' +
        '.xw-cb{width:18px;height:18px;accent-color:#4f46e5;flex:none;cursor:pointer}' +
        '.xw-ln{flex:1;min-width:0}' +
        '.xw-badge{flex:none;font-size:13px;font-weight:900;color:#3730a3;background:#e0e7ff;border-radius:999px;padding:2px 9px;white-space:nowrap}.xw-badge.z{color:#64748b;background:#f1f5f9}' +
        '.xw-empty{padding:28px 12px;text-align:center;font-size:15px;font-weight:700;color:#64748b;line-height:1.6}' +
        '.xw-right{flex:none;width:400px;min-height:0;overflow-y:auto;background:#f8fafc;padding:14px;display:flex;flex-direction:column;gap:12px;-webkit-overflow-scrolling:touch}' +
        '.xw-box{background:#fff;border:1px solid #e2e8f0;border-radius:14px;padding:10px 12px}' +
        '.xw-box h4{margin:0 0 6px;font-size:14px;font-weight:900;color:#1e293b;text-transform:uppercase}' +
        '.xw-hint{margin:8px 0 0;font-size:13px;font-weight:600;color:#475569;line-height:1.45;text-align:justify;text-justify:inter-word;-webkit-hyphens:auto;hyphens:auto}' +
        '.xw-rd{display:flex;align-items:center;gap:8px;margin:3px 0;font-size:14.5px;font-weight:800;color:#1e293b;cursor:pointer}' +
        '.xw-rd input{accent-color:#4f46e5;width:17px;height:17px}' +
        '.xw-q{display:grid;gap:8px;margin:6px 0 4px}.xw-q.l4{grid-template-columns:repeat(4,1fr)}.xw-q.l3{grid-template-columns:repeat(3,1fr)}' +
        '.xw-q label{text-align:center;font-size:13px;font-weight:900}.xw-q input{width:100%;box-sizing:border-box;margin-top:2px;border:1px solid #cbd5e1;border-radius:10px;padding:5px 2px;text-align:center;font-size:17px;font-weight:900;color:#0f172a;outline:none;background:#fff}' +
        '.xw-q span{display:block;font-size:12px;font-weight:700;color:#64748b}' +
        '.xw-foot{flex:none;display:flex;flex-wrap:wrap;justify-content:flex-end;gap:10px;padding:10px 20px;background:#f1f5f9;border-top:1px solid #e2e8f0}' +
        '.xw-btn{border:0;border-radius:999px;padding:10px 24px;font-size:15px;font-weight:900;text-transform:uppercase;cursor:pointer;transition:transform .12s}.xw-btn:active{transform:scale(.96)}' +
        '.xw-btn.gry{background:#fff;color:#334155;border:1px solid #cbd5e1}.xw-btn.go{color:#fff;background:linear-gradient(90deg,#2563eb,#4f46e5);box-shadow:0 3px 8px rgba(79,70,229,.4)}' +
        '.xw-btn[disabled]{opacity:.5;cursor:wait}' +
        '.xw-ov{position:absolute;inset:0;z-index:5;background:rgba(15,23,42,.6);display:none;align-items:center;justify-content:center;padding:16px}.xw-ov.show{display:flex}' +
        '.xw-ov>div{background:#fff;border-radius:18px;padding:20px 26px;max-width:min(520px,92vw);text-align:center;font-weight:700;color:#1e293b;line-height:1.55;white-space:pre-line}' +
        '.xw-ov b{display:block;font-size:19px;font-weight:900;color:#3730a3;margin-bottom:6px}.xw-ov.ok b{color:#047857}' +
        '.xw-ov button{margin-top:12px;border:0;border-radius:999px;padding:8px 26px;font-weight:900;font-size:15px;color:#fff;background:linear-gradient(90deg,#2563eb,#4f46e5);cursor:pointer}' +
        '@media (max-width:1100px){.xw-grid{grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}}' +
        '@media (max-width:767px){' +
        '.xw-head{padding:10px 12px}.xw-head h2{font-size:17px}.xw-head .xw-tag{display:none}' +
        '.xw-info{margin:8px 12px 0}' +
        '.xw-main{flex-direction:column;overflow-y:auto}.xw-left{flex:none;border-right:0}.xw-tree{max-height:44vh;flex:none}' +
        '.xw-right{width:auto;overflow:visible}.xw-ls.ind{margin-left:8px}.xw-foot{padding:8px 12px}}';

    /* ===================== HTML ===================== */
    function inp(id, label, ph, extra) { return '<div class="xw-f"><label>' + label + '</label><input type="text" id="' + id + '" placeholder="' + ph + '" ' + (extra || 'oninput="CODE162.onInfo()"') + '></div>'; }
    var HTML = '' +
        '<div class="xw-panel">' +
        '<div class="xw-head"><div style="display:flex;align-items:center;min-width:0"><h2>📄 Xuất file Word từ Ngân hàng đề</h2><span class="xw-tag">Theo bài • Theo chương • Cả khối</span></div>' +
        '<button type="button" class="xw-x" onclick="CODE162.close()">✕ Đóng</button></div>' +
        '<details id="xw-info" class="xw-info" open><summary>Thông tin trang đầu của đề thi</summary><div class="xw-grid">' +
        inp('xw-sgd', 'Sở giáo dục', 'VD: SỞ GD – ĐT QUẢNG TRỊ') + inp('xw-school', 'Tên trường', 'VD: THPT NGUYỄN CHÍ THANH') + inp('xw-exam', 'Tên kì thi', 'VD: KIỂM TRA GIỮA KÌ I') +
        inp('xw-subject-t', 'Môn thi', 'VD: Hóa học', 'oninput="CODE162.onInfo(\'subject\')"') + inp('xw-grade-t', 'Lớp', 'VD: 12', 'oninput="CODE162.onInfo(\'grade\')"') +
        inp('xw-year', 'Năm học', 'VD: 2026 – 2027') + inp('xw-time', 'Thời gian làm bài (phút)', 'VD: 50') +
        '</div></details>' +
        '<div class="xw-main">' +
        '<div class="xw-left"><div class="xw-bar"><label><input id="xw-all" type="checkbox" class="xw-cb" onchange="CODE162.toggleAll(this.checked)"> Chọn tất cả (cả khối)</label>' +
        '<button type="button" class="xw-pill" onclick="CODE162.expandAll(true)">Mở hết chương</button><button type="button" class="xw-pill" onclick="CODE162.expandAll(false)">Thu gọn</button></div>' +
        '<div id="xw-tree" class="xw-tree"></div></div>' +
        '<div class="xw-right">' +
        '<div class="xw-box"><h4>Số câu lấy vào đề (theo phần)</h4>' +
        '<div id="xw-pquota" class="xw-q l3">' +
        '<label style="color:#1d4ed8">Phần I<input id="xw-p-mc" type="number" min="0" value="0" onfocus="this.select()" oninput="CODE162.updateSummary()"><span id="xw-pv-mc">có 0</span></label>' +
        '<label style="color:#047857">Phần II<input id="xw-p-tf" type="number" min="0" value="0" onfocus="this.select()" oninput="CODE162.updateSummary()"><span id="xw-pv-tf">có 0</span></label>' +
        '<label style="color:#c2410c">Phần III<input id="xw-p-sa" type="number" min="0" value="0" onfocus="this.select()" oninput="CODE162.updateSummary()"><span id="xw-pv-sa">có 0</span></label></div>' +
        '<p class="xw-hint">Để 0 ở cả ba phần = lấy toàn bộ câu hỏi của các bài đã chọn.</p>' +
        '<p class="xw-hint">📐 Mức độ tự động theo Bộ GD&amp;ĐT: Nhận biết 40% – Thông hiểu 30% – Vận dụng 30% (thiếu mức nào thì tự bù từ mức khác).</p>' +
        '<p class="xw-hint">⚖️ Số câu chia đều giữa các chương đã chọn; trong mỗi chương chia đều giữa các bài đã chọn.</p>' +
        '<label class="xw-rd" style="margin-top:8px;font-size:13.5px"><input id="xw-rand" type="checkbox" checked> Chọn ngẫu nhiên câu hỏi trong từng bài</label></div>' +
        '<div class="xw-box"><h4>Tệp Word cần xuất</h4>' +
        '<label class="xw-rd"><input id="xw-o-exam" type="checkbox" checked> Đề thi (dành cho học sinh)</label>' +
        '<label class="xw-rd"><input id="xw-o-ans" type="checkbox" checked> Đề có đáp án (dành cho giáo viên)</label>' +
        '<label class="xw-rd"><input id="xw-o-key" type="checkbox" checked> Bảng đáp án</label>' +
        '<div class="xw-f" style="margin-top:8px"><label>Mã đề (không bắt buộc)</label><input type="text" id="xw-code" maxlength="4" inputmode="numeric" placeholder="VD: 0101 — để trống nếu không cần"></div></div>' +
        '</div></div>' +
        '<div class="xw-foot"><button type="button" class="xw-btn gry" onclick="CODE162.close()">Hủy</button>' +
        '<button type="button" class="xw-btn go" id="xw-do" onclick="CODE162.doExport()">📄 Xuất file Word</button></div>' +
        '<div id="xw-ov" class="xw-ov"><div id="xw-ov-b"></div></div>' +
        '</div>';

    function build() {
        if (S.built && $('xw-modal')) return;
        if (!$('code162-css')) { var st = document.createElement('style'); st.id = 'code162-css'; st.textContent = CSS; document.head.appendChild(st); }
        var m = document.createElement('div'); m.id = 'xw-modal'; m.className = 'xw-modal xw-off xw-fade'; m.innerHTML = HTML;
        document.body.appendChild(m); S.built = true;
        var tr = $('xw-tree');
        tr.addEventListener('click', function (e) {
            var tg = e.target.closest && e.target.closest('[data-tg]');
            if (tg) { var id = tg.getAttribute('data-tg'); S.col[id] = !S.col[id]; renderTree(); }
        });
        tr.addEventListener('change', function (e) {
            var t = e.target;
            if (t.hasAttribute('data-ls')) { var k = t.getAttribute('data-ls'); if (t.checked) S.sel[k] = true; else delete S.sel[k]; updateSummary(); syncAll(); }
            else if (t.hasAttribute('data-ch')) {
                chapterItems(parseInt(t.getAttribute('data-ch'), 10)).forEach(function (it) { if (it.cnt) { if (t.checked) S.sel[it.key] = true; else delete S.sel[it.key]; } });
                renderTree(); syncAll();
            }
        });
    }
    function showM() { var m = $('xw-modal'); m.classList.remove('xw-off'); setTimeout(function () { m.classList.remove('xw-fade'); }, 10); }
    function close() {
        var m = $('xw-modal'); if (!m || S.busy) return;
        m.classList.add('xw-fade'); setTimeout(function () { m.classList.add('xw-off'); }, 260);
    }
    function note(title, msg, ok) {
        var o = $('xw-ov'); if (!o) return;
        $('xw-ov-b').innerHTML = '<b>' + esc(title) + '</b>' + esc(msg) + '<br><button type="button" onclick="CODE162.closeNote()">OK</button>';
        o.className = 'xw-ov show' + (ok ? ' ok' : '');
    }
    function closeNote() { var o = $('xw-ov'); if (o) o.className = 'xw-ov'; }
    function progress(msg) {
        var o = $('xw-ov'); if (!o) return;
        if (!msg) { if (S.busy === false) closeNote(); return; }
        $('xw-ov-b').innerHTML = '<b>⏳ ' + esc(msg) + '</b>Vui lòng chờ trong giây lát…';
        o.className = 'xw-ov show';
    }

    /* ===================== Dữ liệu ngân hàng ===================== */
    function tree(sj, g) {
        var B = bank(), out = [], cur = null;
        if (!B || !sj || !g) return out;
        B.lessonsOf(sj, g).forEach(function (x) {
            if (x.h) { cur = { id: x.id, n: x.n, items: [] }; out.push(cur); return; }
            if (!cur) { cur = { id: '_0', n: '', items: [] }; out.push(cur); }
            var key = sj + '|' + g + '|' + x.id, m = B.meta(key);
            cur.items.push({ id: x.id, n: x.n, key: key, cnt: m.n || 0, lv: m.m || {} });
        });
        return out;
    }
    function lvText(lv) { var t = []; LV.forEach(function (k) { if (lv && lv[k]) t.push(k + ' ' + lv[k]); }); return t.join(' • '); }
    /* ===================== Thông tin trang đầu ===================== */
    function mixCfg() { try { var k = window.__CODE93_CORE && window.__CODE93_CORE.LS_KEY; return k ? (JSON.parse(localStorage.getItem(k) || '{}') || {}) : {}; } catch (e) { return {}; } }
    function ownCfg() { try { return JSON.parse(localStorage.getItem(LSK) || '{}') || {}; } catch (e) { return {}; } }
    function fieldId(k) { return k === 'subject' ? 'xw-subject-t' : k === 'grade' ? 'xw-grade-t' : 'xw-' + k; }
    function fillInfo() {
        var own = ownCfg(), mx = mixCfg();
        INFO.forEach(function (k) {
            var el = $(fieldId(k)); if (!el) return;
            if (k === 'subject') el.value = S.sj;
            else if (k === 'grade') el.value = S.g ? String(S.g) : '';
            else el.value = own[k] != null ? own[k] : (mx[k] || '');   // lần đầu lấy thông tin trường từ mục TRỘN ĐỀ THI
        });
    }
    function readInfo() { var o = {}; INFO.forEach(function (k) { o[k] = val(fieldId(k)); }); return o; }
    function saveInfo() { try { var o = readInfo(); delete o.subject; delete o.grade; localStorage.setItem(LSK, JSON.stringify(o)); } catch (e) {} }
    function onInfo(k) { if (k) S.touched[k] = true; saveInfo(); }
    /* ===================== Mở trang ===================== */
    function open(sj, g, kind, id) {
        var B = bank(); if (!B) return;
        build();
        S.sj = sj; S.g = g; S.sel = {}; S.col = {}; S.touched = {}; S.busy = false;
        tree(sj, g).forEach(function (c) {
            if (kind === 'root') c.items.forEach(function (it) { if (it.cnt) S.sel[it.key] = true; });
            if (kind === 'chap' && c.id === id) c.items.forEach(function (it) { if (it.cnt) S.sel[it.key] = true; });
            if (kind === 'les') c.items.forEach(function (it) { if (it.id === id && it.cnt) S.sel[it.key] = true; });
        });
        ['mc', 'tf', 'sa'].forEach(function (k) { var e = $('xw-p-' + k); if (e) e.value = 0; });
        var rd = $('xw-rand'); if (rd) rd.checked = true;
        ['xw-o-exam', 'xw-o-ans', 'xw-o-key'].forEach(function (i) { var e = $(i); if (e) e.checked = true; });
        var cd = $('xw-code'); if (cd) cd.value = '';
        fillInfo(); closeNote();
        $('xw-info').open = window.innerWidth > 767;
        renderTree(); showM();
        setTimeout(function () { try { var f = document.querySelector('#xw-tree input[data-ls]:checked'); if (f && f.scrollIntoView) f.scrollIntoView({ block: 'center' }); } catch (e) {} }, 60);
    }

    /* ===================== Cây Chương / Bài ===================== */
    function renderTree() {
        var box = $('xw-tree'); if (!box) return;
        var data = tree(S.sj, S.g), h = '', any = false;
        data.forEach(function (c, ci) {
            if (!c.items.length) return;
            any = true;
            var tot = 0, sel = 0, selable = 0;
            c.items.forEach(function (it) { tot += it.cnt; if (it.cnt) { selable++; if (S.sel[it.key]) sel++; } });
            var open = !S.col[c.id];
            if (c.n) h += '<div class="xw-chap"><input type="checkbox" class="xw-cb" data-ch="' + ci + '"' + (selable && sel === selable ? ' checked' : '') + (selable ? '' : ' disabled') + '>' +
                '<button type="button" data-tg="' + esc(c.id) + '"><span style="display:inline-block;width:14px">' + (open ? '▾' : '▸') + '</span> ' + esc(c.n) + '</button><span class="xw-badge">' + tot + ' câu</span></div>';
            if (open) c.items.forEach(function (it) {
                h += '<label class="xw-ls' + (it.cnt ? '' : ' off') + (c.n ? ' ind' : '') + '"><input type="checkbox" class="xw-cb" data-ls="' + esc(it.key) + '"' + (S.sel[it.key] ? ' checked' : '') + (it.cnt ? '' : ' disabled') + '>' +
                    '<span class="xw-ln">' + esc(it.n) + '</span>' + (it.cnt ? '<span class="xw-badge">' + it.cnt + ' câu' + (lvText(it.lv) ? ' • ' + lvText(it.lv) : '') + '</span>' : '<span class="xw-badge z">chưa có câu</span>') + '</label>';
            });
        });
        if (!any) h = '<div class="xw-empty">Ngân hàng đề chưa có bài cho <b>' + esc(S.sj) + ' • Lớp ' + S.g + '</b>.</div>';
        box.innerHTML = h; updateSummary(); syncAll();
    }
    function chapterItems(ci) { var c = tree(S.sj, S.g)[ci]; return c ? c.items : []; }
    function toggleAll(on) { tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { if (it.cnt) { if (on) S.sel[it.key] = true; else delete S.sel[it.key]; } }); }); renderTree(); }
    function expandAll(on) { tree(S.sj, S.g).forEach(function (c) { S.col[c.id] = !on; }); renderTree(); }
    function syncAll() {
        var al = $('xw-all'); if (!al) return;
        var n = 0, s = 0; tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { if (it.cnt) { n++; if (S.sel[it.key]) s++; } }); });
        al.checked = n > 0 && n === s;
    }
    function selectedItems() {
        var out = []; tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { if (S.sel[it.key] && it.cnt) out.push({ it: it, chap: c }); }); }); return out;
    }
    function partOf(q) { return q && q.type === 'tf' ? 'tf' : (q && q.type === 'sa' ? 'sa' : 'mc'); }
    function updateSummary() {   // số câu có sẵn của từng phần trong các bài đã chọn
        var sl = selectedItems(), pc = { mc: 0, tf: 0, sa: 0 };
        try { if (sl.length) bank().getMany(sl.map(function (x) { return x.it.key; })).forEach(function (arr) { (arr || []).forEach(function (q) { pc[partOf(q)]++; }); }); } catch (e) {}
        PART.forEach(function (p) { var a = $('xw-pv-' + p[0]); if (a) a.textContent = 'có ' + pc[p[0]]; });
    }

    /* ===================== Chọn câu hỏi ===================== */
    /* Theo Bộ GD&ĐT: mỗi phần chia 4 : 3 : 3 (Nhận biết : Thông hiểu : Vận dụng; câu VDC tính vào Vận dụng); thiếu thì bù từ mức khác.
       Chia đều: các chương đã chọn nhận số câu bằng nhau; trong mỗi chương các bài đã chọn nhận số câu bằng nhau (bài nào hết câu thì bài khác bù). */
    var TIERS = ['NB', 'TH', 'VD'], RATIO = { NB: 4, TH: 3, VD: 3 };
    function tierOf(q) { var l = q && q.level; return l === 'NB' ? 'NB' : l === 'TH' ? 'TH' : (l === 'VD' || l === 'VDC') ? 'VD' : 'NO'; }
    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    function rid() { return 'g_' + Math.random().toString(36).slice(2, 8); }
    function balancedTake(P, k, T) {   // P: các "đơn vị" (1 câu hoặc 1 nhóm câu cùng dữ kiện); T: số câu đã lấy của từng chương / bài (cộng dồn cả đề)
        var out = [], rem = k;
        while (rem > 0) {
            var bi = -1, bc = 0, bl = 0;
            for (var i = 0; i < P.length; i++) {
                var u = P[i]; if (u.length > rem) continue;
                var c = T.c[u.c] || 0, l = T.l[u.l] || 0;
                if (bi < 0 || c < bc || (c === bc && l < bl)) { bi = i; bc = c; bl = l; }
            }
            if (bi < 0) break;
            var u2 = P.splice(bi, 1)[0];
            T.c[u2.c] = (T.c[u2.c] || 0) + u2.length; T.l[u2.l] = (T.l[u2.l] || 0) + u2.length;
            rem -= u2.length; out.push(u2);
        }
        return out;
    }
    function pick() {
        var B = bank(), sl = selectedItems();
        if (!sl.length) { note('Chưa chọn bài', 'Hãy tích chọn ít nhất 1 bài (hoặc cả chương) có câu hỏi trong Ngân hàng đề.'); return null; }
        var all = B.getMany(sl.map(function (x) { return x.it.key; })), pool = [], cIdx = {}, cn = 0;
        sl.forEach(function (x, i) {
            if (!(x.chap.id in cIdx)) cIdx[x.chap.id] = cn++;
            (all[i] || []).forEach(function (q) { var c = Object.assign({}, q); c.__k = x.it.key; c.__c = cIdx[x.chap.id]; c.__l = i; c.__i = pool.length; pool.push(c); });
        });
        if (!pool.length) { note('Không có câu hỏi', 'Các bài đã chọn chưa có câu hỏi nào trong Ngân hàng đề.'); return null; }
        var need = {}, total = 0;
        PART.forEach(function (p) { need[p[0]] = Math.max(0, parseInt(val('xw-p-' + p[0]), 10) || 0); total += need[p[0]]; });
        var chosen = pool, lack = [], rnd = chk('xw-rand');
        if (total > 0) {
            var units = [], gm = {};
            pool.forEach(function (q) {
                if (q.gid) { var k = q.__k + '#' + q.gid; if (!gm[k]) { gm[k] = []; units.push(gm[k]); } gm[k].push(q); } else units.push([q]);
            });
            units.forEach(function (u) { u.c = u[0].__c; u.l = u[0].__l; u.t = tierOf(u[0]); u.p = partOf(u[0]); });
            var T = { c: {}, l: {} }, picked = [];
            PART.forEach(function (p) {
                var n = need[p[0]]; if (!n) return;
                var cells = { NB: [], TH: [], VD: [], NO: [] };
                units.forEach(function (u) { if (u.p === p[0]) cells[u.t].push(u); });
                if (rnd) Object.keys(cells).forEach(function (t) { shuffle(cells[t]); });
                var raw = TIERS.map(function (l) { return n * RATIO[l] / 10; }), tg = raw.map(Math.floor), rest = n - tg.reduce(function (a, b) { return a + b; }, 0);
                raw.map(function (v, i) { return [v - Math.floor(v), i]; }).sort(function (a, b) { return b[0] - a[0]; }).forEach(function (x) { if (rest > 0) { tg[x[1]]++; rest--; } });
                var left = n, got = 0;
                var take = function (t, k) {
                    if (!(k > 0) || left <= 0) return;
                    balancedTake(cells[t], Math.min(k, left), T).forEach(function (u) { picked.push(u); left -= u.length; got += u.length; });
                };
                TIERS.forEach(function (l, i) { take(l, tg[i]); });
                ['TH', 'NB', 'VD', 'NO'].forEach(function (l) { take(l, left); });
                if (got < n) lack.push(p[1] + ': cần ' + n + ', chỉ có ' + got);
            });
            chosen = [].concat.apply([], picked);
        }
        if (!chosen.length) { note('Không đủ câu', 'Các bài đã chọn không có câu hỏi theo yêu cầu của bạn.'); return null; }
        chosen.sort(function (a, b) { return a.__i - b.__i; });
        // thống kê phân bổ (hiện sau khi xuất)
        var lvc = { NB: 0, TH: 0, VD: 0, NO: 0 }, cc = {}, lc = {};
        chosen.forEach(function (q) { lvc[tierOf(q)]++; cc[q.__c] = (cc[q.__c] || 0) + 1; lc[q.__l] = (lc[q.__l] || 0) + 1; });
        var stat = 'Mức độ: NB ' + lvc.NB + ' • TH ' + lvc.TH + ' • VD ' + lvc.VD + (lvc.NO ? ' • chưa phân mức ' + lvc.NO : '');
        var chNames = []; sl.forEach(function (x) { if (chNames.indexOf(x.chap) < 0) chNames.push(x.chap); });
        if (total > 0 && chNames.length > 1) stat += '\nTheo chương: ' + chNames.map(function (c, i) { return (c.n || ('Nhóm ' + (i + 1))).slice(0, 24) + ' = ' + (cc[i] || 0); }).join(' • ');
        if (total > 0 && sl.length > 1 && sl.length <= 12) stat += '\nTheo bài: ' + sl.map(function (x, i) { return x.it.n.slice(0, 22) + ' = ' + (lc[i] || 0); }).join(' • ');
        // nhóm câu (dữ kiện chung): tạo mã nhóm mới cho từng bài, giữ dữ kiện ở câu đầu nhóm được chọn
        var info = {}, remap = {}, seen = {};
        pool.forEach(function (q) { var k = q.__k + '#' + q.gid; if (q.gid && q.ginfo && !info[k]) info[k] = q.ginfo; });
        chosen.forEach(function (q) {
            if (!q.gid) return;
            var k = q.__k + '#' + q.gid; if (!remap[k]) remap[k] = rid();
            var first = !seen[k]; seen[k] = 1; q.gid = remap[k];
            if (first && info[k]) q.ginfo = info[k]; else delete q.ginfo;
        });
        chosen.forEach(function (q) { delete q.__k; delete q.__i; delete q.__c; delete q.__l; });
        return { list: chosen, sl: sl, lack: lack, stat: stat };
    }
    function titleName(sl) {
        if (sl.length === 1) return sl[0].it.n;
        var ch = sl[0].chap;
        if (ch.n && sl.every(function (x) { return x.chap === ch; })) return ch.n;
        return sl[0].it.n + '_va_' + (sl.length - 1) + '_bai_khac';
    }

    /* ===================== Xuất file ===================== */
    function download(blob, name) {
        var url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = name; document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 2500);
    }
    async function ensureZip() {
        if (typeof JSZip !== 'undefined') return;
        if (window.__code98LoadLib) { try { await window.__code98LoadLib('JSZip', ['https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js']); } catch (e) {} }
        if (typeof JSZip === 'undefined') throw new Error('Không tải được thư viện tạo file Word (JSZip). Hãy kiểm tra Internet rồi tải lại trang.');
    }
    async function doExport() {
        if (S.busy) return;
        var pk = pick(); if (!pk) return;
        var opt = { exam: chk('xw-o-exam'), ans: chk('xw-o-ans'), key: chk('xw-o-key'), code: val('xw-code').replace(/\D/g, '').slice(0, 4) };
        if (!opt.exam && !opt.ans && !opt.key) { note('Chưa chọn tệp xuất', 'Hãy tích chọn ít nhất một loại: Đề thi / Đề có đáp án / Bảng đáp án.'); return; }
        var M = window.CODE93Mix;
        if (!M || !M.bankWord) { note('Chưa sẵn sàng', 'Chưa nạp được bộ xuất Word. Hãy tải lại trang rồi thử lại.'); return; }
        var info = readInfo(); saveInfo();
        var tn = titleName(pk.sl);
        var base = 'De_' + safe(info.subject || S.sj, 'de_thi') + '_lop_' + safe(info.grade || String(S.g), '') + '_' + safe(tn, 'ngan_hang');
        opt.base = base.replace(/_+/g, '_').replace(/_$/, '');
        var btn = $('xw-do'); if (btn) btn.disabled = true;
        S.busy = true; progress('Đang chuẩn bị…');
        try {
            await ensureZip();
            var files = await M.bankWord(pk.list, info, opt, progress);
            var lackTxt = (pk.lack.length ? '\nLưu ý – không đủ câu: ' + pk.lack.join('; ') + '.' : '') + (pk.stat ? '\n' + pk.stat : ''), name;
            if (files.length === 1) {
                name = files[0].name;
                download(new Blob([files[0].data], { type: DOCX }), name);
                S.busy = false; note('Đã xuất file Word', 'Đã tải về “' + name + '” (' + pk.list.length + ' câu).' + lackTxt, true);
            } else {
                progress('Đang nén thành 1 thư mục…');
                var root = 'Xuat_' + opt.base, zip = new JSZip();
                files.forEach(function (f) { zip.file(root + '/' + f.dir + '/' + f.name, f.data); });
                var blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
                download(blob, root + '.zip');
                S.busy = false; note('Đã xuất file Word', 'Đã tải về “' + root + '.zip” (' + pk.list.length + ' câu). Giải nén sẽ được thư mục “' + root + '” gồm ' + files.length + ' file Word.' + lackTxt, true);
            }
        } catch (err) {
            console.error('[CODE162] export', err);
            S.busy = false; note('Lỗi xuất file', String(err && err.message ? err.message : err));
        } finally { S.busy = false; if (btn) btn.disabled = false; }
    }

    /* ===================== Sự kiện ===================== */
    document.addEventListener('click', function (e) {   // nút "Xuất file word" trong NGÂN HÀNG ĐỀ (chỉ giáo viên)
        var t = e.target; if (!t || !t.closest) return;
        var b = t.closest('[data-xwr],[data-xw],[data-xwc]'); if (!b) return;
        var bm = $('bank-modal'); if (!bm || !bm.contains(b)) return;
        e.preventDefault(); e.stopPropagation();
        if (document.body.classList.contains('is-student')) return;
        var B = bank(), p = B && B.path ? B.path() : [];
        if (p.length < 2) return;
        if (b.hasAttribute('data-xwr')) { open(p[0], p[1], 'root', ''); return; }   // nút ở thư mục chính (môn học)
        var chap = b.hasAttribute('data-xwc');
        open(p[0], p[1], chap ? 'chap' : 'les', b.getAttribute(chap ? 'data-xwc' : 'data-xw'));
    }, true);
    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        var m = $('xw-modal'); if (!m || m.classList.contains('xw-off')) return;
        var o = $('xw-ov'); if (o && o.classList.contains('show')) { if (!S.busy) closeNote(); } else close();
    });

    window.CODE162 = { open: open, close: close, closeNote: closeNote, onInfo: onInfo, renderTree: renderTree,
        toggleAll: toggleAll, expandAll: expandAll, updateSummary: updateSummary, doExport: doExport };
})();
