
/* [CODE129] NGÂN HÀNG ĐỀ: Môn học (có ⬆⬇ trên máy tính) -> Khối lớp -> Danh sách bài học (SGK thống nhất "Kết nối tri thức với cuộc sống", GDPT 2018)
   -> nút "Tạo ngân hàng đề" / "Cập nhật ngân hàng đề". Dữ liệu lưu localStorage (chạy tốt trên GitHub Pages).
   Móc nối nội dung sau: CODE129Bank.onLessonAction = function (info) {...}; CODE129Bank.setCount(info.key, soCau). */
(function () {
    'use strict';
    var LSK0 = 'matrix_bank_v1', LSQ0 = 'matrix_bank_questions_v1', qMem = null, qMemFor = '', applying = false;
    function lsk() { return LSK0 + (isStu() ? '_stu' : ''); }
    function lsq() { return LSQ0 + (isStu() ? '_stu' : ''); }
    var SUBJ = [
        ['Toán lớp 6','🧮',[6]],
        ['Toán lớp 7','🧮',[7]],
        ['Toán lớp 8','🧮',[8]],
        ['Toán lớp 9','🧮',[9]],
        ['Toán lớp 10','🧮',[10]],
        ['Toán lớp 11','🧮',[11]],
        ['Toán lớp 12','🧮',[12]]
    ];
    /* Danh sách bài mẫu (# = tên chương). Các môn/lớp chưa có sẵn: giáo viên bấm "Thêm bài". Có thể sửa/xóa từng bài. */
    var CUR = {"Toán lớp 6|6": "#Chương I. Tập hợp các số tự nhiên|Bài 1. Tập hợp|Bài 2. Cách ghi số tự nhiên|Bài 3. Thứ tự trong tập hợp các số tự nhiên|Bài 4. Phép cộng và phép trừ số tự nhiên|Bài 5. Phép nhân và phép chia số tự nhiên|Bài 6. Lũy thừa với số mũ tự nhiên|Bài 7. Thứ tự thực hiện các phép tính|#Chương II. Tính chia hết trong tập hợp các số tự nhiên|Bài 8. Quan hệ chia hết và tính chất|Bài 9. Dấu hiệu chia hết|Bài 10. Số nguyên tố|Bài 11. Ước chung. Ước chung lớn nhất|Bài 12. Bội chung. Bội chung nhỏ nhất|#Chương III. Số nguyên|Bài 13. Tập hợp các số nguyên|Bài 14. Phép cộng và phép trừ số nguyên|Bài 15. Quy tắc dấu ngoặc|Bài 16. Phép nhân số nguyên|Bài 17. Phép chia hết. Ước và bội của một số nguyên|#Chương IV. Một số hình phẳng trong thực tiễn|Bài 18. Hình tam giác đều. Hình vuông. Hình lục giác đều|Bài 19. Hình chữ nhật. Hình thoi. Hình bình hành. Hình thang cân|Bài 20. Chu vi và diện tích của một số tứ giác đã học|#Chương V. Tính đối xứng của hình phẳng trong tự nhiên|Bài 21. Hình có trục đối xứng|Bài 22. Hình có tâm đối xứng|#Chương VI. Phân số|Bài 23. Mở rộng phân số. Phân số bằng nhau|Bài 24. So sánh phân số. Hỗn số dương|Bài 25. Phép cộng và phép trừ phân số|Bài 26. Phép nhân và phép chia phân số|Bài 27. Hai bài toán về phân số|#Chương VII. Số thập phân|Bài 28. Số thập phân|Bài 29. Tính toán với số thập phân|Bài 30. Làm tròn và ước lượng|Bài 31. Một số bài toán về tỉ số và tỉ số phần trăm|#Chương VIII. Những hình học cơ bản|Bài 32. Điểm và đường thẳng|Bài 33. Điểm nằm giữa hai điểm. Tia|Bài 34. Đoạn thẳng. Độ dài đoạn thẳng|Bài 35. Trung điểm của đoạn thẳng|Bài 36. Góc|Bài 37. Số đo góc|#Chương IX. Dữ liệu và xác suất thực nghiệm|Bài 38. Dữ liệu và thu thập dữ liệu|Bài 39. Bảng thống kê và biểu đồ tranh|Bài 40. Biểu đồ cột|Bài 41. Biểu đồ cột kép|Bài 42. Kết quả có thể và sự kiện trong trò chơi, thí nghiệm|Bài 43. Xác suất thực nghiệm", "Toán lớp 7|7": "#Chương I. Số hữu tỉ|Bài 1. Tập hợp các số hữu tỉ|Bài 2. Cộng, trừ, nhân, chia số hữu tỉ|Bài 3. Lũy thừa với số mũ tự nhiên của một số hữu tỉ|Bài 4. Thứ tự thực hiện các phép tính. Quy tắc chuyển vế|#Chương II. Số thực|Bài 5. Làm quen với số thập phân vô hạn tuần hoàn|Bài 6. Số vô tỉ. Căn bậc hai số học|Bài 7. Tập hợp các số thực|#Chương III. Góc và đường thẳng song song|Bài 8. Góc ở vị trí đặc biệt. Tia phân giác của một góc|Bài 9. Hai đường thẳng song song và dấu hiệu nhận biết|Bài 10. Tiên đề Euclid. Tính chất của hai đường thẳng song song|Bài 11. Định lí và chứng minh định lí|#Chương IV. Tam giác bằng nhau|Bài 12. Tổng các góc trong một tam giác|Bài 13. Hai tam giác bằng nhau. Trường hợp bằng nhau thứ nhất của tam giác|Bài 14. Trường hợp bằng nhau thứ hai và thứ ba của tam giác|Bài 15. Các trường hợp bằng nhau của tam giác vuông|Bài 16. Tam giác cân. Đường trung trực của đoạn thẳng|#Chương V. Thu thập và biểu diễn dữ liệu|Bài 17. Thu thập và phân loại dữ liệu|Bài 18. Biểu đồ hình quạt tròn|Bài 19. Biểu đồ đoạn thẳng|#Chương VI. Tỉ lệ thức và đại lượng tỉ lệ|Bài 20. Tỉ lệ thức|Bài 21. Tính chất của dãy tỉ số bằng nhau|Bài 22. Đại lượng tỉ lệ thuận|Bài 23. Đại lượng tỉ lệ nghịch|#Chương VII. Biểu thức đại số và đa thức một biến|Bài 24. Biểu thức đại số|Bài 25. Đa thức một biến|Bài 26. Phép cộng và phép trừ đa thức một biến|Bài 27. Phép nhân đa thức một biến|Bài 28. Phép chia đa thức một biến|#Chương VIII. Làm quen với biến cố và xác suất của biến cố|Bài 29. Làm quen với biến cố|Bài 30. Làm quen với xác suất của biến cố|#Chương IX. Quan hệ giữa các yếu tố trong một tam giác|Bài 31. Quan hệ giữa góc và cạnh đối diện trong một tam giác|Bài 32. Quan hệ giữa đường vuông góc và đường xiên|Bài 33. Quan hệ giữa ba cạnh của một tam giác|Bài 34. Sự đồng quy của ba đường trung tuyến, ba đường phân giác trong một tam giác|Bài 35. Sự đồng quy của ba đường trung trực, ba đường cao trong một tam giác|#Chương X. Một số hình khối trong thực tiễn|Bài 36. Hình hộp chữ nhật và hình lập phương|Bài 37. Hình lăng trụ đứng tam giác và hình lăng trụ đứng tứ giác", "Toán lớp 8|8": "#Chương I. Đa thức|Bài 1. Đơn thức|Bài 2. Đa thức|Bài 3. Phép cộng và phép trừ đa thức|Bài 4. Phép nhân đa thức|Bài 5. Phép chia đa thức cho đơn thức|#Chương II. Hằng đẳng thức đáng nhớ và ứng dụng|Bài 6. Hiệu hai bình phương. Bình phương của một tổng hay một hiệu|Bài 7. Lập phương của một tổng hay một hiệu|Bài 8. Tổng và hiệu hai lập phương|Bài 9. Phân tích đa thức thành nhân tử|#Chương III. Tứ giác|Bài 10. Tứ giác|Bài 11. Hình thang cân|Bài 12. Hình bình hành|Bài 13. Hình chữ nhật|Bài 14. Hình thoi và hình vuông|#Chương IV. Định lí Thalès|Bài 15. Định lí Thalès trong tam giác|Bài 16. Đường trung bình của tam giác|Bài 17. Tính chất đường phân giác của tam giác|#Chương V. Dữ liệu và biểu đồ|Bài 18. Thu thập và phân loại dữ liệu|Bài 19. Biểu diễn dữ liệu bằng bảng, biểu đồ|Bài 20. Phân tích số liệu thống kê dựa vào biểu đồ|#Chương VI. Phân thức đại số|Bài 21. Phân thức đại số|Bài 22. Tính chất cơ bản của phân thức đại số|Bài 23. Phép cộng và phép trừ phân thức đại số|Bài 24. Phép nhân và phép chia phân thức đại số|#Chương VII. Phương trình bậc nhất và hàm số bậc nhất|Bài 25. Phương trình bậc nhất một ẩn|Bài 26. Giải bài toán bằng cách lập phương trình|Bài 27. Khái niệm hàm số và đồ thị của hàm số|Bài 28. Hàm số bậc nhất và đồ thị của hàm số bậc nhất|Bài 29. Hệ số góc của đường thẳng|#Chương VIII. Mở đầu về tính xác suất của biến cố|Bài 30. Kết quả có thể và kết quả thuận lợi|Bài 31. Cách tính xác suất của biến cố bằng tỉ số|Bài 32. Mối liên hệ giữa xác suất thực nghiệm với xác suất và ứng dụng|#Chương IX. Tam giác đồng dạng|Bài 33. Hai tam giác đồng dạng|Bài 34. Ba trường hợp đồng dạng của hai tam giác|Bài 35. Định lí Pythagore và ứng dụng|Bài 36. Các trường hợp đồng dạng của hai tam giác vuông|Bài 37. Hình đồng dạng|#Chương X. Một số hình khối trong thực tiễn|Bài 38. Hình chóp tam giác đều|Bài 39. Hình chóp tứ giác đều", "Toán lớp 9|9": "#Chương I. Phương trình và hệ hai phương trình bậc nhất hai ẩn|Bài 1. Khái niệm phương trình và hệ hai phương trình bậc nhất hai ẩn|Bài 2. Giải hệ hai phương trình bậc nhất hai ẩn|Bài 3. Giải bài toán bằng cách lập hệ phương trình|#Chương II. Phương trình và bất phương trình bậc nhất một ẩn|Bài 4. Phương trình quy về phương trình bậc nhất một ẩn|Bài 5. Bất đẳng thức và tính chất|Bài 6. Bất phương trình bậc nhất một ẩn|#Chương III. Căn bậc hai và căn bậc ba|Bài 7. Căn bậc hai và căn thức bậc hai|Bài 8. Khai căn bậc hai với phép nhân và phép chia|Bài 9. Biến đổi đơn giản và rút gọn biểu thức chứa căn thức bậc hai|Bài 10. Căn bậc ba và căn thức bậc ba|#Chương IV. Hệ thức lượng trong tam giác vuông|Bài 11. Tỉ số lượng giác của góc nhọn|Bài 12. Một số hệ thức giữa cạnh, góc trong tam giác vuông và ứng dụng|#Chương V. Đường tròn|Bài 13. Mở đầu về đường tròn|Bài 14. Cung và dây của một đường tròn|Bài 15. Độ dài của cung tròn. Diện tích hình quạt tròn và hình vành khuyên|Bài 16. Vị trí tương đối của đường thẳng và đường tròn|Bài 17. Vị trí tương đối của hai đường tròn|#Chương VI. Hàm số y = ax^2 (a ≠ 0). Phương trình bậc hai một ẩn|Bài 18. Hàm số y = ax^2 (a ≠ 0)|Bài 19. Phương trình bậc hai một ẩn|Bài 20. Định lí Viète và ứng dụng|Bài 21. Giải bài toán bằng cách lập phương trình|#Chương VII. Tần số và tần số tương đối|Bài 22. Bảng tần số và biểu đồ tần số|Bài 23. Bảng tần số tương đối và biểu đồ tần số tương đối|Bài 24. Bảng tần số, tần số tương đối ghép nhóm và biểu đồ|#Chương VIII. Xác suất của biến cố trong một số mô hình xác suất đơn giản|Bài 25. Phép thử ngẫu nhiên và không gian mẫu|Bài 26. Xác suất của biến cố liên quan tới phép thử|#Chương IX. Đường tròn ngoại tiếp và đường tròn nội tiếp|Bài 27. Góc nội tiếp|Bài 28. Đường tròn ngoại tiếp và đường tròn nội tiếp của một tam giác|Bài 29. Tứ giác nội tiếp|Bài 30. Đa giác đều|#Chương X. Một số hình khối trong thực tiễn|Bài 31. Hình trụ và hình nón|Bài 32. Hình cầu", "Toán lớp 10|10": "#Chương I. Mệnh đề và tập hợp|Bài 1. Mệnh đề|Bài 2. Tập hợp và các phép toán trên tập hợp|#Chương II. Bất phương trình và hệ bất phương trình bậc nhất hai ẩn|Bài 3. Bất phương trình bậc nhất hai ẩn|Bài 4. Hệ bất phương trình bậc nhất hai ẩn|#Chương III. Hệ thức lượng trong tam giác|Bài 5. Giá trị lượng giác của một góc từ 0° đến 180°|Bài 6. Hệ thức lượng trong tam giác|#Chương IV. Vectơ|Bài 7. Các khái niệm mở đầu|Bài 8. Tổng và hiệu của hai vectơ|Bài 9. Tích của một vectơ với một số|Bài 10. Vectơ trong mặt phẳng tọa độ|Bài 11. Tích vô hướng của hai vectơ|#Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm|Bài 12. Số gần đúng và sai số|Bài 13. Các số đặc trưng đo xu thế trung tâm|Bài 14. Các số đặc trưng đo độ phân tán|#Chương VI. Hàm số, đồ thị và ứng dụng|Bài 15. Hàm số|Bài 16. Hàm số bậc hai|Bài 17. Dấu của tam thức bậc hai|Bài 18. Phương trình quy về phương trình bậc hai|#Chương VII. Phương pháp tọa độ trong mặt phẳng|Bài 19. Phương trình đường thẳng|Bài 20. Vị trí tương đối giữa hai đường thẳng. Góc và khoảng cách|Bài 21. Đường tròn trong mặt phẳng tọa độ|Bài 22. Ba đường conic|#Chương VIII. Đại số tổ hợp|Bài 23. Quy tắc đếm|Bài 24. Hoán vị, chỉnh hợp và tổ hợp|Bài 25. Nhị thức Newton|#Chương IX. Tính xác suất theo định nghĩa cổ điển|Bài 26. Biến cố và định nghĩa cổ điển của xác suất|Bài 27. Thực hành tính xác suất theo định nghĩa cổ điển", "Toán lớp 11|11": "#Chương I. Hàm số lượng giác và phương trình lượng giác|Bài 1. Giá trị lượng giác của góc lượng giác|Bài 2. Công thức lượng giác|Bài 3. Hàm số lượng giác|Bài 4. Phương trình lượng giác cơ bản|#Chương II. Dãy số. Cấp số cộng và cấp số nhân|Bài 5. Dãy số|Bài 6. Cấp số cộng|Bài 7. Cấp số nhân|#Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm|Bài 8. Mẫu số liệu ghép nhóm|Bài 9. Các số đặc trưng đo xu thế trung tâm|#Chương IV. Quan hệ song song trong không gian|Bài 10. Đường thẳng và mặt phẳng trong không gian|Bài 11. Hai đường thẳng song song|Bài 12. Đường thẳng và mặt phẳng song song|Bài 13. Hai mặt phẳng song song|Bài 14. Phép chiếu song song|#Chương V. Giới hạn. Hàm số liên tục|Bài 15. Giới hạn của dãy số|Bài 16. Giới hạn của hàm số|Bài 17. Hàm số liên tục|#Chương VI. Hàm số mũ và hàm số lôgarit|Bài 18. Lũy thừa với số mũ thực|Bài 19. Lôgarit|Bài 20. Hàm số mũ và hàm số lôgarit|Bài 21. Phương trình, bất phương trình mũ và lôgarit|#Chương VII. Quan hệ vuông góc trong không gian|Bài 22. Hai đường thẳng vuông góc|Bài 23. Đường thẳng vuông góc với mặt phẳng|Bài 24. Phép chiếu vuông góc. Góc giữa đường thẳng và mặt phẳng|Bài 25. Hai mặt phẳng vuông góc|Bài 26. Khoảng cách|Bài 27. Thể tích|#Chương VIII. Các quy tắc tính xác suất|Bài 28. Biến cố hợp, biến cố giao, biến cố độc lập|Bài 29. Công thức cộng xác suất|Bài 30. Công thức nhân xác suất cho hai biến cố độc lập|#Chương IX. Đạo hàm|Bài 31. Định nghĩa và ý nghĩa của đạo hàm|Bài 32. Các quy tắc tính đạo hàm|Bài 33. Đạo hàm cấp hai", "Toán lớp 12|12": "#Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số|Bài 1. Tính đơn điệu và cực trị của hàm số|Bài 2. Giá trị lớn nhất và giá trị nhỏ nhất của hàm số|Bài 3. Đường tiệm cận của đồ thị hàm số|Bài 4. Khảo sát sự biến thiên và vẽ đồ thị của hàm số|Bài 5. Ứng dụng đạo hàm để giải quyết một số vấn đề liên quan đến thực tiễn|#Chương II. Vectơ và hệ trục tọa độ trong không gian|Bài 6. Vectơ trong không gian|Bài 7. Hệ trục tọa độ trong không gian|Bài 8. Biểu thức tọa độ của các phép toán vectơ|#Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm|Bài 9. Khoảng biến thiên và khoảng tứ phân vị|Bài 10. Phương sai và độ lệch chuẩn|#Chương IV. Nguyên hàm và tích phân|Bài 11. Nguyên hàm|Bài 12. Tích phân|Bài 13. Ứng dụng hình học của tích phân|#Chương V. Phương pháp tọa độ trong không gian|Bài 14. Phương trình mặt phẳng|Bài 15. Phương trình đường thẳng trong không gian|Bài 16. Công thức tính góc trong không gian|Bài 17. Phương trình mặt cầu|#Chương VI. Xác suất có điều kiện|Bài 18. Xác suất có điều kiện|Bài 19. Công thức xác suất toàn phần và công thức Bayes"};
    var st = { order: [], lessons: {}, q: {}, m: {} }, path = [], modal, body, keepPath = false;
    function isMathBankKey(k) { return /^Toán lớp \d+\|\d+(?:\||$)/i.test(String(k || '')); }
    function mathOnlyMap(o) { var r = {}; Object.keys(o || {}).forEach(function (k) { if (isMathBankKey(k)) r[k] = o[k]; }); return r; }
    function loadSt() {
        st = { order: [], lessons: {}, q: {}, m: {} };
        try {
            var s = JSON.parse(localStorage.getItem(lsk()) || '{}');
            st.order = (s.order || []).filter(function (n) { return /^Toán lớp \d+$/i.test(String(n || '')); });
            st.lessons = mathOnlyMap(s.lessons); st.q = mathOnlyMap(s.q); st.m = mathOnlyMap(s.m);
            localStorage.setItem(lsk(), JSON.stringify(st));
        } catch (e) {}
    }
    loadSt();
try { if (!isStu() && !localStorage.getItem(LSK0 + '_c137')) { st.lessons = {}; st.q = st.q || {}; localStorage.setItem(LSK0 + '_c137', '1'); } } catch (e) {}
    function save() { try { localStorage.setItem(lsk(), JSON.stringify(st)); } catch (e) {} if (!applying) BS.touch(false); }
    function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function isStu() { return document.body.classList.contains('is-student'); }
    function subjects() {
        var names = SUBJ.map(function (x) { return x[0]; });
        var o = st.order.filter(function (n) { return names.indexOf(n) >= 0; });
        names.forEach(function (n) { if (o.indexOf(n) < 0) o.push(n); });
        return o;
    }
    function info(n) { return SUBJ.filter(function (x) { return x[0] === n; })[0]; }
    function lessons(sj, g) {
        var k = sj + '|' + g;
        if (st.lessons[k]) return st.lessons[k];
        var raw = CUR[k]; if (!raw) return [];
        return raw.split('|').map(function (t, i) { return t.charAt(0) === '#' ? { id: 'c' + i, h: 1, n: t.slice(1) } : { id: 'l' + i, n: t }; });
    }
    function setL(sj, g, arr) { st.lessons[sj + '|' + g] = arr; save(); }
    function moveSubj(n, d) {
        var l = subjects(), i = l.indexOf(n), j = i + d;
        if (i < 0 || j < 0 || j >= l.length) return;
        var t = l[i]; l[i] = l[j]; l[j] = t; st.order = l; save(); render(true);
        /* [CODE158] vị trí mới được CỐ ĐỊNH (lưu máy + đồng bộ Firebase cho học sinh); giữ nguyên chỗ cuộn và nháy khung môn vừa chuyển */
        try {
            var cards = body.querySelectorAll('.bk-card');
            for (var ci = 0; ci < cards.length; ci++) if (cards[ci].getAttribute('data-sj') === n) { cards[ci].classList.add('bk-flash'); if (cards[ci].scrollIntoView) cards[ci].scrollIntoView({ block: 'nearest' }); break; }
        } catch (e) {}
    }
    var ARW = 'bk-mv';
    function crumb() {
        var h = '<div class="bk-crumb"><a data-go="0">📚 Ngân hàng đề</a>';
        if (path[0]) h += ' › <a data-go="1">' + esc(path[0]) + '</a>';
        if (path[1]) h += path.length > 2 ? ' › <a data-go="2">' + esc(path[0]) + ' ' + path[1] + '</a>' : ' › <b>' + esc(path[0]) + ' ' + path[1] + '</b>';
        if (path[2]) h += ' › <b>' + esc(lessonName(path)) + '</b>';
        return h + '</div>';
    }
    /* [CODE138] ngân hàng câu hỏi: lưu / đọc câu hỏi từng bài (localStorage) */
    /* [CODE160] Câu hỏi ngân hàng đề lưu trong IndexedDB (hàng trăm MB, mỗi bài 1 bản ghi) thay cho localStorage (~5MB, gây lỗi "Không lưu được").
       Bộ nhớ đệm qMem giữ API đọc/ghi đồng bộ như cũ; dữ liệu cũ trong localStorage tự chuyển sang IndexedDB rồi xóa khỏi localStorage. */
    var QDB = {};
    function qdb() {
        var mk = lsq();
        if (QDB[mk]) return QDB[mk];
        var s = QDB[mk] = { name: mk, saved: {}, rec: null, merged: false, chain: Promise.resolve(), warned: false };
        s.dbP = new Promise(function (res) {
            try {
                var rq = indexedDB.open('mxbank_' + mk, 1);
                rq.onupgradeneeded = function () { rq.result.createObjectStore('q', { keyPath: 'k' }); };
                rq.onsuccess = function () { res(rq.result); };
                rq.onerror = rq.onblocked = function () { res(null); };
            } catch (e) { res(null); }
        });
        s.loadP = s.dbP.then(function (db) {
            if (!db) return null;
            return new Promise(function (res) {
                try {
                    var out = {}, rq = db.transaction('q', 'readonly').objectStore('q').getAll();
                    rq.onsuccess = function () { (rq.result || []).forEach(function (r) { out[r.k] = { q: r.q, t: r.t || 0 }; }); res(out); };
                    rq.onerror = function () { res(null); };
                } catch (e) { res(null); }
            });
        }).then(function (rec) {
            s.rec = mathOnlyMap(rec || {});
            if (qMemFor === s.name) applyRec(s);
        });
        return s;
    }
    function applyRec(s) {
        if (s.merged || !s.rec || !qMem || qMemFor !== s.name) return;
        s.merged = true;
        var changed = false;
        Object.keys(s.rec).forEach(function (k) {
            var r = s.rec[k], c = qMem[k];
            if (!c || (r.t || 0) > (c.t || 0)) { qMem[k] = r; changed = true; }
            s.saved[k] = r.t || 0;
        });
        persist(s);   /* đưa dữ liệu cũ còn trong localStorage (nếu có) sang IndexedDB */
        if (changed) { try { if (modal && modal.classList.contains('open') && editIdx < 0 && !editDirty) render(true); } catch (e) {} }
    }
    function persist(s) {
        s.chain = s.chain.then(function () { return s.loadP; }).then(function () { return s.dbP; }).then(function (db) {
            var snap = qMem && qMemFor === s.name ? qMem : null;
            if (!snap) return;
            if (!db) {   /* trình duyệt không có IndexedDB: thử localStorage, nếu đầy thì chỉ giữ tạm trong phiên */
                try { localStorage.setItem(s.name, JSON.stringify(snap)); }
                catch (e) { if (!s.warned) { s.warned = true; try { status('⚠ Trình duyệt không cho lưu lâu dài: ngân hàng đề chỉ giữ tạm đến khi đóng trang. Hãy bấm ĐỒNG BỘ LÊN để lưu lên máy chủ.'); setTimeout(unstatus, 7000); } catch (e2) {} } }
                return;
            }
            return new Promise(function (res) {
                try {
                    var tx = db.transaction('q', 'readwrite'), os = tx.objectStore('q'), kr = os.getAllKeys();
                    kr.onsuccess = function () {
                        (kr.result || []).forEach(function (k) { if (!snap[k]) { os.delete(k); delete s.saved[k]; } });
                        Object.keys(snap).forEach(function (k) {
                            var t = snap[k].t || 0;
                            if (s.saved[k] !== t) { os.put({ k: k, q: snap[k].q || [], t: t }); s.saved[k] = t; }
                        });
                    };
                    tx.oncomplete = function () { try { localStorage.removeItem(s.name); } catch (e) {} res(true); };
                    tx.onabort = tx.onerror = function () {
                        s.saved = {};
                        if (!s.warned) { s.warned = true; try { status('⚠ Không ghi được vào bộ nhớ trình duyệt (có thể ổ đĩa đầy). Hãy bấm ĐỒNG BỘ LÊN để lưu lên máy chủ.'); setTimeout(unstatus, 7000); } catch (e2) {} }
                        res(false);
                    };
                } catch (e) { res(false); }
            });
        });
        return s.chain;
    }
    function readQ() {
        var mk = lsq();
        if (qMem && qMemFor === mk) return qMem;
        var o = {}; try { o = JSON.parse(localStorage.getItem(mk) || '{}') || {}; } catch (e) {}
        qMem = mathOnlyMap(o); qMemFor = mk;
        try { localStorage.setItem(mk, JSON.stringify(qMem)); } catch (e) {}
        var s = qdb(); applyRec(s);
        return qMem;
    }
    function writeQ(o) { qMem = o; qMemFor = lsq(); persist(qdb()); return true; }
    try { readQ(); } catch (e) {}   /* mở IndexedDB và nạp dữ liệu ngay khi tải trang */
    function getQuestions(key) { var o = readQ(), r = (o[key] && o[key].q) ? o[key].q : []; try { if (!isStu() && window.__bankBase) window.__bankBase(key, r); } catch (e) {} return r; }
    function lvCount(arr) { var c = { NB: 0, TH: 0, VD: 0, VDC: 0 }; arr.forEach(function (x) { if (c[x.level] != null) c[x.level]++; }); return c; }
    function saveQuestions(key, arr) {
        var chg = null; try { if (!isStu() && window.__bankPre) chg = window.__bankPre(key, arr); } catch (e) { console.error(e); }
        var o = readQ(); o[key] = { q: arr, t: Date.now() };
        if (!writeQ(o)) { console.error('[CODE138] quota'); return false; }
        st.q[key] = arr.length; st.m[key] = lvCount(arr); save(); try { if (chg && window.__bankPost) window.__bankPost(key, arr, chg); } catch (e) { console.error(e); } return true;
    }
    function removeQuestions(key) {
        var o = readQ(); if (o[key]) { delete o[key]; writeQ(o); }
        delete st.q[key]; delete st.m[key]; save();
    }
    function lvText(key) {
        var m = st.m && st.m[key]; if (!m) return '';
        var t = (m.NB ? ' • NB ' + m.NB : '') + (m.TH ? ' • TH ' + m.TH : '') + (m.VD ? ' • VD ' + m.VD : '') + (m.VDC ? ' • VDC ' + m.VDC : '');
        return t;
    }
    function exportBank() {
        var data = { app: 'matrix-bank', v: 1, state: st, questions: readQ() }, a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
        a.download = 'ngan-hang-de_' + new Date().toISOString().slice(0, 10) + '.json';
        document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    }
    function importBank() {
        var inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
        inp.onchange = function () {
            var f = inp.files && inp.files[0]; if (!f) return;
            var r = new FileReader();
            r.onload = function () {
                try {
                    var d = JSON.parse(r.result);
                    if (!d || d.app !== 'matrix-bank' || !d.state) throw new Error('Không phải file sao lưu ngân hàng đề.');
                    if (!confirm('Khôi phục sẽ GHI ĐÈ toàn bộ ngân hàng đề hiện có trên trình duyệt này. Tiếp tục?')) return;
                    if (!writeQ(d.questions || {})) throw new Error('Bộ nhớ trình duyệt đầy.');
                    st.order = (d.state.order || []).filter(function (n) { return /^Toán lớp \d+$/i.test(String(n || '')); });
                    st.lessons = mathOnlyMap(d.state.lessons); st.q = mathOnlyMap(d.state.q); st.m = mathOnlyMap(d.state.m);
                    var q = mathOnlyMap(d.questions || {}); writeQ(q);
                    save(); BS.touch(true); render(); status('Đã khôi phục ngân hàng đề môn Toán.'); setTimeout(unstatus, 2500);
                } catch (e) { alert('Không khôi phục được: ' + (e && e.message ? e.message : e)); }
            };
            r.readAsText(f);
        };
        inp.click();
    }
    /* [CODE139] XEM CÂU HỎI của từng bài trong ngân hàng đề (+ sửa / xóa từng câu) */
    function lessonName(p) { var a = lessons(p[0], p[1]); for (var i = 0; i < a.length; i++) if (a[i].id === p[2]) return a[i].n; return ''; }
    function fmtQ(t) {
        t = String(t == null ? '' : t);
        try { if (typeof window.formatMathAndChemHTML === 'function') return window.formatMathAndChemHTML(t); } catch (e) {}
        return esc(t);
    }
    /* [CODE143] Hình vẽ trong câu hỏi / đáp án / lời giải tự động căn giữa. Ảnh công thức nhỏ nằm trong dòng chữ giữ nguyên. */
    function markFig(img) {
        if (!img || img.tagName !== 'IMG' || !img.closest || !img.closest('.bk-view') || img.closest('.katex')) return;
        if (img.hasAttribute('data-al')) { img.classList.remove('bk-fig'); return; }   /* [CODE161] ảnh đã có căn lề theo file nguồn */
        var nw = img.naturalWidth, nh = img.naturalHeight; if (!nw || !nh) return;
        var sw = parseFloat(img.style.width) || 0, dw = sw || nw, dh = nh * dw / nw;
        if (dh >= 60 || dw >= 300) img.classList.add('bk-fig'); else img.classList.remove('bk-fig');
    }
    /* [CODE144] Lời giải mặc định ẨN (nút "💡 XEM HƯỚNG DẪN"); trạng thái mở chỉ giữ trong lúc xem 1 bài, đổi bài/xóa câu thì ẩn lại */
    function resetSol() { var o = window.LVSO; if (!o) return; Object.keys(o).forEach(function (k) { if (k.indexOf('bk_') === 0) delete o[k]; }); }
    var lvFilter = 'all';
    var LVL = [['NB', 'NHẬN BIẾT', 'Nhận biết'], ['TH', 'THÔNG HIỂU', 'Thông hiểu'], ['VD', 'VẬN DỤNG', 'Vận dụng'], ['VDC', 'VẬN DỤNG CAO', 'Vận dụng cao'], ['', 'CHƯA PHÂN MỨC ĐỘ', 'Chưa phân mức']];
    function lvOf(x) { return (x.level === 'NB' || x.level === 'TH' || x.level === 'VD' || x.level === 'VDC') ? x.level : ''; }
    function viewHtml() {
        /* [CODE142] Phân loại theo mức độ: bộ lọc Nhận biết / Thông hiểu / Vận dụng; luôn hiện đủ 3 nhóm chính; đổi mức độ nhanh ngay trên thẻ. Hiển thị câu hỏi dùng thẻ làm bài. */
        var key = path.join('|'), qs = getQuestions(key), stu = isStu(), B = window.BKView;
        var h = '<div class="bk-view"><div class="bk-tools"><b>' + esc(lessonName(path)) + '</b>' + (stu ? '' : '<span><button class="bk-b bk-up" data-act2="' + esc(path[2]) + '">➕ Cập nhật ngân hàng đề</button>' + (qs.length ? '<button class="bk-b bk-rm" data-qdelall="1" title="Xóa tất cả câu hỏi của bài này">🗑 Xóa toàn bộ câu hỏi</button>' : '') + '</span>') + '</div>';
        if (!qs.length) return h + '<div class="bk-empty"><b>Bài này chưa có câu hỏi</b><span>Bấm "Cập nhật ngân hàng đề" để thêm câu hỏi.</span></div></div>';
        if (!B) return h + '<div class="bk-empty"><b>Chưa tải xong giao diện câu hỏi</b><span>Hãy tải lại trang (Ctrl+F5) rồi mở lại.</span></div></div>';
        var ordered = [], cnt = { NB: 0, TH: 0, VD: 0, VDC: 0, '': 0 };
        LVL.forEach(function (L) {
            ['mc', 'tf', 'sa'].forEach(function (t) {
                qs.forEach(function (x, i) {
                    var tt = (x.type === 'tf' || x.type === 'sa') ? x.type : 'mc';
                    if (lvOf(x) === L[0] && tt === t) { ordered.push(Object.assign({}, x, { id: 'bk_' + i, type: t, _oi: i, _lv: L[0] })); cnt[L[0]]++; }
                });
            });
        });
        if (lvFilter !== 'all' && lvFilter !== 'none' && !cnt.hasOwnProperty(lvFilter)) lvFilter = 'all';
        /* thanh lọc mức độ */
        h += '<div class="bk-flt"><button class="bk-fc' + (lvFilter === 'all' ? ' on' : '') + '" data-lvf="all">Tất cả <span>(' + qs.length + ')</span></button>';
        LVL.forEach(function (L) {
            var code = L[0] || 'none';
            if (cnt[L[0]] || L[0] === 'NB' || L[0] === 'TH' || L[0] === 'VD' || lvFilter === code)
                h += '<button class="bk-fc' + (lvFilter === code ? ' on' : '') + '" data-lvf="' + code + '">' + L[2] + ' <span>(' + cnt[L[0]] + ')</span></button>';
        });
        h += '</div>';
        var nm = B.numMap(ordered), ctx = { nm: nm };
        window.LVSO = window.LVSO || {};
        LVL.forEach(function (L) {
            var code = L[0] || 'none', main = (L[0] === 'NB' || L[0] === 'TH' || L[0] === 'VD');
            if (lvFilter === 'all' ? !(cnt[L[0]] || main) : lvFilter !== code) return;
            h += '<div class="bk-lvh bk-lvh-' + code + '">' + L[1] + ' <span>(' + cnt[L[0]] + ' câu)</span></div>';
            var items = ordered.filter(function (o) { return o._lv === L[0]; });
            if (!items.length) { h += '<div class="bk-lve">Chưa có câu hỏi ở mức độ này.' + (stu ? '' : ' Chọn mức độ ở mục "🎯 Mức độ" của từng câu để phân loại.') + '</div>'; return; }
            var lastT = null;
            h += '<div class="qc-live">';
            items.forEach(function (q) {
                if (window.LVSO[q.id] !== true) window.LVSO[q.id] = false;   /* [CODE145] mặc định ẨN hướng dẫn; chỉ mở khi giáo viên bấm "XEM HƯỚNG DẪN" */
                if (q.type !== lastT) { h += B.partHd(q.type); lastT = q.type; }
                if (!stu && q._oi === editIdx) { h += editFormHtml(qs[q._oi], q._oi, q.type, (nm[q.id] || {}).num || ''); return; }
                var k = { correct: q.correct, tf: q.tfAnswers, sa: q.shortAnswer, sol: q.solution || '', tfSol: q.tfSol || [] };
                var a = q.type === 'sa' ? { value: String(q.shortAnswer == null ? '' : q.shortAnswer) } : null;
                var c = B.card(q, a, k, null, false, ctx, {});
                if (!stu) c = c.replace(/^<div[^>]*>/, function (m) {
                    var sel = LVL.map(function (V) { return '<option value="' + V[0] + '"' + (V[0] === q._lv ? ' selected' : '') + '>' + (V[0] ? V[2] : 'Chưa chọn') + '</option>'; }).join('');
                    return m + '<div class="bk-ctb"><label class="bk-lsl">🎯 Mức độ <select class="bk-lsel" data-qlv="' + q._oi + '">' + sel + '</select></label><span class="bk-sp"></span><button class="bk-b" data-qedit="' + q._oi + '">✏️ Chỉnh sửa</button><button class="bk-b bk-rm" data-qdel="' + q._oi + '">🗑 Xóa</button></div>';
                });
                h += c;
            });
            h += '</div>';
        });
        return h + '<div class="bk-ver">Phiên bản CODE145 • Hướng dẫn giải mặc định ẩn – bấm "XEM HƯỚNG DẪN" ở từng câu để hiện</div></div>';
    }
    function setLevel(i, v, sel) {
        var key = path.join('|'), qs = getQuestions(key), q = qs[i];
        if (!q) return;
        if (editIdx >= 0 && editDirty) { alert('Hãy lưu hoặc hủy câu đang chỉnh sửa trước khi đổi mức độ câu khác.'); if (sel) sel.value = lvOf(q); return; }
        if (v) q.level = v; else delete q.level;
        if (!saveQuestions(key, qs)) { alert('Không lưu được thay đổi (bộ nhớ trình duyệt đầy).'); return; }
        render(true);
    }
    /* [CODE141] SỬA TRỰC TIẾP: bấm "Chỉnh sửa" => thẻ câu hỏi đó chuyển thành biểu mẫu ngay tại chỗ (ảnh/bảng nhúng được rút gọn thành [[HÌNH n]]) */
    var editIdx = -1, editHolder = [], editDirty = false;
    var MASK_RE = /@@(?:IMG|TBL)_[A-Za-z0-9+\/=_-]+(?:~\d+x\d+)?@@|<img\b[^>]*>/gi;
    function maskT(t) {
        return String(t == null ? '' : t).replace(MASK_RE, function (tk) {
            var i = editHolder.indexOf(tk); if (i < 0) { editHolder.push(tk); i = editHolder.length - 1; }
            return (tk.slice(0, 5) === '@@TBL' ? '[[BẢNG ' : '[[HÌNH ') + (i + 1) + ']]';
        });
    }
    function unmaskT(t) { return String(t == null ? '' : t).replace(/\[\[(?:HÌNH|BẢNG) (\d+)\]\]/g, function (m, n) { return editHolder[n - 1] || m; }); }
    function taField(name, val, rows) {
        return '<textarea class="bk-ta2" data-f="' + name + '" rows="' + (rows || 2) + '" spellcheck="false">' + esc(maskT(val)) + '</textarea><div class="bk-pv math-content"></div>';
    }
    function autosize(ta) { ta.style.height = 'auto'; ta.style.height = (ta.scrollHeight + 2) + 'px'; }
    function preview(ta) {
        var pv = ta.nextElementSibling; if (!pv || !pv.classList.contains('bk-pv')) return;
        var raw = ta.value;
        if (!raw.trim() || !/[$\\@<^_]|\[\[/.test(raw)) { pv.style.display = 'none'; pv.innerHTML = ''; return; }
        pv.innerHTML = fmtQ(unmaskT(raw)); pv.style.display = 'block';
    }
    function editFormHtml(x, i, t, num) {
        var PMT = { mc: 'Phần I – Nhiều lựa chọn', tf: 'Phần II – Đúng/Sai', sa: 'Phần III – Trả lời ngắn' }, lv = x.level || '', opts = x.options || [], j;
        function lo(v, tx) { return '<option value="' + v + '"' + (lv === v ? ' selected' : '') + '>' + tx + '</option>'; }
        var h = '<div class="bk-ef" data-edit-form="' + i + '"><div class="bk-efh"><b>✏️ Đang chỉnh sửa Câu ' + num + '</b><span class="bk-efp">' + PMT[t] + '</span><span class="bk-sp"></span>' +
            '<label>🎯 Mức độ <select data-f="level">' + lo('', 'Chưa chọn') + lo('NB', 'Nhận biết') + lo('TH', 'Thông hiểu') + lo('VD', 'Vận dụng') + lo('VDC', 'Vận dụng cao') + '</select></label></div>';
        if (x.ginfo) h += '<div class="bk-el">🔗 Thông tin chung của nhóm câu</div>' + taField('ginfo', x.ginfo, 3);
        h += '<div class="bk-el">Nội dung câu hỏi</div>' + taField('text', x.text, 3);
        if (t === 'mc') {
            h += '<div class="bk-el">Các phương án (chọn ◉ ở đáp án đúng)</div>';
            for (j = 0; j < opts.length; j++) h += '<div class="bk-eo"><label class="bk-er"><input type="radio" name="bk-correct" value="' + esc(opts[j].letter) + '"' + (opts[j].letter === x.correct ? ' checked' : '') + '><b>' + esc(opts[j].letter) + '.</b></label><div class="bk-ec">' + taField('opt' + j, opts[j].text, 1) + '</div></div>';
        } else if (t === 'tf') {
            h += '<div class="bk-el">Các ý a), b), c), d)</div>';
            for (j = 0; j < 4; j++) {
                var ok = !!(x.tfAnswers && x.tfAnswers[j]);
                h += '<div class="bk-eo"><b class="bk-etl">' + 'abcd'.charAt(j) + ')</b><div class="bk-ec">' + taField('opt' + j, opts[j] ? opts[j].text : '', 1) +
                    '<div class="bk-etr"><label><input type="radio" name="bk-tf' + j + '" value="1"' + (ok ? ' checked' : '') + '> Đúng</label><label><input type="radio" name="bk-tf' + j + '" value="0"' + (ok ? '' : ' checked') + '> Sai</label></div>' +
                    '<div class="bk-es">Giải thích ý ' + 'abcd'.charAt(j) + ') (nếu có)</div>' + taField('tfsol' + j, (x.tfSol && x.tfSol[j]) || '', 1) + '</div></div>';
            }
        } else {
            h += '<div class="bk-el">Đáp án (trả lời ngắn)</div><input class="bk-ei" data-f="sa" value="' + esc(x.shortAnswer == null ? '' : x.shortAnswer) + '">';
        }
        h += '<div class="bk-el">📖 Lời giải / Hướng dẫn giải' + (t === 'tf' ? ' chung' : '') + ' (nếu có)</div>' + taField('sol', x.solution || '', 3);
        return h + '<div class="bk-eb"><button class="bk-b bk-up" data-qsave="1">💾 Lưu thay đổi</button><button class="bk-b" data-qcancel="1">Hủy</button></div></div>';
    }
    function editQ(i) {
        if (editIdx === i) return;
        if (editIdx >= 0 && editDirty && !confirm('Câu đang sửa chưa được lưu. Bỏ thay đổi và sửa câu khác?')) return;
        editIdx = i; editHolder = []; editDirty = false; render(true);
        var f = body.querySelector('[data-edit-form]');
        if (f) { try { f.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} var tx = f.querySelector('[data-f="text"]'); if (tx) { try { tx.focus({ preventScroll: true }); } catch (e) { tx.focus(); } } }
    }
    function cancelEdit() {
        if (editDirty && !confirm('Bỏ các thay đổi chưa lưu của câu này?')) return;
        editIdx = -1; editDirty = false; render(true);
    }
    function saveEdit() {
        var key = path.join('|'), qs = getQuestions(key), q = qs[editIdx], f = body.querySelector('[data-edit-form]'), j;
        if (!q || !f) return;
        function g(n) { var e = f.querySelector('[data-f="' + n + '"]'); return e ? unmaskT(e.value) : ''; }
        var t = (q.type === 'tf' || q.type === 'sa') ? q.type : 'mc';
        if (!g('text').trim()) { alert('Nội dung câu hỏi không được để trống.'); return; }
        if (t === 'sa' && !g('sa').trim()) { alert('Hãy nhập đáp án của câu trả lời ngắn.'); return; }
        q.text = g('text').trim();
        var lv = g('level'); if (lv) q.level = lv; else delete q.level;
        if (f.querySelector('[data-f="ginfo"]')) { var gi = g('ginfo').trim(); if (gi) q.ginfo = gi; else delete q.ginfo; }
        if (t === 'mc') {
            (q.options || []).forEach(function (o, k) { o.text = g('opt' + k).trim(); });
            var r = f.querySelector('input[name="bk-correct"]:checked'); if (r) q.correct = r.value;
        } else if (t === 'tf') {
            q.options = q.options || []; q.tfAnswers = q.tfAnswers || [];
            for (j = 0; j < 4; j++) {
                if (!q.options[j]) q.options[j] = { letter: 'abcd'.charAt(j), text: '' };
                q.options[j].text = g('opt' + j).trim();
                var rt = f.querySelector('input[name="bk-tf' + j + '"]:checked'); q.tfAnswers[j] = !!(rt && rt.value === '1');
            }
            var ts = [0, 1, 2, 3].map(function (k) { return g('tfsol' + k).trim(); });
            if (ts.some(Boolean)) q.tfSol = ts; else delete q.tfSol;
        } else { q.shortAnswer = g('sa').trim(); }
        var so = g('sol').trim(); if (so) q.solution = so; else delete q.solution;
        if (!saveQuestions(key, qs)) { alert('Không lưu được thay đổi (bộ nhớ trình duyệt đầy).'); return; }
        editIdx = -1; editDirty = false; render(true);
        status('Đã lưu câu hỏi.'); setTimeout(unstatus, 1800);
    }
    function delAllQ() {
        var key = path.join('|'), qs = getQuestions(key);
        if (!qs.length) return;
        if (!confirm('Xóa TOÀN BỘ ' + qs.length + ' câu hỏi của bài "' + lessonName(path) + '" khỏi ngân hàng đề?\nThao tác này không thể hoàn tác.')) return;
        if (!confirm('Xác nhận lần cuối: xóa toàn bộ câu hỏi của bài này?')) return;
        removeQuestions(key); editIdx = -1;
        path.pop(); render();   /* quay về danh sách bài (bài học vẫn giữ nguyên, chỉ xóa câu hỏi) */
        status('Đã xóa toàn bộ câu hỏi của bài.'); setTimeout(unstatus, 2500);
    }
    function delQ(i) {
        var key = path.join('|'), qs = getQuestions(key), rm = qs[i];
        if (!rm || !confirm('Xóa câu hỏi này khỏi ngân hàng đề?')) return;
        editIdx = -1; resetSol();
        qs.splice(i, 1);
        if (rm.gid && rm.ginfo) { for (var k = 0; k < qs.length; k++) if (qs[k].gid === rm.gid) { if (!qs[k].ginfo) qs[k].ginfo = rm.ginfo; break; } }
        qs.forEach(function (x, k) { x.id = k + 1; });
        if (!qs.length) { removeQuestions(key); path.pop(); render(); return; }
        if (!saveQuestions(key, qs)) { alert('Không lưu được thay đổi (bộ nhớ trình duyệt đầy).'); return; }
        render(true);
    }
    function render(keep) {
        if (!body) return;
        if (path.length < 3) editIdx = -1;
        var top = keep ? body.scrollTop : 0, h = BS.barHtml() + crumb(), stu = isStu();
        if (!path.length) {
            var l = subjects();
            if (!stu) h += '<div class="bk-tools"><b>Chọn môn học</b><span><button class="bk-b" data-bkexp="1" title="Tải file sao lưu toàn bộ ngân hàng đề về máy">💾 Sao lưu ngân hàng đề</button><button class="bk-b" data-bkimp="1" title="Khôi phục từ file sao lưu">📥 Khôi phục</button></span></div>';
            h += '<div class="bk-grid">' + l.map(function (n, i) {
                return '<div class="bk-card" data-sj="' + esc(n) + '"><div class="bk-ic">' + info(n)[1] + '</div><div class="bk-nm">' + esc(n) + '</div><div class="bk-sub">' + info(n)[2].length + ' khối lớp</div>' +
                    (stu ? '' : '<div class="bk-mvw"><button type="button" class="bk-mv" data-mvs="' + esc(n) + '" data-d="-1" title="Chuyển môn học lên trước"' + (i === 0 ? ' disabled' : '') + '>◀</button><button type="button" class="bk-mv" data-mvs="' + esc(n) + '" data-d="1" title="Chuyển môn học ra sau"' + (i === l.length - 1 ? ' disabled' : '') + '>▶</button></div>') + '</div>';   /* [CODE158] hiện lại nút di chuyển môn học (máy tính) */
            }).join('') + '</div>';
        } else if (path.length === 1) {
            h += '<div class="bk-grid">' + info(path[0])[2].map(function (g) {
                var c = lessons(path[0], g).filter(function (x) { return !x.h; }).length;
                return '<div class="bk-card" data-gr="' + g + '"><div class="bk-ic">📁</div><div class="bk-nm">' + esc(path[0]) + ' ' + g + '</div><div class="bk-sub">' + (c ? c + ' bài học' : 'Chưa có danh sách bài') + '</div></div>';
            }).join('') + '</div>';
        } else if (path.length === 2) {
            var sj = path[0], g = path[1], arr = lessons(sj, g), n = 0;
            var allQ = 0; arr.forEach(function (x) { if (!x.h) allQ += st.q[sj + '|' + g + '|' + x.id] || 0; });
            h += '<div class="bk-root"><span class="bk-rootn">' + esc(sj) + ' ' + g + '</span>' + (stu && allQ ? '<button class="bk-b bk-rootgo" data-allprac="1">ÔN LUYỆN</button>' : '') + (stu ? '' : '<span class="bk-rootb">' + (allQ ? '<button class="bk-b bk-xw" data-xwr="1" title="Xuất file Word cho cả môn học (chọn chương / bài trong trang xuất)">📄 Xuất file word</button>' : '') + '<button class="bk-b" data-file="1">📎 Thêm danh sách từ file (Word, Excel, PDF, ảnh)</button><button class="bk-b" data-add="1">➕ Thêm / dán danh sách bài</button>' + (st.lessons[sj + '|' + g] && CUR[sj + '|' + g] ? '<button class="bk-b" data-reset="1">↺ Mặc định</button>' : '') + '</span>') + '</div>';
            if (!arr.length) h += '<div class="bk-empty"><b>Chưa có danh sách bài học</b><span>' + (stu ? 'Giáo viên sẽ cập nhật sớm.' : 'Bấm "➕ Thêm / dán danh sách bài" để nhập các bài học của lớp này.') + '</span></div>';
            h += arr.map(function (x, ai) {
                if (x.h) {
                    var cq = 0; for (var z = ai + 1; z < arr.length && !arr[z].h; z++) cq += st.q[sj + '|' + g + '|' + arr[z].id] || 0;
                    return '<div class="bk-ch"><span class="bk-chn">' + esc(x.n) + '</span>' + (stu && cq ? '<button class="bk-b bk-go" data-chap="' + x.id + '">ÔN LUYỆN</button>' : '') + (stu ? '' : ' <button class="bk-i" data-ren="' + x.id + '">✏️</button><button class="bk-i" data-del="' + x.id + '">🗑</button>') + '</div>'; }
                n++; var key = sj + '|' + g + '|' + x.id, q = st.q[key] || 0;
                return '<div class="bk-ls"><span class="bk-no">' + n + '</span><span class="bk-ln">' + esc(x.n) + '' + '</span>' +
                    (stu ? (q ? '<button class="bk-b bk-go" data-act2="' + x.id + '">ÔN LUYỆN</button>' : '') :
                    '<button class="bk-i" data-ren="' + x.id + '">✏️</button><button class="bk-i" data-del="' + x.id + '">🗑</button>' + (q ? '<button class="bk-b bk-vw" data-view="' + x.id + '">👁 Xem câu hỏi</button>' : '') + '<button class="bk-b ' + (q ? 'bk-up' : 'bk-go') + '" data-act2="' + x.id + '">' + (q ? 'Cập nhật ngân hàng đề' : 'Tạo ngân hàng đề') + '</button>') + '</div>';
            }).join('');
        } else { h += viewHtml(); }
        body.innerHTML = h; body.scrollTop = top;
        if (editIdx >= 0) body.querySelectorAll('[data-edit-form] textarea.bk-ta2').forEach(function (ta) { autosize(ta); preview(ta); });
        body.querySelectorAll('.bk-view img').forEach(markFig);
    }
    /* [CODE136] Thêm danh sách bài TỪ FILE: Word (.docx), Excel (.xlsx/.xls/.csv), PDF, ảnh (OCR tiếng Việt). Chạy hoàn toàn trên trình duyệt (GitHub Pages). */
    var URL_PDF = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js', URL_PDFW = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
        URL_TESS = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js', URL_ZIP = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
        URL_XLS = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', NSW = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main', stEl = null;
    function lib(url, test) {
        return new Promise(function (res, rej) {
            if (test()) return res();
            var sc = document.createElement('script'); sc.src = url; sc.onload = function () { res(); };
            sc.onerror = function () { rej(new Error('Không tải được thư viện xử lý file (kiểm tra mạng): ' + url)); };
            document.head.appendChild(sc);
        });
    }
    function status(t) {
        if (!stEl) { stEl = document.createElement('div'); stEl.style.cssText = 'position:fixed;left:50%;top:18px;transform:translateX(-50%);z-index:120;background:#9a3412;color:#fff;padding:10px 18px;border-radius:12px;font:700 15px Roboto,Arial,sans-serif;box-shadow:0 6px 18px rgba(0,0,0,.3);max-width:90vw;text-align:center'; document.body.appendChild(stEl); }
        stEl.textContent = t; stEl.style.display = 'block';
    }
    function unstatus() { if (stEl) stEl.style.display = 'none'; }
    function fromDocx(f) {
        return f.arrayBuffer().then(function (b) { return lib(URL_ZIP, function () { return window.JSZip; }).then(function () { return JSZip.loadAsync(b); }); })
            .then(function (z) { var e = z.file('word/document.xml'); if (!e) throw new Error('Không đọc được file Word. Hãy dùng định dạng .docx (không phải .doc cũ).'); return e.async('string'); })
            .then(function (x) {
                var d = new DOMParser().parseFromString(x, 'application/xml'), ps = d.getElementsByTagNameNS(NSW, 'p'), out = [];
                for (var i = 0; i < ps.length; i++) {
                    var ns = ps[i].getElementsByTagNameNS(NSW, '*'), t = '';
                    for (var k = 0; k < ns.length; k++) { var ln = ns[k].localName; if (ln === 't') t += ns[k].textContent; else if (ln === 'tab' || ln === 'br') t += ' '; }
                    out.push(t);
                }
                return out;
            });
    }
    function fromExcel(f) {
        return f.arrayBuffer().then(function (b) { return lib(URL_XLS, function () { return window.XLSX; }).then(function () { return XLSX.read(b, { type: 'array' }); }); })
            .then(function (wb) {
                var out = [];
                wb.SheetNames.forEach(function (n) {
                    XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, defval: '' }).forEach(function (r) { r.forEach(function (c) { c = String(c).trim(); if (c) out.push(c); }); });
                });
                return out;
            });
    }
    function ocr(srcs) {
        var idx = 0, total = srcs.length;
        return lib(URL_TESS, function () { return window.Tesseract; }).then(function () {
            status('Đang tải bộ nhận dạng chữ tiếng Việt...');
            return Tesseract.createWorker('vie', 1, { logger: function (m) { if (m.status === 'recognizing text') status('Đang nhận dạng chữ ' + idx + '/' + total + ': ' + Math.round(m.progress * 100) + '%'); } });
        }).then(function (w) {
            var acc = [], p = Promise.resolve();
            srcs.forEach(function (s) {
                p = p.then(function () { idx++; status('Đang xử lý ảnh/trang ' + idx + '/' + total + '...'); return Promise.resolve(typeof s === 'function' ? s() : s); })
                    .then(function (img) { return w.recognize(img); })
                    .then(function (r) { acc = acc.concat(r.data.text.split('\n')); });
            });
            return p.then(function () { return w.terminate(); }).then(function () { return acc; });
        });
    }
    function fromPdf(f) {
        var pdf;
        return f.arrayBuffer().then(function (b) {
            return lib(URL_PDF, function () { return window.pdfjsLib; }).then(function () {
                return fetch(URL_PDFW).then(function (r) { return r.text(); }).then(function (t) { pdfjsLib.GlobalWorkerOptions.workerSrc = URL.createObjectURL(new Blob([t], { type: 'text/javascript' })); })
                    .catch(function () { pdfjsLib.GlobalWorkerOptions.workerSrc = URL_PDFW; });
            }).then(function () { return pdfjsLib.getDocument({ data: b }).promise; });
        }).then(function (d) {
            pdf = d; var n = Math.min(d.numPages, 80), p = Promise.resolve([]);
            for (var i = 1; i <= n; i++) (function (i) {
                p = p.then(function (acc) {
                    status('Đang đọc PDF trang ' + i + '/' + n + '...');
                    return pdf.getPage(i).then(function (pg) { return pg.getTextContent(); }).then(function (c) {
                        var rows = [], y = null, cur = '';
                        c.items.forEach(function (it) { var yy = Math.round(it.transform[5]); if (y !== null && Math.abs(yy - y) > 3) { rows.push(cur); cur = ''; } y = yy; cur += (cur ? ' ' : '') + it.str; });
                        if (cur) rows.push(cur); return acc.concat(rows);
                    });
                });
            })(i);
            return p;
        }).then(function (lines) {
            if (lines.join('').replace(/\s/g, '').length >= 40) return lines;
            var n = Math.min(pdf.numPages, 10), srcs = [];   /* PDF dạng ảnh scan -> OCR */
            for (var i = 1; i <= n; i++) (function (i) {
                srcs.push(function () {
                    status('Đang chuyển trang ' + i + '/' + n + ' sang ảnh...');
                    return pdf.getPage(i).then(function (pg) { var vp = pg.getViewport({ scale: 2 }), cv = document.createElement('canvas'); cv.width = vp.width; cv.height = vp.height; return pg.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise.then(function () { return cv; }); });
                });
            })(i);
            return ocr(srcs);
        });
    }
    /* Phân tích các dòng chữ -> danh sách chương (#) và bài học */
    function parseLines(lines) {
        var chRe = /^(chương|chủ đề|chuyên đề|phần|chapter|part|module)\s+([ivxlcdm]+|\d+)(?![a-zà-ỹ])/i,
            junk = /^(mục lục|trang|stt|tt|nội dung|tên bài|bài học|chương|chủ đề|page|contents|table of contents|lớp \d+)$/i, out = [];
        lines.forEach(function (l) {
            l = String(l).replace(/[\u00a0\t]+/g, ' ').replace(/\s+/g, ' ').trim()
                .replace(/\s*[\.…·_\-–]{3,}\s*\d*\s*$/, '').replace(/^[•●▪■◦*]\s*/, '').replace(/^[-–]\s+/, '').trim();
            if (l.length < 3 || /^[\d\s\.\-–,;:]+$/.test(l) || junk.test(l) || /^(trang|page)\s*\d+$/i.test(l) || l.length > 160) return;
            var isCh = chRe.test(l), prev = out[out.length - 1];
            if (!isCh && prev && !prev.ch && /^[a-zà-ỹ]/.test(l) && prev.t.length < 140) { prev.t += ' ' + l; return; }   /* dòng bị xuống hàng */
            if (prev && prev.t === l) return;
            out.push({ ch: isCh, t: l });
        });
        return out.map(function (x) { return (x.ch ? '#' : '') + x.t; }).join('\n');
    }
    function fExt(f) { return (f.name.split('.').pop() || '').toLowerCase(); }
    function isImg(f) { return /^(png|jpe?g|webp|bmp|gif)$/.test(fExt(f)) || /^image\//.test(f.type || ''); }
    function readOne(f) {
        var ext = fExt(f);
        if (ext === 'docx') return fromDocx(f);
        if (ext === 'xlsx' || ext === 'xls' || ext === 'csv') return fromExcel(f);
        if (ext === 'pdf') return fromPdf(f);
        return Promise.reject(new Error('Chưa hỗ trợ định dạng "' + f.name + '". Hãy chọn Word (.docx), Excel, PDF hoặc ảnh.'));
    }
    function handleFiles(list, sj, g, arr) {
        var files = Array.prototype.slice.call(list).sort(function (a, b) { return a.name.localeCompare(b.name, 'vi', { numeric: true }); }), groups = [];
        files.forEach(function (f) { var l = groups[groups.length - 1]; if (isImg(f) && l && l.img) l.f.push(f); else groups.push({ img: isImg(f), f: [f] }); });
        var p = Promise.resolve([]);
        groups.forEach(function (gr) {
            p = p.then(function (acc) {
                status('Đang đọc ' + (gr.img ? gr.f.length + ' ảnh' : gr.f[0].name) + '...');
                return (gr.img ? ocr(gr.f) : readOne(gr.f[0])).then(function (l) { return acc.concat(l); });
            });
        });
        p.then(function (lines) {
            unstatus(); var txt = parseLines(lines);
            if (!txt) { alert('Không tìm thấy danh sách bài trong file. Với ảnh/PDF scan, hãy chụp rõ nét hơn hoặc dán danh sách thủ công.'); return; }
            bulk(sj, g, arr, txt);
        }).catch(function (err) { unstatus(); console.error(err); alert('Không đọc được file: ' + (err && err.message ? err.message : err)); });
    }
    function pickFile(sj, g, arr) {
        var inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true;   /* chọn được nhiều ảnh/file cùng lúc */
        inp.accept = '.docx,.xlsx,.xls,.csv,.pdf,image/*';
        inp.onchange = function () { if (inp.files && inp.files.length) handleFiles(inp.files, sj, g, arr); };
        inp.click();
    }
    function bulk(sj, g, arr, init) {
        var o = document.createElement('div');
        o.style.cssText = 'position:fixed;inset:0;z-index:100;background:rgba(15,23,42,.6);display:flex;align-items:center;justify-content:center;padding:12px';
        o.innerHTML = '<div style="background:#fff;border-radius:16px;padding:16px;width:100%;max-width:640px;font-family:Roboto,Arial,sans-serif"><b style="color:#9a3412;font-size:17px">Thêm bài: ' + esc(sj) + ' ' + g + '</b>' +
            '<p style="font-size:13px;color:#64748b;margin:6px 0">Mỗi dòng là một bài học. Dòng bắt đầu bằng # là tên chương. Có thể dán trực tiếp từ mục lục sách.' + (init ? ' <b style="color:#b45309">Danh sách dưới đây do phần mềm tự phân tích từ file - hãy kiểm tra và sửa trước khi thêm.</b>' : '') + '</p>' +
            '<textarea id="bk-ta" style="width:100%;height:260px;border:2px solid #fdba74;border-radius:10px;padding:8px;font-size:15px" placeholder="#Chương 1. ...&#10;Bài 1. ...&#10;Bài 2. ..."></textarea>' +
            '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px;flex-wrap:wrap"><button class="bk-b" id="bk-x">Hủy</button><button class="bk-b" id="bk-r">Thay toàn bộ</button><button class="bk-b bk-go" id="bk-a">Thêm vào cuối</button></div></div>';
        document.body.appendChild(o);
        var ta = o.querySelector('#bk-ta'); if (init) ta.value = init; ta.focus();
        function done(rep) {
            var add = ta.value.split('\n').map(function (x) { return x.trim(); }).filter(Boolean).map(function (t, i) {
                var h = t.charAt(0) === '#'; return { id: 'x' + Date.now() + '_' + i, h: h ? 1 : 0, n: h ? t.slice(1).trim() : t };
            });
            if (add.length) { setL(sj, g, rep ? add : arr.concat(add)); render(true); }
            o.remove();
        }
        o.querySelector('#bk-x').onclick = function () { o.remove(); };
        o.querySelector('#bk-a').onclick = function () { done(false); };
        o.querySelector('#bk-r').onclick = function () { done(true); };
    }
    function up() { if (path.length) { path.pop(); render(); return true; } return false; }
    /* [CODE154] đảm bảo câu hỏi đã có trên máy (học sinh) rồi mới mở ÔN LUYỆN */
    function withQ(keys, fn) {
        var miss = isStu() ? keys.filter(function (k) { return (st.q[k] || 0) > 0 && !getQuestions(k).length; }) : [];
        if (!miss.length) { fn(); return; }
        status('⟳ Đang tải câu hỏi từ giáo viên…');
        BS.fetchLessons(miss).then(function () { unstatus(); fn(); }, function (er) {
            unstatus();
            var m = 'Chưa tải được câu hỏi (' + (er && er.message ? er.message : 'lỗi mạng') + '). Em kiểm tra mạng rồi bấm lại nhé.';
            if (window.prNotice) window.prNotice('Chưa tải được câu hỏi', m); else alert(m);
        });
    }
    /* [CODE155] Gom bài theo chương. upToId = chỉ lấy từ chương đầu đến hết chương upToId (chương đã học + chương đang chọn) */
    function buildChapters(arr, sj, g, upToId) {
        var list = [], cur = null, done = false;
        for (var i = 0; i < arr.length; i++) {
            var x = arr[i];
            if (x.h) {
                if (done) break;
                cur = { id: x.id, name: x.n, items: [] }; list.push(cur);
                if (upToId && x.id === upToId) done = true;
            } else {
                if (!cur) { cur = { id: '_0', name: 'Các bài chưa thuộc chương', items: [] }; list.push(cur); }
                cur.items.push({ key: sj + '|' + g + '|' + x.id, name: x.n });
            }
        }
        return list;
    }
    function fillChapterPools(chs) {
        chs.forEach(function (c) {
            c.pools = [];
            c.items.forEach(function (it) { var qq = getQuestions(it.key); if (qq.length) c.pools.push({ key: it.key, lesson: it.name, qs: qq }); });
        });
    }
    function onClick(e) {
        try { onClick0(e); } catch (er) { console.error(er); try { if (window.prNotice) window.prNotice('Có lỗi xảy ra', String(er && er.message || er)); } catch (e2) {} }
    }
    function onClick0(e) {
        var t = e.target, q = function (s) { return t.closest ? t.closest(s) : null; }, b;
        if ((b = q('[data-bksync]'))) { BS.manual(b.getAttribute('data-bksync')); return; }
        if ((b = q('[data-go]'))) { path = path.slice(0, +b.getAttribute('data-go')); render(); return; }
        if ((b = q('[data-mvs]'))) { if (!b.disabled && !isStu()) moveSubj(b.getAttribute('data-mvs'), +b.getAttribute('data-d')); return; }   /* [CODE158] */
        if ((b = q('[data-sj]'))) { path = [b.getAttribute('data-sj')]; render(); return; }
        if ((b = q('[data-gr]'))) { path = [path[0], +b.getAttribute('data-gr')]; render(); return; }
        if (q('[data-bkexp]')) { exportBank(); return; }
        if (q('[data-bkimp]')) { importBank(); return; }
        if (path.length < 2) return;
        var sj = path[0], g = path[1], arr = lessons(sj, g).slice(), id;
        if ((b = q('[data-allprac]'))) {   /* [CODE155] ÔN LUYỆN toàn bộ: học sinh tick chọn chương + mức độ */
            var chsA = buildChapters(arr, sj, g, null), keysA = [];
            chsA.forEach(function (c) { c.items.forEach(function (it) { keysA.push(it.key); }); });
            withQ(keysA, function () {
                fillChapterPools(chsA);
                if (window.openPracticeSetup) window.openPracticeSetup({ subject: sj, grade: g, scope: 'toàn bộ', title: sj + ' ' + g, chapters: chsA, defaultChapters: [] });
            });
            return;
        }
        if ((b = q('[data-view]'))) { path = [sj, g, b.getAttribute('data-view')]; lvFilter = 'all'; resetSol(); render(); return; }
        if ((b = q('[data-lvf]'))) { lvFilter = b.getAttribute('data-lvf'); render(true); return; }
        if (q('[data-qdelall]')) { delAllQ(); return; }
        if ((b = q('[data-qedit]'))) { editQ(+b.getAttribute('data-qedit')); return; }
        if (q('[data-qsave]')) { saveEdit(); return; }
        if (q('[data-qcancel]')) { cancelEdit(); return; }
        if ((b = q('[data-qdel]'))) { delQ(+b.getAttribute('data-qdel')); return; }
        if (q('[data-file]')) { pickFile(sj, g, arr); } else if (q('[data-add]')) { bulk(sj, g, arr);
        } else if (q('[data-reset]')) { if (confirm('Khôi phục danh sách bài mặc định?')) { delete st.lessons[sj + '|' + g]; save(); render(); } }
        else if ((b = q('[data-ren]'))) { id = b.getAttribute('data-ren'); var it = arr.filter(function (x) { return x.id === id; })[0]; var v = prompt('Đổi tên:', it.n); if (v && v.trim()) { it.n = v.trim(); setL(sj, g, arr); render(true); } }
        else if ((b = q('[data-del]'))) { id = b.getAttribute('data-del'); if (confirm('Xóa mục này khỏi danh sách? (Câu hỏi đã lưu trong ngân hàng của bài này cũng sẽ bị xóa)')) { removeQuestions(sj + '|' + g + '|' + id); setL(sj, g, arr.filter(function (x) { return x.id !== id; })); render(true); } }
        else if ((b = q('[data-chap]'))) {   /* [CODE155] ÔN LUYỆN chương: hiện các chương đã học (1..n) + chương đang chọn */
            id = b.getAttribute('data-chap');
            var chsC = buildChapters(arr, sj, g, id), keysC = [], ctitle = '';
            chsC.forEach(function (c) { if (c.id === id) ctitle = c.name; c.items.forEach(function (it) { keysC.push(it.key); }); });
            withQ(keysC, function () {
                fillChapterPools(chsC);
                if (window.openPracticeSetup) { window.openPracticeSetup({ subject: sj, grade: g, scope: 'chương', title: ctitle, chapters: chsC, defaultChapters: [id] }); }
            });
        }
        else if ((b = q('[data-act2]'))) {
            id = b.getAttribute('data-act2'); var ls = arr.filter(function (x) { return x.id === id; })[0], key = sj + '|' + g + '|' + id;
            var inf = { key: key, subject: sj, grade: g, lessonId: id, lesson: ls.n, count: st.q[key] || 0, mode: st.q[key] ? 'update' : 'create' };
            if (typeof API.onLessonAction === 'function') API.onLessonAction(inf);
            else if (isStu()) { withQ([key], function () { if (window.startBankPractice) window.startBankPractice(inf, getQuestions(key)); }); }
            else if (window.openBankEditor) window.openBankEditor(inf);   /* [CODE138] mở khung soạn đề (ẩn Bài học/Lớp/Môn) */
            else alert('Chưa tải xong trình soạn đề, vui lòng thử lại.');
        }
    }
    function init(bodyEl) {
        if (!document.getElementById('code129-css')) {
            var c = document.createElement('style'); c.id = 'code129-css';
            c.textContent = '.bk-crumb{font-size:14px;margin-bottom:12px;color:#64748b;font-weight:700}.bk-crumb a{color:#c2410c;cursor:pointer;text-decoration:underline}.bk-crumb b{color:#0f172a}' +
                '.bk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}.bk-card{position:relative;background:#fff7ed;border:2px solid #fdba74;border-radius:16px;padding:14px;cursor:pointer;text-align:center;transition:.15s}.bk-card:hover{background:#ffedd5;transform:translateY(-2px);box-shadow:0 6px 14px rgba(234,88,12,.2)}' +
                '.bk-ic{font-size:34px}.bk-nm{font-weight:900;font-size:16px;color:#9a3412;margin-top:4px}.bk-sub{font-size:13px;color:#64748b;margin-top:2px}.bk-mvw{display:flex;gap:6px;justify-content:center;margin-top:8px}' +
                '.bk-mv{width:36px;height:30px;border-radius:10px;border:1px solid #cbd5e1;background:#fff;font-weight:900;cursor:pointer}.bk-mv:disabled{opacity:.3;cursor:not-allowed}' +
                '.bk-tools{display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px;font-size:18px;color:#9a3412}.bk-tools span{display:flex;gap:6px}' +
                '.bk-b{border:0;border-radius:10px;padding:7px 12px;font-weight:900;font-size:14px;cursor:pointer;background:#e2e8f0;color:#334155}.bk-go{background:linear-gradient(90deg,#f59e0b,#ea580c);color:#fff}.bk-up{background:linear-gradient(90deg,#16a34a,#15803d);color:#fff}' +
                '.bk-ch{margin:14px 0 6px;padding:8px 12px;border-radius:10px;background:#fed7aa;color:#7c2d12;font-weight:900}.bk-ls{display:flex;align-items:center;gap:8px;padding:9px 10px;border-bottom:1px solid #e2e8f0;flex-wrap:wrap}' +
                '.bk-no{flex:0 0 28px;height:28px;border-radius:50%;background:#ea580c;color:#fff;font-weight:900;display:flex;align-items:center;justify-content:center;font-size:13px}.bk-ln{flex:1 1 200px;min-width:0;font-weight:700;color:#0f172a}.bk-ln em{color:#15803d;font-style:normal;font-size:13px}' +
                '.bk-i{border:0;background:transparent;cursor:pointer;font-size:16px;padding:2px 4px}body.layout-portrait .bk-ls .bk-go,body.layout-portrait .bk-ls .bk-up,body.layout-portrait .bk-ls .bk-vw{flex:1 0 100%}' +
                '#bank-modal .bk-view .qc-live,#bank-modal .bk-view .qc-live *:not(.katex):not(.katex *),#bank-modal .bk-view .bk-ta2,#bank-modal .bk-view .bk-ei,#bank-modal .bk-view .bk-pv,#bank-modal .bk-view .bk-pv *:not(.katex):not(.katex *){font-family:Roboto,Arial,"Helvetica Neue",sans-serif !important}' +
                '#bank-modal#bank-modal .bk-view .bk-tools,#bank-modal#bank-modal .bk-view .bk-tools *,#bank-modal#bank-modal .bk-view .bk-b,#bank-modal#bank-modal .bk-view .bk-lvh,#bank-modal#bank-modal .bk-view .bk-lvh *,#bank-modal#bank-modal .bk-view .bk-lve,#bank-modal#bank-modal .bk-view .bk-flt,#bank-modal#bank-modal .bk-view .bk-flt *,#bank-modal#bank-modal .bk-view .bk-ctb,#bank-modal#bank-modal .bk-view .bk-ctb *,#bank-modal#bank-modal .bk-view .bk-efh,#bank-modal#bank-modal .bk-view .bk-efh *,#bank-modal#bank-modal .bk-view .bk-el,#bank-modal#bank-modal .bk-view .bk-es,#bank-modal#bank-modal .bk-view .bk-eb,#bank-modal#bank-modal .bk-view .bk-eb *,#bank-modal#bank-modal .bk-view .bk-er,#bank-modal#bank-modal .bk-view .bk-er *,#bank-modal#bank-modal .bk-view .bk-etl,#bank-modal#bank-modal .bk-view .bk-etr,#bank-modal#bank-modal .bk-view .bk-etr *,#bank-modal#bank-modal .bk-view .bk-empty,#bank-modal#bank-modal .bk-view .bk-empty *{font-family:"UTM HelvetIns","Helvetica Neue",Helvetica,Arial,sans-serif !important}' +
                '#bank-modal#bank-modal .bk-view .bk-ctb .bk-b,#bank-modal#bank-modal .bk-view .bk-ctb .bk-lsl,#bank-modal#bank-modal .bk-view .bk-ctb .bk-lsel{font-family:"UTM HelvetIns","Helvetica Neue",Helvetica,Arial,sans-serif !important}' +
                '.bk-lvh{margin:18px 0 4px;padding:9px 14px;border-radius:12px;font-weight:900;font-size:17px;letter-spacing:.3px;color:#fff;background:#64748b}.bk-lvh span{font-weight:500;font-size:14px;opacity:.9}.bk-lvh-NB{background:linear-gradient(90deg,#0ea5e9,#0369a1)}.bk-lvh-TH{background:linear-gradient(90deg,#22c55e,#15803d)}.bk-lvh-VD{background:linear-gradient(90deg,#f59e0b,#c2410c)}.bk-lvh-VDC{background:linear-gradient(90deg,#ef4444,#991b1b)}' +
                '.bk-vw{background:#e0f2fe;color:#075985}.bk-rm{background:#fee2e2;color:#b91c1c}.bk-q{border:1px solid #e2e8f0;border-radius:12px;padding:10px 12px;margin:8px 0;background:#fff}.bk-qh{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px;color:#334155}.bk-sp{flex:1}' +
                '.bk-lv{background:#dbeafe;color:#1d4ed8;font-weight:900;font-size:12px;padding:2px 8px;border-radius:999px}.bk-lv.sol{background:#fef3c7;color:#92400e}.bk-qt{white-space:pre-line;font-weight:700;color:#0f172a;margin-bottom:6px;overflow-wrap:anywhere}.bk-gi{background:#fff1f2;border:1px solid #fecdd3;border-radius:8px;padding:6px 8px;margin-bottom:6px;font-size:13px;white-space:pre-line}' +
                '.bk-op{display:grid;grid-template-columns:1fr 1fr;gap:6px}.bk-op.one{grid-template-columns:1fr}.bk-op>div{border:1px solid #e2e8f0;border-radius:8px;padding:5px 8px;font-size:14px;overflow-wrap:anywhere}.bk-op>div.ok{background:#dcfce7;border-color:#86efac}.bk-op em{font-style:normal;font-weight:900;color:#475569}body.layout-portrait .bk-op{grid-template-columns:1fr}' + 'body.layout-portrait .bk-grid{grid-template-columns:1fr 1fr}';
            document.head.appendChild(c);
        }
        body = bodyEl; modal = document.getElementById('bank-modal');
        if (!modal.__c129) {
            modal.__c129 = 1;
            body.addEventListener('click', onClick);
            body.addEventListener('load', function (e) { markFig(e.target); }, true);
            body.addEventListener('input', function (e) {
                var ta = e.target; if (!ta.closest || !ta.closest('[data-edit-form]')) return;
                editDirty = true; if (ta.classList && ta.classList.contains('bk-ta2')) { autosize(ta); preview(ta); }
            });
            body.addEventListener('change', function (e) {
                var t = e.target;
                if (t.hasAttribute && t.hasAttribute('data-qlv')) { setLevel(+t.getAttribute('data-qlv'), t.value, t); return; }
                if (t.closest && t.closest('[data-edit-form]')) editDirty = true;
            });
            /* Nút X lùi từng cấp rồi mới đóng */
            modal.addEventListener('click', function (e) {
                var b = e.target.closest && e.target.closest('[data-act="close"]');
                if (b && path.length) { e.stopPropagation(); up(); }
            }, true);
        }
        editIdx = -1; editDirty = false; lvFilter = 'all'; resetSol();
        if (!document.getElementById('code141-css')) {
            var c2 = document.createElement('style'); c2.id = 'code141-css';
            c2.textContent = '#bank-modal .bk-body{overflow-y:auto !important;overscroll-behavior:auto !important;-webkit-overflow-scrolling:touch}' +
                '#bank-modal .bk-view .qc-live{display:flex !important;flex-direction:column !important;justify-content:flex-start !important;align-items:stretch !important;gap:14px;flex:none !important;height:auto !important;min-height:0 !important;max-height:none !important;margin:0 0 8px !important;padding:0 !important;overflow:visible !important;overflow-x:visible !important;overflow-y:visible !important;overscroll-behavior:auto !important}' +
                '.bk-ctb{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:6px}.bk-lsl{font-size:14px;font-weight:700;color:#075985}.bk-lsel{border:1px solid #7dd3fc;border-radius:8px;padding:3px 6px;background:#f0f9ff;font-weight:700;font-size:14px;color:#0c4a6e;cursor:pointer}' +
                '.bk-flt{display:flex;gap:6px;flex-wrap:wrap;margin:4px 0 10px}.bk-fc{border:2px solid #cbd5e1;background:#fff;color:#334155;border-radius:999px;padding:5px 12px;font-weight:700;font-size:14px;cursor:pointer}.bk-fc span{opacity:.75;font-weight:400}.bk-fc.on{color:#fff;border-color:transparent;background:linear-gradient(90deg,#f59e0b,#ea580c)}' +
                '.bk-ver{margin:10px 0 2px;text-align:center;font-size:12px;color:#94a3b8}.bk-lve{padding:12px;color:#64748b;font-style:italic;border:1px dashed #cbd5e1;border-radius:10px;margin:6px 0 10px}' +
                '#bank-modal .bk-view img.bk-fig{display:block !important;margin:10px auto !important;max-width:100% !important;height:auto !important}' +
                '.bk-ef{border:2px solid #fb923c;background:#fffbeb;border-radius:14px;padding:12px;box-shadow:0 4px 14px rgba(234,88,12,.18)}.bk-efh{display:flex;align-items:center;gap:10px;flex-wrap:wrap;color:#9a3412;font-size:17px;margin-bottom:6px}.bk-efp{background:#ffedd5;border-radius:999px;padding:2px 10px;font-size:13px;font-weight:700}.bk-efh label{font-size:14px;font-weight:700;color:#075985}.bk-efh select{border:1px solid #7dd3fc;border-radius:8px;padding:3px 6px;background:#f0f9ff;font-weight:700}' +
                '.bk-el{margin:10px 0 4px;font-weight:900;font-size:14px;color:#7c2d12}.bk-es{margin:6px 0 3px;font-weight:700;font-size:13px;color:#64748b}' +
                '.bk-ta2,.bk-ei{width:100%;box-sizing:border-box;border:2px solid #fdba74;border-radius:10px;padding:8px 10px;font-size:18px;line-height:1.4;background:#fff;color:#0f172a;resize:vertical;overflow:hidden}.bk-ta2:focus,.bk-ei:focus{outline:none;border-color:#ea580c;box-shadow:0 0 0 3px rgba(234,88,12,.2)}' +
                '.bk-pv{display:none;margin-top:4px;padding:6px 10px;border-radius:8px;background:#f0fdf4;border:1px dashed #86efac;font-size:17px;overflow-wrap:anywhere}.bk-pv:before{content:"Xem trước: ";font-weight:900;color:#15803d;font-size:12px}' +
                '.bk-eo{display:flex;gap:8px;align-items:flex-start;margin:6px 0}.bk-er{display:flex;align-items:center;gap:4px;padding-top:10px;font-size:17px;cursor:pointer;color:#0f172a}.bk-etl{padding-top:10px;font-size:17px;color:#0f172a;width:22px}.bk-ec{flex:1;min-width:0}.bk-etr{display:flex;gap:16px;margin:6px 0 0;font-weight:700;font-size:15px}.bk-etr label{display:flex;align-items:center;gap:4px;cursor:pointer}' +
                '.bk-eb{display:flex;gap:8px;justify-content:flex-end;margin-top:12px;position:sticky;bottom:0;background:linear-gradient(180deg,rgba(255,251,235,0),#fffbeb 40%);padding-top:8px}';
            document.head.appendChild(c2);
        }
        if (!document.getElementById('code147-css')) {
            var c3 = document.createElement('style'); c3.id = 'code147-css';
            c3.textContent = '.bk-ch{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.bk-ch .bk-chn{flex:1 1 200px;min-width:0}.bk-ch .bk-go{margin-left:auto;white-space:nowrap}';
            document.head.appendChild(c3);
        }
        var kp = keepPath; keepPath = false; if (!kp) path = [];
        loadSt(); BS.onOpen(); render(kp); BS.pull(false);
    }
    /* [CODE149] ĐỒNG BỘ qua máy chủ (Firebase, nhánh s/<mã>/bank): giáo viên đẩy lên, học sinh tải về */
    var BS = (function () {
        var SY = { busy: false, pbusy: false, timer: 0, force: false, again: 0, msg: '', ok: true, poll: 0, fullOnce: false };
        var SAME = {};   /* [CODE157] dấu hiệu "bản trên máy chủ không đổi" */
        /* [CODE157] tải song song tối đa n yêu cầu (nhanh hơn trên điện thoại, không tăng dung lượng) */
        function runPool(items, fn, n) {
            var i = 0;
            function w() { if (i >= items.length) return Promise.resolve(); var it = items[i++]; return fn(it).then(w); }
            var ws = []; for (var j = 0; j < Math.min(n, items.length); j++) ws.push(w());
            return Promise.all(ws);
        }
        /* [CODE160] Nén gzip nội dung từng bài trước khi đẩy lên Firebase (giảm 30-80% dung lượng lưu trữ + băng thông tải về của học sinh).
           Bản ghi cũ (không nén) vẫn đọc được; máy quá cũ không có DecompressionStream tự nạp thư viện pako. */
        function u8b64(u) { var s = '', i = 0; for (; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
        function b64u8(b) { var bin = atob(b), u = new Uint8Array(bin.length), i = 0; for (; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
        function pack(str) {
            if (str.length < 3000 || typeof CompressionStream === 'undefined') return Promise.resolve({ d: str });
            try {
                var cs = new CompressionStream('gzip'), w = cs.writable.getWriter();
                w.write(new TextEncoder().encode(str)); w.close();
                return new Response(cs.readable).arrayBuffer().then(function (buf) {
                    var b = u8b64(new Uint8Array(buf));
                    return b.length < str.length ? { d: b, z: 'gz' } : { d: str };
                }, function () { return { d: str }; });
            } catch (e) { return Promise.resolve({ d: str }); }
        }
        function loadPako() {
            if (window.pako) return Promise.resolve(window.pako);
            return new Promise(function (res, rej) {
                var sc = document.createElement('script'); sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/pako/2.1.0/pako.min.js';
                sc.onload = function () { window.pako ? res(window.pako) : rej(new Error('pako')); }; sc.onerror = function () { rej(new Error('Trình duyệt quá cũ, hãy cập nhật trình duyệt')); };
                document.head.appendChild(sc);
            });
        }
        function unpack(o) {
            if (!o || typeof o.d !== 'string') return Promise.resolve(null);
            if (o.z !== 'gz') { try { return Promise.resolve(JSON.parse(o.d)); } catch (e) { return Promise.reject(e); } }
            var u = b64u8(o.d);
            if (typeof DecompressionStream !== 'undefined') {
                var ds = new DecompressionStream('gzip'), w = ds.writable.getWriter();
                w.write(u); w.close();
                return new Response(ds.readable).text().then(function (t) { return JSON.parse(t); });
            }
            return loadPako().then(function (p) { return JSON.parse(p.ungzip(u, { to: 'string' })); });
        }
        function api() { return window.CloudSync && window.CloudSync.api ? window.CloudSync.api : null; }
        function connected() { try { var a = api(); return !!(a && a.effStu()); } catch (e) { return false; } }
        function mk() { return 'matrix_bank_sync' + (isStu() ? '_stu' : ''); }
        function metaGet() { try { var m = JSON.parse(localStorage.getItem(mk()) || 'null'); if (m && m.k) return m; } catch (e) {} return { rev: '', k: {} }; }
        function metaSet(m) { try { localStorage.setItem(mk(), JSON.stringify(m)); } catch (e) {} }
        function hhmm() { var d = new Date(), p = function (n) { return (n < 10 ? '0' : '') + n; }; return p(d.getHours()) + ':' + p(d.getMinutes()); }
        function setMsg(t, ok) { SY.msg = t; SY.ok = ok !== false; var e = document.getElementById('bk-synctxt'); if (e) e.textContent = t; var b = document.getElementById('bk-syncbar'); if (b) { b.className = 'bk-sync ' + (SY.ok ? 'ok' : 'bad'); b.style.display = SY.ok ? 'none' : 'flex'; } }
        function barHtml() {
            var b = isStu() ? '<button class="bk-b" data-bksync="pull">⟳ Cập nhật</button>' : '<button class="bk-b" data-bksync="push">☁ Đồng bộ lên</button><button class="bk-b" data-bksync="pull">⬇ Tải về</button>';
            return '<div id="bk-syncbar" class="bk-sync ' + (SY.ok ? 'ok' : 'bad') + '" style="display:' + (SY.ok ? 'none' : 'flex') + '"><span id="bk-synctxt">' + esc(SY.msg) + '</span>' + b + '</div>';
        }
        function hasLocal() { return Object.keys(readQ()).length > 0 || Object.keys(st.lessons || {}).length > 0; }
        function noConn() {
            setMsg(isStu() ? '⚠ Chưa kết nối với giáo viên nên chưa tải được ngân hàng đề. Em hãy mở bằng liên kết / mã QR do giáo viên gửi.' : '⚠ Chưa kết nối máy chủ: ngân hàng đề mới chỉ lưu trên máy này, học sinh chưa thấy. Hãy bấm ĐỒNG BỘ và dán Mã kết nối.', false);
        }
        /* ---- giáo viên: đẩy lên ---- */
        function push(force) {
            if (isStu()) return Promise.resolve();
            if (!connected()) { noConn(); return Promise.resolve(); }
            if (SY.busy) { SY.again = force ? 2 : (SY.again || 1); return Promise.resolve(); }
            SY.busy = true; setMsg('☁ Đang đồng bộ lên máy chủ…', true);
            var a = api(), Q = readQ(), M = metaGet(), keys = Object.keys(Q), newK = {}, del = {}, chain = Promise.resolve();
            var rev = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
            /* [CODE157] chỉ lấy DANH SÁCH KHÓA (shallow) để dọn bài đã xóa, không tải cả bản mục lục nặng */
            if (force) chain = chain.then(function () { return a.req('GET', 's', 'bank/lq?shallow=true'); }).then(function (r) {
                if (r) { var have = {}; keys.forEach(function (k) { have[a.enc(k)] = 1; }); Object.keys(r).forEach(function (ek) { if (!have[ek]) del[ek] = null; }); }
            });
            keys.forEach(function (k) {
                var t = Q[k].t || 0; newK[k] = t;
                if (!force && M.k[k] === t) return;
                chain = chain.then(function () { return pack(JSON.stringify(Q[k].q || [])).then(function (pk) { var body = { k: k, t: t, d: pk.d }; if (pk.z) body.z = pk.z; return a.req('PUT', 's', 'bank/lq/' + a.enc(k) + '?print=silent', body); }); });   /* [CODE160] nén gzip */
            });
            chain = chain.then(function () {
                Object.keys(M.k).forEach(function (k) { if (!(k in Q)) del[a.enc(k)] = null; });
                if (Object.keys(del).length) return a.req('PATCH', 's', 'bank/lq?print=silent', del);
            }).then(function () {
                var ik = {}; keys.forEach(function (k) { ik[a.enc(k)] = { k: k, t: newK[k] }; });
                return a.req('PUT', 's', 'bank/idx?print=silent', { rev: rev, ts: Date.now(), state: JSON.stringify(st), keys: ik })
                    .then(function () { return a.req('PUT', 's', 'bank/rev?print=silent', rev).catch(function () { }); });   /* [CODE157] nút "rev" nhỏ xíu để máy học sinh kiểm tra có bản mới không */
            });
            return chain.then(function () {
                metaSet({ rev: rev, k: newK }); SY.busy = false;
                setMsg('☁ Đã đồng bộ lên máy chủ lúc ' + hhmm() + ' • học sinh sẽ thấy ngay', true);
                if (SY.again) { var f = SY.again === 2; SY.again = 0; return push(f); }
            }, function (e) {
                SY.busy = false; setMsg('⚠ Chưa đồng bộ được (' + (e && e.message ? e.message : 'lỗi mạng') + ') • sẽ tự thử lại', false);
                clearTimeout(SY.timer); SY.timer = setTimeout(function () { SY.timer = 0; push(false); }, 20000);
            });
        }
        function touch(force) {
            if (applying || isStu()) return;
            if (force) SY.force = true;
            clearTimeout(SY.timer);
            SY.timer = setTimeout(function () { SY.timer = 0; var f = SY.force; SY.force = false; push(f); }, force ? 1500 : 4000);   /* [CODE158] gom nhiều thao tác thành 1 lần ghi */
        }
        /* ---- tải về (học sinh; giáo viên máy mới) ---- */
        function pull(force, silent) {
            if (SY.pbusy) return Promise.resolve();
            if (!connected()) { noConn(); return Promise.resolve(); }
            if (!isStu() && (SY.timer || SY.busy)) return Promise.resolve();
            var a = api(), M = metaGet(); SY.pbusy = true;
            /* [CODE157] kiểm tra nhanh "bank/rev" (vài byte) trước; chỉ tải mục lục đầy đủ khi có bản mới */
            var pre = (!force && SY.fullOnce && M.rev) ? a.req('GET', 's', 'bank/rev').then(function (rv) { return rv; }, function () { return null; }) : Promise.resolve(null);
            return pre.then(function (rv) { return (typeof rv === 'string' && rv === M.rev) ? SAME : a.req('GET', 's', 'bank/idx?cb=' + Date.now()); }).then(function (idx) {
                if (idx === SAME) { SY.pbusy = false; setMsg('☁ Đã cập nhật • ' + hhmm(), true); return; }
                SY.fullOnce = true;
                if (!idx || typeof idx.state !== 'string') {
                    SY.pbusy = false;
                    if (!isStu()) { if (hasLocal()) return push(true); setMsg('☁ Đã kết nối • máy chủ chưa có ngân hàng đề.', true); }
                    else setMsg('Giáo viên chưa đưa ngân hàng đề lên máy chủ.', false);
                    return;
                }
                var lackLocal = false; try { var Q0 = readQ(), rk0 = idx.keys || {}; lackLocal = Object.keys(rk0).some(function (ek) { var r0 = rk0[ek]; return r0 && r0.k && !Q0[r0.k]; }); } catch (e) {}   /* [CODE154] */
                if (!force && idx.rev === M.rev && !lackLocal) { SY.pbusy = false; setMsg('☁ Đã cập nhật • ' + hhmm(), true); return; }
                if (!isStu() && !force && !M.rev && hasLocal()) {
                    if (silent) { SY.pbusy = false; return; }
                    if (!confirm('Máy chủ đã có ngân hàng đề.\nOK = TẢI từ máy chủ về máy này (ghi đè dữ liệu trên máy này).\nHủy = GIỮ dữ liệu máy này và đẩy lên máy chủ.')) { SY.pbusy = false; return push(true); }
                }
                setMsg('⬇ Đang tải ngân hàng đề…', true);
                var rk = idx.keys || {}, Q = readQ(), newQ = {}, newM = {}, need = [];
                Object.keys(rk).forEach(function (ek) {
                    var r = rk[ek]; if (!r || !r.k || !isMathBankKey(r.k)) return;
                    if (!force && Q[r.k] && Q[r.k].t === r.t) { newQ[r.k] = Q[r.k]; newM[r.k] = r.t; } else need.push(r);
                });
                var chain = runPool(need, function (r) {   /* [CODE157] chỉ tải các bài mới/đổi, song song 3 luồng */
                    return a.req('GET', 's', 'bank/lq/' + a.enc(r.k) + '?cb=' + Date.now()).then(function (o) {
                        return unpack(o).then(function (arr) {   /* [CODE160] giải nén nếu cần */
                            if (!arr) return;
                            newQ[r.k] = { q: arr, t: o.t || r.t }; newM[r.k] = o.t || r.t;
                        });
                    });
                }, 3);
                return chain.then(function () {
                    var rs = JSON.parse(idx.state) || {};
                    applying = true;
                    try {
                        writeQ(newQ);
                        st.order = (rs.order || []).filter(function (n) { return /^Toán lớp \d+$/i.test(String(n || '')); });
                        st.lessons = mathOnlyMap(rs.lessons); st.q = mathOnlyMap(rs.q); st.m = mathOnlyMap(rs.m);
                        Object.keys(newQ).forEach(function (k) { st.q[k] = (newQ[k].q || []).length; st.m[k] = lvCount(newQ[k].q || []); });
                        save();
                    } finally { applying = false; }
                    metaSet({ rev: idx.rev, k: newM });
                    setMsg('☁ Đã cập nhật ' + Object.keys(newQ).length + ' bài • ' + hhmm(), true);
                    if (modal && modal.classList.contains('open') && editIdx < 0 && !editDirty) render(true);
                });
            }).then(function () { SY.pbusy = false; }, function (e) {
                SY.pbusy = false; setMsg('⚠ Không tải được (' + (e && e.message ? e.message : 'lỗi mạng') + ') • đang dùng bản đã lưu trên máy.', false);
            });
        }
        /* [CODE154] học sinh: tải trực tiếp câu hỏi các bài còn thiếu trên máy (điện thoại không đủ bộ nhớ lưu / chưa tải xong) */
        function fetchLessons(keys) {
            if (!connected()) return Promise.reject(new Error('chưa kết nối với giáo viên'));
            var a = api(), got = {};
            var chain = runPool(keys, function (k) {   /* [CODE157] tải song song 3 luồng */
                return a.req('GET', 's', 'bank/lq/' + a.enc(k) + '?cb=' + Date.now()).then(function (o) {
                    return unpack(o).then(function (arr) { if (arr) got[k] = { q: arr, t: (o && o.t) || 0 }; });   /* [CODE160] */
                });
            }, 3);
            return chain.then(function () {
                var Q = readQ(); Object.keys(got).forEach(function (k) { Q[k] = got[k]; });
                applying = true; try { writeQ(Q); } finally { applying = false; }
                return got;
            });
        }
        function manual(kind) {
            if (kind === 'push') { clearTimeout(SY.timer); SY.timer = 0; push(true); }
            else if (isStu()) pull(true);
            else if (confirm('Tải ngân hàng đề từ máy chủ về máy này?\nDữ liệu hiện có trên máy này sẽ được thay bằng bản trên máy chủ.')) pull(true);
        }
        function onOpen() {
            if (!connected()) noConn(); else setMsg(isStu() ? '⟳ Đang kiểm tra ngân hàng đề mới…' : '☁ Đang kiểm tra máy chủ…', true);
            if (!SY.poll) {
                SY.poll = setInterval(function () { if (modal && modal.classList.contains('open') && !document.hidden) pull(false); }, 60000);   /* [CODE159] */
                document.addEventListener('visibilitychange', function () { if (!document.hidden && modal && modal.classList.contains('open')) pull(false); });
                window.addEventListener('online', function () { pull(false); });
            }
        }
        /* giáo viên đã có sẵn ngân hàng trên máy: tự đưa lên máy chủ 1 lần nếu máy chủ còn trống */
        setInterval(function () {
            try {
                if (isStu() || SY.auto || SY.busy || SY.pbusy || SY.timer || !connected() || metaGet().rev || !hasLocal()) return;
                SY.auto = true; pull(false, true);
            } catch (e) {}
        }, 30000);
        return { touch: touch, push: push, pull: pull, manual: manual, onOpen: onOpen, barHtml: barHtml, fetchLessons: fetchLessons };
    })();

    var API = { sync: BS, path: function () { return path.slice(); },
        /* [CODE153] đọc danh sách môn / khối / bài + câu hỏi cho trình soạn đề */
        subjectNames: function () { return subjects(); },
        gradesOf: function (sj) { var i = info(sj); return i ? i[2].slice() : []; },
        lessonsOf: function (sj, g) { return lessons(sj, g).map(function (x) { return { id: x.id, n: x.n, h: !!x.h }; }); },
        meta: function (key) { return { n: (st.q && st.q[key]) || 0, m: (st.m && st.m[key]) || {} }; },
        getMany: function (keys) { var o = readQ(); return keys.map(function (k) { return (o[k] && o[k].q) ? o[k].q : []; }); },
        LEVELS: ['NB', 'TH', 'VD', 'VDC'], getByLevel: function (key, lv) { return getQuestions(key).filter(function (x) { return lvOf(x) === (lv || ''); }); },
        levelCounts: function (key) { return lvCount(getQuestions(key)); }, onLessonAction: null, setCount: function (key, n) { st.q[key] = n; save(); render(true); }, open: function () { window.CODE126Bank.open(); },
        getQuestions: getQuestions, saveQuestions: saveQuestions, removeQuestions: removeQuestions,
        restore: function () { keepPath = true; window.CODE126Bank.open(); },
        toast: function (t) { status(t); setTimeout(unstatus, 4000); } };
    window.CODE129Bank = API;
    function hook() { if (window.CODE126Bank) window.CODE126Bank.onOpen = init; }
    hook();
})();
