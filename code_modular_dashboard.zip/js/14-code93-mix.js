
/* ============================================================
   [CODE93] TRỘN ĐỀ THI – nhập đề từ Word, trộn nhiều mã đề, xuất file Word (.docx) đề + đáp án
   Phần 1: tiện ích XML, đổi công thức LaTeX -> công thức Word (OMML), đổi văn bản có định dạng -> run Word
   ============================================================ */
(function () {
    'use strict';
    var $ = function (id) { return document.getElementById(id); };
    var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    var LS_KEY = 'code93_mix_cfg_v1';

    /* ---------- 1. Tiện ích XML ---------- */
    var X = function (s) {
        return String(s == null ? '' : s)
            .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    };
    var decodeEnt = function (s) {
        return String(s).replace(/&nbsp;/g, '\u00A0').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
    };
    var TBL_RE_SRC = '@@TBL_([A-Za-z0-9+/=_-]+)@@';
    var IMG_RE = /@@IMG_([A-Za-z0-9+\/=_-]+)(?:~(\d+)x(\d+))?@@/y;
    var TEXT_W = 10207;            // bề ngang vùng chữ A4, lề 1,5 cm (giống file mẫu)
    var MAX_IMG_EMU = 6300000;     // ảnh rộng tối đa ~17,5 cm

    /* ---------- 2. LaTeX -> OMML (qua MathML của KaTeX) ---------- */
    var tn = function (el) { return String((el && (el.localName || el.nodeName)) || '').toLowerCase(); };
    var kids = function (el) {
        return Array.prototype.filter.call(el.childNodes, function (n) { return n.nodeType === 1 && !/^annotation/.test(tn(n)); });
    };
    var txt = function (el) { return el.textContent || ''; };
    var MFONT = '<w:rPr><w:rFonts w:ascii="Cambria Math" w:hAnsi="Cambria Math" w:eastAsia="Cambria Math" w:cs="Cambria Math"/></w:rPr>';
    var mrun = function (text, o) {
        o = o || {};
        if (text === '' || text == null) return '';
        var rp = '';
        if (o.nor) rp = '<m:nor/>'; else if (o.sty) rp = '<m:sty m:val="' + o.sty + '"/>';
        return '<m:r>' + (rp ? '<m:rPr>' + rp + '</m:rPr>' : '') + MFONT + '<m:t xml:space="preserve">' + X(text) + '</m:t></m:r>';
    };
    var NARY_RE = /^[\u2211\u220F\u2210\u222B\u222C\u222D\u222E\u22C3\u22C2\u22C1\u22C0]$/;
    var isNary = function (n) { return n && tn(n) === 'mo' && NARY_RE.test(txt(n).trim()); };
    var isFence = function (n) { return tn(n) === 'mo' && n.getAttribute('fence') === 'true'; };
    var BB = { R: '\u211D', Z: '\u2124', N: '\u2115', Q: '\u211A', C: '\u2102' };
    var ACC = { '\u2192': '\u20D7', '\u20D7': '\u20D7', '^': '\u0302', '\u02C6': '\u0302', '~': '\u0303', '\u02DC': '\u0303', '\u02D9': '\u0307', '\u00A8': '\u0308', '\u02C7': '\u030C', '\u2190': '\u20D6', '\u00B4': '\u0301', '`': '\u0300' };
    var BARS = /^[\u00AF\u203E\u2015_\u2212\u2012\u2013\u2014\-]$/;

    function cvList(nodes) { return nodes.map(cv).join(''); }
    function cvKids(el) { return cvList(kids(el)); }
    function E(inner) { return '<m:e>' + inner + '</m:e>'; }
    function dlm(open, close, inner) {
        return '<m:d><m:dPr><m:begChr m:val="' + X(open) + '"/><m:endChr m:val="' + X(close) + '"/><m:grow m:val="1"/></m:dPr>' + E(inner) + '</m:d>';
    }
    function nary(base, sub, sup, under) {
        var ch = txt(base).trim();
        var integral = /^[\u222B\u222C\u222D\u222E]$/.test(ch);
        var pr = '<m:chr m:val="' + X(ch) + '"/><m:limLoc m:val="' + (integral && !under ? 'subSup' : 'undOvr') + '"/>' +
            (sub ? '' : '<m:subHide m:val="1"/>') + (sup ? '' : '<m:supHide m:val="1"/>');
        return '<m:nary><m:naryPr>' + pr + '</m:naryPr><m:sub>' + (sub ? cv(sub) : '') + '</m:sub><m:sup>' + (sup ? cv(sup) : '') + '</m:sup><m:e></m:e></m:nary>';
    }
    function accentOf(over) {   // phần trên là 1 dấu mũi tên / mũ / ngã... ?
        var o = over;
        while (o && /^(mstyle|mpadded|mrow)$/.test(tn(o)) && kids(o).length === 1) o = kids(o)[0];
        if (o && tn(o) === 'mo') return txt(o).trim();
        return null;
    }
    function cvTable(el) {
        var rows = kids(el).filter(function (r) { return tn(r) === 'mtr'; });
        var grid = rows.map(function (r) { return kids(r).map(function (c) { return cvKids(c); }); });
        var cols = grid.reduce(function (m, r) { return Math.max(m, r.length); }, 0);
        var aligned = cols === 2 && /^right/.test(el.getAttribute('columnalign') || '');
        if (cols <= 1 || aligned) {
            return '<m:eqArr><m:eqArrPr><m:maxDist m:val="1"/></m:eqArrPr>' + grid.map(function (r) { return E(r.join('')); }).join('') + '</m:eqArr>';
        }
        return '<m:m><m:mPr><m:mcs><m:mc><m:mcPr><m:count m:val="' + cols + '"/><m:mcJc m:val="center"/></m:mcPr></m:mc></m:mcs></m:mPr>' +
            grid.map(function (r) { var cells = r.slice(); while (cells.length < cols) cells.push(''); return '<m:mr>' + cells.map(E).join('') + '</m:mr>'; }).join('') + '</m:m>';
    }
    function cv(el) {
        var t = tn(el), k;
        switch (t) {
            case 'math': case 'semantics': case 'mstyle': case 'mpadded': case 'mtd': case 'mtr': case 'menclose': case 'merror':
                if (t === 'menclose' && /box|circle|roundedbox/.test(el.getAttribute('notation') || '')) return '<m:borderBox><m:borderBoxPr/>' + E(cvKids(el)) + '</m:borderBox>';
                return cvKids(el);
            case 'mphantom': case 'annotation': case 'annotation-xml': return '';
            case 'mrow': {
                k = kids(el);
                if (k.length >= 2 && isFence(k[0]) && isFence(k[k.length - 1])) {
                    return dlm(txt(k[0]).trim(), txt(k[k.length - 1]).trim(), cvList(k.slice(1, -1)));
                }
                if (k.length >= 2 && isFence(k[0]) && /^[{\[(|]$/.test(txt(k[0]).trim())) return dlm(txt(k[0]).trim(), '', cvList(k.slice(1)));   // \left\{ ... \right.
                if (k.length >= 2 && isFence(k[k.length - 1]) && /^[}\])|]$/.test(txt(k[k.length - 1]).trim())) return dlm('', txt(k[k.length - 1]).trim(), cvList(k.slice(0, -1)));
                return cvList(k);
            }
            case 'mi': {
                var s = txt(el), mv = el.getAttribute('mathvariant') || '';
                if (mv === 'double-struck' && BB[s]) return mrun(BB[s], { sty: 'p' });
                var sty = mv === 'bold' ? 'b' : mv === 'bold-italic' ? 'bi' : (mv === 'normal' || s.length > 1) ? 'p' : '';
                return mrun(s, { sty: sty });
            }
            case 'mn': return mrun(txt(el));
            case 'mo': return el.children && el.children.length ? cvKids(el) : mrun(txt(el));
            case 'mtext': return mrun(txt(el).replace(/\u00A0/g, ' '), { nor: true });
            case 'mspace': return /^-/.test(el.getAttribute('width') || '') ? '' : mrun('\u2009');
            case 'mfrac': {
                k = kids(el);
                var lt = el.getAttribute('linethickness');
                var nb = lt !== null && /^0(\.0*)?(px|em|ex|pt)?$/.test(lt.trim());
                return '<m:f>' + (nb ? '<m:fPr><m:type m:val="noBar"/></m:fPr>' : '') + '<m:num>' + cv(k[0]) + '</m:num><m:den>' + cv(k[1] || k[0]) + '</m:den></m:f>';
            }
            case 'msqrt': return '<m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg></m:deg>' + E(cvKids(el)) + '</m:rad>';
            case 'mroot': k = kids(el); return '<m:rad><m:radPr/><m:deg>' + cv(k[1]) + '</m:deg>' + E(cv(k[0])) + '</m:rad>';
            case 'msup': k = kids(el); if (isNary(k[0])) return nary(k[0], null, k[1]); return '<m:sSup><m:sSupPr/>' + E(cv(k[0])) + '<m:sup>' + cv(k[1]) + '</m:sup></m:sSup>';
            case 'msub': k = kids(el); if (isNary(k[0])) return nary(k[0], k[1], null); return '<m:sSub><m:sSubPr/>' + E(cv(k[0])) + '<m:sub>' + cv(k[1]) + '</m:sub></m:sSub>';
            case 'msubsup': k = kids(el); if (isNary(k[0])) return nary(k[0], k[1], k[2]); return '<m:sSubSup><m:sSubSupPr/>' + E(cv(k[0])) + '<m:sub>' + cv(k[1]) + '</m:sub><m:sup>' + cv(k[2]) + '</m:sup></m:sSubSup>';
            case 'munder': {
                k = kids(el);
                if (isNary(k[0])) return nary(k[0], k[1], null, true);
                var u = accentOf(k[1]);
                if (u !== null && BARS.test(u)) return '<m:bar><m:barPr><m:pos m:val="bot"/></m:barPr>' + E(cv(k[0])) + '</m:bar>';
                return '<m:limLow><m:limLowPr/>' + E(cv(k[0])) + '<m:lim>' + cv(k[1]) + '</m:lim></m:limLow>';
            }
            case 'mover': {
                k = kids(el);
                var a = accentOf(k[1]);
                if (a !== null && a !== '') {
                    if (/^[\u00AF\u203E\u2015]$/.test(a) || (a === '-' || a === '_')) return '<m:bar><m:barPr><m:pos m:val="top"/></m:barPr>' + E(cv(k[0])) + '</m:bar>';
                    var baseTxt = txt(k[0]).replace(/\s+/g, '');
                    if (/^[\u2192\u2190\u2194\u20D7]$/.test(a) && baseTxt.length > 1 && !/^[\u2192\u2190\u2194]$/.test(baseTxt)) {
                        return '<m:groupChr><m:groupChrPr><m:chr m:val="' + X(a === '\u20D7' ? '\u2192' : a) + '"/><m:pos m:val="top"/><m:vertJc m:val="bot"/></m:groupChrPr>' + E(cv(k[0])) + '</m:groupChr>';
                    }
                    if (ACC[a] && !/^[\u2192\u2190\u2194]$/.test(baseTxt)) return '<m:acc><m:accPr><m:chr m:val="' + X(ACC[a]) + '"/></m:accPr>' + E(cv(k[0])) + '</m:acc>';
                }
                return '<m:limUpp><m:limUppPr/>' + E(cv(k[0])) + '<m:lim>' + cv(k[1]) + '</m:lim></m:limUpp>';
            }
            case 'munderover': {
                k = kids(el);
                if (isNary(k[0])) return nary(k[0], k[1], k[2], true);
                return '<m:limUpp><m:limUppPr/>' + E('<m:limLow><m:limLowPr/>' + E(cv(k[0])) + '<m:lim>' + cv(k[1]) + '</m:lim></m:limLow>') + '<m:lim>' + cv(k[2]) + '</m:lim></m:limUpp>';
            }
            case 'mtable': return cvTable(el);
            default: return cvKids(el);
        }
    }
    function rawMath(s) { return '<m:oMath>' + mrun(s, { nor: true }) + '</m:oMath>'; }
    function latexToOmml(latex) {
        var s = String(latex || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim();
        if (!s) return '';
        var bb = { '\u211D': 'R', '\u2124': 'Z', '\u2115': 'N', '\u211A': 'Q', '\u2102': 'C' };
        s = s.replace(/[\u211D\u2124\u2115\u211A\u2102]/g, function (ch) { return '\\mathbb{' + bb[ch] + '}'; });
        s = s.replace(/(\d),(?=\d)/g, '$1{,}');
        if (typeof katex === 'undefined') return rawMath(s);
        try {
            var html = katex.renderToString(s, { throwOnError: false, strict: false, output: 'mathml' });
            var doc = new DOMParser().parseFromString(html, 'text/html');
            var math = doc.querySelector('math');
            if (!math) return rawMath(s);
            var out = cv(math);
            if (!out) return rawMath(s);
            return '<m:oMath>' + out + '</m:oMath>';
        } catch (e) {
            return rawMath(s);
        }
    }

    /* ---------- 3. Văn bản có định dạng -> run Word ---------- */
    function rPr(f) {
        var o = '';
        if (f.b) o += '<w:b/><w:bCs/>'; else if (f.nb) o += '<w:b w:val="0"/><w:bCs w:val="0"/>';
        if (f.i) o += '<w:i/><w:iCs/>';
        if (f.color) o += '<w:color w:val="' + f.color + '"/>';
        if (f.sz) o += '<w:sz w:val="' + f.sz + '"/><w:szCs w:val="' + f.sz + '"/>';
        if (f.u) o += '<w:u w:val="single"/>';
        if (f.vert) o += '<w:vertAlign w:val="' + (f.vert === 'sup' ? 'superscript' : 'subscript') + '"/>';
        return o ? '<w:rPr>' + o + '</w:rPr>' : '';
    }
    function textRun(t, f) {
        if (!t) return '';
        var pr = rPr(f || {});
        return t.split('\t').map(function (part, i) {
            return (i ? '<w:r>' + pr + '<w:tab/></w:r>' : '') + (part ? '<w:r>' + pr + '<w:t xml:space="preserve">' + X(part) + '</w:t></w:r>' : '');
        }).join('');
    }
    // Bản sao các bước định dạng hóa học / chỉ số của màn hình hiển thị (formatMathAndChemHTML) để file Word giống màn hình
    function chemTransform(str) {
        str = str.replace(/\\rightleftharpoons/g, ' \u21CC ').replace(/\\leftrightarrow/g, ' \u2194 ').replace(/\\rightarrow/g, ' \u2192 ')
            .replace(/\\leftarrow/g, ' \u2190 ').replace(/\\Rightarrow/g, ' \u21D2 ').replace(/\\Leftarrow/g, ' \u21D0 ')
            .replace(/\\Leftrightarrow/g, ' \u21D4 ').replace(/\\Delta/g, '\u0394');
        str = str.replace(/\u0394([rfa])\s*H\s*(?:0|\u00B0)\s*298/gi, '\u0394<sub>$1</sub>H<sup>0</sup><sub>298</sub>');
        str = str.replace(/\bK\s*_\s*([A-Za-z0-9]+)\b/g, 'K<sub>$1</sub>');
        str = str.replace(/\bK(C|P|a|b|w|sp)\b/g, 'K<sub>$1</sub>');
        str = str.replace(/([A-Za-z\)\]])(\d+)(?=[A-Za-z\(\[\s\.\,\;\:\+\-\=\u2192\u21CC\)\]]|$)/g, function (m, p1, p2) {
            if (/^[A-DF-Z]$/.test(p1) && p2.length > 2) return m;
            return p1 + '<sub>' + p2 + '</sub>';
        });
        str = str.replace(/10\s*([\-\u2212\u2013]\d+)/g, '10<sup>$1</sup>');
        str = str.replace(/\^\{([^{}]+)\}/g, '<sup>$1</sup>');
        str = str.replace(/_\{([^{}]+)\}/g, '<sub>$1</sub>');
        return str;
    }
    function tagRuns(seg, f0) {
        var f = Object.assign({}, f0), out = '';
        var re = /<(\/?)(b|strong|i|em|u|sub|sup)\s*>|<br\s*\/?>|<\/?(?:span|font|p|div|a)\b[^>]*>|\r?\n/gi;
        var last = 0, m;
        var emit = function (t) { if (t) out += textRun(decodeEnt(t), f); };
        while ((m = re.exec(seg))) {
            emit(seg.slice(last, m.index));
            last = re.lastIndex;
            if (m[2]) {
                var on = !m[1], k = m[2].toLowerCase();
                if (k === 'b' || k === 'strong') f.b = on ? true : !!f0.b;
                else if (k === 'i' || k === 'em') f.i = on ? true : !!f0.i;
                else if (k === 'u') f.u = on ? true : !!f0.u;
                else if (k === 'sub') f.vert = on ? 'sub' : f0.vert;
                else if (k === 'sup') f.vert = on ? 'sup' : f0.vert;
            } else if (/^<br/i.test(m[0]) || /^\r?\n$/.test(m[0])) {
                out += '<w:r><w:br/></w:r>';
            }
        }
        emit(seg.slice(last));
        return out;
    }
    function inlineXml(doc, str, f) {
        f = f || {};
        str = String(str == null ? '' : str).replace(new RegExp(TBL_RE_SRC, 'g'), '');
        var toks = [];
        var ph = function (x) { toks.push(x); return '\uE000' + (toks.length - 1) + '\uE001'; };
        var out = '', i = 0, n = str.length;
        while (i < n) {
            var c = str[i];
            if (c === '$') {
                if (str[i + 1] === '$') {
                    var e = str.indexOf('$$', i + 2);
                    if (e > i + 2) { out += ph({ m: str.slice(i + 2, e) }); i = e + 2; continue; }
                }
                var e1 = str.indexOf('$', i + 1);
                if (e1 > i + 1) { out += ph({ m: str.slice(i + 1, e1) }); i = e1 + 1; continue; }
            } else if (c === '\\' && str[i + 1] === '(') {
                var e2 = str.indexOf('\\)', i + 2);
                if (e2 > i + 2) { out += ph({ m: str.slice(i + 2, e2) }); i = e2 + 2; continue; }
            } else if (c === '@' && str.charCodeAt(i + 1) === 64 && str.startsWith('@@IMG_', i)) {
                IMG_RE.lastIndex = i;
                var mm = IMG_RE.exec(str);
                if (mm) { out += ph({ img: mm[0] }); i = IMG_RE.lastIndex; continue; }
            }
            out += c; i++;
        }
        out = chemTransform(out);
        var res = '';
        out.split(/\uE000(\d+)\uE001/).forEach(function (part, idx) {
            if (idx % 2 === 0) { res += tagRuns(part, f); return; }
            var tk = toks[+part];
            if (tk.m !== undefined) { doc.hasMath = true; var mtx = (doc.fmt === 'mathtype' && doc.mathObject) ? doc.mathObject(tk.m) : null; res += (mtx != null ? mtx : latexToOmml(tk.m)); }
            else if (tk.img) res += doc.imageRun(tk.img);
        });
        return res;
    }

    window.__CODE93_CORE = { X: X, esc: esc, LS_KEY: LS_KEY, TEXT_W: TEXT_W, MAX_IMG_EMU: MAX_IMG_EMU, TBL_RE_SRC: TBL_RE_SRC, IMG_RE: IMG_RE,
        latexToOmml: latexToOmml, inlineXml: inlineXml, rPr: rPr, textRun: textRun, decodeEnt: decodeEnt, mrun: mrun, $: $ };
})();

/* ============================================================
   [CODE93] Phần 2: dựng file Word (.docx) – đề thi, đề có đáp án, bảng đáp án tổng hợp
   ============================================================ */
(function () {
    'use strict';
    var C = window.__CODE93_CORE;
    var X = C.X, inlineXml = C.inlineXml, decodeEnt = C.decodeEnt, TEXT_W = C.TEXT_W;
    var NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" ' +
        'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" ' +
        'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w10="urn:schemas-microsoft-com:office:word"';

    /* ---------- Ảnh (token @@IMG_..@@) ---------- */
    var IMGCACHE = new Map();
    function b64ToBytes(b64) {
        var bin = atob(b64), u8 = new Uint8Array(bin.length);
        for (var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        return u8;
    }
    function loadImg(src) {
        return new Promise(function (res) {
            var im = new Image();
            im.onload = function () { res(im); };
            im.onerror = function () { res(null); };
            im.src = src;
        });
    }
    async function prepareOneImage(token) {
        if (IMGCACHE.has(token)) return;
        var m = /^@@IMG_([A-Za-z0-9+\/=_-]+)(?:~(\d+)x(\d+))?@@$/.exec(token);
        if (!m) return;
        var dataUrl;
        try { dataUrl = decodeURIComponent(escape(atob(m[1]))); } catch (e) { return; }
        var alx = ''; dataUrl = dataUrl.replace(/#al=([crjlLR])$/, function (_, a) { alx = a; return ''; });   // [CODE161]
        var mm = /^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i.exec(dataUrl);
        if (!mm) return;
        var mime = mm[1].toLowerCase(), bytes = null, ext = '';
        var w = m[2] ? +m[2] : 0, h = m[3] ? +m[3] : 0;
        if (mime === 'image/png') ext = 'png'; else if (mime === 'image/jpeg' || mime === 'image/jpg') ext = 'jpeg'; else if (mime === 'image/gif') ext = 'gif';
        if (ext) {
            try { bytes = b64ToBytes(mm[2]); } catch (e) { return; }
            if (!w || !h) { var im = await loadImg(dataUrl); if (im) { w = im.naturalWidth; h = im.naturalHeight; } }
        } else {   // webp / svg / bmp ... -> PNG bằng canvas
            var im2 = await loadImg(dataUrl);
            if (!im2) return;
            var cw = im2.naturalWidth || w || 300, ch = im2.naturalHeight || h || 200;
            var cv = document.createElement('canvas'); cv.width = cw; cv.height = ch;
            var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cw, ch); cx.drawImage(im2, 0, 0, cw, ch);
            var blob = await new Promise(function (r) { cv.toBlob(r, 'image/png'); });
            if (!blob) return;
            bytes = new Uint8Array(await blob.arrayBuffer()); ext = 'png';
            if (!w || !h) { w = cw; h = ch; }
        }
        if (!w || !h) { w = 300; h = 200; }
        var cxE = Math.round(w * 9525), cyE = Math.round(h * 9525);
        if (cxE > C.MAX_IMG_EMU) { cyE = Math.round(cyE * C.MAX_IMG_EMU / cxE); cxE = C.MAX_IMG_EMU; }
        IMGCACHE.set(token, { bytes: bytes, ext: ext, cx: cxE, cy: cyE, al: alx.toLowerCase(), fl: /^[LR]$/.test(alx) ? alx : '' });   // [CODE169] fl: ảnh nổi có chữ bao quanh
    }
    async function prepareImages(texts) {
        var seen = {}, list = [];
        texts.forEach(function (t) {
            var re = /@@IMG_[A-Za-z0-9+\/=_-]+(?:~\d+x\d+)?@@/g, mm;
            t = String(t || '');
            while ((mm = re.exec(t))) { if (!seen[mm[0]]) { seen[mm[0]] = 1; list.push(mm[0]); } }
            // ảnh nằm trong ô bảng (token bảng là JSON base64)
            var tr = new RegExp(C.TBL_RE_SRC, 'g'), tm;
            while ((tm = tr.exec(t))) {
                var d = decodeTable(tm[1]);
                if (d && d.rows) d.rows.forEach(function (row) { row.forEach(function (c) {
                    var s = String((c && c.t) || ''), r2 = /@@IMG_[A-Za-z0-9+\/=_-]+(?:~\d+x\d+)?@@/g, m2;
                    while ((m2 = r2.exec(s))) { if (!seen[m2[0]]) { seen[m2[0]] = 1; list.push(m2[0]); } }
                }); });
            }
        });
        for (var i = 0; i < list.length; i++) await prepareOneImage(list[i]);
    }
    function decodeTable(b64) {
        try { return JSON.parse(decodeURIComponent(escape(atob(b64)))); } catch (e) { return null; }
    }

    /* ---------- Tài liệu ---------- */
    function Doc() { this.body = []; this.rels = []; this.media = {}; this.embeds = {}; this.relN = 0; this.pid = 0; this.imgs = new Map(); this.hasMath = false; this.fmt = (window.__CODE94_FMT === 'omml') ? 'omml' : 'mathtype'; this.shapeType = false; }
    var SHAPETYPE = '<v:shapetype id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f"><v:stroke joinstyle="miter"/><v:formulas><v:f eqn="if lineDrawn pixelLineWidth 0"/><v:f eqn="sum @0 1 0"/><v:f eqn="sum 0 0 @1"/><v:f eqn="prod @2 1 2"/><v:f eqn="prod @3 21600 pixelWidth"/><v:f eqn="prod @3 21600 pixelHeight"/><v:f eqn="sum @0 0 1"/><v:f eqn="prod @6 1 2"/><v:f eqn="prod @7 21600 pixelWidth"/><v:f eqn="sum @8 21600 0"/><v:f eqn="prod @7 21600 pixelHeight"/><v:f eqn="sum @10 21600 0"/></v:formulas><v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/><o:lock v:ext="edit" aspectratio="t"/></v:shapetype>';
    // [CODE94] Công thức = đối tượng MathType thật (OLE Equation.DSMT4) + ảnh xem trước; bấm đúp trong Word để sửa bằng MathType
    Doc.prototype.mathObject = function (latex) {
        if (!String(latex || '').trim()) return '';
        var MTx = window.MT93, m;
        try { m = MTx.make(String(latex).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')); } catch (e) { return null; }
        if (!m || !m.ole || !m.png) return null;
        var n = ++this.relN, img = 'mt' + n + '.png', ole = 'oleObject' + n + '.bin', sid = '_x0000_i' + (1024 + n);
        this.media[img] = m.png; this.embeds[ole] = m.ole;
        this.rels.push('<Relationship Id="rIdMi' + n + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/' + img + '"/>');
        this.rels.push('<Relationship Id="rIdMo' + n + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/oleObject" Target="embeddings/' + ole + '"/>');
        var st = ''; if (!this.shapeType) { st = SHAPETYPE; this.shapeType = true; }
        var w = m.wPt.toFixed(1), h = m.hPt.toFixed(1), pos = -Math.round(m.dPt * 2);
        return '<w:r><w:rPr><w:position w:val="' + pos + '"/></w:rPr><w:object w:dxaOrig="' + Math.round(m.wPt * 20) + '" w:dyaOrig="' + Math.round(m.hPt * 20) + '">' + st +
            '<v:shape id="' + sid + '" type="#_x0000_t75" style="width:' + w + 'pt;height:' + h + 'pt" o:ole=""><v:imagedata r:id="rIdMi' + n + '" o:title=""/></v:shape>' +
            '<o:OLEObject Type="Embed" ProgID="Equation.DSMT4" ShapeID="' + sid + '" DrawAspect="Content" ObjectID="_' + String(1300000000 + n) + '" r:id="rIdMo' + n + '"/></w:object></w:r>';
    };
    Doc.prototype.imageRun = function (token) {
        var info = IMGCACHE.get(token);
        if (!info) return '';
        var rid = this.imgs.get(token);
        if (!rid) {
            this.relN++; rid = 'rIdImg' + this.relN;
            var name = 'image' + this.relN + '.' + info.ext;
            this.imgs.set(token, rid);
            this.media[name] = info.bytes;
            this.rels.push('<Relationship Id="' + rid + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/' + name + '"/>');
        }
        var id = ++this.pid;
        if (info.fl) {   // [CODE169] ảnh nổi: neo trong đoạn, chữ bao quanh (wrapSquare) đúng như file nguồn
            var side = info.fl === 'R' ? 'right' : 'left';
            return '<w:r><w:drawing><wp:anchor distT="0" distB="91440" distL="' + (side === 'left' ? '0' : '137160') + '" distR="' + (side === 'left' ? '137160' : '0') + '" simplePos="0" relativeHeight="' + (251658240 + id) + '" behindDoc="0" locked="0" layoutInCell="1" allowOverlap="0">' +
                '<wp:simplePos x="0" y="0"/><wp:positionH relativeFrom="column"><wp:align>' + side + '</wp:align></wp:positionH><wp:positionV relativeFrom="paragraph"><wp:posOffset>0</wp:posOffset></wp:positionV>' +
                '<wp:extent cx="' + info.cx + '" cy="' + info.cy + '"/><wp:effectExtent l="0" t="0" r="0" b="0"/><wp:wrapSquare wrapText="bothSides"/><wp:docPr id="' + id + '" name="Hinh ' + id + '"/><wp:cNvGraphicFramePr/>' +
                '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="' + id + '" name="Hinh ' + id + '"/><pic:cNvPicPr/></pic:nvPicPr>' +
                '<pic:blipFill><a:blip r:embed="' + rid + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>' +
                '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + info.cx + '" cy="' + info.cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>';
        }
        return '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="' + info.cx + '" cy="' + info.cy + '"/><wp:docPr id="' + id + '" name="Hinh ' + id + '"/>' +
            '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="' + id + '" name="Hinh ' + id + '"/><pic:cNvPicPr/></pic:nvPicPr>' +
            '<pic:blipFill><a:blip r:embed="' + rid + '"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>' +
            '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="' + info.cx + '" cy="' + info.cy + '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>';
    };

    /* ---------- Đoạn văn / bảng ---------- */
    function P(inner, o) {
        o = o || {};
        var pp = '';
        if (o.keepNext) pp += '<w:keepNext/>';
        if (o.pageBreakBefore) pp += '<w:pageBreakBefore/>';
        if (o.tabs) pp += '<w:tabs>' + o.tabs.map(function (t) { return '<w:tab w:val="' + (t.v || 'left') + '" w:pos="' + t.pos + '"/>'; }).join('') + '</w:tabs>';
        if (o.before != null || o.after != null || o.line) pp += '<w:spacing' + (o.before != null ? ' w:before="' + o.before + '"' : '') + (o.after != null ? ' w:after="' + o.after + '"' : '') + (o.line ? ' w:line="' + o.line + '" w:lineRule="' + (o.lineRule || 'auto') + '"' : '') + '/>';
        if (o.left != null || o.hanging != null || o.firstLine != null) pp += '<w:ind' + (o.left != null ? ' w:left="' + o.left + '"' : '') + (o.hanging != null ? ' w:hanging="' + o.hanging + '"' : '') + (o.firstLine != null ? ' w:firstLine="' + o.firstLine + '"' : '') + '/>';
        if (o.jc) pp += '<w:jc w:val="' + o.jc + '"/>';
        return '<w:p>' + (pp ? '<w:pPr>' + pp + '</w:pPr>' : '') + (inner || '') + '</w:p>';
    }
    var SPACER = '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="120" w:lineRule="exact"/></w:pPr></w:p>';
    function cellXml(doc, c, w, span, vm, o) {
        o = o || {};
        var pr = '<w:tcW w:w="' + w + '" w:type="dxa"/>';
        if (span > 1) pr += '<w:gridSpan w:val="' + span + '"/>';
        if (vm === 'restart') pr += '<w:vMerge w:val="restart"/>'; else if (vm === 'cont') pr += '<w:vMerge/>';
        if (c && c.bg && /^[0-9a-f]{6}$/i.test(c.bg)) pr += '<w:shd w:val="clear" w:color="auto" w:fill="' + c.bg + '"/>';
        var va = c && c.va;
        pr += '<w:vAlign w:val="' + (va === 'center' ? 'center' : va === 'bottom' ? 'bottom' : 'top') + '"/>';
        var jc = c && c.al === 'c' ? 'center' : c && c.al === 'r' ? 'right' : 'left';
        var f = o.f || {};
        var lines = String((c && c.t) || '').split(/\r?\n/);
        var ps = lines.map(function (ln) {
            var jcL = jc, mk = /\u2060{2,4}[ \t]*$/.exec(ln);   // [CODE167] căn lề riêng của từng đoạn trong ô
            if (mk) { var nn = mk[0].trim().length; jcL = nn === 3 ? 'center' : nn === 4 ? 'right' : 'left'; ln = ln.slice(0, mk.index); }
            ln = ln.replace(/\u2060{2,4}/g, '');
            return P(inlineXml(doc, ln, f), { jc: jcL, before: 20, after: 20, line: 252 });
        }).join('');
        return '<w:tc><w:tcPr>' + pr + '</w:tcPr>' + (ps || P('')) + '</w:tc>';
    }
    // bảng dữ liệu của câu hỏi (token @@TBL@@)
    function tableXml(doc, data) {
        if (!data || !Array.isArray(data.rows) || !data.rows.length) return '';
        var ncol = 0;
        data.rows.forEach(function (r) { var s = 0; r.forEach(function (c) { s += Math.max(1, parseInt(c.cs, 10) || 1); }); ncol = Math.max(ncol, s); });
        var ws = Array.isArray(data.w) ? data.w.filter(function (n) { return n > 0; }) : [];
        if (ws.length !== ncol) ws = new Array(ncol).fill(Math.floor(Math.min(TEXT_W, 9000) / Math.max(1, ncol)));
        var tot = ws.reduce(function (a, b) { return a + b; }, 0);
        if (tot > TEXT_W) { ws = ws.map(function (x) { return Math.floor(x * TEXT_W / tot); }); tot = ws.reduce(function (a, b) { return a + b; }, 0); }
        var bd = data.bd ? '<w:tblBorders>' + ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(function (s) { return '<w:' + s + ' w:val="single" w:sz="4" w:space="0" w:color="000000"/>'; }).join('') + '</w:tblBorders>' : '';
        var out = '<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/>' + (data.c ? '<w:jc w:val="center"/>' : '') + bd +
            '<w:tblLayout w:type="autofit"/><w:tblCellMar><w:left w:w="70" w:type="dxa"/><w:right w:w="70" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>' +
            ws.map(function (w) { return '<w:gridCol w:w="' + w + '"/>'; }).join('') + '</w:tblGrid>';
        var pend = [];   // pend[col] = {left, span}
        data.rows.forEach(function (row) {
            var col = 0, cells = '';
            var wAt = function (c0, sp) { var s = 0; for (var q = c0; q < c0 + sp && q < ws.length; q++) s += ws[q]; return s || ws[0]; };
            var fillPend = function () {
                while (pend[col] && pend[col].left > 0) {
                    var p = pend[col];
                    cells += cellXml(doc, null, wAt(col, p.span), p.span, 'cont');
                    p.left--; col += p.span;
                }
            };
            row.forEach(function (c) {
                fillPend();
                var cs = Math.max(1, parseInt(c.cs, 10) || 1), rs = Math.max(1, parseInt(c.rs, 10) || 1);
                cells += cellXml(doc, c, wAt(col, cs), cs, rs > 1 ? 'restart' : null);
                if (rs > 1) pend[col] = { left: rs - 1, span: cs };
                col += cs;
            });
            fillPend();
            out += '<w:tr><w:trPr><w:cantSplit/></w:trPr>' + cells + '</w:tr>';
        });
        return out + '</w:tbl>';
    }
    // bảng đơn giản (đáp án, thông tin đề)
    function gridTable(doc, rows, widths, o) {
        o = o || {};
        var tot = widths.reduce(function (a, b) { return a + b; }, 0);
        var bd = o.noBorder ? '' : '<w:tblBorders>' + ['top', 'left', 'bottom', 'right', 'insideH', 'insideV'].map(function (s) { return '<w:' + s + ' w:val="single" w:sz="4" w:space="0" w:color="000000"/>'; }).join('') + '</w:tblBorders>';
        var out = '<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/>' + bd + '<w:tblLayout w:type="autofit"/><w:tblCellMar><w:left w:w="70" w:type="dxa"/><w:right w:w="70" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>' +
            widths.map(function (w) { return '<w:gridCol w:w="' + w + '"/>'; }).join('') + '</w:tblGrid>';
        rows.forEach(function (row) {
            out += '<w:tr><w:trPr><w:cantSplit/></w:trPr>' + row.map(function (c, i) {
                var cell = typeof c === 'string' ? { t: c } : c;
                var pr = '<w:tcW w:w="' + widths[i] + '" w:type="dxa"/>' + (cell.bg ? '<w:shd w:val="clear" w:color="auto" w:fill="' + cell.bg + '"/>' : '') + '<w:vAlign w:val="center"/>';
                var ps = (cell.paras || [cell.t]).map(function (t, k) {
                    var f = cell.f || {};
                    return cell.raw ? t : P(inlineXml(doc, t, f), { jc: cell.jc || 'center', before: 30, after: 30, line: 252 });
                }).join('');
                return '<w:tc><w:tcPr>' + pr + '</w:tcPr>' + ps + '</w:tc>';
            }).join('') + '</w:tr>';
        });
        return out + '</w:tbl>';
    }
    // [CODE114] nhận diện dòng là 1 "ý" của câu: (a) (b) (c) (d) · a) b) · (1) (2) (3) · 1) 2) · (I) (II)
    var STMT_IND = 284;
    var STMT_RE = /^(?:\((?:[a-hA-H]|\d{1,2}|[ivxIVX]{1,4})\)|[a-hA-H]\)|\d{1,2}\))(?=[\s\u00A0$\\<A-Za-z\u00C0-\u1EF9]|$)/;
    function isStmtLine(ln) {
        var t = String(ln == null ? '' : ln).replace(/<\/?(?:b|strong|i|em|u|span|font)\b[^>]*>/gi, '').replace(/^[\s\u00A0]+/, '');
        return STMT_RE.test(t);
    }
    // văn bản có thể chứa bảng: tách thành đoạn + bảng
    function richBlock(doc, text, labelRuns, po, f) {
        var parts = String(text == null ? '' : text).split(new RegExp(C.TBL_RE_SRC));
        var out = [], first = true, lastP = -1, lastArgs = null;
        var pushP = function (inner, o2) { lastP = out.length; lastArgs = [inner, o2]; out.push(P(inner, o2)); };
        for (var i = 0; i < parts.length; i += 2) {
            var seg = parts[i];
            if (i > 0) seg = seg.replace(/^[ \t]*\r?\n/, '');
            if (i < parts.length - 1) seg = seg.replace(/\r?\n[ \t]*$/, '');
            if (first || seg.trim()) {
                var lines = seg.split(/\r?\n/);
                lines.forEach(function (ln, li) {
                    if (li > 0 && !ln.trim()) return;
                    // [CODE98] chỉ đoạn cuối của câu dẫn mới "dính" với phần dưới; các đoạn trước tự nhiên liền kề, không đẩy cả khối sang trang mới
                    // [CODE114] các ý (a) (b) (c) (d) / (1) (2) (3) ... thụt vào ~0,5 cm so với chữ "Câu n." (đúng mẫu đề của Bộ GD&ĐT); dòng dẫn & dòng kết ("Số phát biểu đúng là") giữ sát lề
                    var stmt = !first && isStmtLine(ln);
                    // [CODE115] dòng chỉ chứa ảnh (không kèm chữ) -> căn giữa trang cho đẹp
                    var imgOnly = /^(?:[ \t\u00A0]*@@IMG_[A-Za-z0-9+\/=_-]+(?:~\d+x\d+)?@@)+[ \t\u00A0]*$/.test(ln) && !(first && labelRuns);
                    var jcImg = 'center';   // [CODE161] ảnh nằm riêng một dòng: xuất Word đúng căn lề của file nguồn (không có thông tin -> căn giữa như trước)
                    if (imgOnly) { var tk0 = /@@IMG_[A-Za-z0-9+\/=_-]+(?:~\d+x\d+)?@@/.exec(ln), inf0 = tk0 && IMGCACHE.get(tk0[0]); if (inf0 && inf0.al) jcImg = inf0.al === 'c' ? 'center' : inf0.al === 'r' ? 'right' : inf0.al === 'j' ? 'both' : 'left'; }
                    var alM = /\u2060{2,4}[ \t]*$/.exec(ln), jcTxt = '';   // [CODE167] căn lề đoạn chữ của file nguồn
                    if (alM) { jcTxt = alM[0].trim().length === 3 ? 'center' : alM[0].trim().length === 4 ? 'right' : 'left'; ln = ln.slice(0, alM.index); }
                    ln = ln.replace(/\u2060{2,4}/g, '');
                    pushP((first ? (labelRuns || '') : '') + inlineXml(doc, ln, f), Object.assign({}, po, { keepNext: false }, li > 0 ? { before: 0 } : {}, stmt ? { left: STMT_IND } : {}, jcTxt ? { jc: jcTxt, left: 0 } : {}, imgOnly ? { jc: jcImg, left: 0 } : {}));
                    first = false;
                });
            }
            if (i + 1 < parts.length) {
                var d = decodeTable(parts[i + 1]);
                if (d) { out.push(tableXml(doc, d)); out.push(SPACER); lastP = -1; }
            }
        }
        if (!out.length) { out.push(P(labelRuns || '', po)); return out; }
        if (po && po.keepNext && lastP >= 0) out[lastP] = P(lastArgs[0], Object.assign({}, lastArgs[1], { keepNext: true }));
        return out;
    }

    /* ---------- Gói .docx ---------- */
    var STYLES = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
        '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="24"/><w:szCs w:val="24"/><w:lang w:val="vi-VN" w:eastAsia="vi-VN" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>' +
        '<w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="276" w:lineRule="auto"/><w:jc w:val="both"/></w:pPr></w:pPrDefault></w:docDefaults>' +
        '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
        '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:unhideWhenUsed/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style></w:styles>';
    var SETTINGS = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">' +
        '<w:compat><w:compatSetting w:name="compatibilityMode" w:uri="http://schemas.microsoft.com/office/word" w:val="15"/></w:compat>' +
        '<m:mathPr><m:mathFont m:val="Cambria Math"/><m:brkBin m:val="before"/><m:smallFrac m:val="0"/><m:dispDef/><m:lMargin m:val="0"/><m:rMargin m:val="0"/><m:defJc m:val="centerGroup"/><m:wrapIndent m:val="1440"/><m:intLim m:val="subSup"/><m:naryLim m:val="undOvr"/></m:mathPr></w:settings>';
    function fieldRuns(instr, f, cached) {
        var pr = C.rPr(f || {});
        return '<w:r>' + pr + '<w:fldChar w:fldCharType="begin"/></w:r><w:r>' + pr + '<w:instrText xml:space="preserve"> ' + instr + ' </w:instrText></w:r><w:r>' + pr + '<w:fldChar w:fldCharType="separate"/></w:r><w:r>' + pr + '<w:t>' + (cached || '1') + '</w:t></w:r><w:r>' + pr + '<w:fldChar w:fldCharType="end"/></w:r>';
    }
    async function pack(doc, title, footerLeft) {
        var zip = new JSZip();
        var f = { sz: 20 };
        var footer = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr ' + NS + '>' +
            P(C.textRun(footerLeft + ' \u2013 Trang ', f) + fieldRuns('PAGE', f) + C.textRun('/', f) + fieldRuns('NUMPAGES', f), { jc: 'right' }) + '</w:ftr>';
        var sect = '<w:sectPr><w:footerReference w:type="default" r:id="rIdFtr"/><w:pgSz w:w="11907" w:h="16840" w:code="9"/><w:pgMar w:top="850" w:right="850" w:bottom="850" w:left="850" w:header="340" w:footer="340" w:gutter="0"/><w:cols w:space="708"/></w:sectPr>';
        if (doc.en) {   // [CODE123] trang giấy, lề, chân trang đúng file mẫu "ĐỀ MẪU ANH"
            footer = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:ftr ' + NS + '>' + P(C.textRun(footerLeft, { sz: 22 }), { jc: 'right' }) + '</w:ftr>';
            sect = '<w:sectPr><w:footerReference w:type="default" r:id="rIdFtr"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="850" w:right="1020" w:bottom="850" w:left="1020" w:header="720" w:footer="720" w:gutter="0"/><w:cols w:space="720"/></w:sectPr>';
        }
        var docXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ' + NS + '><w:body>' + doc.body.join('') + sect + '</w:body></w:document>';
        var rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
            '<Relationship Id="rIdSty" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
            '<Relationship Id="rIdSet" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings" Target="settings.xml"/>' +
            '<Relationship Id="rIdFtr" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/>' + doc.rels.join('') + '</Relationships>';
        var ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
            '<Default Extension="png" ContentType="image/png"/><Default Extension="bin" ContentType="application/vnd.openxmlformats-officedocument.oleObject"/><Default Extension="jpeg" ContentType="image/jpeg"/><Default Extension="gif" ContentType="image/gif"/>' +
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
            '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
            '<Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/>' +
            '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/>' +
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' +
            '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>';
        var now = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
        zip.file('[Content_Types].xml', ct);
        zip.file('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>' +
            '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/></Relationships>');
        zip.file('docProps/core.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>' + X(title) + '</dc:title><dc:creator>Quan ly de thi</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">' + now + '</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">' + now + '</dcterms:modified></cp:coreProperties>');
        zip.file('docProps/app.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>Microsoft Office Word</Application></Properties>');
        zip.file('word/document.xml', docXml);
        zip.file('word/styles.xml', doc.en ? STYLES_EN : STYLES);
        zip.file('word/settings.xml', SETTINGS);
        zip.file('word/footer1.xml', footer);
        zip.file('word/_rels/document.xml.rels', rels);
        Object.keys(doc.media).forEach(function (name) { zip.file('word/media/' + name, doc.media[name]); });
        Object.keys(doc.embeds || {}).forEach(function (name) { zip.file('word/embeddings/' + name, doc.embeds[name]); });
        return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    }

    /* ---------- Nội dung đề ---------- */
    var B = { b: true };
    var plainLen = function (s) {
        s = String(s || '').replace(/@@IMG_[^@]*@@/g, 'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM').replace(new RegExp(C.TBL_RE_SRC, 'g'), 'MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM')
            .replace(/\$([^$]*)\$/g, function (m, a) { return a.replace(/\\[a-zA-Z]+/g, 'x').replace(/[{}^_]/g, ''); }).replace(/<[^>]+>/g, '');
        return decodeEnt(s).length;
    };
    /* [CODE114] Ước lượng độ rộng thật (twips) của 1 phương án để tự chia đáp án A. B. C. D. thành 1 dòng (4 cột) / 2 dòng (2 cột) / 4 dòng (1 cột) */
    var CW_NARROW = /[ijl.,;:!'|\u2019]/, CW_MID = /[tfrI()\[\]\-\u2212\u2013\/"]/;
    function charTw(c) {
        var k = c.charCodeAt(0);
        if (k >= 0x300 && k <= 0x36F) return 0;                       // dấu tổ hợp
        if (c === ' ' || c === '\u00A0') return 60;
        if (c === 'm') return 175; if (c === 'w') return 160;
        if (c === 'M' || c === 'W') return 210;
        if (CW_NARROW.test(c)) return 66;
        if (CW_MID.test(c)) return 98;
        if (c >= '0' && c <= '9') return 120;
        if (c.toUpperCase() === c && c.toLowerCase() !== c) return 165;   // chữ hoa (kể cả Ă Â Đ Ê Ô Ơ Ư...)
        if (k > 0x2000) return 140;                                    // ký hiệu → ⇌ ° ...
        if (c === '+' || c === '=' || c === '<' || c === '>') return 135;
        return 112;
    }
    function strTw(str, chem) {
        str = String(str || '').normalize('NFC');
        var w = 0, prev = '';
        for (var i = 0; i < str.length; i++) {
            var c = str[i], t = charTw(c);
            // chỉ số dưới của công thức hóa học (CH3COOH, H2SO4...) nhỏ hơn ~35%
            if (chem && c >= '0' && c <= '9' && /[A-Za-z)\]]/.test(prev)) t = Math.round(t * 0.62);
            w += t; prev = c;
        }
        return w;
    }
    function mathTw(m) {
        var s = String(m || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'), w = 0, ch = true;
        var guard = 0;
        while (guard++ < 8 && /\\[dt]?frac\s*\{[^{}]*\}\s*\{[^{}]*\}/.test(s)) {
            s = s.replace(/\\[dt]?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, function (x, a, b) { return a.length >= b.length ? a : b; });
        }
        s = s.replace(/[_^]\s*\{([^{}]*)\}|[_^]\s*([A-Za-z0-9+\-])/g, function (x, a, b) { w += Math.round(strTw(a || b, false) * 0.66); return ''; });
        s = s.replace(/\\sqrt\s*(?:\[[^\]]*\])?/g, '\u221A').replace(/\\(?:left|right|mathrm|mathbf|mathit|textbf|text|operatorname|displaystyle|quad|qquad)(?![A-Za-z])\s*/g, '').replace(/\\[,;!]/g, '')
            .replace(/\\(?:rightarrow|to|longrightarrow|rightleftharpoons|leftrightarrow|Delta|circ|degree|cdot|times|pm|approx|geq?|leq?|neq|infty|alpha|beta|gamma|pi|sum|int|lim)\b/g, '\u2248')
            .replace(/\\[A-Za-z]+/g, 'x').replace(/[{}$\\]/g, '');
        return w + Math.round(strTw(s, ch) * 1.06) + 40;
    }
    function optTw(opt) {   // trả về 99999 nếu phương án không thể xếp chung hàng (xuống dòng / có bảng)
        var s = String(opt == null ? '' : opt), w = 0;
        if (/\r?\n/.test(s.replace(/^\s+|\s+$/g, '')) || new RegExp(C.TBL_RE_SRC).test(s)) return 99999;
        s = s.replace(/@@IMG_[A-Za-z0-9+\/=_-]+(?:~\d+x\d+)?@@/g, function (tok) { var inf = IMGCACHE.get(tok); w += inf ? Math.round(inf.cx / 635) + 40 : 2400; return ''; });
        s = s.replace(/\$\$([^$]*)\$\$|\$([^$]*)\$|\\\(([\s\S]*?)\\\)/g, function (x, a, b, c2) { w += mathTw(a || b || c2); return ''; });
        s = s.replace(/<(sub|sup)>([^<]*)<\/\1>/gi, function (x, t, a) { w += Math.round(strTw(decodeEnt(a), false) * 0.62); return ''; });
        s = s.replace(/\\(?:rightleftharpoons|leftrightarrow|rightarrow|leftarrow|Rightarrow|Delta)/g, '\u21CC');
        s = s.replace(/<[^>]+>/g, '');
        return w + strTw(decodeEnt(s), true);
    }
    function pickCols(opts, avail) {
        if (!opts || opts.length !== 4) return 1;
        var LABEL = 330, GAP = 170, SAFE = 1.07;                       // "A. " in đậm + khoảng cách giữa các cột + hệ số an toàn
        var mx = 0;
        for (var i = 0; i < 4; i++) { var tw = optTw(opts[i]); if (tw >= 99999) return 1; mx = Math.max(mx, (tw + LABEL) * SAFE); }
        if (mx + GAP <= avail / 4) return 4;      // vừa 1 dòng
        if (mx + GAP <= avail / 2) return 2;      // 2 dòng, mỗi dòng 2 đáp án
        return 1;                                 // 4 dòng, mỗi dòng 1 đáp án
    }
    function optionsBlock(doc, q, withAns) {
        var out = [], L = 'ABCD', opts = q.opts;
        var cols = pickCols(opts, TEXT_W - 284);
        var one = function (k) {
            var ok = withAns && q.correct === k;
            var f = ok ? { b: true, u: true } : {};
            return C.textRun(L[k] + '. ', Object.assign({ b: true }, ok ? { u: true } : {})) + inlineXml(doc, opts[k], f);
        };
        var IND = 284;   // [CODE98] đáp án A. B. C. D. thụt vào ~0,5 cm so với chữ "Câu n." (đúng mẫu đề của Bộ GD&ĐT)
        var colW = Math.floor((TEXT_W - IND) / cols);
        var tabs = []; for (var t = 1; t < cols; t++) tabs.push({ pos: IND + colW * t });
        for (var i = 0; i < opts.length; i += cols) {
            var row = [];
            for (var j = i; j < Math.min(opts.length, i + cols); j++) row.push(one(j));
            var last = i + cols >= opts.length;
            var nRows = Math.ceil(opts.length / cols), rIdx = i / cols;
            // [CODE115] chỉ giữ "câu dẫn + dòng đáp án đầu" và "2 dòng đáp án cuối" đi cùng nhau; phần còn lại tự trôi liền sang trang sau, không bỏ trống cuối trang
            var kn = !last && (rIdx === 0 || rIdx === nRows - 2);
            out.push(P(row.join('<w:r><w:tab/></w:r>'), { jc: 'left', tabs: tabs, keepNext: kn, before: 0, after: last ? 40 : 0, left: IND }));
        }
        return out;
    }
    function questionBlock(doc, q, num, withAns) {
        var out = [];
        if (q.gFirst) {
            var g = q.gFirst;
            var ref = g.to > g.from ? (g.to === g.from + 1 ? 'câu ' + g.from + ' và câu ' + g.to : 'câu ' + g.from + ' đến câu ' + g.to) : 'câu ' + g.from;
            out = out.concat(richBlock(doc, g.info || '', g.gm ? '' : C.textRun('Sử dụng thông tin sau để trả lời ' + ref + (g.info ? ': ' : '.'), { b: true, i: true }), { before: 80, keepNext: true }, {}));   // [CODE121] nhóm English: dòng dẫn đã nằm trong đề dẫn
        }
        var label = C.textRun(((q.en || q.gm) ? 'Question ' : 'Câu ') + num + '. ', { b: true });
        var stem = richBlock(doc, q.text, label, { before: 80, keepNext: q.type !== 'sa' || (withAns && !!q.sa) });
        out = out.concat(stem);
        if (q.type === 'mc') {
            out = out.concat(optionsBlock(doc, q, withAns));
        } else if (q.type === 'tf') {
            q.opts.forEach(function (o, i) {
                var on = withAns && q.tfKnown && q.tf[i];
                var f = on ? { b: true, u: true, color: 'FF0000' } : {};
                out.push(P(C.textRun('abcd'[i] + ') ', Object.assign({}, f, { b: true })) + inlineXml(doc, o, f), { jc: 'both', left: 284, before: 0, after: 0, keepNext: i === 0 || i === 2 || (withAns && !!q.tfSol[i]) }));
                if (withAns && q.tfSol[i] && q.tfSol[i].trim()) out = out.concat(richBlock(doc, q.tfSol[i], C.textRun('Giải thích ý ' + 'abcd'[i] + '): ', { i: true, b: true }), { left: 284, before: 0, after: 0 }, { i: true }));
            });
        } else if (withAns) {
            out.push(P(C.textRun('Trả lời: ', { i: true }) + inlineXml(doc, q.sa || '(chưa có đáp án)', { b: true, i: true }), { jc: 'left', before: 0, after: 0 }));
        }
        if (withAns && q.solution && q.solution.trim()) {
            out = out.concat(richBlock(doc, q.solution, C.textRun('Lời giải: ', { b: true, i: true }), { before: 20, after: 40 }, {}));
        }
        return out;
    }
    function infoCfg(cfg) {
        return {
            sgd: String(cfg.sgd || '').trim().toUpperCase(), school: String(cfg.school || '').trim().toUpperCase(), exam: String(cfg.exam || '').trim().toUpperCase(),
            subject: String(cfg.subject || '').trim(), grade: String(cfg.grade || '').trim(), year: String(cfg.year || '').trim(), time: String(cfg.time || '').trim()
        };
    }
    function headerBlock(doc, cfg, ver, total, withAns) {
        var I = infoCfg(cfg);
        var cp = function (txt, f) { return P(C.textRun(txt, f || {}), { jc: 'center', before: 0, after: 0 }); };
        var left = [], right = [];
        if (I.sgd) left.push(cp(I.sgd, B));
        if (I.school) left.push(cp(I.school, B));
        left.push(cp('ĐỀ CHÍNH THỨC'));
        left.push(cp('(Đề thi có ' + total + ' câu)'));
        if (I.exam) right.push(cp(I.exam, B));
        var mon = (I.subject ? 'MÔN: ' + I.subject.toUpperCase() : '') + (I.grade ? (I.subject ? ' – ' : '') + 'LỚP ' + I.grade.toUpperCase() : '');
        if (mon) right.push(cp(mon, B));
        if (I.year) right.push(cp('Năm học ' + I.year, B));
        if (I.time) right.push(cp('Thời gian làm bài: ' + I.time + ' phút, không kể thời gian phát đề'));
        var w1 = 3600, w2 = TEXT_W - 3600;
        var tbl = gridTable(doc, [[{ paras: left, raw: true, jc: 'center' }, { paras: right, raw: true, jc: 'center' }]], [w1, w2]);
        var out = [];
        if (withAns) out.push(P(C.textRun('ĐỀ CÓ ĐÁP ÁN – DÀNH CHO GIÁO VIÊN (KHÔNG PHÁT CHO HỌC SINH)', { b: true, color: 'C00000' }), { jc: 'center', after: 60 }));
        out.push(tbl);
        out.push(P(C.textRun('Họ và tên thí sinh: ', {}) + C.textRun('.'.repeat(52), {}) + (ver.code ? '<w:r><w:tab/></w:r>' + C.textRun('Mã đề thi: ' + ver.code, { b: true }) : ''),
            { jc: 'left', tabs: [{ v: 'right', pos: TEXT_W }], before: 120, after: 0 }));
        out.push(P(C.textRun('Số báo danh: ', {}) + C.textRun('.'.repeat(30), {}), { jc: 'left', before: 0, after: 60 }));
        return out;
    }
    var PART_HEAD = {
        mc: function (n) { return 'PHẦN I. Thí sinh trả lời ' + (n > 1 ? 'từ câu 1 đến câu ' + n : 'câu 1') + '. Mỗi câu hỏi thí sinh chỉ chọn một phương án.'; },
        tf: function (n) { return 'PHẦN II. Thí sinh trả lời ' + (n > 1 ? 'từ câu 1 đến câu ' + n : 'câu 1') + '. Trong mỗi ý a), b), c), d) ở mỗi câu, thí sinh chọn đúng hoặc sai.'; },
        sa: function (n) { return 'PHẦN III. Thí sinh trả lời ' + (n > 1 ? 'từ câu 1 đến câu ' + n : 'câu 1') + '.'; }
    };
    async function buildExamDocx(ver, cfg, withAns) {
        var texts = [];
        ver.parts.forEach(function (p) { p.list.forEach(function (q) { texts.push(q.text, q.solution, q.gFirst && q.gFirst.info); (q.opts || []).forEach(function (o) { texts.push(o); }); (q.tfSol || []).forEach(function (o) { texts.push(o); }); texts.push(q.sa); }); });
        await prepareImages(texts);
        var doc = new Doc();
        var total = ver.parts.reduce(function (s, p) { return s + p.list.length; }, 0);
        if (isEnVer(ver)) {   // [CODE123] đề English: xuất đúng định dạng file mẫu
            doc.en = true;
            enHeader(doc, cfg, ver, withAns, total).forEach(function (x) { doc.body.push(x); });
            var nq = 0;
            ver.parts.forEach(function (p) { p.list.forEach(function (q) { nq++; enQuestionBlock(doc, q, nq, withAns).forEach(function (x) { doc.body.push(x); }); }); });
            doc.body.push(P(C.textRun('-------------------- THE END --------------------', { b: true }), { jc: 'center', before: 160, after: 80 }));
            doc.body.push(P(C.textRun('- Thí sinh không được sử dụng tài liệu;', { i: true, sz: 22 }) + '<w:r><w:br/></w:r>' + C.textRun('- Giám thị không giải thích gì thêm.', { i: true, sz: 22 }), { after: 0 }));
            return pack(doc, (infoCfg(cfg).exam || 'Đề thi') + (ver.code ? ' - Mã đề ' + ver.code : ''), ver.code ? 'Mã đề thi ' + ver.code : (infoCfg(cfg).exam || 'Đề thi'));
        }
        headerBlock(doc, cfg, ver, total, withAns).forEach(function (x) { doc.body.push(x); });
        ver.parts.forEach(function (p) {
            if (!p.list.length) return;
            doc.body.push(P(C.textRun(PART_HEAD[p.type](p.list.length), { b: true }), { jc: 'left', before: 160, after: 40, keepNext: true }));
            p.list.forEach(function (q, i) { questionBlock(doc, q, i + 1, withAns).forEach(function (x) { doc.body.push(x); }); });
        });
        doc.body.push(P(C.textRun('----------- HẾT -----------', { b: true }), { jc: 'center', before: 200, after: 0 }));
        doc.body.push(P(C.textRun('Thí sinh không được sử dụng tài liệu. Cán bộ coi thi không giải thích gì thêm.', { i: true }), { jc: 'center', before: 0, after: 0 }));
        var I = infoCfg(cfg);
        return pack(doc, (I.exam || 'Đề thi') + (ver.code ? ' - Mã đề ' + ver.code : ''), ver.code ? 'Mã đề thi ' + ver.code : (I.exam || 'Đề thi'));
    }
    // bảng đáp án tổng hợp cho tất cả mã đề
    async function buildKeyDocx(vers, cfg) {
        var en = !!(vers.length && isEnVer(vers[0])), LQ = en ? 'Question' : 'Câu', LA = en ? 'Answer' : 'Đáp án';   // [CODE123]
        var texts = [];
        vers.forEach(function (v) { v.parts.forEach(function (p) { p.list.forEach(function (q) { texts.push(q.sa); }); }); });
        await prepareImages(texts);
        var doc = new Doc();
        var I = infoCfg(cfg);
        var title = ['ĐÁP ÁN – ' + (I.exam || 'ĐỀ THI'), I.subject ? 'MÔN: ' + I.subject.toUpperCase() + (I.grade ? ' – LỚP ' + I.grade.toUpperCase() : '') : ''].filter(Boolean);
        title.forEach(function (t) { doc.body.push(P(C.textRun(t, { b: true }), { jc: 'center', after: 40 })); });
        vers.forEach(function (v, vi) {
            if (v.code) doc.body.push(P(C.textRun('MÃ ĐỀ ' + v.code, { b: true, sz: 28 }), { jc: 'center', before: vi ? 0 : 120, after: 80, pageBreakBefore: vi > 0, keepNext: true }));
            v.parts.forEach(function (p) {
                if (!p.list.length) return;
                if (!en) doc.body.push(P(C.textRun(p.type === 'mc' ? 'Phần I. Trắc nghiệm nhiều lựa chọn' : p.type === 'tf' ? 'Phần II. Trắc nghiệm đúng – sai' : 'Phần III. Trả lời ngắn', { b: true }), { jc: 'left', before: 100, after: 40, keepNext: true }));
                if (p.type === 'mc') {
                    for (var i = 0; i < p.list.length; i += 10) {
                        var ch = p.list.slice(i, i + 10), w0 = 1100, wc = Math.floor((TEXT_W - w0) / 10);
                        var r1 = [{ t: LQ, f: B, bg: 'D9E2F3' }], r2 = [{ t: LA, f: B }];
                        for (var k = 0; k < 10; k++) { r1.push(ch[k] ? { t: String(i + k + 1), f: B, bg: 'D9E2F3' } : { t: '' }); r2.push({ t: ch[k] ? (ch[k].correct >= 0 ? 'ABCD'[ch[k].correct] : '?') : '' }); }
                        doc.body.push(gridTable(doc, [r1, r2], [w0].concat(new Array(10).fill(wc)))); doc.body.push(SPACER);
                    }
                } else if (p.type === 'tf') {
                    var rows = [[{ t: LQ, f: B, bg: 'D9E2F3' }, { t: 'Ý a)', f: B, bg: 'D9E2F3' }, { t: 'Ý b)', f: B, bg: 'D9E2F3' }, { t: 'Ý c)', f: B, bg: 'D9E2F3' }, { t: 'Ý d)', f: B, bg: 'D9E2F3' }]];
                    p.list.forEach(function (q, i) { rows.push([{ t: String(i + 1), f: B }].concat([0, 1, 2, 3].map(function (j) { return { t: q.tfKnown ? (q.tf[j] ? 'Đúng' : 'Sai') : '?' }; }))); });
                    var wq = 1200, wx = Math.floor((TEXT_W - wq) / 4);
                    doc.body.push(gridTable(doc, rows, [wq, wx, wx, wx, wx])); doc.body.push(SPACER);
                } else {
                    for (var s = 0; s < p.list.length; s += 6) {
                        var c6 = p.list.slice(s, s + 6), w1 = 1100, w6 = Math.floor((TEXT_W - w1) / 6);
                        var a1 = [{ t: LQ, f: B, bg: 'D9E2F3' }], a2 = [{ t: LA, f: B }];
                        for (var z = 0; z < 6; z++) { a1.push(c6[z] ? { t: String(s + z + 1), f: B, bg: 'D9E2F3' } : { t: '' }); a2.push({ t: c6[z] ? (c6[z].sa || '?') : '' }); }
                        doc.body.push(gridTable(doc, [a1, a2], [w1].concat(new Array(6).fill(w6)))); doc.body.push(SPACER);
                    }
                }
            });
        });
        return pack(doc, 'Bảng đáp án tổng hợp', 'Bảng đáp án');
    }

/* ============================================================
   [CODE123] English – xuất file Word đúng định dạng file mẫu "ĐỀ MẪU ANH"
   - Trang A4, lề trái/phải 1020, trên/dưới 850; Times New Roman 11,5; "Question n." in đậm
   - Đáp án: 4 đáp án / 1 dòng, 2 đáp án / dòng hoặc mỗi đáp án 1 dòng (tự chọn theo độ dài)
   - Câu có đề dài nhiều dòng (sắp xếp câu...): thụt lề 1474 như mẫu; câu có đề 1 dòng: đáp án thụt 283
   - Đáp án đúng (bản có đáp án): gạch chân cả "A." và nội dung; sau câu có dòng "Answer:" (chữ nghiêng)
   ============================================================ */
var STYLES_EN = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
    '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:eastAsia="Times New Roman" w:cs="Times New Roman"/><w:sz w:val="23"/><w:szCs w:val="23"/><w:lang w:val="en-US" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>' +
    '<w:pPrDefault><w:pPr><w:spacing w:after="40" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>' +
    '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>' +
    '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:uiPriority w:val="99"/><w:semiHidden/><w:unhideWhenUsed/><w:tblPr><w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/><w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style></w:styles>';
var EN_H = 1474, EN_S = 283, EN_TAB = '<w:r><w:tab/></w:r>', EN_BR = '<w:r><w:br/></w:r>';
function isEnVer(ver) { return !!(ver && ver.parts && ver.parts.some(function (p) { return p.list.some(function (q) { return q.en || q.gm; }); })); }
function plainTxt(s) { return decodeEnt(String(s == null ? '' : s).replace(/<[^>]+>/g, '')).replace(/[\s\u00A0]+/g, ' ').trim(); }
function enRuns(doc, str, f) { return inlineXml(doc, String(str == null ? '' : str).replace(/^[\s\u00A0]+|[\s\u00A0]+$/g, ''), f || {}); }
function enLines(str) { return String(str || '').split(/\r?\n/).filter(function (l) { return plainTxt(l) !== '' || /@@IMG_|@@TBL_/.test(l); }); }
function enOpt(doc, q, k, withAns) {
    var ok = withAns && q.correct === k;
    return C.textRun('ABCD'[k] + '. ', ok ? { b: true, u: true } : { b: true }) + enRuns(doc, q.opts[k], ok ? { u: true } : {});
}
function enCols(q, w4, w2) {   // 4 = cả 4 đáp án 1 dòng | 2 = 2 đáp án / dòng | 1 = mỗi đáp án 1 dòng
    if (!q.opts || q.opts.length !== 4) return 1;
    var mx = 0;
    for (var i = 0; i < 4; i++) { var tw = optTw(q.opts[i]); if (tw >= 99999) return 1; mx = Math.max(mx, (tw + 330) * 1.07); }
    return mx <= w4 ? 4 : mx <= w2 ? 2 : 1;
}
// Đề dẫn của nhóm: dòng "Read the following..." (đậm nghiêng), tiêu đề (đậm, giữa), đoạn văn (thụt dòng đầu), "(Adapted from ...)" (nghiêng, phải)
function enInfoBlock(doc, g) {
    var out = [];
    enLines(g.info).forEach(function (ln, i) {
        var pl = plainTxt(ln);
        if (/@@TBL_/.test(ln)) { richBlock(doc, ln, '', { before: 0 }, {}).forEach(function (x) { out.push(x); }); return; }
        if (i === 0) {
            var d = ln.replace(/<\/?(?:b|i|strong|em)\s*>/gi, '');
            if (window.CODE121EN && g.from && g.to) d = CODE121EN.fixRange(d, g.from, g.to);
            out.push(P(enRuns(doc, d, { b: true, i: true }), { jc: 'both', before: 120, after: 60, keepNext: true }));
            return;
        }
        if (/^<b>(?:(?!<\/?b>)[\s\S])*<\/b>$/.test(ln.trim()) && pl.length <= 120 && !/[.!?]$/.test(pl)) {
            out.push(P(enRuns(doc, ln), { jc: 'center', before: 60, after: 60, keepNext: true }));
        } else if (/^\(\s*(?:Adapted|Source|Retrieved)\b[\s\S]*\)\s*$/i.test(pl)) {
            out.push(P(enRuns(doc, ln, { i: true, sz: 21 }), { jc: 'right', after: 60 }));
        } else {
            out.push(P(enRuns(doc, ln), { jc: 'both', firstLine: 454 }));
        }
    });
    return out;
}
function enQuestionBlock(doc, q, num, withAns) {
    var out = q.gFirst ? enInfoBlock(doc, q.gFirst) : [];
    var lines = enLines(q.text), opts = q.opts || [];
    var label = C.textRun('Question ' + num + '.', { b: true });
    var one = function (k) { return enOpt(doc, q, k, withAns); };
    var all = function () { return [0, 1, 2, 3].map(one).join(EN_TAB); };
    var cols, k;
    if (lines.length === 1) {                       // câu có 1 dòng đề: "Question n. đề" rồi đáp án thụt 283
        cols = enCols(q, 2200, 4600);
        out.push(P(label + C.textRun(' ', {}) + enRuns(doc, lines[0]), { jc: 'both', before: 40, after: 20, keepNext: true }));
        if (cols === 4) out.push(P(all(), { tabs: [{ pos: 2551 }, { pos: 5102 }, { pos: 7654 }], left: EN_S, before: 0, after: 20 }));
        else if (cols === 2) {
            out.push(P(one(0) + EN_TAB + one(1), { tabs: [{ pos: 5075 }], left: EN_S, before: 0, after: 20, keepNext: true }));
            out.push(P(one(2) + EN_TAB + one(3), { tabs: [{ pos: 5075 }], left: EN_S, before: 0, after: 20 }));
        } else for (k = 0; k < opts.length; k++) out.push(P(one(k), { jc: 'both', left: EN_S, before: 0, after: 20, keepNext: k < opts.length - 1 }));
    } else if (!lines.length) {                     // câu điền từ (không có đề): "Question n." + tab + đáp án
        cols = enCols(q, 1950, 4000);
        if (cols === 4) out.push(P(label + EN_TAB + all(), { tabs: [{ pos: EN_H }, { pos: 3572 }, { pos: 5670 }, { pos: 7768 }], before: 0, after: 20 }));
        else if (cols === 2) {
            out.push(P(label + EN_TAB + one(0) + EN_TAB + one(1), { tabs: [{ pos: EN_H }, { pos: 5783 }], left: EN_H, hanging: EN_H, before: 0, after: 20, keepNext: true }));
            out.push(P(one(2) + EN_TAB + one(3), { tabs: [{ pos: 5783 }], left: EN_H, before: 0, after: 20 }));
        } else {
            out.push(P(label + EN_TAB + one(0), { tabs: [{ pos: EN_H }], left: EN_H, hanging: EN_H, jc: 'both', before: 0, after: 20, keepNext: true }));
            for (k = 1; k < opts.length; k++) out.push(P(one(k), { jc: 'both', left: EN_H, before: 0, after: 20, keepNext: k < opts.length - 1 }));
        }
    } else {                                        // đề nhiều dòng (sắp xếp câu, hội thoại...): thụt 1474 như mẫu
        lines.forEach(function (ln, i) {
            out.push(i === 0
                ? P(label + EN_TAB + enRuns(doc, ln), { tabs: [{ pos: EN_H }], left: EN_H, hanging: EN_H, jc: 'both', before: 0, after: 20, keepNext: true })
                : P(enRuns(doc, ln), { jc: 'both', left: EN_H, before: 0, after: 20, keepNext: i >= lines.length - 2 }));
        });
        cols = enCols(q, 1950, 4000);
        if (cols === 4) out.push(P(all(), { tabs: [{ pos: 3572 }, { pos: 5669 }, { pos: 7767 }], left: EN_H, before: 0, after: 20 }));
        else if (cols === 2) {
            out.push(P(one(0) + EN_TAB + one(1), { tabs: [{ pos: 5783 }], left: EN_H, before: 0, after: 20, keepNext: true }));
            out.push(P(one(2) + EN_TAB + one(3), { tabs: [{ pos: 5783 }], left: EN_H, before: 0, after: 20 }));
        } else for (k = 0; k < opts.length; k++) out.push(P(one(k), { jc: 'both', left: EN_H, before: 0, after: 20, keepNext: k < opts.length - 1 }));
    }
    if (withAns) {
        var sol = String(q.solution || '').trim();
        out.push(P(C.textRun('Answer: ', { b: true }) + (sol ? enRuns(doc, sol, { i: true }) : C.textRun('Chọn ' + (q.correct >= 0 ? 'ABCD'[q.correct] : '?') + '.', { i: true })), { jc: 'both', before: 20, after: 60 }));
    }
    return out;
}
// Bảng tiêu đề trang đầu: 2 cột không viền, ô "Mã đề" có viền (giống mẫu)
function enHeader(doc, cfg, ver, withAns, total) {
    var I = infoCfg(cfg), s22 = { b: true, sz: 22 }, i22 = { i: true, sz: 22 };
    var pages = Math.max(1, Math.round(total / 10)), pg = (pages < 10 ? '0' : '') + pages;
    var l1 = [];
    if (I.sgd) l1.push(C.textRun(I.sgd, s22));
    if (I.school) l1.push(C.textRun(I.school, s22));
    l1.push(C.textRun('ĐỀ THI CHÍNH THỨC', s22));
    l1.push(C.textRun('(Đề thi có ', i22) + fieldRuns('NUMPAGES \\# "00"', i22, pg) + C.textRun(' trang)', i22));
    var r1 = [];
    if (I.exam) r1.push(C.textRun(I.exam, s22));
    if (I.year) r1.push(C.textRun('Năm học ' + I.year, s22));
    var mon = (I.subject ? 'Môn thi: ' + I.subject.toUpperCase() : '') + (I.grade ? (I.subject ? ' – ' : '') + 'LỚP ' + I.grade.toUpperCase() : '');
    if (mon) r1.push(C.textRun(mon, s22));
    if (I.time) r1.push(C.textRun('Thời gian làm bài: ' + I.time + ' phút, không kể thời gian phát đề', { b: true, i: true, sz: 22 }));
    var tc = function (inner) { return '<w:tc><w:tcPr><w:tcW w:w="4933" w:type="dxa"/></w:tcPr>' + inner + '</w:tc>'; };
    var bd = ['top', 'left', 'bottom', 'right'].map(function (x) { return '<w:' + x + ' w:val="single" w:sz="6" w:space="0" w:color="auto"/>'; }).join('');
    var box = '<w:tbl><w:tblPr><w:tblW w:w="2154" w:type="dxa"/><w:jc w:val="right"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="2154"/></w:tblGrid>' +
        '<w:tr><w:tc><w:tcPr><w:tcW w:w="2154" w:type="dxa"/><w:tcBorders>' + bd + '</w:tcBorders></w:tcPr>' + (ver.code ? P(C.textRun('Mã đề: ' + ver.code, { b: true }), { jc: 'center' }) : P('', { jc: 'center' })) + '</w:tc></w:tr></w:tbl>';
    var tail = '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="40" w:lineRule="exact"/></w:pPr></w:p>';
    var tbl = '<w:tbl><w:tblPr><w:tblW w:w="9866" w:type="dxa"/><w:jc w:val="center"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="4933"/><w:gridCol w:w="4933"/></w:tblGrid>' +
        '<w:tr>' + tc(P(l1.join(EN_BR), { jc: 'center' })) + tc(P(r1.join(EN_BR), { jc: 'center' })) + '</w:tr>' +
        '<w:tr>' + tc(P(C.textRun('Họ, tên thí sinh: ' + '.'.repeat(46), s22) + EN_BR + C.textRun('Số báo danh: ' + '.'.repeat(51), s22))) + tc(P('', { jc: 'right' }) + box + tail) + '</w:tr></w:tbl>';
    var out = [];
    if (withAns) out.push(P(C.textRun('ĐỀ CÓ ĐÁP ÁN – DÀNH CHO GIÁO VIÊN (KHÔNG PHÁT CHO HỌC SINH)', { b: true, color: 'C00000' }), { jc: 'center', after: 60 }));
    out.push(tbl);
    return out;
}

    window.__CODE93_DOC = { buildExamDocx: buildExamDocx, buildKeyDocx: buildKeyDocx, prepareImages: prepareImages, Doc: Doc, tableXml: tableXml, decodeTable: decodeTable };
})();

/* ============================================================
   [CODE93] Phần 3: trang TRỘN ĐỀ THI – dữ liệu, thuật toán trộn, giao diện, xuất file
   ============================================================ */
(function () {
    'use strict';
    var C = window.__CODE93_CORE, D = window.__CODE93_DOC;
    var $ = C.$, esc = C.esc;

    var MIX = { src: [], fileName: '', versions: [], cfg: null, monTouched: false, active: false };
    var DEFAULT_CFG = { fmt: 'mathtype', sgd: '', school: '', exam: '', subject: '', grade: '', year: '', time: '', mon: '', n: 4, mI: true, oI: true, mII: true, oII: true, mIII: true };

    var fold = function (s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').toLowerCase().trim(); };
    var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };
    function subjectCode(name) {
        var f = fold(name);
        if (!f) return '';
        if (/tieng\s*anh|english|^anh$/.test(f)) return '11';   // [CODE123] theo file mẫu ĐỀ MẪU ANH (mã đề 1127)
        if (/\btoan\b/.test(f)) return '01';
        if (/vat\s*(li|ly)|^ly$/.test(f)) return '02';
        if (/\bhoa\b/.test(f)) return '03';
        if (/\bsinh\b/.test(f)) return '04';
        if (/tin\s*hoc/.test(f)) return '05';
        if (/cong\s*nghe/.test(f)) return '06';
        if (/lich\s*su|^su$/.test(f)) return '08';
        if (/dia\s*(li|ly)|^dia$/.test(f)) return '09';
        if (/gdkt|gdcd|kinh\s*te|cong\s*dan/.test(f)) return '10';
        return '';
    }

    /* ---------- cấu hình ---------- */
    function loadCfg() {
        var c = {};
        try { c = JSON.parse(localStorage.getItem(C.LS_KEY) || '{}') || {}; } catch (e) { c = {}; }
        return Object.assign({}, DEFAULT_CFG, c);
    }
    function saveCfg() { try { localStorage.setItem(C.LS_KEY, JSON.stringify(MIX.cfg)); } catch (e) {} }
    function readCfg() {
        var g = function (id) { var el = $(id); return el ? el.value : ''; };
        var k = function (id) { var el = $(id); return !!(el && el.checked); };
        var n = parseInt(g('mx-n'), 10);
        MIX.cfg = {
            fmt: (g('mx-fmt') === 'omml' ? 'omml' : 'mathtype'), sgd: g('mx-sgd'), school: g('mx-school'), exam: g('mx-exam'), subject: g('mx-subject'), grade: g('mx-grade'), year: g('mx-year'), time: g('mx-time'),
            mon: String(g('mx-mon')).replace(/\D/g, '').slice(0, 2), n: isFinite(n) ? n : 1, mI: k('mx-mI'), oI: k('mx-oI'), mII: k('mx-mII'), oII: k('mx-oII'), mIII: k('mx-mIII')
        };
        return MIX.cfg;
    }
    function writeCfg() {
        var c = MIX.cfg, set = function (id, v) { var el = $(id); if (el) el.value = v; }, chk = function (id, v) { var el = $(id); if (el) el.checked = !!v; };
        set('mx-fmt', c.fmt === 'omml' ? 'omml' : 'mathtype'); set('mx-sgd', c.sgd); set('mx-school', c.school); set('mx-exam', c.exam); set('mx-subject', c.subject); set('mx-grade', c.grade); set('mx-year', c.year); set('mx-time', c.time);
        set('mx-mon', c.mon); set('mx-n', c.n); chk('mx-mI', c.mI); chk('mx-oI', c.oI); chk('mx-mII', c.mII); chk('mx-oII', c.oII); chk('mx-mIII', c.mIII);
    }
    function effMon(cfg) { return (cfg.mon && cfg.mon.length === 2) ? cfg.mon : (subjectCode(cfg.subject) || '00'); }
    function codesFor(cfg) {
        var n = Math.max(0, Math.min(99, cfg.n | 0)), mon = effMon(cfg), out = [];
        for (var i = 1; i <= n; i++) out.push(mon + pad2(i));
        return out;
    }

    /* ---------- chuẩn hóa câu hỏi nhập từ Word ---------- */
    var REF_RE = /(^|[\s,;(])(c[aả]\s|tất cả|tat ca|cả hai|đều|không có|các (ý|phương án|đáp án)|phương án [A-D]\b|đáp án [A-D]\b|\b[A-D]\s*(,|và|&)\s*[A-D]\b)/i;
    var EN_LOCK1 = /\b(?:all|none|both|neither)\s+of\s+(?:the\s+)?(?:above|these|them|those)\b/i;   // [CODE123]
    var EN_LOCK2 = /\bboth\s+[A-D]\s+and\s+[A-D]\b|\b[A-D]\s*(?:,|&|and)\s*[A-D]\b/;
    function normQ(q) {
        var t = qType(q);
        var o = { type: t, text: String(q.text || ''), solution: String(q.solution || ''), gid: q.gid ? String(q.gid) : '', ginfo: q.ginfo ? String(q.ginfo) : '', gm: q.gm ? String(q.gm) : '', en: (q.en || q.gm) ? 1 : 0 };   // [CODE121]
        var opts = (q.options || []).map(function (x) { return String((x && x.text) || ''); });
        if (t === 'mc') {
            o.opts = opts;
            o.correct = q.detectedByStyle ? (q.correctIndex | 0) : -1;
            o.lock = o.en ? opts.some(function (s) { var t = String(s).replace(/<[^>]+>/g, ''); return EN_LOCK1.test(t) || EN_LOCK2.test(t); })
                : opts.some(function (s) { return REF_RE.test(String(s).replace(/<[^>]+>/g, '')); });
        } else if (t === 'tf') {
            while (opts.length < 4) opts.push('');
            o.opts = opts.slice(0, 4);
            o.tf = [0, 1, 2, 3].map(function (i) { return !!(q.tfAnswers && q.tfAnswers[i]); });
            o.tfKnown = !!q.detectedByStyle || o.tf.some(Boolean);
            o.tfSol = [0, 1, 2, 3].map(function (i) { return String((q.tfSol && q.tfSol[i]) || ''); });
        } else {
            o.sa = String(q.shortAnswer || '').trim();
        }
        return o;
    }
    function snippet(s, n) {
        s = String(s || '').replace(/@@IMG_[^@]*@@/g, ' [hình] ').replace(/@@TBL_[^@]*@@/g, ' [bảng] ').replace(/\$([^$]*)\$/g, function (m, a) { return ' ' + a.replace(/\\[a-zA-Z]+/g, '').replace(/[{}^_]/g, '') + ' '; })
            .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
        return s.length > n ? s.slice(0, n - 1) + '…' : s;
    }
    var unresolved = function (q) { return q.type === 'mc' ? q.correct < 0 : q.type === 'tf' ? !q.tfKnown : !q.sa; };

    /* ---------- thuật toán trộn ---------- */
    function seedRng() {
        var s;
        try { var a = new Uint32Array(1); crypto.getRandomValues(a); s = a[0]; } catch (e) { s = (Date.now() ^ (Math.random() * 4294967296)) >>> 0; }
        return function () {   // mulberry32
            s = (s + 0x6D2B79F5) >>> 0;
            var t = s;
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };
    }
    function shuffle(a, rnd) {
        for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
        return a;
    }
    // [CODE123] Lời giải English có "Chọn D." / "đáp án B"...: đảo đáp án thì chữ cái phải đổi theo vị trí mới
    var LETTER_REF = /(Chọn|chọn|Đáp\s*án(?:\s*đúng)?(?:\s*là)?|đáp\s*án(?:\s*đúng)?(?:\s*là)?|Phương\s*án|phương\s*án|Option|option)(\s*[:\-]?\s*)([A-D])(?![A-Za-zÀ-ỹ0-9])/g;
    function remapSolution(sol, order) {
        if (!sol) return sol;
        return String(sol).replace(LETTER_REF, function (m, p1, p2, L) {
            var nk = order.indexOf('ABCD'.indexOf(L));
            return nk < 0 ? m : p1 + p2 + 'ABCD'[nk];
        });
    }
    function inst(q, cfg, rnd) {
        var c = { type: q.type, srcIdx: q.idx, text: q.text, solution: q.solution, gid: q.gid, ginfo: q.ginfo, gm: q.gm, en: q.en, perm: '' };
        var n, order, i;
        if (q.type === 'mc') {
            n = q.opts.length; order = []; for (i = 0; i < n; i++) order.push(i);
            if (cfg.oI && !q.lock) shuffle(order, rnd);
            c.opts = order.map(function (k) { return q.opts[k]; });
            c.correct = q.correct >= 0 ? order.indexOf(q.correct) : -1;
            c.perm = order.join('');
            if (q.en) c.solution = remapSolution(q.solution, order);   // [CODE123]
        } else if (q.type === 'tf') {
            order = [0, 1, 2, 3];
            if (cfg.oII) shuffle(order, rnd);
            c.opts = order.map(function (k) { return q.opts[k]; });
            c.tf = order.map(function (k) { return q.tf[k]; });
            c.tfSol = order.map(function (k) { return q.tfSol[k]; });
            c.tfKnown = q.tfKnown;
            c.perm = order.join('');
        } else {
            c.sa = q.sa;
        }
        return c;
    }
    function makeVersion(cfg, rnd, code, srcList) {
        var parts = [], sig = '';
        ['mc', 'tf', 'sa'].forEach(function (t) {
            var blocks = [];
            var srcT = (srcList || MIX.src).filter(function (q) { return q.type === t; });
            var doShuf = (t === 'mc' ? cfg.mI : t === 'tf' ? cfg.mII : cfg.mIII);
            var enT = !!(window.CODE121EN && srcT.some(function (q) { return q.gm; }));   // [CODE121] đề English
            if (enT) {
                var flat = doShuf ? CODE121EN.shuffleList(srcT, function (a) { return shuffle(a.slice(), rnd); }) : srcT;
                blocks = [flat];
            } else {
                srcT.forEach(function (q) {
                    var lb = blocks[blocks.length - 1];
                    if (q.gid && lb && lb[0].gid === q.gid) lb.push(q); else blocks.push([q]);   // câu cùng nhóm (dữ kiện chung) đi liền nhau
                });
                if (doShuf) shuffle(blocks, rnd);
            }
            var list = [].concat.apply([], blocks).map(function (q) { return inst(q, cfg, rnd); });
            for (var i = 0; i < list.length; i++) {   // thông tin nhóm: in trước câu đầu nhóm
                var q = list[i];
                if (q.gid && (i === 0 || list[i - 1].gid !== q.gid)) {
                    var j = i, info = q.ginfo;
                    while (j + 1 < list.length && list[j + 1].gid === q.gid) { j++; if (!info && list[j].ginfo) info = list[j].ginfo; }
                    q.gFirst = { from: i + 1, to: j + 1, info: info || '', gm: q.gm };
                }
            }
            list.forEach(function (q) { sig += q.srcIdx + ':' + q.perm + ','; });
            parts.push({ type: t, list: list });
        });
        return { code: code, parts: parts, sig: sig };
    }
    function keyOf(q) {
        if (q.type === 'mc') return q.correct >= 0 ? 'ABCD'[q.correct] : '?';
        if (q.type === 'tf') return q.tfKnown ? q.tf.map(function (v) { return v ? 'Đ' : 'S'; }).join('') : '????';
        return q.sa || '?';
    }

    /* ---------- giao diện ---------- */
    var CSS = '' +
        '.mx-modal{position:absolute;inset:0;z-index:64;background:rgba(0,0,0,.75);display:flex;justify-content:center;align-items:stretch;transition:opacity .3s}' +
        '.mx-modal.hidden{display:none}.mx-modal.opacity-0{opacity:0}' +
        '.mx-panel{background:#f1f5f9;width:100%;height:100%;display:flex;flex-direction:column;overflow:hidden;color:#0f172a}' +
        '.mx-head{background:linear-gradient(90deg,#7c3aed,#4f46e5);color:#fff;padding:12px 20px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex:none}' +
        '.mx-head h2{margin:0;font-size:22.5px;font-weight:900;letter-spacing:.03em;text-transform:uppercase}' +
        '.mx-x{background:rgba(255,255,255,.2);color:#fff;border:0;border-radius:999px;padding:7px 16px;font-weight:900;font-size:16px;cursor:pointer;white-space:nowrap}.mx-x:hover{background:rgba(255,255,255,.35)}' +
        '.mx-body{flex:1;min-height:0;overflow-y:auto;padding:14px 20px 28px}' +
        '.mx-wrap{max-width:none;width:100%;margin:0;display:flex;flex-direction:column;gap:12px}' +
        '.mx-card{background:#fff;border:1px solid #dbe3ef;border-radius:16px;padding:14px 16px;box-shadow:0 1px 4px rgba(15,23,42,.06)}' +
        '.mx-card h3{margin:0 0 10px;font-size:17px;font-weight:900;color:#4338ca;text-transform:uppercase;letter-spacing:.02em}' +
        '.mx-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px}' +
        '.mx-grid.one{grid-template-columns:1.3fr 1.5fr 1.5fr 1fr .55fr .95fr .95fr;gap:8px;align-items:end}' +
        '.mx-grid.one .mx-f{min-width:0}' +
        '.mx-grid.one .mx-f label{font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
        '.mx-grid.one .mx-f input[type=text]{font-size:15.5px;padding:8px 9px}' +
        '@media (max-width:1100px){.mx-grid.one{grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}}' +
        '.mx-f label{display:block;font-size:14px;font-weight:900;color:#475569;text-transform:uppercase;margin-bottom:3px}' +
        '.mx-f input[type=text],.mx-f input[type=number]{width:100%;box-sizing:border-box;border:2px solid #cbd5e1;border-radius:10px;padding:8px 10px;font-size:17px;font-weight:700;color:#0f172a;background:#f8fafc;outline:none}' +
        '.mx-f input:focus{border-color:#6366f1;background:#fff}' +
        '.mx-f select{width:100%;box-sizing:border-box;border:2px solid #cbd5e1;border-radius:10px;padding:8px 10px;font-size:16px;font-weight:700;color:#0f172a;background:#f8fafc}' +
        '.mx-btn{border:0;border-radius:12px;padding:10px 18px;font-weight:900;font-size:16px;text-transform:uppercase;color:#fff;cursor:pointer;box-shadow:0 2px 6px rgba(15,23,42,.2);transition:transform .12s}.mx-btn:active{transform:scale(.96)}' +
        '.mx-btn.sky{background:linear-gradient(90deg,#0ea5e9,#2563eb)}.mx-btn.vio{background:linear-gradient(90deg,#8b5cf6,#6d28d9)}.mx-btn.grn{background:linear-gradient(90deg,#10b981,#059669)}.mx-btn.gry{background:#94a3b8;box-shadow:none}.mx-btn.red{background:#ef4444}' +
        '.mx-btn[disabled]{opacity:.45;cursor:not-allowed}' +
        '.mx-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}' +
        '.mx-note{font-size:14.5px;font-weight:600;color:#64748b;line-height:1.45;margin:6px 0 0}' +
        '.mx-warn{background:#fffbeb;border:1px solid #fcd34d;color:#92400e;border-radius:12px;padding:8px 12px;font-size:15px;font-weight:700;margin-top:8px}' +
        '.mx-ok{background:#ecfdf5;border:1px solid #6ee7b7;color:#065f46;border-radius:12px;padding:8px 12px;font-size:15.5px;font-weight:800;margin-top:8px}' +
        '.mx-chk{display:flex;align-items:center;gap:8px;font-size:17px;font-weight:700;padding:5px 0;cursor:pointer}.mx-chk input{width:19px;height:19px;accent-color:#6366f1}.mx-chk.sub{margin-left:30px;font-weight:600;color:#334155}' +
        '.mx-list{max-height:240px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:12px;margin-top:8px}' +
        '.mx-li{display:flex;gap:8px;align-items:baseline;padding:5px 10px;border-bottom:1px solid #f1f5f9;font-size:15px}.mx-li:last-child{border-bottom:0}' +
        '.mx-li b{flex:none;min-width:84px;color:#4338ca}.mx-li span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#334155}' +
        '.mx-li em{flex:none;font-style:normal;font-weight:900;color:#047857;background:#d1fae5;border-radius:999px;padding:1px 9px}.mx-li em.q{color:#b45309;background:#fef3c7}' +
        '.mx-ver{border:1px solid #c7d2fe;background:#eef2ff;border-radius:14px;padding:10px 12px}' +
        '.mx-ver-h{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.mx-ver-h b{font-size:19.5px;color:#3730a3;font-weight:900}' +
        '.mx-key{font-family:ui-monospace,Consolas,monospace;font-size:15px;line-height:1.6;word-break:break-all;color:#1e293b;margin-top:4px}.mx-key u{text-decoration:none;font-weight:900;color:#4338ca;font-family:inherit}' +
        '.mx-pv{background:#fff;border:1px solid #cbd5e1;border-radius:12px;padding:10px 14px;margin-top:8px;max-height:420px;overflow-y:auto;font-size:17px;line-height:1.5}' +
        '.mx-pv .pq{margin:0 0 10px}.mx-pv .po{display:inline-block;min-width:48%;vertical-align:top;margin:1px 0}.mx-pv .ok{font-weight:900;text-decoration:underline;color:#047857}.mx-pv h4{margin:10px 0 6px;font-weight:900;color:#4338ca}' +
        '.mx-fs{position:absolute;inset:0;z-index:30;background:#f1f5f9;display:flex;flex-direction:column}.mx-fs.hidden{display:none}' +
        '.mx-fs-h{flex:none;background:linear-gradient(90deg,#7c3aed,#4f46e5);color:#fff;padding:10px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px}' +
        '.mx-fs-h h2{margin:0;font-size:20.5px;font-weight:900;letter-spacing:.03em;text-transform:uppercase;font-family:Roboto,Arial,sans-serif}' +
        '.mx-fs-b{flex:1;min-height:0;overflow-y:auto;padding:16px 18px 40px}' +
        '.mx-fs-w{max-width:none;margin:0;background:#fff;border:1px solid #cbd5e1;border-radius:14px;padding:22px 28px;font-family:Roboto,Arial,sans-serif !important}' +
        '.mx-fs-w .mx-pv{max-height:none;overflow:visible;border:0;margin:0;padding:0;font-family:Roboto,Arial,sans-serif !important;font-size:19px;line-height:1.65;color:#0f172a}' +
        '.mx-fs-w .mx-pv *{font-family:inherit}.mx-fs-w .mx-pv .po{min-width:48%}' +
        '.mx-fs-w .mx-key{font-family:Roboto,Arial,sans-serif;font-size:17px;margin-top:18px;padding-top:12px;border-top:2px dashed #c7d2fe}' +
        '.mx-fs-h h2,.mx-fs-w .mx-pv h4,.mx-fs-w .mx-key>b{font-family:\'UTM HelvetIns\',\'Helvetica Neue\',Helvetica,Arial,sans-serif !important}.mx-fs-w .mx-pv h4{font-size:20.5px;letter-spacing:.02em}' +
        '@media (max-width:640px){.mx-fs-w{padding:14px 12px}.mx-fs-w .mx-pv{font-size:17.5px}.mx-fs-w .mx-pv .po{min-width:100%}}' +
        '.mx-prog{position:absolute;inset:0;z-index:5;background:rgba(15,23,42,.6);display:flex;align-items:center;justify-content:center}' +
        '.mx-prog>div{background:#fff;border-radius:18px;padding:22px 30px;font-weight:900;color:#3730a3;text-align:center;max-width:90%}' +
        '.c83-mixbtn{width:100%;max-width:340px;display:flex;align-items:center;justify-content:center;gap:8px;padding:12px 16px;border-radius:14px;font-size:15px;font-weight:900;letter-spacing:.03em;color:#fff !important;background:linear-gradient(90deg,#ec4899,#8b5cf6 55%,#4f46e5);border:3px solid #fbbf24;box-shadow:0 0 0 3px rgba(79,70,229,.30),0 6px 16px rgba(124,58,237,.45);text-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .12s,filter .12s}' +
        '.c83-mixbtn:hover{transform:translateY(-1px);filter:brightness(1.08)}.c83-mixbtn:active{transform:scale(.97)}';
    var SUBJECTS = ['Toán'];
    var HTML = '' +
        '<div class="mx-panel">' +
        '<div class="mx-head"><h2>🔀 Trộn đề thi</h2><button type="button" class="mx-x" onclick="CODE93Mix.close()">← Về trang chủ</button></div>' +
        '<div class="mx-body"><div class="mx-wrap">' +

        '<div class="mx-card"><h3>1. Nhập đề gốc</h3>' +
        '<div class="mx-row"><button type="button" class="mx-btn sky" onclick="CODE93Mix.importWord()">📄 Nhập đề từ file Word</button>' +
        '<button type="button" class="mx-btn" id="mx-import-en" style="background:linear-gradient(90deg,#f97316,#dc2626)" onclick="CODE93Mix.importWordEN()" title="Đáp án gạch chân • câu hỏi nhóm đặt trong [ ] • lời giải sau Answer:">📘 NHẬP FILE WORD ENGLISH</button>' +
        '<button type="button" class="mx-btn vio" id="mx-view" onclick="CODE93Mix.viewSrc()" disabled>👁 Xem lại đề gốc</button>' +
        '<button type="button" class="mx-btn gry" id="mx-clear" onclick="CODE93Mix.clearSrc()">Xóa đề đã nạp</button></div>' +
        '<p class="mx-note">📘 <b>File English:</b> đáp án đúng <u>gạch chân</u>; câu hỏi nhóm đặt trong <b>[ ]</b>; nhóm có “Read the” giữ nguyên số thứ tự câu, chỉ đảo A, B, C, D; các nhóm còn lại đảo cả thứ tự câu và đáp án; lời giải đặt sau “Answer:”.</p>' +
        '<div id="mx-src-status"></div>' +
        '<div id="mx-src-view" style="display:none"></div>' +
        '</div>' +

        '<div class="mx-card"><h3>2. Thông tin trang đầu của đề thi</h3><div class="mx-grid one">' +
        '<div class="mx-f"><label>Sở giáo dục</label><input type="text" id="mx-sgd" placeholder="VD: SỞ GD – ĐT QUẢNG TRỊ" oninput="CODE93Mix.onCfg()"></div>' +
        '<div class="mx-f"><label>Tên trường</label><input type="text" id="mx-school" placeholder="VD: THPT NGUYỄN CHÍ THANH" oninput="CODE93Mix.onCfg()"></div>' +
        '<div class="mx-f"><label>Tên kì thi</label><input type="text" id="mx-exam" placeholder="VD: KIỂM TRA GIỮA KÌ I" oninput="CODE93Mix.onCfg()"></div>' +
        '<div class="mx-f"><label>Môn thi</label><input type="text" id="mx-subject" list="mx-subj-list" placeholder="VD: Hóa học" oninput="CODE93Mix.onSubject()"><datalist id="mx-subj-list">' +
        SUBJECTS.map(function (s) { return '<option value="' + esc(s) + '">'; }).join('') + '</datalist></div>' +
        '<div class="mx-f"><label>Lớp</label><input type="text" id="mx-grade" placeholder="VD: 12" oninput="CODE93Mix.onCfg()"></div>' +
        '<div class="mx-f"><label>Năm học</label><input type="text" id="mx-year" placeholder="VD: 2026 – 2027" oninput="CODE93Mix.onCfg()"></div>' +
        '<div class="mx-f"><label title="Thời gian làm bài (phút)">Thời gian làm bài (phút)</label><input type="text" id="mx-time" placeholder="VD: 50" oninput="CODE93Mix.onCfg()"></div>' +
        '</div></div>' +

        '<div class="mx-card"><h3>3. Cấu hình trộn</h3>' +
        '<label class="mx-chk"><input type="checkbox" id="mx-mI" onchange="CODE93Mix.onCfg()"> Trộn thứ tự các câu Phần I (nhiều lựa chọn)</label>' +
        '<label class="mx-chk sub"><input type="checkbox" id="mx-oI" onchange="CODE93Mix.onCfg()"> Đảo vị trí các phương án A, B, C, D trong mỗi câu</label>' +
        '<label class="mx-chk"><input type="checkbox" id="mx-mII" onchange="CODE93Mix.onCfg()"> Trộn thứ tự các câu Phần II (đúng – sai)</label>' +
        '<label class="mx-chk sub"><input type="checkbox" id="mx-oII" onchange="CODE93Mix.onCfg()"> Đảo vị trí các ý a), b), c), d) trong mỗi câu</label>' +
        '<label class="mx-chk"><input type="checkbox" id="mx-mIII" onchange="CODE93Mix.onCfg()"> Trộn thứ tự các câu Phần III (trả lời ngắn)</label>' +
        '<div class="mx-f" style="margin-top:10px"><label>Định dạng công thức Toán – Lý – Hóa trong file Word</label><select id="mx-fmt" onchange="CODE93Mix.onCfg()"><option value="mathtype">MathType (đối tượng công thức MathType, bấm đúp để sửa)</option><option value="omml">Equation của Word (OMML – dự phòng)</option></select></div>' +
        '<div id="mx-lock-note"></div></div>' +

        '<div class="mx-card"><h3>4. Số lượng mã đề cần tạo</h3><div class="mx-grid">' +
        '<div class="mx-f"><label>Số lượng mã đề cần tạo (1 – 99)</label><input type="number" id="mx-n" min="1" max="99" oninput="CODE93Mix.onCfg()"></div>' +
        '<div class="mx-f"><label>Mã môn (2 số đầu của mã đề)</label><input type="text" id="mx-mon" maxlength="2" inputmode="numeric" placeholder="tự nhận theo môn" oninput="CODE93Mix.onMon()"></div></div>' +
        '<div id="mx-codes" class="mx-note" style="font-weight:800;color:#3730a3"></div>' +
        '<p class="mx-note">Mã đề gồm 4 số: 2 số đầu là mã môn theo cách đánh mã đề của Bộ GD&ĐT, 2 số sau là số thứ tự. Đã đối chiếu mã đề thi tốt nghiệp THPT 2026: Toán 01 (0101…0124), Vật lí 02, Lịch sử 08, Tiếng Anh 11 (theo file mẫu: 1127). Các môn khác là mã gợi ý, thầy/cô sửa lại ở ô “Mã môn” nếu khác.</p></div>' +

        '<div class="mx-card"><div class="mx-row">' +
        '<button type="button" class="mx-btn vio" id="mx-gen" onclick="CODE93Mix.generate()">🔀 Tạo đề</button>' +
        '<button type="button" class="mx-btn grn" id="mx-exp" onclick="CODE93Mix.exportAll()" disabled>⬇ Xuất file đề</button>' +
        '<button type="button" class="mx-btn" id="mx-exp-qm" style="background:linear-gradient(90deg,#f59e0b,#ea580c)" onclick="CODE93Mix.exportKey(\'qm\')" disabled title="File Excel đáp án nhập vào app chấm thi QM (QM 2025 / Young Mix)">📊 Xuất đáp án QM</button>' +
        '<button type="button" class="mx-btn" id="mx-exp-tn" style="background:linear-gradient(90deg,#14b8a6,#0e7490)" onclick="CODE93Mix.exportKey(\'tn\')" disabled title="File Excel đáp án nhập vào app chấm thi TNMaker">📊 Xuất đáp án TNMaker</button></div>' +
        '<p class="mx-note">“Xuất file đề” tải về 1 gói (.zip) giải nén ra thành 1 thư mục gồm: đề thi từng mã đề (.docx), đề có đáp án từng mã đề (.docx) và bảng đáp án tổng hợp (.docx). Hai nút “Xuất đáp án QM” và “Xuất đáp án TNMaker” tải về file Excel (.xlsx) đáp án của tất cả mã đề đã tạo để nhập thẳng vào phần mềm chấm trắc nghiệm tương ứng.</p>' +
        '<div id="mx-results" style="display:flex;flex-direction:column;gap:10px;margin-top:10px"></div></div>' +

        '</div></div></div>';

    function ensureModal() {
        var m = $('mix-modal');
        if (m) return m;
        if (!$('code93-style')) { var st = document.createElement('style'); st.id = 'code93-style'; st.textContent = CSS; document.head.appendChild(st); }
        m = document.createElement('div');
        m.id = 'mix-modal'; m.className = 'mx-modal hidden opacity-0';
        m.innerHTML = HTML;
        ($('app-wrapper') || document.body).appendChild(m);
        return m;
    }
    function open() {
        var m = ensureModal();
        MIX.cfg = loadCfg();
        if (!MIX.cfg.mon) MIX.monTouched = false;
        writeCfg(); renderAll();
        m.classList.remove('hidden');
        setTimeout(function () { m.classList.remove('opacity-0'); }, 10);
    }
    function close() {
        var m = $('mix-modal'); if (!m) return;
        try { closePreview(); } catch (e) {}
        m.classList.add('opacity-0');
        setTimeout(function () { m.classList.add('hidden'); }, 300);
    }
    function onCfg() { readCfg(); saveCfg(); renderCodes(); }
    function onSubject() {
        var c = readCfg();
        if (!MIX.monTouched) {
            var code = subjectCode(c.subject), el = $('mx-mon');
            if (el) el.value = code;
            c = readCfg();
        }
        saveCfg(); renderCodes();
    }
    function onMon() { MIX.monTouched = true; readCfg(); saveCfg(); renderCodes(); }
    function renderCodes() {
        var el = $('mx-codes'); if (!el) return;
        var c = MIX.cfg || readCfg(), codes = codesFor(c);
        if (!codes.length) { el.textContent = ''; return; }
        el.textContent = 'Mã đề sẽ tạo (' + codes.length + '): ' + (codes.length > 12 ? codes.slice(0, 8).join(', ') + ', …, ' + codes[codes.length - 1] : codes.join(', '));
        if (c.n > 99) el.textContent += ' — tối đa 99 mã đề.';
    }
    function enNote() {   // [CODE123]
        var st = $('mx-src-status'); if (!st || !MIX.src.length) return;
        if (!MIX.src.some(function (q) { return q.gm || q.en; })) return;
        var g = {}, free = 0, k = 0, d2 = 0;
        MIX.src.forEach(function (q) { if (q.gid) g[q.gid] = q.gm; else free++; });
        Object.keys(g).forEach(function (id) { if (g[id] === 'k') k++; else d2++; });
        st.insertAdjacentHTML('beforeend', '<div class="mx-ok" style="background:#eff6ff;border-color:#93c5fd;color:#1e3a8a">📘 Đề English: ' + k + ' nhóm dạng 1 (“Read the” – giữ số câu, chỉ đảo A–D) • ' + d2 + ' nhóm dạng 2 (đảo cả câu và đáp án) • ' + free + ' câu lẻ.</div>');
    }
    function renderSrc() { renderSrc0(); enNote(); }
    function renderSrc0() {
        var st = $('mx-src-status'), box = $('mx-lock-note');
        if (!st) return;
        if (!MIX.src.length) { st.innerHTML = '<div class="mx-warn">Chưa có đề gốc. Bấm “Nhập đề từ file Word” để nạp đề.</div>'; if (box) box.innerHTML = ''; return; }
        var cnt = { mc: 0, tf: 0, sa: 0 }, un = 0, rows = '';
        var seq = { mc: 0, tf: 0, sa: 0 }, locked = [];
        MIX.src.forEach(function (q) {
            cnt[q.type]++; seq[q.type]++;
            var bad = unresolved(q); if (bad) un++;
            if (q.type === 'mc' && q.lock) locked.push(seq.mc);
            var ans = q.type === 'mc' ? (q.correct >= 0 ? 'ABCD'[q.correct] : '?') : q.type === 'tf' ? (q.tfKnown ? q.tf.map(function (v) { return v ? 'Đ' : 'S'; }).join('') : '????') : (q.sa || '?');
            rows += '<div class="mx-li"><b>' + (q.type === 'mc' ? 'Phần I' : q.type === 'tf' ? 'Phần II' : 'Phần III') + ' – Câu ' + seq[q.type] + '</b><span>' + esc(snippet(q.text, 110)) + '</span><em class="' + (bad ? 'q' : '') + '">' + esc(ans) + '</em></div>';
        });
        st.innerHTML = '<div class="mx-ok">✓ Đã nạp ' + MIX.src.length + ' câu' + (MIX.fileName ? ' từ “' + esc(MIX.fileName) + '”' : '') + ': Phần I = ' + cnt.mc + ', Phần II = ' + cnt.tf + ', Phần III = ' + cnt.sa + '.</div>' +
            (un ? '<div class="mx-warn">⚠ Có ' + un + ' câu chưa có đáp án đúng (hiện dấu “?”). Đề vẫn trộn được nhưng bảng đáp án sẽ để “?” ở các câu này. Bấm “Nhập đề từ file Word” lần nữa để chọn đáp án ở màn hình kiểm tra, hoặc dùng ô “Nhập nhanh đáp án”.</div>' : '');   /* [CODE104] bỏ danh sách câu để tiết kiệm chỗ (xem bằng nút “Xem lại đề gốc”) */
        if (box) box.innerHTML = '';   /* [CODE108] không hiện cảnh báo “câu giữ nguyên thứ tự phương án” */
    }
    function keyHtml(ver) {
        var h = '';
        ver.parts.forEach(function (p) {
            if (!p.list.length) return;
            var label = p.type === 'mc' ? 'Phần I' : p.type === 'tf' ? 'Phần II' : 'Phần III';
            var sep = p.type === 'sa' ? ' | ' : ' ';
            var s = p.list.map(function (q, i) { return (p.type === 'mc' ? (i + 1) + '.' : p.type === 'sa' ? (i + 1) + ': ' : (i + 1) + ':') + esc(keyOf(q)); }).join(sep);
            h += '<div class="mx-key"><u>' + label + ':</u> ' + s + '</div>';
        });
        return h;
    }
    function previewHtml(ver) {
        var h = '';
        ver.parts.forEach(function (p) {
            if (!p.list.length) return;
            h += '<h4>' + (p.type === 'mc' ? 'PHẦN I' : p.type === 'tf' ? 'PHẦN II' : 'PHẦN III') + '</h4>';
            p.list.forEach(function (q, i) {
                h += '<div class="pq">';
                if (q.gFirst && q.gFirst.info) h += '<div><i>Thông tin chung (câu ' + q.gFirst.from + '–' + q.gFirst.to + '):</i> ' + formatMathAndChemHTML(q.gFirst.info, { center: true }) + '</div>';
                h += '<b>' + ((q.en || q.gm) ? 'Question' : 'Câu') + ' ' + (i + 1) + '.</b> ' + formatMathAndChemHTML(q.text, { center: true });
                if (q.type === 'mc') {
                    h += '<div>' + q.opts.map(function (o, k) { return '<span class="po' + (q.correct === k ? ' ok' : '') + '"><b>' + 'ABCD'[k] + '.</b> ' + formatMathAndChemHTML(o) + '</span>'; }).join('') + '</div>';
                } else if (q.type === 'tf') {
                    h += q.opts.map(function (o, k) { return '<div class="' + (q.tfKnown && q.tf[k] ? 'ok' : '') + '" style="margin-left:14px">' + '<b>' + 'abcd'[k] + ')</b> ' + formatMathAndChemHTML(o) + '</div>'; }).join('');
                } else {
                    h += '<div class="ok">Trả lời: ' + formatMathAndChemHTML(q.sa || '?') + '</div>';
                }
                h += '</div>';
            });
        });
        return h;
    }
    function renderResults() {
        var box = $('mx-results'), exp = $('mx-exp');
        if (!box) return;
        if (exp) exp.disabled = !MIX.versions.length;
        ['mx-exp-qm', 'mx-exp-tn'].forEach(function (id) { var b = $(id); if (b) b.disabled = !MIX.versions.length; });   /* [CODE125] */
        if (!MIX.versions.length) { box.innerHTML = ''; return; }
        box.innerHTML = '<div class="mx-ok">✓ Đã tạo ' + MIX.versions.length + ' mã đề. Bấm “Xem đề” để kiểm tra, rồi bấm “Xuất file đề”.</div>' + MIX.versions.map(function (v, i) {
            return '<div class="mx-ver"><div class="mx-ver-h"><b>Mã đề ' + v.code + '</b><button type="button" class="mx-btn sky" style="padding:5px 12px;font-size:12px" onclick="CODE93Mix.togglePreview(' + i + ')">Xem đề</button></div><div id="mx-pv-' + i + '" style="display:none"></div></div>';   /* [CODE105] bỏ bảng đáp án dưới mỗi mã đề (đã có trong file xuất) */
        }).join('');
    }
    /* [CODE104] Xem trước (đề gốc / mã đề đã trộn): mở TOÀN MÀN HÌNH, font Roboto */
    var fsKind = '', fsIdx = -1;
    function fsEl() {
        var m = ensureModal(), f = $('mx-fs');
        if (f) return f;
        f = document.createElement('div'); f.id = 'mx-fs'; f.className = 'mx-fs hidden';
        f.innerHTML = '<div class="mx-fs-h"><h2 id="mx-fs-t"></h2><button type="button" class="mx-x" onclick="CODE93Mix.closePreview()">✕ Đóng xem trước</button></div>' +
            '<div class="mx-fs-b" id="mx-fs-b"><div class="mx-fs-w" id="mx-fs-w"></div></div>';
        m.appendChild(f);
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { var x = $('mx-fs'); if (x && !x.classList.contains('hidden')) { closePreview(); e.stopPropagation(); } } }, true);
        return f;
    }
    function openPreview(kind, idx) {
        var v = kind === 'src' ? srcVersion() : MIX.versions[idx]; if (!v) return;
        var f = fsEl(); fsKind = kind; fsIdx = idx;
        $('mx-fs-t').textContent = kind === 'src' ? '👁 Đề gốc (chưa trộn)' : '👁 Xem đề – Mã đề ' + v.code;
        $('mx-fs-w').innerHTML = '<div class="mx-pv">' + previewHtml(v) + '</div><div class="mx-key"><b>Đáp án:</b>' + keyHtml(v) + '</div>';
        f.classList.remove('hidden'); $('mx-fs-b').scrollTop = 0;
    }
    function closePreview() { var f = $('mx-fs'); if (f) f.classList.add('hidden'); fsKind = ''; fsIdx = -1; }
    function togglePreview(i) { openPreview('ver', i); }
    /* [CODE97] Xem lại đề gốc: hiển thị toàn bộ đề đã nạp theo đúng thứ tự gốc (chưa trộn), có đánh dấu đáp án đúng */
    var srcViewOpen = false;
    function srcVersion() {
        var parts = [];
        ['mc', 'tf', 'sa'].forEach(function (t) {
            var list = MIX.src.filter(function (q) { return q.type === t; }).map(function (q) {
                var c = {}; for (var k in q) c[k] = q[k]; return c;
            });
            for (var i = 0; i < list.length; i++) {
                var q = list[i];
                if (q.gid && (i === 0 || list[i - 1].gid !== q.gid)) {
                    var j = i, info = q.ginfo;
                    while (j + 1 < list.length && list[j + 1].gid === q.gid) { j++; if (!info && list[j].ginfo) info = list[j].ginfo; }
                    q.gFirst = { from: i + 1, to: j + 1, info: info || '', gm: q.gm };
                }
            }
            parts.push({ type: t, list: list });
        });
        return { code: 'GOC', parts: parts, sig: '' };
    }
    function renderSrcView() {
        var btn = $('mx-view');
        if (btn) { btn.disabled = !MIX.src.length; btn.textContent = '👁 Xem lại đề gốc'; }
        if (!MIX.src.length && fsKind === 'src') closePreview();
        else if (fsKind === 'src') openPreview('src', -1);
        else if (fsKind === 'ver' && !MIX.versions[fsIdx]) closePreview();
    }
    function viewSrc() {
        if (!MIX.src.length) { toast('Chưa có đề gốc', 'Hãy bấm “Nhập đề từ file Word” để nạp đề trước khi xem lại.'); return; }
        openPreview('src', -1);
    }
    function renderAll() { renderSrc(); renderSrcView(); renderCodes(); renderResults(); }
    function toast(title, msg, type) { try { showModal(title, msg, type || 'info'); } catch (e) { alert(title + '\n' + msg); } }

    /* ---------- nhập đề ---------- */
    var BTN_SEL = '#word-import-modal button[onclick="applyWordImportToEditor()"]';
    function importWord() {
        MIX.active = true;
        openWordImportModal();
        var b = document.querySelector(BTN_SEL);
        if (b) { if (!b.dataset.old) b.dataset.old = b.textContent.trim(); b.textContent = 'Đưa vào TRỘN ĐỀ'; }
    }
    function importWordEN() {   // [CODE123] nút "NHẬP FILE WORD ENGLISH"
        MIX.active = true;
        var ok = false;
        try { ok = !!(window.CODE121EN && CODE121EN.openForMix && CODE121EN.openForMix()); } catch (e) { ok = false; }
        if (!ok) { MIX.active = false; toast('Chưa nhập được', 'Không mở được khung nhập file Word English. Hãy tải lại trang rồi thử lại.'); return; }
        var b = document.querySelector(BTN_SEL);
        if (b) { if (!b.dataset.old) b.dataset.old = b.textContent.trim(); b.textContent = 'Đưa vào TRỘN ĐỀ'; }
    }
    function leaveImport() {
        MIX.active = false;
        var b = document.querySelector(BTN_SEL);
        if (b && b.dataset.old) b.textContent = ' ' + b.dataset.old + ' ';
    }
    // gọi từ applyImportDraft khi đang ở chế độ trộn đề
    function receive(draft) {
        if (!draft || !draft.length) { toast('Thông báo', 'Chưa có câu hỏi nào từ file Word! Vui lòng chọn file Word (.docx) trước.'); return; }
        var radio = document.querySelector('input[name="word-import-mode"]:checked');
        var mode = radio ? radio.value : 'replace';
        var list = draft.map(normQ);
        MIX.src = mode === 'append' ? MIX.src.concat(list) : list;
        MIX.src.forEach(function (q, i) { q.idx = i; });
        try { if (typeof wordTempMemoryBuffer !== 'undefined' && wordTempMemoryBuffer && wordTempMemoryBuffer.fileName) MIX.fileName = wordTempMemoryBuffer.fileName; } catch (e) {}
        MIX.versions = [];
        closeWordImportModal();
        leaveImport();
        try { if (MIX.src.some(function (q) { return q.gm || q.en; })) { var sj = $('mx-subject'); if (sj && !String(sj.value).trim()) { sj.value = 'Tiếng Anh'; onSubject(); } } } catch (e) {}   // [CODE123]
        renderAll();
        var un = MIX.src.filter(unresolved).length;
        toast(un ? 'Đã nạp – cần kiểm tra' : 'Thành công!', 'Đã nạp ' + MIX.src.length + ' câu hỏi vào TRỘN ĐỀ THI.' + (un ? ' ⚠ ' + un + ' câu chưa có đáp án đúng.' : ''), un ? 'info' : 'success');
    }
    function clearSrc() { MIX.src = []; MIX.versions = []; MIX.fileName = ''; srcViewOpen = false; renderAll(); }

    /* ---------- tạo đề ---------- */
    function generate() {
        var cfg = readCfg(); saveCfg();
        if (!MIX.src.length) { toast('Chưa có đề gốc', 'Hãy bấm “Nhập đề từ file Word” để nạp đề trước khi tạo mã đề.'); return; }
        if (!cfg.n || cfg.n < 1) { toast('Số lượng mã đề', 'Hãy nhập số lượng mã đề cần tạo (từ 1 đến 99).'); return; }
        if (cfg.n > 99) { cfg.n = 99; var el = $('mx-n'); if (el) el.value = 99; }
        var codes = codesFor(cfg), rnd = seedRng(), seen = {}, vers = [];
        codes.forEach(function (code) {
            var v = null;
            for (var t = 0; t < 30; t++) { v = makeVersion(cfg, rnd, code); if (!seen[v.sig]) break; }
            seen[v.sig] = 1; vers.push(v);
        });
        MIX.versions = vers;
        var anyShuffle = cfg.mI || cfg.oI || cfg.mII || cfg.oII || cfg.mIII;
        renderResults();
        if (!anyShuffle) toast('Lưu ý', 'Chưa chọn kiểu trộn nào nên các mã đề giống đề gốc. Hãy tích chọn ở mục “Cấu hình trộn”.');
        else if (vers.length > 1 && new Set(vers.map(function (v) { return v.sig; })).size < vers.length) toast('Lưu ý', 'Đề gốc có ít câu nên một số mã đề trùng thứ tự nhau. Hãy bật thêm các lựa chọn trộn.');
    }

    /* ---------- xuất file ---------- */
    function safe(s, def) {
        var r = fold(s).replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);
        return r || def;
    }
    var tick = function () { return new Promise(function (r) { setTimeout(r, 20); }); };
    function progress(msg) {
        var m = $('mix-modal'); if (!m) return;
        var p = $('mx-prog');
        if (!msg) { if (p) p.remove(); return; }
        if (!p) { p = document.createElement('div'); p.id = 'mx-prog'; p.className = 'mx-prog'; p.innerHTML = '<div id="mx-prog-t"></div>'; m.appendChild(p); }
        $('mx-prog-t').textContent = msg;
    }
    function download(blob, name) {
        var url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = name; document.body.appendChild(a); a.click();
        setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 2500);
    }
    async function exportAll() {
        var cfg = readCfg(); saveCfg(); window.__CODE94_FMT = cfg.fmt;
        if (!MIX.versions.length) { toast('Chưa tạo đề', 'Hãy bấm “Tạo đề” trước khi xuất file.'); return; }
        if (typeof JSZip === 'undefined' && window.__code98LoadLib) { progress('Đang tải thư viện nén…'); try { await window.__code98LoadLib('JSZip', ['https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js', 'https://unpkg.com/jszip@3.10.1/dist/jszip.min.js']); } catch (e) {} progress(''); }
        if (typeof JSZip === 'undefined') { toast('Chưa tải được thư viện', 'Không tìm thấy thư viện nén JSZip. Hãy kiểm tra kết nối Internet rồi tải lại trang.'); return; }
        var root = 'Tron_de_' + safe(cfg.subject, 'de_thi') + (cfg.grade ? '_lop_' + safe(cfg.grade, '') : '') + '_' + MIX.versions.length + '_ma_de';
        try {
            var zip = new JSZip(), n = MIX.versions.length;
            for (var i = 0; i < n; i++) {
                var v = MIX.versions[i];
                progress('Đang tạo file Word mã đề ' + v.code + ' (' + (i + 1) + '/' + n + ')…'); await tick();
                zip.file(root + '/1_DE_THI/De_' + v.code + '.docx', await D.buildExamDocx(v, cfg, false));
                zip.file(root + '/2_DE_CO_DAP_AN/De_' + v.code + '_co_dap_an.docx', await D.buildExamDocx(v, cfg, true));
            }
            progress('Đang tạo bảng đáp án tổng hợp…'); await tick();
            zip.file(root + '/3_BANG_DAP_AN/Bang_dap_an_tong_hop.docx', await D.buildKeyDocx(MIX.versions, cfg));
            progress('Đang nén thành 1 thư mục…'); await tick();
            var blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
            progress('');
            download(blob, root + '.zip');
            toast('Đã xuất file đề', 'Đã tải về “' + root + '.zip”. Giải nén sẽ được thư mục “' + root + '” gồm ' + n + ' đề thi, ' + n + ' đề có đáp án và 1 bảng đáp án tổng hợp.', 'success');
        } catch (err) {
            progress('');
            console.error('[CODE93] export', err);
            toast('Lỗi xuất file', String(err && err.message ? err.message : err));
        }
    }

    /* ============================================================
       [CODE125] XUẤT FILE ĐÁP ÁN EXCEL cho phần mềm chấm trắc nghiệm QM (QM 2025 / Young Mix) và TNMaker
       - Cấu trúc theo phiếu TLTN 2025: Phần I tối đa 40 câu (A-D), Phần II tối đa 8 câu (4 ý Đ/S), Phần III tối đa 6 câu (đáp án số).
       - Câu không dùng đến để TRỐNG; mã đề lưu dạng chữ để không mất số 0 đầu (VD 0101).
       - QM: mỗi mã đề 1 dòng; cột A = mã đề, tiếp theo Phần I 1…40, Phần II 1a…8d, Phần III 1…6.
       - TNMaker: mỗi mã đề 1 cột (các mã đề nối tiếp theo chiều ngang), các hàng là câu 1…54; Phần II viết liền 4 ký tự Đ/S.
         Đáp án nằm ở cả sheet 1 và sheet 2 (TNMaker đọc file Excel đáp án ở sheet 2, QR đọc ở sheet 1).
       ============================================================ */
    var KLIM = { mc: 40, tf: 8, sa: 6 };
    function partList(ver, type) {
        for (var i = 0; i < ver.parts.length; i++) if (ver.parts[i].type === type) return ver.parts[i].list || [];
        return [];
    }
    function aMc(q) { return q && q.correct >= 0 ? 'ABCD'[q.correct] : null; }
    function aTf(q, j) { return q && q.tfKnown && q.tf ? (q.tf[j] ? 'Đ' : 'S') : null; }
    function aSa(q) { var t = q && q.sa != null ? String(q.sa).replace(/\s+/g, ' ').trim() : ''; return (!t || t === '?') ? null : t; }
    function keyOverflow(vers) {
        var o = [];
        vers.forEach(function (v) {
            if (partList(v, 'mc').length > KLIM.mc) o.push('Phần I (' + partList(v, 'mc').length + ' câu, tối đa ' + KLIM.mc + ')');
            if (partList(v, 'tf').length > KLIM.tf) o.push('Phần II (' + partList(v, 'tf').length + ' câu, tối đa ' + KLIM.tf + ')');
            if (partList(v, 'sa').length > KLIM.sa) o.push('Phần III (' + partList(v, 'sa').length + ' câu, tối đa ' + KLIM.sa + ')');
        });
        return o.filter(function (x, i) { return o.indexOf(x) === i; });
    }
    function keyAoaQM(vers) {
        var head = ['Mã đề'], i, j;
        for (i = 1; i <= KLIM.mc; i++) head.push(String(i));
        for (i = 1; i <= KLIM.tf; i++) for (j = 0; j < 4; j++) head.push(i + 'abcd'[j]);
        for (i = 1; i <= KLIM.sa; i++) head.push(String(i));
        var rows = [head];
        vers.forEach(function (v) {
            var mc = partList(v, 'mc'), tf = partList(v, 'tf'), sa = partList(v, 'sa'), r = [String(v.code)];
            for (i = 0; i < KLIM.mc; i++) r.push(aMc(mc[i]));
            for (i = 0; i < KLIM.tf; i++) for (j = 0; j < 4; j++) r.push(aTf(tf[i], j));
            for (i = 0; i < KLIM.sa; i++) r.push(aSa(sa[i]));
            rows.push(r);
        });
        return rows;
    }
    function keyAoaTN(vers) {
        var head = ['Câu'].concat(vers.map(function (v) { return String(v.code); })), rows = [head], i, n = 0;
        function line(fn) { n++; var r = [String(n)]; vers.forEach(function (v) { r.push(fn(v)); }); rows.push(r); }
        for (i = 0; i < KLIM.mc; i++) (function (k) { line(function (v) { return aMc(partList(v, 'mc')[k]); }); })(i);
        for (i = 0; i < KLIM.tf; i++) (function (k) {
            line(function (v) {
                var q = partList(v, 'tf')[k]; if (!q || !q.tfKnown) return null;
                return [0, 1, 2, 3].map(function (j) { return aTf(q, j) || ''; }).join('');
            });
        })(i);
        for (i = 0; i < KLIM.sa; i++) (function (k) { line(function (v) { return aSa(partList(v, 'sa')[k]); }); })(i);
        return rows;
    }
    function makeSheet(aoa, cols) {
        var ws = XLSX.utils.aoa_to_sheet(aoa);
        Object.keys(ws).forEach(function (a) { if (a[0] !== '!' && ws[a] && ws[a].t !== 's') { ws[a].t = 's'; ws[a].v = String(ws[a].v); } });   /* mọi ô là chữ: giữ số 0 đầu, dấu phẩy thập phân */
        ws['!cols'] = cols;
        return ws;
    }
    async function exportKey(kind) {
        var cfg = readCfg(); saveCfg();
        if (!MIX.versions.length) { toast('Chưa tạo đề', 'Hãy bấm “Tạo đề” trước khi xuất file đáp án.'); return; }
        if (typeof XLSX === 'undefined' && window.__code98LoadLib) {
            progress('Đang tải thư viện Excel…');
            try { await window.__code98LoadLib('XLSX', ['https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', 'https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js']); } catch (e) {}
            progress('');
        }
        if (typeof XLSX === 'undefined') { toast('Chưa tải được thư viện Excel', 'Hãy kiểm tra kết nối Internet rồi tải lại trang.'); return; }
        try {
            var vers = MIX.versions, wb = XLSX.utils.book_new(), name, label;
            var base = safe(cfg.subject, 'de_thi') + (cfg.grade ? '_lop_' + safe(cfg.grade, '') : '') + '_' + vers.length + '_ma_de';
            if (kind === 'qm') {
                var aq = keyAoaQM(vers), cq = [{ wch: 9 }]; for (var c = 1; c < aq[0].length; c++) cq.push({ wch: 4.5 });
                XLSX.utils.book_append_sheet(wb, makeSheet(aq, cq), 'DapAn');
                name = 'DapAn_QM_' + base + '.xlsx'; label = 'QM';
            } else {
                var at = keyAoaTN(vers), ct = [{ wch: 7 }]; vers.forEach(function () { ct.push({ wch: 9 }); });
                XLSX.utils.book_append_sheet(wb, makeSheet(at, ct), 'DapAn');
                XLSX.utils.book_append_sheet(wb, makeSheet(at, ct), 'DapAn_2');
                name = 'DapAn_TNMaker_' + base + '.xlsx'; label = 'TNMaker';
            }
            var out = XLSX.write(wb, { bookType: 'xlsx', type: 'array', compression: true });
            download(new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), name);
            var ov = keyOverflow(vers), un = 0;
            vers.forEach(function (v) { v.parts.forEach(function (p) { p.list.forEach(function (q) { if (unresolved(q)) un++; }); }); });
            var msg = 'Đã tải về “' + name + '” (' + vers.length + ' mã đề). Mở app ' + label + ' → Đáp án → nhập từ file Excel.';
            if (ov.length) msg += ' ⚠ Đề có ' + ov.join(', ') + ' nên các câu vượt giới hạn của phiếu 2025 không được ghi vào file.';
            if (un) msg += ' ⚠ Có câu chưa có đáp án đúng nên ô đáp án để trống.';
            toast('Đã xuất đáp án ' + label, msg, (ov.length || un) ? undefined : 'success');
        } catch (err) {
            progress('');
            console.error('[CODE125] export key', err);
            toast('Lỗi xuất đáp án', String(err && err.message ? err.message : err));
        }
    }


    /* [CODE162] XUẤT FILE WORD TỪ NGÂN HÀNG ĐỀ: dùng đúng bộ dựng Word của TRỘN ĐỀ (giữ thứ tự ngân hàng, không trộn, không có mã đề trừ khi nhập) */
    function bankToDraft(q) {
        var t = (q && (q.type === 'tf' || q.type === 'sa')) ? q.type : 'mc';
        var d = { type: t, text: String((q && q.text) || ''), solution: String((q && q.solution) || ''), gid: q && q.gid ? String(q.gid) : '', ginfo: q && q.ginfo ? String(q.ginfo) : '' };
        if (q && q.gm) d.gm = String(q.gm);
        d.options = ((q && q.options) || []).map(function (o) { return { text: String((o && o.text) || '') }; });
        if (t === 'mc') {
            var ci = -1; ((q && q.options) || []).forEach(function (o, i) { if (ci < 0 && o && o.letter === q.correct) ci = i; });
            d.detectedByStyle = ci >= 0; d.correctIndex = Math.max(0, ci);
        } else if (t === 'tf') {
            d.tfAnswers = [0, 1, 2, 3].map(function (i) { return !!(q.tfAnswers && q.tfAnswers[i]); });
            d.tfSol = [0, 1, 2, 3].map(function (i) { return String((q.tfSol && q.tfSol[i]) || ''); });
            d.detectedByStyle = Array.isArray(q.tfAnswers);
        } else {
            d.shortAnswer = String(q.shortAnswer == null ? '' : q.shortAnswer);
        }
        return d;
    }
    function bankVersion(list, code) {
        var src = list.map(bankToDraft).map(normQ);
        src.forEach(function (q, i) { q.idx = i; });
        return makeVersion({ mI: false, mII: false, mIII: false, oI: false, oII: false }, seedRng(), code || '', src);
    }
    async function bankWord(list, info, opt, prog) {
        opt = opt || {};
        var cfg = Object.assign({}, loadCfg(), info || {});
        cfg.fmt = cfg.fmt === 'omml' ? 'omml' : 'mathtype';
        window.__CODE94_FMT = cfg.fmt;
        var ver = bankVersion(list, opt.code || ''), base = opt.base || 'De_thi', out = [];
        var say = function (m) { try { if (prog) prog(m); } catch (e) {} };
        if (opt.exam) { say('Đang tạo file đề thi…'); await tick(); out.push({ dir: '1_DE_THI', name: base + '.docx', data: await D.buildExamDocx(ver, cfg, false) }); }
        if (opt.ans) { say('Đang tạo file đề có đáp án…'); await tick(); out.push({ dir: '2_DE_CO_DAP_AN', name: base + '_co_dap_an.docx', data: await D.buildExamDocx(ver, cfg, true) }); }
        if (opt.key) { say('Đang tạo bảng đáp án…'); await tick(); out.push({ dir: '3_BANG_DAP_AN', name: 'Bang_dap_an_' + base + '.docx', data: await D.buildKeyDocx([ver], cfg) }); }
        return out;
    }

    window.CODE93Mix = {
        bankWord: bankWord,
        open: open, close: close, onCfg: onCfg, onSubject: onSubject, onMon: onMon, importWord: importWord, importWordEN: importWordEN, receive: receive, leaveImport: leaveImport,
        clearSrc: clearSrc, viewSrc: viewSrc, closePreview: closePreview, generate: generate, exportAll: exportAll, exportKey: exportKey, togglePreview: togglePreview,
        get active() { return MIX.active; }, set active(v) { MIX.active = !!v; }, _state: MIX
    };
})();

