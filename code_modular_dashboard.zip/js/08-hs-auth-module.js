
/* ======================================================================
   [CODE111] TÀI KHOẢN HỌC SINH: ĐĂNG KÍ / ĐĂNG NHẬP
   - "Tôi là HS" -> 2 nút: ĐĂNG NHẬP | ĐĂNG KÍ.
   - ĐĂNG KÍ: Họ và tên, Lớp, Tên đăng nhập (không được trùng), Mật khẩu.
   - ĐĂNG NHẬP: Tên đăng nhập + Mật khẩu -> vào ứng dụng với quyền học sinh,
     Họ tên + Lớp lấy từ tài khoản (khóa, không sửa được) để kết quả không bị nhầm tên.
   - Lưu trên trình duyệt (localStorage). Nếu máy đã kết nối máy chủ của giáo viên (Firebase)
     thì tài khoản còn được lưu lên đó để kiểm tra trùng tên & đăng nhập ở máy khác.
   - Mật khẩu không lưu dạng thô: băm SHA-256 + muối riêng từng tài khoản.
   ====================================================================== */
(function () {
    'use strict';
    var LS_ACC = 'matrix_hs_accounts_v1';
    var view = 'menu';              // menu | login | register
    var busy = false;

    function $(id) { return document.getElementById(id); }
    function show(id, on) { var el = $(id); if (el) el.classList.toggle('hidden', !on); }
    function api() { return (window.CloudSync && window.CloudSync.api) || null; }
    function cloudOn() { try { var a = api(); return !!(a && a.effStu()); } catch (e) { return false; } }

    /* ---------- kho tài khoản cục bộ ---------- */
    function load() {
        try { var o = JSON.parse(localStorage.getItem(LS_ACC) || 'null'); if (o && o.users) return o; } catch (e) {}
        return { users: {} };
    }
    function save(o) { try { localStorage.setItem(LS_ACC, JSON.stringify(o)); return true; } catch (e) { return false; } }
    function normUser(u) { return String(u == null ? '' : u).normalize('NFC').trim().toLowerCase(); }
    function validUser(u) { return /^[a-z0-9._-]{3,30}$/.test(u); }
    function cleanText(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }
    function cloudKey(u) { return 'accounts/' + String(u).replace(/[.$#\[\]\/\u0000-\u001f\u007f]/g, '_'); }

    function rndSalt() {
        var a = 'abcdefghijklmnopqrstuvwxyz0123456789', out = '';
        try { var b = new Uint8Array(12); crypto.getRandomValues(b); for (var i = 0; i < 12; i++) out += a[b[i] % a.length]; }
        catch (e) { for (var j = 0; j < 12; j++) out += a[Math.floor(Math.random() * a.length)]; }
        return out;
    }
    function fallbackHash(str) {
        var h1 = 0x811c9dc5, h2 = 0x1b873593;
        for (var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            h1 ^= c; h1 = Math.imul(h1, 0x01000193);
            h2 = Math.imul(h2 ^ c, 0x85ebca6b); h2 ^= h2 >>> 13;
        }
        return 'f' + (h1 >>> 0).toString(16) + (h2 >>> 0).toString(16);
    }
    function hashPw(salt, pw) {
        var s = 'hs|' + salt + '|' + pw;
        try {
            if (window.crypto && crypto.subtle && window.TextEncoder) {
                return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(function (buf) {
                    return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
                }).catch(function () { return fallbackHash(s); });
            }
        } catch (e) {}
        return Promise.resolve(fallbackHash(s));
    }

    /* ---------- máy chủ (không bắt buộc) ---------- */
    function cloudGet(u) {
        if (!cloudOn()) return Promise.resolve(null);
        return api().req('GET', 's', cloudKey(u)).then(function (r) { return r && r.ph ? r : null; }, function () { return null; });
    }
    function cloudPut(u, rec) {
        if (!cloudOn()) return Promise.resolve(false);
        return api().req('PUT', 's', cloudKey(u), rec).then(function () { return true; }, function () { return false; });
    }
    /* Tìm tài khoản: nếu đã kết nối Host (cloudOn) thì kiểm tra trên Host để đảm bảo tài khoản đã bị Giáo viên xoá trên Host sẽ không đăng nhập được nữa */
    function findAccount(u) {
        if (cloudOn()) {
            return api().req('GET', 's', cloudKey(u)).then(function (r) {
                var db = load();
                if (r && r.ph) {
                    db.users[u] = r;
                    save(db);
                    return r;
                } else {
                    if (db.users[u]) { delete db.users[u]; save(db); }
                    return null;
                }
            }, function () {
                return load().users[u] || null;
            });
        }
        var local = load().users[u];
        return Promise.resolve(local || null);
    }

    /* ---------- giao diện ---------- */
    function setText(id, t) { var el = $(id); if (el) el.textContent = t; }
    function clearErr() { if (typeof clearLoginError === 'function') clearLoginError(); }
    function err(msg, input, box) { if (typeof showLoginError === 'function') showLoginError(msg, input, box); }
    function ok(msg) {
        var el = $('login-error-msg'); if (!el) return;
        el.textContent = msg;
        el.className = 'bg-emerald-50 border-2 border-emerald-300 text-emerald-700 rounded-xl px-3.5 py-2 text-xs font-black text-center shadow-sm';
    }
    function resetErrClass() {
        var el = $('login-error-msg'); if (el) el.className = 'hidden bg-red-50 border-2 border-red-300 text-red-600 rounded-xl px-3.5 py-2 text-xs font-black text-center shadow-sm';
    }
    function setBtn(txt, visible) {
        var b = $('login-submit-btn'); if (!b) return;
        b.textContent = txt; b.parentElement.classList.toggle('hidden', !visible);
    }

    function showView(v, keepMsg) {
        view = v;
        if (!keepMsg) { clearErr(); resetErrClass(); }
        ['login-name-group', 'login-class-group', 'login-user-group', 'login-pass-group', 'login-pass2-group',
         'login-showpass-wrap', 'login-gv-greet', 'login-gv-blocked', 'login-gv-hint', 'login-reset-wrap', 'login-hs-menu', 'login-hs-back']
            .forEach(function (id) { show(id, false); });
        ['login-pass-input', 'login-pass2-input'].forEach(function (id) { var el = $(id); if (el) { el.value = ''; el.type = 'password'; } });
        var chk = $('login-showpass-check'); if (chk) chk.checked = false;
        setText('login-pass2-label', '4. Xác nhận lại mật khẩu:');
        var pi = $('login-pass-input');

        if (v === 'menu') {
            show('login-hs-menu', true);
            setBtn('', false);
            setText('login-hero-title', 'CỔNG HỌC SINH');
            return;
        }
        show('login-hs-back', true);
        show('login-user-group', true);
        show('login-pass-group', true);
        show('login-showpass-wrap', true);
        if (v === 'register') {
            show('login-name-group', true);
            show('login-class-group', true);
            setText('login-name-label', '2. Họ và tên:');
            setText('login-class-label', '3. Lớp:');
            setText('login-user-label', '4. Tên đăng nhập (không được trùng):');
            setText('login-pass-label', '5. Mật khẩu (ít nhất 4 ký tự):');
            show('login-pass2-group', true);   // [CODE118] Nhập lại mật khẩu khi đăng kí
            setText('login-pass2-label', '6. Nhập lại mật khẩu:');
            if (pi) pi.setAttribute('autocomplete', 'new-password');
            var ni = $('login-name-input'), ci = $('login-class-input');
            if (ni) { ni.value = ''; ni.placeholder = 'Họ và tên đầy đủ của em...'; }
            if (ci) ci.value = '';
            var ui = $('login-user-input'); if (ui) ui.value = '';
            setBtn('ĐĂNG KÍ ➜', true);
            setText('login-hero-title', 'ĐĂNG KÍ HỌC SINH');
        } else {
            setText('login-user-label', '2. Tên đăng nhập:');
            setText('login-pass-label', '3. Mật khẩu:');
            if (pi) pi.setAttribute('autocomplete', 'current-password');
            setBtn('ĐĂNG NHẬP ➜', true);
            setText('login-hero-title', 'ĐĂNG NHẬP HỌC SINH');
        }
        if (!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches)) {
            setTimeout(function () {
                var f = (v === 'register') ? $('login-name-input') : $('login-user-input');
                if (f) { try { f.focus({ preventScroll: true }); } catch (e) { f.focus(); } }
            }, 60);
        }
    }

    /* ---------- đăng kí ---------- */
    function doRegister() {
        var ni = $('login-name-input'), ci = $('login-class-input'), ui = $('login-user-input'), pi = $('login-pass-input');
        var name = cleanText(ni && ni.value), cls = cleanText(ci && ci.value);
        var userRaw = ui ? ui.value : '', user = normUser(userRaw), pass = pi ? pi.value : '';
        var p2i = $('login-pass2-input'), pass2 = p2i ? p2i.value : '';
        if (!name) return err('⚠️ Vui lòng nhập Họ và tên của em!', ni, $('login-name-box'));
        if (!cls) return err('⚠️ Vui lòng nhập Lớp của em (VD: 12A1)!', ci, $('login-class-box'));
        if (!user) return err('⚠️ Vui lòng nhập Tên đăng nhập!', ui, $('login-user-box'));
        if (!validUser(user)) return err('⚠️ Tên đăng nhập gồm 3–30 ký tự: chữ không dấu, số, dấu . _ - (không có khoảng trắng).', ui, $('login-user-box'));
        if (pass.length < 4) return err('⚠️ Mật khẩu cần có ít nhất 4 ký tự!', pi, $('login-pass-box'));
        if (!pass2) return err('⚠️ Vui lòng nhập lại mật khẩu để xác nhận!', p2i, $('login-pass2-box'));
        if (pass2 !== pass) { if (p2i) p2i.value = ''; return err('⚠️ Mật khẩu nhập lại chưa khớp. Em nhập lại nhé!', p2i, $('login-pass2-box')); }
        if (busy) return; busy = true; setBtn('ĐANG XỬ LÝ...', true);

        findAccount(user).then(function (exist) {
            if (exist) { busy = false; setBtn('ĐĂNG KÍ ➜', true); return err('❌ Tên đăng nhập "' + user + '" đã có người dùng. Em hãy chọn tên khác!', ui, $('login-user-box')); }
            var salt = rndSalt();
            return hashPw(salt, pass).then(function (ph) {
                var rec = { u: user, name: name, cls: cls, salt: salt, ph: ph, ts: Date.now(), status: 'pending', approved: false, requestedClass: cls };
                var db = load(); db.users[user] = rec;
                if (!save(db)) { busy = false; setBtn('ĐĂNG KÍ ➜', true); return err('⚠️ Không lưu được tài khoản trên trình duyệt này (có thể đang ở chế độ ẩn danh).'); }
                return cloudPut(user, rec).then(function (cloudOk) {
                    busy = false;
                    showView('login', true);
                    var ui2 = $('login-user-input'); if (ui2) ui2.value = user;
                    ok('✅ Đã gửi đăng ký thành công. Tài khoản đang CHỜ GIÁO VIÊN XÁC NHẬN vào lớp. Em chỉ đăng nhập và xem bài giảng sau khi được duyệt.' + (cloudOn() && !cloudOk ? ' Lưu ý: chưa đồng bộ được máy chủ, hãy báo giáo viên.' : ''));
                    var p = $('login-pass-input'); if (p && !(window.matchMedia && window.matchMedia('(pointer: coarse)').matches)) p.focus();
                });
            });
        }).catch(function () { busy = false; setBtn('ĐĂNG KÍ ➜', true); err('⚠️ Có lỗi khi đăng kí, em thử lại nhé!'); });
    }

    /* ---------- đăng nhập ---------- */
    function doLogin() {
        var ui = $('login-user-input'), pi = $('login-pass-input');
        var user = normUser(ui && ui.value), pass = pi ? pi.value : '';
        if (!user) return err('⚠️ Vui lòng nhập Tên đăng nhập!', ui, $('login-user-box'));
        if (!pass) return err('⚠️ Vui lòng nhập Mật khẩu!', pi, $('login-pass-box'));
        if (busy) return; busy = true; setBtn('ĐANG KIỂM TRA...', true);
        var bad = function (msg, el, box) { busy = false; setBtn('ĐĂNG NHẬP ➜', true); err(msg, el, box); };

        findAccount(user).then(function (acc) {
            if (!acc) return bad('❌ Chưa có tài khoản "' + user + '". Em hãy bấm "Quay lại" và chọn ĐĂNG KÍ trước!', ui, $('login-user-box'));
            if (acc.approved !== true && acc.status !== 'approved') return bad('⏳ Tài khoản đang chờ giáo viên xác nhận vào lớp. Em vui lòng liên hệ giáo viên.', ui, $('login-user-box'));
            return hashPw(acc.salt, pass).then(function (ph) {
                if (ph !== acc.ph) { if (pi) pi.value = ''; return bad('❌ Mật khẩu chưa đúng. Em nhập lại nhé!', pi, $('login-pass-box')); }
                busy = false; setBtn('ĐĂNG NHẬP ➜', true);
                if (typeof finishLoginModal === 'function') finishLoginModal('HS', acc.name, acc.cls, acc.u);
            });
        }).catch(function () { bad('⚠️ Có lỗi khi đăng nhập, em thử lại nhé!'); });
    }

    window.HSAuth = {
        view: function () { return view; },
        show: showView,
        submit: function () { if (view === 'register') doRegister(); else if (view === 'login') doLogin(); },
        hasAccount: function (u) { return !!load().users[normUser(u)]; },
        get: function (u) { return load().users[normUser(u)] || null; },
        isApproved: function (u) { var a = load().users[normUser(u)]; return !!(a && (a.approved === true || a.status === 'approved')); },
        setApproval: function (u, cls) {
            u = normUser(u); var db = load(), rec = db.users[u];
            if (!rec) return Promise.reject(new Error('Không tìm thấy tài khoản học sinh.'));
            rec.cls = cleanText(cls); rec.status = 'approved'; rec.approved = true; rec.approvedAt = Date.now();
            db.users[u] = rec; save(db); return cloudPut(u, rec).then(function (ok) { if (cloudOn() && !ok) throw new Error('Không đồng bộ được máy chủ.'); return ok; });
        },
        createForTeacher: function (name, cls, u, pass) {
            name = cleanText(name); cls = cleanText(cls); u = normUser(u);
            if (!name || !cls || !validUser(u) || String(pass || '').length < 4) return Promise.reject(new Error('Vui lòng nhập đủ họ tên, lớp, tên đăng nhập hợp lệ và mật khẩu từ 4 ký tự.'));
            return findAccount(u).then(function (exist) {
                if (exist) throw new Error('Tên đăng nhập đã tồn tại.');
                var salt = rndSalt(); return hashPw(salt, pass).then(function (ph) {
                    var rec = { u:u, name:name, cls:cls, salt:salt, ph:ph, ts:Date.now(), status:'approved', approved:true, approvedAt:Date.now(), createdByTeacher:true };
                    var db = load(); db.users[u] = rec; if (!save(db)) throw new Error('Không lưu được tài khoản trên thiết bị.');
                    return cloudPut(u, rec).then(function (ok) { if (cloudOn() && !ok) throw new Error('Không đồng bộ được máy chủ. Kiểm tra kết nối Đồng bộ rồi thử lại.'); return rec; });
                });
            });
        }
    };
    window.hsAuthShow = showView;
})();

    