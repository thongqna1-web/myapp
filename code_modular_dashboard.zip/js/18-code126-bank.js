
/* [CODE126] Khung NGÂN HÀNG ĐỀ (máy tính) / TỰ LUYỆN (điện thoại) - dùng chung 1 nội dung nên luôn đồng bộ.
   Nội dung sẽ bổ sung sau: gọi CODE126Bank.setContent(htmlHoặcNode) hoặc CODE126Bank.onOpen = function (bodyEl) { ... }. */
(function () {
    'use strict';
    var modal = null, body = null;
    function build() {
        if (modal) return;
        modal = document.createElement('div');
        modal.id = 'bank-modal';
        modal.className = 'no-print';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.innerHTML =
            '<div class="bk-panel">' +
              '<div class="bk-head">' +
                '<div class="bk-title"><span class="t-desk">📚 Ngân hàng đề</span><span class="t-mob">📚 Tự luyện</span></div>' +
                '<button type="button" class="bk-ib" data-act="home" title="Trang chủ" aria-label="Trang chủ"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/></svg></button>' +
                '<button type="button" class="bk-ib" data-act="close" title="Đóng" aria-label="Đóng"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
              '</div>' +
              '<div class="bk-body" id="bank-body"><div class="bk-empty"><b>Đang cập nhật nội dung</b><span>Mục này sẽ sớm có đề luyện tập cho học sinh.</span></div></div>' +
            '</div>';
        document.body.appendChild(modal);
        body = modal.querySelector('#bank-body');
        modal.addEventListener('click', function (e) {
            if (e.target === modal) { close(); return; }
            var b = e.target.closest ? e.target.closest('[data-act]') : null;
            if (!b) return;
            if (b.getAttribute('data-act') === 'close') close();
            else if (b.getAttribute('data-act') === 'home') { close(); try { window.goHome && window.goHome(); } catch (x) {} }
        });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && modal.classList.contains('open')) close(); });
    }
    function open() {
        build();
        modal.classList.add('open');
        try { if (typeof API.onOpen === 'function') API.onOpen(body); } catch (e) { console.error('[CODE126] onOpen', e); }
    }
    function close() { if (modal) modal.classList.remove('open'); }
    function setContent(c) {
        build();
        body.innerHTML = '';
        if (typeof c === 'string') body.innerHTML = c; else if (c && c.nodeType) body.appendChild(c);
    }
    var API = { open: open, close: close, setContent: setContent, onOpen: null };
    window.CODE126Bank = API;
    /* Bấm TRANG CHỦ ở bất kỳ nơi nào => đóng luôn khung này */
    var gh = window.goHome;
    if (typeof gh === 'function') window.goHome = function () { close(); return gh.apply(this, arguments); };
})();
