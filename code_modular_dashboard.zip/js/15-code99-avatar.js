
/* [CODE99] Ảnh đại diện cho Giáo viên VÀ Học sinh: 1 nút duy nhất (bấm vào ảnh tròn), chạy được trên điện thoại,
   tự thu nhỏ 160px và ĐỒNG BỘ qua máy chủ (Firebase) để mở trên máy/trình duyệt nào cũng thấy cùng ảnh. */
(function () {
    'use strict';
    var KEY = 'matrix_avatar_v2:', box = null, input = null, lastPull = 0, busy = false, status = '';
    function $(id) { return document.getElementById(id); }
    function isStu() { return typeof isStudentMode !== 'undefined' && isStudentMode === true; }
    function fold(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'd').toLowerCase().replace(/[^a-z0-9]+/g, ''); }
    function nm() { try { return String($('main-fullname-input').value || '').trim(); } catch (e) { return ''; } }
    function cl() { try { return String($('main-class-input').value || '').trim(); } catch (e) { return ''; } }
    function ukey() { var n = fold(nm()); if (!n) return ''; return isStu() ? 'hs_' + n + '_' + fold(cl()) : 'gv_' + n; }
    function api() { return window.CloudSync && CloudSync.api ? CloudSync.api : null; }
    function lget() { try { var o = JSON.parse(localStorage.getItem(KEY + ukey()) || 'null'); return (o && typeof o === 'object') ? o : { d: '', ts: 0 }; } catch (e) { return { d: '', ts: 0 }; } }
    function lset(o) { try { localStorage.setItem(KEY + ukey(), JSON.stringify(o)); return true; } catch (e) { return false; } }
    function css() {
        if ($('code99-css')) return;
        var st = document.createElement('style'); st.id = 'code99-css';
        st.textContent = '#c99-wrap{position:relative;width:80px;margin:0 auto 2px;flex:none;text-align:center}' +
            '#c99-ring{position:relative;width:76px;height:76px;margin:0 auto;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(37,99,235,.35);background:linear-gradient(135deg,#6366f1,#2563eb);color:#fff;font-weight:900;font-size:28px;display:flex;align-items:center;justify-content:center;overflow:hidden}' +
            '#c99-ring img{width:100%;height:100%;object-fit:cover;display:block}' +
            '#c99-in{position:absolute;left:0;top:0;width:76px;height:76px;margin:0;padding:0;opacity:0;cursor:pointer;border-radius:50%;z-index:3;font-size:0}' +
            '#c99-cam{position:absolute;right:2px;bottom:2px;width:24px;height:24px;border-radius:50%;background:#2563eb;color:#fff;border:2px solid #fff;font-size:12px;line-height:1;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:2}' +
            '#c99-cam.ok{background:#059669}#c99-cam.bad{background:#d97706}' +
            'body.layout-portrait:not(.printing-a4) #c99-wrap{width:auto;display:flex;align-items:center;gap:6px;margin:0}body.layout-portrait:not(.printing-a4) #c99-ring{width:40px;height:40px;font-size:15px;border-width:2px;margin:0}' +
            'body.layout-portrait:not(.printing-a4) #c99-in{width:40px;height:40px}body.layout-portrait:not(.printing-a4) #c99-cam{display:none}';
        document.head.appendChild(st);
    }
    function build() {
        var ub = $('user-box'); if (!ub) return false;
        /* [CODE100] Chống trùng nút: xóa MỌI khung ảnh cũ (kể cả khung bị lưu cứng vào file khi "Tải index.html") rồi chỉ tạo 1 khung */
        if (box && ub.contains(box) && document.querySelectorAll('#c99-wrap, #c98-ava-wrap').length === 1) return true;
        css();
        var olds = document.querySelectorAll('#c99-wrap, #c98-ava-wrap, .c99-dup');
        for (var i = 0; i < olds.length; i++) { if (olds[i].parentNode) olds[i].parentNode.removeChild(olds[i]); }
        box = document.createElement('div'); box.id = 'c99-wrap';
        box.innerHTML = '<div id="c99-ring"></div><span id="c99-cam" aria-hidden="true">📷</span>' +
            '<input type="file" id="c99-in" accept="image/*" title="Bấm để đổi ảnh đại diện" aria-label="Tải ảnh đại diện lên">' +
            '';
        ub.insertBefore(box, ub.firstChild);
        input = $('c99-in');
        input.addEventListener('click', function (e) { if (!ukey()) { e.preventDefault(); alert('Hãy đăng nhập (nhập họ tên) trước khi tải ảnh đại diện.'); } });
        input.addEventListener('change', function () { var f = input.files && input.files[0]; if (f) readFile(f); try { input.value = ''; } catch (e) {} });
        return true;
    }
    /* Trạng thái đồng bộ hiển thị bằng màu + chú thích của biểu tượng 📷 (xanh = đã đồng bộ, cam = chưa) để không tốn chỗ */
    function setStatus(t, cls) { status = t; var e = $('c99-cam'); if (e) { e.className = cls || ''; e.title = t || 'Bấm vào ảnh để đổi ảnh đại diện'; } }
    function readFile(f) {
        if (f.type && !/^image\//.test(f.type)) { alert('Vui lòng chọn file ảnh (JPG, PNG, WEBP).'); return; }
        var url = null, im = new Image();
        try { url = (window.URL || window.webkitURL).createObjectURL(f); } catch (e) {}
        function done(src) {
            im.onload = function () {
                try {
                    var S = 160, c = document.createElement('canvas'); c.width = c.height = S;
                    var w = im.naturalWidth || im.width, h = im.naturalHeight || im.height, side = Math.min(w, h);
                    var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, S, S);
                    g.drawImage(im, (w - side) / 2, (h - side) / 2, side, side, 0, 0, S, S);
                    var data = c.toDataURL('image/jpeg', 0.82);
                    if (url) { try { (window.URL || window.webkitURL).revokeObjectURL(url); } catch (e) {} }
                    if (!lset({ d: data, ts: Date.now() })) { alert('Không lưu được ảnh (bộ nhớ trình duyệt đầy). Hãy thử ảnh khác.'); return; }
                    paint(); push();
                } catch (e) { alert('Không xử lý được ảnh này. Hãy chọn ảnh JPG hoặc PNG khác.'); }
            };
            im.onerror = function () { alert('Không đọc được ảnh này (có thể là định dạng HEIC). Hãy chọn ảnh JPG hoặc PNG.'); };
            im.src = src;
        }
        if (url) done(url);
        else { var fr = new FileReader(); fr.onload = function () { done(fr.result); }; fr.onerror = function () { alert('Không đọc được file ảnh.'); }; fr.readAsDataURL(f); }
    }
    function initial() { var n = nm().split(/\s+/); return (n[n.length - 1] || '?').charAt(0).toUpperCase(); }
    function paint() {
        if (!build()) return;
        var ring = $('c99-ring'), o = lget();
        ring.innerHTML = '';
        if (o.d) { var im = document.createElement('img'); im.alt = 'Ảnh đại diện'; im.src = o.d; ring.appendChild(im); box.classList.add('has'); }
        else { ring.textContent = initial(); box.classList.remove('has'); }
        if (status) setStatus(status, $('c99-cam') && $('c99-cam').className);
    }
    /* ---- đồng bộ qua máy chủ: dùng chung kho dữ liệu của app (nhánh avatars/…) ---- */
    function remotePath() { return 'avatars/' + (api() ? api().enc(ukey()) : ukey()); }
    function connected() { var a = api(); try { return !!(a && a.effStu()); } catch (e) { return false; } }
    function push() {
        var k = ukey(); if (!k) return Promise.resolve();
        if (!connected()) { setStatus('⚠ Chưa kết nối máy chủ', 'bad'); return Promise.resolve(); }
        var o = lget(); setStatus('Đang đồng bộ…', '');
        return api().req('PUT', 's', remotePath(), { d: o.d || '', ts: o.ts || Date.now() }).then(function () {
            if (ukey() === k) setStatus('☁ Đã đồng bộ', 'ok');
        }, function () { if (ukey() === k) setStatus('⚠ Chưa đồng bộ được', 'bad'); });
    }
    function pull(force) {
        var k = ukey(); if (!k || busy || document.hidden) return;
        if (!connected()) return;
        if (!force && Date.now() - lastPull < 90000) return;
        busy = true; lastPull = Date.now();
        api().req('GET', 's', remotePath() + '?cb=' + Date.now()).then(function (r) {
            busy = false; if (ukey() !== k) return;
            var l = lget(), rts = (r && +r.ts) || 0;
            if (r && rts > (l.ts || 0) && typeof r.d === 'string') { lset({ d: r.d, ts: rts }); paint(); setStatus('☁ Đã đồng bộ', 'ok'); }
            else if ((l.ts || 0) > rts) push();
            else setStatus((l.ts || r) ? '☁ Đã đồng bộ' : '', 'ok');
        }, function () { busy = false; setStatus(lget().d ? '⚠ Chưa đồng bộ được' : '', 'bad'); });
    }
    function start() {
        paint(); pull(true);
        var t = 0, run = function () { if (t) return; t = setTimeout(function () { t = 0; paint(); lastPull = 0; pull(true); }, 150); };
        ['user-name', 'user-role-label'].forEach(function (id) {
            var e = $(id); if (e && window.MutationObserver) new MutationObserver(run).observe(e, { childList: true, characterData: true, subtree: true });
        });
        document.addEventListener('visibilitychange', function () { if (!document.hidden) pull(false); });
        window.addEventListener('online', function () { lastPull = 0; pull(true); });
        setInterval(function () { pull(false); }, 120000);
        setTimeout(function () { lastPull = 0; pull(true); }, 4000);   /* chờ CloudSync khởi động xong */
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
