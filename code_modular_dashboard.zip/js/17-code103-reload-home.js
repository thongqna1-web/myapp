
/* [CODE103] Bấm nút TẢI LẠI của trình duyệt (F5 / Ctrl+R / ⟳) => luôn về TRANG CHỦ.
   Sau khi app khởi động xong, nếu là lần tải lại thì: đóng mọi cửa sổ đang mở (Thư viện, Lớp học, Trộn đề, Kết quả...),
   bỏ đề đang mở và hiển thị lại trang chủ. Giữ nguyên đăng nhập. Nếu người dùng đã bắt đầu thao tác thì không can thiệp nữa. */
(function () {
    'use strict';
    if (!window.__RELOAD_HOME__) return;
    var touched = false, runs = 0;
    ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) { window.addEventListener(ev, function () { touched = true; }, { capture: true, passive: true, once: true }); });
    function closeAll() {
        var sel = '#library-modal,#class-modal,#student-class-modal,#results-modal,#result-detail-modal,#folder-modal,#move-topic-modal,#assign-modal,#cm-form-modal,#mix-modal,#my-results-modal';
        var nodes = document.querySelectorAll(sel);
        for (var i = 0; i < nodes.length; i++) { nodes[i].classList.add('hidden', 'opacity-0'); }
    }
    function forceHome() {
        if (touched || runs >= 4) return;
        runs++;
        try {
            var qa = typeof questionsData !== 'undefined' ? questionsData : null;
            var inQuiz = false;
            try { inQuiz = isStudentMode && hasStartedQuiz && !isQuizSubmitted && qa && qa.length > 0; } catch (e) {}
            if (inQuiz) return;
            closeAll();
            if (typeof goHome === 'function') goHome();
            if (qa && qa.length && typeof clearToBlankState === 'function') clearToBlankState();
            window.scrollTo(0, 0);
        } catch (e) {}
    }
    if (document.readyState === 'complete') forceHome(); else window.addEventListener('load', forceHome);
    [600, 1800, 3500].forEach(function (ms) { setTimeout(forceHome, ms); });
})();
