
    /* [CODE67] Lớp học qua ĐỒNG BỘ (Firebase): giáo viên bật đồng bộ ngay trong Quản lí lớp học -> lớp tự lên máy chủ -> học sinh thấy lớp trên điện thoại */
    (function () {
        'use strict';
        var API = function () { return window.CloudSync && window.CloudSync.api; };
        var E = function (x) { return _escHtml(x); };
        var state = { classes: [], joins: {}, view: 'mine', msg: '', loading: false, q: '', pending: {}, pendTotal: 0, polledOnce: false,
                      pub: { st: 'idle', ts: 0, msg: '', n: 0 }, lastPoll: 0, connMsg: '' };
        var LS_MY = 'matrix_my_classes_v1', LS_PUB = 'matrix_classnet_pub_v3';
        var LS_LEFT = 'matrix_classnet_left_v1', LS_CTX = 'matrix_active_assign_v1', LS_CACHE = 'matrix_classnet_mycache_v1';   // [CODE78]
        function ls(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
        function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
        function sKey() { var i = getStudentIdentity(); return cmNormLoose(i.name) + '_' + cmNormClass(i.cls); }
        function myMap() { return ls(LS_MY, {}); }
        function fmtT(ts) { if (!ts) return '—'; var d = new Date(ts), p = function (n) { return String(n).padStart(2, '0'); }; return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()); }
        function toast(t) {
            var d = document.createElement('div');
            d.textContent = t;
            d.style.cssText = 'position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:100001;background:#0f766e;color:#fff;padding:12px 22px;border-radius:12px;font-weight:800;box-shadow:0 8px 24px rgba(0,0,0,.3);max-width:92vw;text-align:center';
            document.body.appendChild(d);
            setTimeout(function () { d.remove(); }, 4500);
        }
        function copyText(t) {
            try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t); return; } } catch (e) {}
            var a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(a); a.select();
            try { document.execCommand('copy'); } catch (e) {} document.body.removeChild(a);
        }
        function teacherName() { try { return (document.getElementById('main-fullname-input').value || '').trim(); } catch (e) { return ''; } }
        var _rkCache = {};   /* [CODE80] ghi nhớ mã băm để không tính lại mỗi 10 giây */
        function rosterKey(name) { var n = cmNormLoose(name); var v = _rkCache[n]; if (v === undefined) { v = _rkCache[n] = API().hash(n); } return v; }

        /* ================= GIÁO VIÊN ================= */
        function classLink() {
            var base = (typeof getEffectiveBaseUrl === 'function') ? getEffectiveBaseUrl() : location.href.split('#')[0].split('?')[0];
            var suf = (window.CloudSync && CloudSync.linkSuffix && CloudSync.linkSuffix()) || '';
            return suf ? base + '?mode=hs' + suf : '';
        }
        /* [CODE81] Môn học, khối lớp và đường dẫn thư mục của đề (theo Thư viện giáo viên) để học sinh biết mình đang học môn nào, khối mấy */
        function topicMeta(tid) {
            var o = { sj: '', g: '', fp: '' };
            try {
                var t = savedTopics.filter(function (z) { return z && z.id === tid; })[0]; if (!t) return o;
                o.sj = t.subject || ''; o.g = t.grade || '';
                var names = [], fid = t.folderId, guard = 0;
                while (fid && guard++ < 30) {
                    var f = getFolderById(fid); if (!f) break;
                    names.unshift(f.name); if (!o.sj && f.subject) o.sj = f.subject;
                    fid = (f.parentId && f.parentId !== '__subjmeta') ? f.parentId : null;
                }
                o.fp = names.join(' › ');
            } catch (e) {}
            return o;
        }
        function buildPayload() {
            var out = {}, a = API(), tn = teacherName();
            classesData.forEach(function (c) {
                if (!c || !c.id) return;
                out[a.enc(c.id)] = {
                    id: c.id, name: c.name, grade: c.grade || '', sj: c.subject || '', year: c.year || '', note: c.note || '', teacher: c.teacher || tn,
                    n: (c.students || []).length,
                    rk: (c.students || []).map(function (s) { return rosterKey(s.name); }),
                    as: (c.assignments || []).map(function (x) {
                        var o = { t: x.topicId, n: cmTopicTitle(x), d: x.dueAt || null, s: x.startAt || null, m: x.note || '', at: x.assignedAt || 0 }, mt = topicMeta(x.topicId);
                        if (mt.sj) o.sj = mt.sj; if (mt.g) o.g = mt.g; if (mt.fp) o.fp = mt.fp;   /* [CODE81] môn / khối / thư mục như bên Thư viện */
                        return o;
                    })
                };
                (c.assignments || []).forEach(function (x) {
                    if (window.CloudSync._state && window.CloudSync._state.forcePub && x.topicId) window.CloudSync._state.forcePub.add(x.topicId);
                });
            });
            return out;
        }
        /* Đẩy danh sách lớp lên máy chủ (nhánh s/classes mà học sinh đọc được) */
        function publishClasses(force) {
            var a = API();
            if (!a || isStudentMode) return Promise.resolve(false);
            if (!a.teacherReady()) { if (state.pub.st !== 'off') { state.pub = { st: 'off', ts: 0, msg: '', n: 0 }; paintBanner(); } return Promise.resolve(false); }
            var out = buildPayload(), n = Object.keys(out).length, h = a.hash(JSON.stringify(out)), tok = a.token(), last = ls(LS_PUB, {});
            /* [CODE74-CRITICAL] Danh sách lớp local rỗng KHÔNG đồng nghĩa giáo viên muốn xóa hết lớp.
               Bản cũ vẫn gửi PATCH null cho mọi ID trong LS_PUB khi n=0 và last.h còn tồn tại,
               có thể xóa sạch danh sách lớp trên Firebase/GitHub chỉ vì một máy đang thiếu localStorage.
               Chỉ xóa dữ liệu máy chủ qua thao tác xóa chủ động; tuyệt đối không xóa trong lần tự đồng bộ rỗng. */
            if (!n) {
                if (state.pub.st !== 'empty') { state.pub = { st: 'empty', ts: Date.now(), msg: '', n: 0 }; paintBanner(); }
                return Promise.resolve(true);
            }
            /* Không tin trạng thái local vô thời hạn: định kỳ xác nhận lại bằng cách đẩy lớp lên máy chủ,
               phòng trường hợp dữ liệu bị xóa/khôi phục trên Firebase hoặc lần đồng bộ trước bị gián đoạn. */
            if (!force && last.h === h && last.tok === tok && last.ts && (Date.now() - last.ts) < 30000) {
                if (state.pub.st !== 'ok' && state.pub.st !== 'sending') state.pub = { st: 'ok', ts: last.ts, msg: '', n: n };
                return Promise.resolve(true);
            }
            if (state.pub.st === 'sending' && state.pub.h === h) return Promise.resolve(false);
            state.pub = { st: 'sending', ts: 0, msg: '', n: n, h: h }; paintBanner();
            /* [CODE73] Đồng bộ an toàn đa thiết bị:
               - PATCH từng lớp, không ghi đè toàn bộ danh sách lớp trên máy chủ.
               - Chỉ xóa lớp cũ nếu dấu vết xuất bản thuộc ĐÚNG mã kết nối (tok) hiện tại.
               - Khi đổi Firebase/mã kết nối, tuyệt đối không dùng danh sách ID cũ để xóa dữ liệu của kho mới.
               - Nếu danh sách rỗng, không tự động xóa dữ liệu trên máy chủ; việc xóa lớp phải do giáo viên chủ động. */
            var ids = Object.keys(out), body = {};
            ids.forEach(function (k) { body[k] = out[k]; });
            if (last.tok && last.tok === tok) {
                (last.ids || []).forEach(function (k) { if (!out[k]) body[k] = null; });
            }
            if (!Object.keys(body).length) {
                lsSet(LS_PUB, { h: '', tok: tok, ts: Date.now(), ids: [] });
                state.pub = { st: 'empty', ts: Date.now(), msg: '', n: 0 };
                paintBanner();
                return Promise.resolve(true);
            }
            return a.req('PATCH', 's', 'classes', body).then(function () {
                lsSet(LS_PUB, { h: n ? h : '', tok: tok, ts: Date.now(), ids: ids });
                state.pub = { st: 'ok', ts: Date.now(), msg: '', n: n };
                paintBanner();
                try { window.CloudSync.schedule(true); } catch (e) {}   /* đẩy luôn các đề đã giao để học sinh mở được */
                return true;
            }).catch(function (e) {
                state.pub = { st: 'err', ts: 0, msg: (e && e.message) || 'Lỗi không xác định', n: n };
                paintBanner();
                return false;
            });
        }
        function publishNow() {
            var a = API(); if (!a || !a.teacherReady()) { openSync(); return; }
            toast('⏳ Đang đẩy lớp học lên máy chủ...');
            publishClasses(true).then(function (ok) { toast(ok ? '✅ Đã đưa ' + state.pub.n + ' lớp lên máy chủ. Học sinh bấm LỚP HỌC để thấy (danh sách tự cập nhật).' : '⚠️ Chưa đẩy được: ' + (state.pub.msg || 'kiểm tra mạng / Rules Firebase')); pollJoins(); });
        }
        function openSync() { try { CloudSync.openUI(); } catch (e) {} }
        function copyTeacherLink() {
            var a = API(), code = a && a.fullCode ? a.fullCode() : '';
            if (!code) { openSync(); return; }
            var base = (typeof getEffectiveBaseUrl === 'function') ? getEffectiveBaseUrl() : location.href.split('#')[0].split('?')[0];
            copyText(base + '?ct=' + code);
            toast('🔑 Đã sao chép LINK GIÁO VIÊN. Mở link này trên trang GitHub/máy khác 1 lần để đồng bộ lớp học. Đừng gửi cho học sinh!');
        }
        function copyLink() {
            var l = classLink();
            if (!l) { openSync(); return; }
            copyText(l); toast('📋 Đã sao chép link vào lớp. Gửi cho học sinh (Zalo, Messenger...).');
        }
        function showQr() {
            var l = classLink(); if (!l) { openSync(); return; }
            var old = document.getElementById('cn-qr'); if (old) old.remove();
            var el = document.createElement('div'); el.id = 'cn-qr';
            el.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:100000;display:flex;align-items:center;justify-content:center;padding:14px';
            var cv = document.createElement('canvas'), url = null;
            try { url = drawQrToCanvasElement(cv, l); } catch (e) {}
            el.innerHTML = '<div style="background:#fff;border-radius:20px;padding:20px;max-width:420px;width:100%;text-align:center;font-family:Roboto,Arial,sans-serif"><div style="font-weight:900;font-size:19px;color:#0f766e;margin-bottom:8px">📱 QR cho học sinh vào LỚP HỌC</div>' +
                (url ? '<img src="' + url + '" style="width:100%;max-width:340px;margin:0 auto;image-rendering:pixelated" alt="QR">' : '<div style="color:#b91c1c;font-weight:800">Không tạo được QR. Hãy dùng nút sao chép link.</div>') +
                '<div style="font-size:13px;font-weight:700;color:#475569;margin:8px 0">Học sinh quét QR → chọn “Tôi là HS” → đăng nhập → bấm <b>LỚP HỌC</b>.</div>' +
                '<button type="button" onclick="document.getElementById(\'cn-qr\').remove()" style="padding:9px 28px;border-radius:12px;background:#e2e8f0;font-weight:900">Đóng</button></div>';
            document.body.appendChild(el);
        }
        function pollJoins() {
            var a = API(); if (!a || !a.teacherReady() || isStudentMode) return Promise.resolve();
            state.lastPoll = Date.now();
            return a.req('GET', 's', 'joins').then(function (j) {
                state.joins = j || {};
                var jsig = ''; try { jsig = JSON.stringify(state.joins); } catch (e) {}
                var joinsChanged = jsig !== state.joinSig; state.joinSig = jsig;   /* [CODE81] chỉ vẽ lại khi có thay đổi */
                var pend = {}, total = 0, prev = state.pendTotal || 0;
                classesData.forEach(function (c) {
                    var m = state.joins[a.enc(c.id)] || {}, n = 0;
                    Object.keys(m).forEach(function (k) { if (m[k] && m[k].status === 'pending') n++; });
                    pend[c.id] = n; total += n;
                });
                processLeft();   /* [CODE79] học sinh bấm RỜI LỚP -> tự xóa khỏi danh sách lớp của giáo viên */
                state.pending = pend; state.pendTotal = total;
                updateBadge();
                if (total > prev && state.polledOnce) toast('🔔 Có ' + (total - prev) + ' học sinh mới xin vào lớp!');
                state.polledOnce = true;
                if (joinsChanged || state.forceRefresh) { state.forceRefresh = false; refreshOpen(); }
            }).catch(function () {});
        }
        /* [CODE79] Học sinh rời lớp -> xóa khỏi danh sách lớp của giáo viên (một lần cho mỗi lần rời) */
        function processLeft() {
            var a = API(); if (!a || isStudentMode) return;
            var changed = false, names = [];
            classesData.forEach(function (c) {
                if (!c || !c.id) return;
                var m = state.joins[a.enc(c.id)] || {};
                Object.keys(m).forEach(function (k) {
                    var r = m[k]; if (!r || r.status !== 'left' || r.ok) return;
                    var nn = cmNormLoose(r.name || '');
                    var idx = (c.students || []).findIndex(function (s) { return cmNormLoose(s.name) === nn; });
                    if (idx >= 0) {
                        var st = c.students[idx]; c.students.splice(idx, 1); cmTombStudent(c, st);
                        changed = true; names.push(st.name + ' (' + c.name + ')');
                    }
                    r.ok = 1;
                    a.req('PATCH', 's', 'joins/' + a.enc(c.id) + '/' + a.enc(k), { ok: 1 }).catch(function () {});
                });
            });
            if (changed) {
                cmSave(); state.forceRefresh = true;
                toast('🚪 ' + names.join(', ') + ' đã rời lớp — đã xóa khỏi danh sách lớp.');
                publishClasses(true);
            }
        }
        /* [CODE79] Giáo viên xóa học sinh: đánh dấu bản ghi xin vào lớp là "removed" + đẩy danh sách mới lên máy chủ ngay */
        function studentRemoved(cid, name) {
            var a = API(); if (!a || isStudentMode || !a.teacherReady()) return;
            publishClasses(true);
            var nn = cmNormLoose(name);
            a.req('GET', 's', 'joins/' + a.enc(cid)).then(function (m) {
                m = m || {};
                Object.keys(m).forEach(function (k) {
                    var r = m[k]; if (!r || r.status !== 'approved' || cmNormLoose(r.name || '') !== nn) return;
                    a.req('PATCH', 's', 'joins/' + a.enc(cid) + '/' + a.enc(k), { status: 'removed', rts: Date.now() }).catch(function () {});
                });
            }).then(function () { pollJoins(); }).catch(function () {});
        }
        /* [CODE79] Xóa lớp: gỡ hẳn khỏi máy chủ (kể cả khi đó là lớp cuối cùng) */
        function classDeleted(id) {
            var a = API(); if (!a || isStudentMode || !a.teacherReady()) return Promise.resolve(false);
            var body = {}; body[a.enc(id)] = null;
            return a.req('PATCH', 's', 'classes', body).then(function () {
                var last = ls(LS_PUB, {});
                if (last && Array.isArray(last.ids)) { last.ids = last.ids.filter(function (k) { return k !== a.enc(id); }); last.h = ''; lsSet(LS_PUB, last); }
                return true;
            }).catch(function () { return false; });
        }
        function updateBadge() {
            var b = document.getElementById('btn-class-manager'); if (!b) return;
            var old = b.querySelector('.cn-badge'); if (old) old.remove();
            if (state.pendTotal > 0) {
                var sp = document.createElement('span'); sp.className = 'cn-badge';
                sp.style.cssText = 'margin-left:8px;background:#ef4444;color:#fff;border-radius:999px;padding:1px 9px;font-size:14px';
                sp.textContent = state.pendTotal; b.appendChild(sp);
            }
        }
        function refreshOpen() {
            var m = document.getElementById('class-modal');
            if (m && !m.classList.contains('hidden') && typeof cmRender === 'function') {
                var active = document.activeElement;
                if (active && /INPUT|TEXTAREA|SELECT/.test(active.tagName)) return;
                cmRender();
            }
        }
        function paintBanner() { refreshOpen(); }
        function pendingCount(id) { return state.pending[id] || 0; }

        /* Khung ĐỒNG BỘ ở đầu danh sách lớp (giống mục ĐỒNG BỘ của Thư viện) + thông báo yêu cầu xin vào lớp */
        function syncPanelHtml() {
            var a = API();
            if (!a || !a.teacherReady()) {
                return '<div class="cm-card p-4 mb-4" style="border:2px solid #ef4444;background:#fef2f2"><div class="font-black text-red-700 text-lg">⚠️ Chưa bật ĐỒNG BỘ (Firebase)</div>' +
                    '<div class="font-bold text-red-600 mt-1" style="font-size:14px;line-height:1.5">Lớp học đang chỉ lưu trên máy này nên <u>học sinh sẽ KHÔNG thấy lớp</u> trên điện thoại. Hãy bật ĐỒNG BỘ giống mục Thư viện (dán “Mã kết nối MQT1” hoặc thiết lập Firebase mới), lớp sẽ tự đưa lên máy chủ.</div>' +
                    '<button type="button" onclick="CloudSync.openUI()" class="cm-btn bg-emerald-600 text-white mt-3" style="font-size:15px;padding:9px 20px">☁️ Bật ĐỒNG BỘ ngay</button></div>';
            }
            var fullWarn = '';
            if (!(a.teacherFull && a.teacherFull())) {
                fullWarn = '<div class="cm-card p-4 mb-4" style="border:2px solid #f59e0b;background:#fffbeb"><div class="font-black text-amber-800 text-lg">⚠️ Máy/trang này chưa có Mã giáo viên (MQT1)</div>' +
                    '<div class="font-bold text-amber-800 mt-1" style="font-size:14px;line-height:1.5">Học sinh vẫn thấy lớp, nhưng <u>danh sách học sinh và đề đã giao của lớp CHƯA đồng bộ</u> giữa máy tính và trang GitHub (mỗi nơi đang lưu riêng một bản). Hãy dán “Mã kết nối MQT1” (lấy ở máy đã có đủ dữ liệu: ☁️ ĐỒNG BỘ → sao chép mã) hoặc mở “Link giáo viên” trên trang này một lần.</div>' +
                    '<button type="button" onclick="CloudSync.openUI()" class="cm-btn bg-amber-600 text-white mt-3" style="font-size:15px;padding:9px 20px">🔑 Nhập mã MQT1 ngay</button></div>';
            }
            /* [CODE76] Đã bỏ khung ĐỒNG BỘ ở Quản lí lớp học (đồng bộ thực hiện ở Thư viện). Chỉ giữ cảnh báo khi có lỗi thật. */
            var p = state.pub;
            if (p.st === 'err') {
                return fullWarn + '<div class="cm-card p-4 mb-4" style="border:2px solid #ef4444;background:#fef2f2;color:#b91c1c"><div class="font-black" style="font-size:15px;line-height:1.5">⚠️ Chưa đưa được lớp lên máy chủ: ' + E(p.msg) + ' (kiểm tra mạng và ☁️ ĐỒNG BỘ ở Thư viện).</div>' +
                    '<button type="button" onclick="ClassNet.publishNow()" class="cm-btn bg-emerald-600 text-white mt-2">🔄 Thử đẩy lại</button></div>';
            }
            return fullWarn;
        }
        function bannerHtml() {
            var h = syncPanelHtml();
            var tot = state.pendTotal || 0;
            if (!tot) return h;
            var rows = classesData.filter(function (c) { return pendingCount(c.id) > 0; }).map(function (c) {
                return '<button type="button" onclick="cmOpenClass(\'' + c.id + '\');cmSetTab(\'requests\')" class="cm-btn bg-amber-500 text-white" style="margin:4px 6px 0 0">' + E(c.name) + ' (' + pendingCount(c.id) + ')</button>';
            }).join('');
            return h + '<div class="cm-card p-4 mb-4" style="border:2px solid #f59e0b;background:#fffbeb"><div class="font-black text-amber-800">🔔 Có ' + tot + ' yêu cầu xin vào lớp đang chờ phê duyệt</div>' + rows + '</div>';
        }
        function approve(cid, k, ok) {
            var a = API(); var cls = cmGetClass(cid); if (!a || !cls) return;
            var rec = (state.joins[a.enc(cid)] || {})[k]; if (!rec) return;
            if (ok && !cls.students.some(function (s) { return cmNormLoose(s.name) === cmNormLoose(rec.name); })) {
                cls.students.push({ id: cmUid('st'), addedAt: Date.now(), name: rec.name, note: 'Tham gia qua mã lớp' }); cmSave();
            }
            rec.status = ok ? 'approved' : 'rejected';
            /* [CODE79] Đẩy danh sách lớp (đã có học sinh mới) lên TRƯỚC, rồi mới ghi trạng thái "đã duyệt" -> máy học sinh không bị nháy mất lớp */
            (ok ? publishClasses(true) : Promise.resolve(true)).catch(function () {}).then(function () {
                return a.req('PUT', 's', 'joins/' + a.enc(cid) + '/' + a.enc(k), rec);
            }).then(function () {
                pollJoins(); cmRender();
            }).catch(function (e) { showModal('Lỗi', e.message, 'error'); });
            cmRender();
        }
        window.cmRequestsHtml = function (cls) {
            var a = API();
            if (!a || !a.teacherReady()) return '<div class="cm-card p-8 text-center font-bold text-slate-500">Hãy bật ĐỒNG BỘ (đám mây) để nhận yêu cầu xin vào lớp từ học sinh.<div style="margin-top:12px"><button type="button" onclick="CloudSync.openUI()" class="cm-btn bg-emerald-600 text-white" style="font-size:15px;padding:9px 20px">☁️ Bật ĐỒNG BỘ ngay</button></div></div>';
            var m = state.joins[a.enc(cls.id)] || {};
            var list = Object.keys(m).map(function (k) { return { k: k, r: m[k] }; }).filter(function (x) { return x.r; });
            list.sort(function (x, y) { return (y.r.ts || 0) - (x.r.ts || 0); });
            var pend = list.filter(function (x) { return x.r.status === 'pending'; });
            var done = list.filter(function (x) { return x.r.status !== 'pending'; });
            var h = '<div class="flex justify-between items-center mb-3"><div class="font-black text-slate-700">Yêu cầu chờ duyệt (' + pend.length + ')</div><button type="button" class="cm-btn bg-slate-200" onclick="ClassNet.refreshT()">↻ Làm mới</button></div>';
            h += pend.length ? pend.map(function (x) {
                return '<div class="cm-card p-3 mb-2 flex items-center justify-between gap-3"><div><b>' + E(x.r.name) + '</b> <span class="text-slate-500 font-bold">· Lớp ' + E(x.r.cls) + '</span><div class="text-xs text-slate-400">' + E(cmFmtDate(x.r.ts)) + '</div></div><div>' +
                    '<button type="button" class="cm-btn bg-green-600 text-white" onclick="ClassNet.approve(\'' + cls.id + '\',\'' + E(x.k) + '\',true)">✓ Duyệt</button> ' +
                    '<button type="button" class="cm-btn bg-red-100 text-red-700" onclick="ClassNet.approve(\'' + cls.id + '\',\'' + E(x.k) + '\',false)">✕ Từ chối</button></div></div>';
            }).join('') : '<div class="cm-card p-6 text-center font-bold text-slate-400">Không có yêu cầu nào đang chờ.</div>';
            if (done.length) h += '<div class="font-black text-slate-600 mt-5 mb-2">Đã xử lý</div>' + done.map(function (x) {
                return '<div class="cm-card p-2 mb-1 text-sm font-bold">' + E(x.r.name) + ' · ' + E(x.r.cls) + ' — ' + (x.r.status === 'approved' ? '<span class="text-green-700">Đã duyệt</span>' : (x.r.status === 'left' ? '<span class="text-slate-500">Đã rời lớp</span>' : (x.r.status === 'removed' ? '<span class="text-slate-500">Đã bị xóa khỏi lớp</span>' : '<span class="text-red-600">Đã từ chối</span>'))) + '</div>';
            }).join('');
            return h;
        };

        /* ================= HỌC SINH ================= */
        /* [CODE79] Tên học sinh có trong danh sách lớp giáo viên đã đưa lên máy chủ (không xét tên lớp) */
        function rosterHas(cl) {
            var a = API(), i = getStudentIdentity();
            return !!(a && i.name && Array.isArray(cl.rk) && cl.rk.indexOf(rosterKey(i.name)) >= 0);
        }
        function rosterMatch(cl) {
            var a = API(), i = getStudentIdentity();
            if (!a || !i.name || !Array.isArray(cl.rk)) return false;
            if (cl.rk.indexOf(rosterKey(i.name)) < 0) return false;
            return !i.cls || cmClassEq(i.cls, cl.name);   /* [CODE78] so khớp tên lớp linh hoạt */
        }
        function statusOf(cl) { var my = myMap(); return my[cl.id]; }
        function loadClasses(silent) {
            var a = API();
            if (!a || !a.effStu()) { state.msg = ''; state.noConn = true; state.loading = false; render(); return Promise.resolve(); }
            state.noConn = false; state.lastLoad = Date.now();   /* [CODE79] */
            if (!silent) { state.loading = true; render(); }
            /* [CODE73] Một số điện thoại/mạng di động trả dữ liệu lỗi thời hoặc lỗi tạm thời:
               thử tải lại tối đa 3 lần, dùng query chống cache; chỉ báo lỗi sau khi đã thử lại. */
            function fetchClassList(attempt) {
                return a.req('GET', 's', 'classes?cb=' + Date.now()).catch(function (err) {
                    if (attempt < 2) return new Promise(function (resolve) {
                        setTimeout(resolve, 350 * (attempt + 1));
                    }).then(function () { return fetchClassList(attempt + 1); });
                    throw err;
                });
            }
            return fetchClassList(0).then(function (c) {
                var raw = Object.keys(c || {}).map(function (k) { return c[k]; }).filter(function (x) { return x && x.id; });
                raw.forEach(function (cl) { if (!Array.isArray(cl.as)) cl.as = cl.as ? Object.keys(cl.as).map(function (k) { return cl.as[k]; }) : []; if (!Array.isArray(cl.rk)) cl.rk = cl.rk ? Object.keys(cl.rk).map(function (k) { return cl.rk[k]; }) : []; });
                /* [CODE72] Cùng một lớp được đưa lên từ nhiều máy (khác mã) -> gộp thành 1 lớp: hợp nhất danh sách học sinh và đề giao */
                var groups = {}, order = [];
                raw.sort(function (x, y) { return String(x.id) < String(y.id) ? -1 : 1; }).forEach(function (cl) {
                    var gk = cmNormLoose(cl.name);
                    var gr = groups[gk];
                    if (!gr) { gr = groups[gk] = Object.assign({}, cl, { ids: [cl.id], rk: cl.rk.slice(), as: cl.as.slice() }); order.push(gk); return; }
                    gr.ids.push(cl.id);
                    cl.rk.forEach(function (x) { if (gr.rk.indexOf(x) < 0) gr.rk.push(x); });
                    cl.as.forEach(function (x) {
                        var j = gr.as.findIndex(function (y) { return y && x && y.t === x.t; });
                        if (j < 0) gr.as.push(x); else if ((x.at || 0) > (gr.as[j].at || 0)) gr.as[j] = x;
                    });
                    gr.n = Math.max(gr.n || 0, cl.n || 0);
                });
                state.classes = order.map(function (gk) { return groups[gk]; });
                var k = sKey(), my = myMap(), left = ls(LS_LEFT, {}), idOk = !!(getStudentIdentity().name), removedNames = [], prevCache = ls(LS_CACHE, []);   /* [CODE79] */
                return Promise.all(state.classes.map(function (cl) {
                    var wasLeft = (cl.ids || [cl.id]).some(function (i) { return left[i]; });   /* [CODE78] lớp đã chủ động rời -> không tự vào lại */
                    if (!idOk) return null;   /* [CODE79] chưa đăng nhập học sinh: giữ nguyên, không đổi trạng thái lớp */
                    if (wasLeft) { delete my[cl.id]; return null; }
                    if (rosterMatch(cl)) { my[cl.id] = 'approved'; return null; }   /* [CODE80] đã có tên trong danh sách lớp: không cần hỏi bản ghi xin vào lớp */
                    return Promise.all(cl.ids.map(function (cid) {
                        return a.req('GET', 's', 'joins/' + a.enc(cid) + '/' + a.enc(k)).then(function (r) { return r && r.status || ''; }, function () { return ''; });
                    })).then(function (sts) {
                        var best = sts.indexOf('approved') >= 0 ? 'approved' : (sts.indexOf('pending') >= 0 ? 'pending' : (sts.indexOf('rejected') >= 0 ? 'rejected' : ''));
                        if (best === 'approved') {
                            /* [CODE79] Bản ghi "đã duyệt" chỉ có giá trị khi học sinh CÒN trong danh sách lớp của giáo viên. */
                            if (rosterHas(cl)) my[cl.id] = 'approved';
                            else { if (my[cl.id] === 'approved') removedNames.push(cl.name); delete my[cl.id]; }
                        }
                        else if (best) my[cl.id] = best;
                        else if (my[cl.id]) { if (my[cl.id] === 'approved') removedNames.push(cl.name); delete my[cl.id]; }
                    });
                })).then(function () {
                    Object.keys(my).forEach(function (id) {
                        if (state.classes.some(function (c) { return c.id === id; })) return;
                        if (idOk && my[id] === 'approved') {   /* [CODE79] lớp đã bị giáo viên xóa khỏi máy chủ */
                            var pc = prevCache.filter(function (z) { return z.id === id; })[0];
                            if (pc && !state.classes.some(function (c) { return my[c.id] === 'approved' && cmNormLoose(c.name) === cmNormLoose(pc.name); })) removedNames.push(pc.name);
                        }
                        delete my[id];
                    });
                    lsSet(LS_MY, my);
                    try {   /* [CODE79] bỏ ngữ cảnh lớp nếu học sinh không còn trong lớp đó */
                        var cx = ls(LS_CTX, null);
                        if (cx && cx.ids && !state.classes.some(function (c) { return my[c.id] === 'approved' && (c.ids || [c.id]).some(function (j) { return cx.ids.indexOf(j) >= 0; }); })) localStorage.removeItem(LS_CTX);
                    } catch (e) {}
                    if (removedNames.length) toast('⚠️ Giáo viên đã xóa em khỏi lớp: ' + removedNames.filter(function (v, i, ar) { return ar.indexOf(v) === i; }).join(', ') + '.');
                    try {   /* [CODE78] nhớ lớp + đề được giao để gắn lớp vào kết quả kể cả khi làm bài từ Thư viện */
                        lsSet(LS_CACHE, state.classes.filter(function (c) { return my[c.id] === 'approved'; }).map(function (c) {
                            return { id: c.id, ids: c.ids || [c.id], name: c.name, t: (c.as || []).map(function (x) { return x && x.t; }).filter(Boolean) };
                        }));
                    } catch (e) {}
                });
            }).then(function () { state.msg = ''; }, function (e) {
                state.msg = (e && e.message) || 'Không tải được danh sách lớp.';
                /* Không xóa state.classes khi mạng lỗi: giữ danh sách đã tải trước đó để người học thử lại. */
            }).then(function () {
                state.loading = false;
                /* [CODE81] làm mới ngầm: chỉ vẽ lại khi danh sách lớp / trạng thái thay đổi (không giật, giữ vị trí cuộn) */
                var sig = ''; try { sig = JSON.stringify([state.classes, myMap(), state.msg, state.noConn, state.view]); } catch (e) {}
                if (silent && sig && sig === state.renderSig) return;
                state.renderSig = sig; render();
            });
        }
        function join(cid) {
            var a = API(), id = getStudentIdentity();
            if (!id.name || !id.cls) { showModal('Thiếu thông tin', 'Hãy nhập Họ tên và Lớp ở trang chủ trước khi xin vào lớp.', 'error'); return; }
            var k = sKey();
            var grp = state.classes.filter(function (c) { return c.id === cid; })[0], targets = (grp && grp.ids) || [cid];
            var lf = ls(LS_LEFT, {}); targets.forEach(function (t) { delete lf[t]; }); delete lf[cid]; lsSet(LS_LEFT, lf);   /* [CODE78] */
            Promise.all(targets.map(function (t) {
                return a.req('PUT', 's', 'joins/' + a.enc(t) + '/' + a.enc(k), { k: k, name: id.name, cls: id.cls, ts: Date.now(), status: 'pending' });
            })).then(function () {
                var my = myMap(); my[cid] = 'pending'; lsSet(LS_MY, my);
                toast('Đã gửi yêu cầu. Chờ giáo viên phê duyệt.'); state.view = 'mine'; render();
            }).catch(function (e) { showModal('Lỗi', e.message, 'error'); });
        }
        function startTopic(id) { window.closeStudentClasses(); loadTopic(id); }
        function open(id, start, cid) {
            if (start && Date.now() < start) { showModal('Chưa đến giờ làm bài', 'Bài này sẽ mở lúc ' + cmFmtDate(start) + '. Em quay lại đúng giờ nhé!', 'info'); return; }
            try {   /* [CODE78] ghi nhớ lớp của bài đang làm để kết quả được gắn đúng lớp */
                var g0 = state.classes.filter(function (c) { return c.id === cid; })[0];
                if (g0) lsSet(LS_CTX, { t: id, ids: g0.ids || [g0.id], name: g0.name, ts: Date.now() });
            } catch (e) {}
            var a = API();
            if (!id || typeof loadTopic !== 'function') return;
            if (savedTopics.some(function (t) { return t.id === id; })) { startTopic(id); return; }
            toast('⏳ Đang tải đề từ máy chủ...');
            a.req('GET', 's', 'pub/' + a.enc(id)).then(function (env) {
                var o = null; try { o = env && typeof env.d === 'string' ? JSON.parse(env.d) : null; } catch (e) {}
                if (!o || !o.id) throw new Error('Đề này giáo viên chưa đưa lên máy chủ. Nhờ giáo viên bật ĐỒNG BỘ rồi bấm “Đẩy lớp lên máy chủ ngay”.');
                if (!savedTopics.some(function (t) { return t.id === o.id; })) savedTopics.push(o);
                try { saveToStorage(); } catch (e) {}
                startTopic(o.id);
            }).catch(function (e) { showModal('Chưa tải được đề', (e && e.message) || 'Hãy thử lại.', 'error'); });
        }
        /* [CODE78] Ngữ cảnh lớp của bài đang làm -> gắn vào kết quả */
        function ctxFor(topicId) {
            var c = ls(LS_CTX, null);
            if (c && c.t === topicId && c.ids && (Date.now() - (c.ts || 0)) < 12 * 3600 * 1000) return { classIds: c.ids, className: c.name };
            var cache = ls(LS_CACHE, []), left = ls(LS_LEFT, {});
            for (var i = 0; i < cache.length; i++) {
                var x = cache[i];
                if ((x.t || []).indexOf(topicId) >= 0 && !(x.ids || [x.id]).some(function (j) { return left[j]; })) return { classIds: x.ids || [x.id], className: x.name };
            }
            return null;
        }
        function attemptInfo(tid) {
            var n = 0, best = null;
            try { var L = myAttemptResults(tid); n = L.length; L.forEach(function (r) { var s = _mrScore(r); if (best === null || s > best) best = s; }); } catch (e) {}
            return { n: n, best: best };
        }
        var SUBJ_LABEL = { 'GDKT&PL': 'Giáo dục kinh tế và pháp luật', 'GDCD': 'Giáo dục công dân' };
        function subjOf(x) {   /* môn học của bài giao (ưu tiên dữ liệu giáo viên, dự phòng đề đã tải trên máy) */
            var v = x.sj || '';
            if (!v) { try { var t = savedTopics.filter(function (z) { return z && z.id === x.t; })[0]; if (t) v = t.subject || ''; } catch (e) {} }
            return v;
        }
        function gradeOf(x) {
            var v = x.g || '';
            if (!v) { try { var t = savedTopics.filter(function (z) { return z && z.id === x.t; })[0]; if (t) v = t.grade || ''; } catch (e) {} }
            return v;
        }
        function metaChips(x) {
            var g = gradeOf(x), out = '';
            if (g) out += '<span class="inline-block px-2 py-0.5 rounded-full text-xs font-black bg-indigo-100 text-indigo-700 mr-1.5">🎓 ' + E(/^\d+$/.test(String(g)) ? 'Lớp ' + g : g) + '</span>';
            if (x.fp) out += '<span class="inline-block px-2 py-0.5 rounded-full text-xs font-black bg-amber-100 text-amber-800 mr-1.5">📁 ' + E(x.fp) + '</span>';
            return out ? '<div class="sc-meta mt-1">' + out + '</div>' : '';
        }
        /* gom các bài giao theo MÔN HỌC (giống Thư viện bên giáo viên) */
        function assignGroupsHtml(cl, as) {
            /* [CODE119] Gom theo MÔN HỌC rồi tới THƯ MỤC CON (đồng bộ từ Thư viện): tiêu đề "📚 MÔN › 📁 thư mục"; trên điện thoại bỏ số bài và các nhãn Lớp/thư mục trong từng bài để tiết kiệm chỗ */
            var groups = {}, order = [];
            as.forEach(function (x) {
                var k = subjOf(x), f = String(x.fp || '').trim(), key = k + '\u0001' + f;
                if (!groups[key]) { groups[key] = { k: k, f: f, items: [] }; order.push(key); }
                groups[key].items.push(x);
            });
            order.sort(function (a, b) {
                var A = groups[a], B = groups[b];
                if (!A.k && B.k) return 1; if (A.k && !B.k) return -1;
                return A.k.localeCompare(B.k, 'vi') || A.f.localeCompare(B.f, 'vi');
            });
            var first = groups[order[0]];
            var showHead = order.length > 1 || (order.length === 1 && (first.k || first.f));
            return order.map(function (key) {
                var g = groups[key];
                var head = showHead ? '<div class="sc-subj-head mt-3 mb-1 px-3 py-1.5 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 font-black uppercase" style="font-size:15px;line-height:1.35">\uD83D\uDCDA ' + E(g.k ? (SUBJ_LABEL[g.k] || g.k) : 'Bài khác') +
                    (g.f ? ' <span class="sc-fp-inline normal-case text-amber-800" style="font-size:.92em;overflow-wrap:anywhere">\u203A \uD83D\uDCC1 ' + E(g.f) + '</span>' : '') +
                    ' <span class="sc-cnt text-teal-600 normal-case">(' + g.items.length + ' bài)</span></div>' : '';
                return head + g.items.map(function (x) { return rowHtml(cl, x); }).join('');
            }).join('');
        }
        function rowHtml(cl, x) {
            var info = attemptInfo(x.t), notYet = x.s && Date.now() < x.s, did = info.n > 0;
            var st = did
                ? '<div class="text-xs font-black text-emerald-700 mt-0.5">✅ Đã làm ' + info.n + ' lần' + (info.best !== null ? ' • Điểm cao nhất: ' + E(_mrFmt(info.best)) + '/10' : '') + '</div>'
                : '<div class="text-xs font-black text-slate-400 mt-0.5">Chưa làm bài này</div>';
            var go = 'ClassNet.open(\'' + E(x.t) + '\',' + (x.s || 0) + ',\'' + E(cl.id) + '\')';
            return '<div class="sc-row border-t py-3"><div><b>' + E(x.n) + '</b>' + metaChips(x) +
                ((x.s || x.d) ? '<div class="sc-dates">' +
                    (x.s ? '<span class="text-xs text-sky-700 font-bold">Bắt đầu: ' + E(cmFmtDate(x.s)) + '</span>' : '') +
                    (x.d ? '<span class="text-xs text-red-600 font-bold">Hạn nộp: ' + E(cmFmtDate(x.d)) + '</span>' : '') + '</div>' : '') +
                (x.m ? '<div class="text-xs text-slate-500">' + E(x.m) + '</div>' : '') + st + '</div>' +
                '<div class="sc-acts flex flex-wrap gap-2 mt-2">' +
                '<button type="button" class="sc-act cm-btn bg-indigo-600 text-white" style="padding:8px 16px;border-radius:10px;font-weight:900" onclick="' + go + '">' + (notYet ? '🕒 Chưa đến giờ' : (did ? '🔁 Làm lại' : '▶ Làm bài')) + '</button>' +
                '<button type="button" class="sc-act cm-btn bg-white text-indigo-700 border-2 border-indigo-300" style="padding:8px 16px;border-radius:10px;font-weight:900' + (did ? '' : ';opacity:.75') + '" onclick="ClassNet.viewResult(\'' + E(x.t) + '\')">📋 Xem kết quả</button>' +
                '</div></div>';
        }
        function viewResult(tid) {
            var has = false;
            try { has = attemptInfo(tid).n > 0 || hasAttemptFor(tid); } catch (e) {}
            if (!has) { showModal('Chưa có kết quả', 'Em chưa làm bài này trên thiết bị này nên chưa có kết quả để xem.\nHãy bấm “Làm bài” trước nhé!', 'info'); return; }
            openMyResults(tid);
        }
        function leave(cid) {
            var grp = state.classes.filter(function (c) { return c.id === cid; })[0], name = grp ? grp.name : '';
            if (!confirm('Em muốn RỜI lớp "' + name + '"?\n\nEm sẽ không còn thấy các bài giao của lớp này. Kết quả đã làm vẫn được giữ trên máy.\nMuốn vào lại, em bấm "Tìm lớp học" và xin vào lớp.')) return;
            var a = API(), k = sKey(), id = getStudentIdentity(), targets = (grp && grp.ids) || [cid];
            var lf = ls(LS_LEFT, {}); targets.forEach(function (t) { lf[t] = Date.now(); }); lf[cid] = Date.now(); lsSet(LS_LEFT, lf);
            var my = myMap(); targets.forEach(function (t) { delete my[t]; }); delete my[cid]; lsSet(LS_MY, my);
            try { var cx = ls(LS_CTX, null); if (cx && (cx.ids || []).some(function (j) { return targets.indexOf(j) >= 0; })) localStorage.removeItem(LS_CTX); } catch (e) {}
            try { lsSet(LS_CACHE, ls(LS_CACHE, []).filter(function (c) { return targets.indexOf(c.id) < 0; })); } catch (e) {}
            render();
            toast('🚪 Đã rời lớp ' + name);
            if (a && a.effStu()) {
                Promise.all(targets.map(function (t) {
                    return a.req('PUT', 's', 'joins/' + a.enc(t) + '/' + a.enc(k), { k: k, name: id.name, cls: id.cls, ts: Date.now(), status: 'left' });
                })).catch(function () {});
            }
        }
        function useCode() {
            var el = document.getElementById('sc-code'), v = el ? el.value : '';
            if (window.CloudSync && CloudSync.setStudentToken(v)) { state.noConn = false; toast('✅ Đã kết nối với giáo viên'); loadClasses(); try { CloudSync.sync(); } catch (e) {} }
            else { state.connMsg = 'Mã/link không hợp lệ. Hãy dán đúng link hoặc mã MQC1... do giáo viên gửi.'; render(); }
        }
        function card(cl, status) {
            var btn = status === 'approved' ? '<span class="font-black text-emerald-700">✅ Đã vào lớp</span>' : status === 'pending' ? '<span class="font-black text-amber-600">⏳ Chờ giáo viên duyệt</span>'
                : (status === 'rejected' ? '<div class="text-xs font-black text-red-600 mb-1 text-right">Yêu cầu trước bị từ chối</div>' : '') + '<button type="button" class="cm-btn bg-emerald-600 text-white" style="padding:8px 18px;border-radius:10px;font-weight:900" onclick="ClassNet.join(\'' + E(cl.id) + '\')">Tham gia lớp</button>';
            return '<div class="bg-white rounded-xl border p-4 mb-3 flex items-center justify-between gap-3 shadow-sm"><div><div class="sc-clname">' + E(cl.name) + '</div><div class="text-sm font-bold text-slate-500">' + E(cl.teacher || '') + (cl.grade ? ' · Khối ' + E(cl.grade) : '') + (cl.year ? ' · ' + E(cl.year) : '') + ' · ' + (cl.n || 0) + ' học sinh</div></div><div>' + btn + '</div></div>';
        }
        function render() {
            var body = document.getElementById('sc-body'); if (!body) return;
            var h;
            if (state.noConn) {
                h = '<div class="bg-white rounded-xl border p-5 shadow-sm"><div class="text-xl font-black text-slate-700 mb-2">📡 Chưa kết nối với giáo viên</div>' +
                    '<div class="font-bold text-slate-500 mb-3" style="line-height:1.55">Hãy mở app bằng <b>link / mã QR vào lớp</b> do giáo viên gửi, hoặc dán link/mã kết nối (bắt đầu bằng <b>MQC1.</b>) vào ô dưới:</div>' +
                    '<textarea id="sc-code" rows="3" class="w-full border-2 rounded-lg px-3 py-2 font-bold" style="font-size:14px" placeholder="Dán link hoặc mã MQC1... vào đây"></textarea>' +
                    (state.connMsg ? '<div class="text-red-600 font-bold mt-2">' + E(state.connMsg) + '</div>' : '') +
                    '<button type="button" class="cm-btn bg-emerald-600 text-white mt-3" style="padding:10px 24px;border-radius:10px;font-weight:900" onclick="ClassNet.useCode()">Kết nối</button></div>';
                body.innerHTML = h; return;
            }
            var my = myMap(), mine = state.classes.filter(function (c) { return my[c.id] === 'approved'; });
            h = '<div class="flex gap-2 mb-4 flex-wrap"><button type="button" class="cm-btn ' + (state.view === 'mine' ? 'bg-teal-600 text-white' : 'bg-white border') + '" style="padding:8px 16px;border-radius:10px;font-weight:900" onclick="ClassNet.setView(\'mine\')">Lớp của tôi</button><button type="button" class="cm-btn ' + (state.view === 'find' ? 'bg-teal-600 text-white' : 'bg-white border') + '" style="padding:8px 16px;border-radius:10px;font-weight:900" onclick="ClassNet.setView(\'find\')">🔍 Tìm lớp học</button></div>';
            if (state.msg) h += '<div class="p-3 mb-3 rounded-lg bg-red-50 text-red-700 font-bold">⚠️ ' + E(state.msg) + '</div>';
            if (state.loading) h += '<div class="font-bold text-slate-500">Đang tải…</div>';
            else if (state.view === 'mine') {
                if (!mine.length) h += '<div class="text-center p-10"><div class="text-5xl mb-2">🏫</div><div class="text-xl font-black text-slate-600 mb-3">Bạn chưa tham gia lớp học nào</div><div class="text-sm font-bold text-slate-400 mb-3">' + (state.classes.length ? 'Có ' + state.classes.length + ' lớp giáo viên đã công bố. Hãy bấm “Tìm lớp học” để tham gia.' : 'Giáo viên chưa công bố lớp nào (hoặc chưa bật ĐỒNG BỘ).') + '</div><button type="button" class="cm-btn bg-emerald-600 text-white" style="padding:10px 26px;font-size:16px;border-radius:10px;font-weight:900" onclick="ClassNet.setView(\'find\')">Tìm lớp học</button></div>';
                mine.forEach(function (cl) {
                    h += '<div class="bg-white rounded-xl border p-4 mb-4 shadow-sm"><div class="flex items-start justify-between gap-2 mb-2"><div class="min-w-0"><div class="sc-clname">' + E(cl.name) + '</div><div class="text-sm font-bold text-slate-500">' + E(cl.teacher || '') + (cl.grade ? ' · Khối ' + E(cl.grade) : '') + '</div></div>' +
                        '<button type="button" class="cm-btn bg-red-50 text-red-700 border-2 border-red-300" style="padding:7px 14px;border-radius:10px;font-weight:900;white-space:nowrap" onclick="ClassNet.leave(\'' + E(cl.id) + '\')">🚪 Rời lớp</button></div>';
                    var as = (cl.as || []).slice().sort(function (x, y) { return (y.at || 0) - (x.at || 0); });
                    h += as.length ? assignGroupsHtml(cl, as) : '<div class="text-slate-400 font-bold border-t pt-2">Chưa có đề nào được giao.</div>';
                    h += '</div>';
                });
            } else {
                var q = cmNormLoose(state.q);
                h += '<input id="sc-search" type="text" value="' + E(state.q) + '" placeholder="Tìm theo tên lớp / giáo viên…" oninput="ClassNet.search(this.value)" class="w-full border-2 rounded-lg px-4 py-2 mb-4 font-bold">';
                var list = state.classes.filter(function (c) { return !q || cmNormLoose(c.name + ' ' + (c.teacher || '')).indexOf(q) >= 0; });
                h += '<div id="sc-list">' + (list.length ? list.map(function (c) { return card(c, my[c.id]); }).join('') : '<div class="text-slate-400 font-bold p-6 text-center">Chưa có lớp nào được giáo viên công bố.</div>') + '</div>';
            }
            body.innerHTML = h;
            if (state.view === 'find') { var si = document.getElementById('sc-search'); if (si && state.q) { si.focus(); si.setSelectionRange(state.q.length, state.q.length); } }
        }
        /* [CODE86] ✕ Đóng: đang ở "Tìm lớp học" thì lùi về "Lớp của tôi"; ở "Lớp của tôi" thì đóng hẳn về trang chủ */
        function closeStep() {
            if (!state.noConn && state.view === 'find') { state.view = 'mine'; state.q = ''; render(); return; }
            window.closeStudentClasses();
        }
        window.openStudentClasses = function () {
            var m = document.getElementById('student-class-modal'); if (!m) return;
            m.classList.remove('hidden'); requestAnimationFrame(function () { m.classList.remove('opacity-0'); });
            state.msg = ''; state.view = 'mine'; loadClasses();
            try { window.CloudSync.sync(); } catch (e) {}
        };
        window.closeStudentClasses = function () {
            var m = document.getElementById('student-class-modal'); if (!m) return;
            m.classList.add('opacity-0'); setTimeout(function () { m.classList.add('hidden'); }, 250);
        };

        window.ClassNet = {
            bannerHtml: bannerHtml, pendingCount: pendingCount, approve: approve, join: join, open: open, useCode: useCode,
            leave: leave, viewResult: viewResult, ctxFor: ctxFor, closeStep: closeStep,   /* [CODE78] */
            studentRemoved: studentRemoved, classDeleted: classDeleted,   /* [CODE79] */
            setView: function (v) { state.view = v; state.q = ''; render(); },
            search: function (v) { state.q = v; render(); },
            refreshS: function () { return loadClasses(); }, refreshT: function () { publishClasses(true); pollJoins(); },
            publish: publishClasses, publishNow: publishNow, copyLink: copyLink, copyTeacherLink: copyTeacherLink, showQr: showQr, classLink: classLink,
            onSyncDone: function () { if (isStudentMode) return; publishClasses(false); if (Date.now() - state.lastPoll > 6000) pollJoins(); }
        };

        /* Giáo viên: đẩy lớp lên mạng khi lưu; hỏi yêu cầu mới mỗi 10 giây */
        var _cs = window.cmSave, _t = null;
        if (typeof _cs === 'function') {
            window.cmSave = function () { var r = _cs.apply(this, arguments); clearTimeout(_t); _t = setTimeout(function () { publishClasses(false); }, 800); return r; };
        }
        var _oc = window.openClassManager;
        if (typeof _oc === 'function') {
            window.openClassManager = function () { var r = _oc.apply(this, arguments); try { publishClasses(false); pollJoins(); } catch (e) {} try { window.CloudSync.schedule(true); } catch (e) {} return r; };
        }
        setInterval(function () { if (!document.hidden && !isStudentMode) { pollJoins(); publishClasses(false); } }, 15000);   /* [CODE80] 10s -> 15s */
        setTimeout(function () { if (!isStudentMode) { publishClasses(false); pollJoins(); } }, 3000);
        /* Học sinh: tự làm mới danh sách lớp khi đang mở cửa sổ LỚP HỌC */
        /* [CODE79] Làm mới danh sách lớp: 15 giây/lần khi đang mở LỚP HỌC, 60 giây/lần khi đóng; và ngay khi quay lại trang */
        setInterval(function () {
            if (!isStudentMode || document.hidden || state.noConn || state.loading) return;
            var m = document.getElementById('student-class-modal');
            var open = m && !m.classList.contains('hidden');
            if (open || Date.now() - (state.lastLoad || 0) > 90000) loadClasses(true);
        }, 20000);   /* [CODE80] nhẹ hơn: 20s khi mở LỚP HỌC, 90s khi đóng */
        document.addEventListener('visibilitychange', function () {
            if (!document.hidden && isStudentMode && !state.noConn && Date.now() - (state.lastLoad || 0) > 5000) loadClasses(true);
        });

        /* Link vào lớp (?mode=hs&cl=...) tự chọn sẵn vai “Tôi là HS” */
        try {
            var P = new URLSearchParams(location.search);
            if (P.get('cl') && P.get('mode') === 'hs' && !P.get('id') && !P.get('hs')) {
                var rs = document.getElementById('login-role-select');
                if (rs && rs.value !== 'HS') { rs.value = 'HS'; if (typeof handleLoginRoleChange === 'function') handleLoginRoleChange(); }
            }
        } catch (e) {}

        /* Đăng xuất: đóng cửa sổ lớp học */
        var _lo = window.logoutApp;
        if (typeof _lo === 'function') {
            window.logoutApp = function () { var m = document.getElementById('student-class-modal'); if (m) m.classList.add('hidden', 'opacity-0'); return _lo.apply(this, arguments); };
        }
    })();
    