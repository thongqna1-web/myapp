
/* [CODE37] CHƠI TRỰC TIẾP: kết nối giáo viên - học sinh qua PeerJS (WebRTC), không cần tài khoản cho học sinh */
(function () {
    const VER = 'b54';
    const $ = id => document.getElementById(id);
    const E = s => _escHtml(String(s == null ? '' : s));
    const F = t => formatMathAndChemHTML(t || '');
    const rid = n => Array.from({ length: n }, () => 'abcdefghijkmnpqrstuvwxyz23456789'[Math.random() * 32 | 0]).join('');
    const PEER_OPTS = { config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }, { urls: 'stun:global.stun.twilio.com:3478' }, { urls: ['turn:openrelay.metered.ca:80', 'turn:openrelay.metered.ca:443', 'turns:openrelay.metered.ca:443?transport=tcp'], username: 'openrelayproject', credential: 'openrelayproject' }] } };   // [CODE170] dự phòng WebRTC: thêm STUN/TURN
    /* [CODE170] KÊNH FIREBASE cho CHƠI TRỰC TIẾP: đi qua HTTPS tới máy chủ Firebase của giáo viên (đã ĐỒNG BỘ) thay cho WebRTC/PeerJS
       -> vào được cả mạng 4G / mạng trường / mạng chặn WebRTC. API giống PeerJS (on open/connection/data/close/error, send, destroy). */
    function Em() { const h = {}; this.on = (e, f) => { (h[e] = h[e] || []).push(f); return this; }; this.emit = (e, ...a) => { (h[e] || []).slice().forEach(f => { try { f(...a); } catch (x) { console.warn(x); } }); }; }
    const fbReq = (m, url, body, keep) => fetch(url, { method: m, cache: 'no-store', keepalive: !!keep, headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined, body: body !== undefined ? JSON.stringify(body) : undefined }).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.status === 204 ? null : r.json(); });
    const fbRetry = async (fn, n) => { for (let i = 0; ; i++) { try { return await fn(); } catch (e) { if (i >= (n == null ? 4 : n)) throw e; await new Promise(r => setTimeout(r, 400 * (i + 1) * (i + 1))); } } };
    const fbSender = url => { let q = Promise.resolve(); return m => { const body = { d: JSON.stringify(m), ts: Date.now() }; q = q.then(() => fbRetry(() => fbReq('POST', url, body))).catch(() => { }); return q; }; };
    const fbSse = (url, cb) => { let es; try { es = new EventSource(url); } catch (e) { return { close() { } }; } const h = ev => { try { const j = JSON.parse(ev.data); if (j) cb(j.path || '/', j.data); } catch (e) { } }; es.addEventListener('put', h); es.addEventListener('patch', h); return es; };
    const fbEach = (path, data, fn) => { if (data == null) return; const sg = String(path).split('/').filter(Boolean); if (sg.length === 0) { for (const a in data) { const o = data[a]; if (o && typeof o === 'object') for (const k in o) fn(a, k, o[k]); } } else if (sg.length === 1) { for (const k in data) fn(sg[0], k, data[k]); } else fn(sg[0], sg[1], data); };
    const fbSort = a => a.sort((x, y) => x[0] < y[0] ? -1 : x[0] > y[0] ? 1 : 0);
    function FbConn(peer, cid) { Em.call(this); this.peer = cid; this.open = true; this.reliable = true; this._s = fbSender(peer._B + '/down/' + cid + '.json'); }
    FbConn.prototype.send = function (m) { if (this.open) this._s(m); };
    FbConn.prototype.close = function () { this.open = false; };
    function FbPeer(id, cfg) {   /* phía giáo viên (chủ phòng) */
        Em.call(this); const me = this; me.id = id; me.destroyed = false; me.conns = {}; me._B = cfg.u + '/s/' + cfg.p + '/live/' + id; const seen = new Set();
        setTimeout(() => {
            fbRetry(() => fbReq('PUT', me._B + '/host.json', { t: Date.now() }), 1).then(() => {
                if (me.destroyed) return;
                me.emit('open', id);
                me._es = fbSse(me._B + '/up.json', (path, data) => {
                    const items = [];
                    fbEach(path, data, (cid, key, it) => { const k = cid + '/' + key; if (it && typeof it.d === 'string' && !seen.has(k)) { seen.add(k); items.push([key, cid, it]); } });
                    fbSort(items).forEach(([k, cid, it]) => {
                        let m; try { m = JSON.parse(it.d); } catch (e) { return; }
                        let c = me.conns[cid];
                        if (m && m.__bye) { if (c) { c.open = false; c.emit('close'); delete me.conns[cid]; } return; }
                        if (!c) { c = me.conns[cid] = new FbConn(me, cid); me.emit('connection', c); }
                        c.emit('data', m);
                    });
                });
            }).catch(() => { if (!me.destroyed) me.emit('error', { type: 'network' }); });
        }, 0);
    }
    FbPeer.prototype = Object.create(Em.prototype);
    FbPeer.prototype.reconnect = function () { };
    FbPeer.prototype.destroy = function () { this.destroyed = true; try { this._es && this._es.close(); } catch (e) { } try { fbReq('DELETE', this._B + '.json', undefined, true).catch(() => { }); } catch (e) { } };
    function FbStudent(cfg) {   /* phía học sinh */
        Em.call(this); this.cfg = cfg; this.id = 'st' + rid(10); this.destroyed = false; setTimeout(() => this.emit('open', this.id), 0);
    }
    FbStudent.prototype = Object.create(Em.prototype);
    FbStudent.prototype.connect = function (hostId) {
        const me = this, c = new Em(), cid = me.id, B = me.cfg.u + '/s/' + me.cfg.p + '/live/' + hostId, seen = new Set(), snd = fbSender(B + '/up/' + cid + '.json');
        c.open = false; c.peer = hostId; c.send = m => { if (c.open) snd(m); }; c.close = () => { c.open = false; try { c._es && c._es.close(); } catch (e) { } };
        fbRetry(() => fbReq('GET', B + '/host.json'), 2).then(h => {
            if (me.destroyed) return;
            if (!h) { me.emit('error', { type: 'peer-unavailable' }); return; }
            c._es = fbSse(B + '/down/' + cid + '.json', (path, data) => {
                const items = [], sg = String(path).split('/').filter(Boolean);
                if (data == null) return;
                if (sg.length === 0) { for (const k in data) items.push([k, data[k]]); } else items.push([sg[0], data]);
                fbSort(items.filter(([k, it]) => it && typeof it.d === 'string' && !seen.has(k) && seen.add(k))).forEach(([k, it]) => { try { c.emit('data', JSON.parse(it.d)); } catch (e) { } });
            });
            c.open = true; c.emit('open');
        }).catch(() => me.emit('error', { type: 'network' }));
        window.addEventListener('pagehide', () => { try { fbReq('POST', B + '/up/' + cid + '.json', { d: JSON.stringify({ __bye: 1 }), ts: Date.now() }, true).catch(() => { }); } catch (e) { } });
        me._c = c; return c;
    };
    FbStudent.prototype.destroy = function () { this.destroyed = true; try { this._c && this._c.close(); } catch (e) { } };

    const fm = x => String(x).replace('.', ',');
    const GS = '.qc-live .q-options-one-row, .qc-live .q-options-two-rows, .qc-live .q-options-four-rows';
    const PL = { mc: 'PHẦN I. TRẮC NGHIỆM NHIỀU LỰA CHỌN', tf: 'PHẦN II. ĐÚNG – SAI', sa: 'PHẦN III. TRẢ LỜI NGẮN' };
    const TC = ['#ef4444', '#2563eb', '#16a34a', '#f59e0b', '#7c3aed', '#db2777', '#0891b2', '#65a30d', '#ea580c', '#475569', '#0d9488', '#b91c1c'];
    const st = document.createElement('style');
    st.textContent = `.lv-w{max-width:900px;margin:0 auto;padding:16px}.lv-hd{background:linear-gradient(90deg,#db2777,#7c3aed);color:#fff;padding:14px 20px;display:flex;justify-content:space-between;align-items:center;gap:8px;position:sticky;top:0;z-index:5}
.lv-b{padding:10px 20px;border-radius:12px;font-weight:900;color:#fff;background:#7c3aed;cursor:pointer;border:0}.lv-b.g{background:#059669}.lv-b.r{background:#dc2626}.lv-b.s{background:#e2e8f0;color:#334155}
.lv-c{background:#fff;border-radius:16px;border:2px solid #e2e8f0;padding:14px;margin:10px 0}.lv-o{display:flex;gap:8px;width:100%;text-align:left;padding:10px 12px;margin:6px 0;border:2px solid #cbd5e1;border-radius:12px;background:#fff;font-weight:400;font-family:Roboto,Arial,sans-serif;cursor:pointer;font-size:17px}
.lv-o.sel{border-color:#7c3aed;background:#ede9fe}.lv-o.ok{border-color:#059669;background:#d1fae5}.lv-o.bad{border-color:#dc2626;background:#fee2e2}
.lv-t{display:inline-block;padding:3px 12px;border-radius:99px;font-weight:900;font-size:14px}.lv-tab{padding:12px 20px;margin-bottom:8px;border-radius:16px;font-weight:900;font-size:16px;cursor:pointer;border:0;color:#475569;background:linear-gradient(180deg,#fff 0%,#e2e8f0 100%);box-shadow:0 5px 0 #94a3b8,0 9px 14px rgba(15,23,42,.18),inset 0 2px 0 rgba(255,255,255,.95);transition:transform .08s,box-shadow .08s,filter .15s}.lv-tab:hover{filter:brightness(1.04)}.lv-tab:active{transform:translateY(4px);box-shadow:0 1px 0 #94a3b8,0 3px 6px rgba(15,23,42,.18),inset 0 2px 0 rgba(255,255,255,.95)}.lv-tab.on{color:#fff;background:linear-gradient(180deg,#c4b5fd 0%,#8b5cf6 45%,#6d28d9 100%);box-shadow:0 5px 0 #4c1d95,0 9px 18px rgba(124,58,237,.5),inset 0 2px 0 rgba(255,255,255,.5);text-shadow:0 1px 2px rgba(0,0,0,.4)}
.lv-tb{width:100%;border-collapse:collapse;background:#fff}.lv-tb th,.lv-tb td{border:1px solid #e2e8f0;padding:7px 10px;text-align:center}.lv-tb td:nth-child(2){text-align:left}.lv-tb th{background:#ede9fe}
.lv-qt,.lv-qt *:not(.katex):not(.katex *),.lv-ot,.lv-ot *:not(.katex):not(.katex *),.lv-o,.lv-o *:not(.katex):not(.katex *),.lv-sol,.lv-sol *:not(.katex):not(.katex *),.lv-i{}.lv-qt,.lv-qt .math-content,.lv-ot,.lv-ot .math-content{font-weight:400!important;text-align:justify!important;text-justify:inter-word}.lv-qt b,.lv-ot b,.lv-o>span:first-child{font-weight:700!important}.lv-o.lk{opacity:.55;cursor:not-allowed}.lv-tag{display:inline-block;margin-left:8px;font-size:13px;font-weight:700;padding:1px 10px;border-radius:99px;background:#1e293b;color:#fff}.lv-g{display:grid;gap:8px}.lv-g.c4{grid-template-columns:repeat(4,minmax(0,1fr))}.lv-g.c2{grid-template-columns:repeat(2,minmax(0,1fr))}.lv-g.c1{grid-template-columns:minmax(0,1fr)}.lv-g .lv-o{margin:0;min-width:0}.lv-tb th,.lv-tb td{white-space:nowrap}.lv-tb td:nth-child(2){width:100%}.lv-b{white-space:nowrap}#lv-s,#lv-t,#lv-d{overscroll-behavior:contain;-webkit-overflow-scrolling:touch}.lv-o,.lv-b,.lv-i{touch-action:manipulation;-webkit-tap-highlight-color:transparent}#lv-s.guard{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}#lv-s.guard input{-webkit-user-select:text;user-select:text}.lv-tag.r{background:#dc2626}.lv-i{border:2px solid #cbd5e1;border-radius:12px;padding:8px 12px;font-size:17px;font-weight:700;width:100%}.lv-tq{border-radius:18px;border:4px solid;background:#fff;overflow:hidden;text-align:center}.lv-tq h4{color:#fff;font-weight:900;font-size:20px;padding:8px 10px;word-break:break-word}.lv-qb{padding:10px;cursor:zoom-in}.lv-mem{display:flex;flex-wrap:wrap;gap:4px;justify-content:center;margin-top:4px}.lv-mem span{font-size:13px;font-weight:700;padding:1px 8px;border-radius:99px}.lv-sh-t .lv-tag{font-size:12px;vertical-align:middle}`;
    document.head.appendChild(st);
    const fl = document.createElement('link'); fl.rel = 'stylesheet'; fl.href = 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap&subset=vietnamese'; document.head.appendChild(fl);
    function layer(id, html) {
        let d = $(id);
        if (!d) { d = document.createElement('div'); d.id = id; d.style.cssText = 'position:fixed;inset:0;z-index:9000;overflow:auto;background:#f1f5f9'; document.body.appendChild(d); }
        d.innerHTML = html; d.classList.toggle('guard', id === 'lv-s' && !!(window.LS && window.LS.guard && window.LS.guard.on)); d.querySelectorAll(GS).forEach(fit); return d;
    }
    /* [CODE49] Tự chọn bố cục đáp án 1 hàng / 2x2 / 4 hàng theo độ rộng thực tế (giống màn hình làm bài về nhà) */
    function fit(g) {
        const btns = [...g.querySelectorAll('.q-option-btn')]; if (!btns.length) return;
        const gw = g.clientWidth; if (!gw) return;
        g.removeAttribute('data-fit');
        const order = ['q-options-one-row', 'q-options-two-rows', 'q-options-four-rows'];
        const fits = () => btns.every(btn => {   /* [CODE64] thử thật: nội dung đáp án (không xuống dòng) phải nhỏ hơn chỗ trống trong ô */
            const txt = btn.querySelector('.q-option-text'); if (!txt) return true;
            const avail = txt.clientWidth, keep = txt.style.cssText;
            ['flex:0 0 auto', 'width:max-content', 'max-width:none', 'min-width:0', 'white-space:nowrap', 'overflow:visible'].forEach(d => { const k = d.split(':'); txt.style.setProperty(k[0], k[1], 'important'); });
            const nat = txt.getBoundingClientRect().width;
            txt.style.cssText = keep;   // [CODE65] đo đúng bề rộng khi nằm 1 dòng (trước đây bị max-width:100% làm đo sai)
            return nat * 1.04 + 8 <= avail;
        });
        g.removeAttribute('data-f');
        let chosen = order[2];
        for (const cls of order.slice(0, 2)) {
            g.classList.remove.apply(g.classList, order); g.classList.add(cls);
            if (fits()) { chosen = cls; break; }
        }
        g.classList.remove.apply(g.classList, order); g.classList.add(chosen); g.setAttribute('data-f', '1'); g.removeAttribute('data-fit');
        /* [CODE124] kiểm tra tràn thật: còn tràn thì nâng dần 1 dòng -> 2 dòng -> 4 dòng */
        let ix = order.indexOf(chosen);
        const over = () => btns.some(b => { const t = b.querySelector('.q-option-text'); return b.scrollWidth > b.clientWidth + 1 || (t && t.scrollWidth > t.clientWidth + 1); });
        while (ix < 2 && over()) { ix++; g.classList.remove.apply(g.classList, order); g.classList.add(order[ix]); }
    }
    let fq = 0, fw = window.innerWidth;
    const fitAll = () => { cancelAnimationFrame(fq); fq = requestAnimationFrame(() => document.querySelectorAll(GS.split(',').map(x => x.trim() + ':not([data-f])').join(',')).forEach(fit)); };
    const refit = () => { document.querySelectorAll(GS).forEach(g => g.removeAttribute('data-f')); fitAll(); };
    new MutationObserver(fitAll).observe(document.body, { childList: true, subtree: true });
    window.addEventListener('resize', () => { if (window.innerWidth !== fw) { fw = window.innerWidth; refit(); } });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(refit);
    /* [CODE124] đo lại khi font Roboto / ảnh trong đáp án / trang tải xong (khung Thư viện, Chơi trực tiếp) */
    try {
        if (document.fonts) { if (document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', refit); if (document.fonts.load) document.fonts.load('400 20px Roboto').then(refit).catch(() => { }); }
        window.addEventListener('load', () => { refit(); setTimeout(refit, 700); });
        document.addEventListener('load', e => { const t = e.target; if (t && t.tagName === 'IMG' && t.closest && t.closest('.q-option-text')) refit(); }, true);
    } catch (e) { }
    /* QR co giãn theo khung (dùng cho 4 mã QR của đội + khi phóng to) */
    const qrScal = url => {
        try {
            const q = qrcode(0, 'M'); q.addData(url); q.make(); const n = q.getModuleCount(), m = 2; let p = '';
            for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) p += `M${c + m},${r + m}h1v1h-1z`;
            return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n + 2 * m} ${n + 2 * m}" shape-rendering="crispEdges" style="width:100%;height:auto;display:block;background:#fff"><path d="${p}" fill="#000"/></svg>`;
        } catch (e) { return ''; }
    };
    const qrSvg = url => { try { const q = qrcode(0, 'M'); q.addData(url); q.make(); return q.createSvgTag(6, 2); } catch (e) { return ''; } };
    const pub = q => { const m = (window.LV && window.LV.nm || {})[q.id] || {}, g = m.g; return { id: q.id, type: qType(q), text: q.text, options: (q.options || []).map(o => ({ letter: o.letter, text: o.text })), gid: q.gid, gm: q.gm, ginfo: g ? g.info : q.ginfo, num: m.num, gf: g ? g.from : undefined, gt: g ? g.to : undefined }; };
    const keyOf = q => ({ correct: q.correct, tf: q.tfAnswers, sa: q.shortAnswer, sol: q.solution || '', tfSol: q.tfSol || [] });

    /* ---------- [CODE49] Thẻ câu hỏi dùng chung (GV + HS): DÙNG ĐÚNG lớp giao diện của màn hình làm bài về nhà ----------
       h = tên đối tượng nhận sự kiện (null = chỉ xem); ctx = { nm: bảng số thứ tự, single: hiện 1 câu }; opt = { noSol, teacher } */
    const numMap = qs => {
        const c = { mc: 0, tf: 0, sa: 0 }, m = {}, gm = {};
        qs.forEach(q => { const t = q.type || qType(q); c[t]++; m[q.id] = { t, num: c[t] }; if (q.gid) (gm[q.gid] = gm[q.gid] || []).push(q); });
        Object.keys(gm).forEach(g => {
            const mem = gm[g], nums = mem.map(x => m[x.id].num), wi = mem.find(x => x.ginfo && String(x.ginfo).trim());
            mem.forEach((x, i) => { m[x.id].g = { first: i === 0, from: nums[0], to: nums[nums.length - 1], info: wi ? String(wi.ginfo) : '', gm: x.gm }; });
        });
        return m;
    };
    const partHd = t => {
        if (window.CODE121EN && CODE121EN.noPartHeader()) return '';   // [CODE121]
        const m = PART_META[t] || PART_META.mc;
        return `<div class="q-part-header bg-gradient-to-r ${m.soft} border-2 rounded-xl px-4 py-2 shadow-sm"><p class="q-part-line"><span class="q-part-badge ${m.badge} text-white font-black rounded-full px-3.5 py-0.5 text-[17px] tracking-wide">PHẦN ${m.roman}</span> <span class="q-part-title font-black text-[19px]">${E(m.title)}</span> <span class="q-part-desc text-[17px] font-bold italic opacity-90">${E(m.desc(0))}</span></p></div>`;
    };
    const grpBox = g => {
        if (!g) return '';
        const head = typeof GROUP_HEAD_TEXT !== 'undefined' ? GROUP_HEAD_TEXT : 'Sử dụng thông tin cho dưới đây để trả lời các câu số';
        const enG = Boolean(g.gm && window.CODE121EN);   // [CODE121]
        return `<div class="q-group-box q-title-text math-content mb-2 p-2.5 rounded-lg border-l-4 border-rose-500 bg-rose-50/70">${enG ? '' : `<div class="q-label-bold">${E(head)} ${g.from === g.to ? g.from : g.from + ' – ' + g.to}:</div>`}${g.info ? `<div class="q-stem-normal">${F(enG ? CODE121EN.fixRange(g.info, g.from, g.to) : g.info)}</div>` : ''}</div>`;
    };
    const estLen = x => { const r = String(x || ''); return /<img/i.test(r) ? 30 : (typeof estimateOptionTextLength === 'function' ? estimateOptionTextLength(r) : r.replace(/<[^>]*>/g, '').replace(/\\[a-zA-Z]+/g, 'x').replace(/[$\{\}\^_]/g, '').length); };
    const hasAns = a => !!(a && (a.sel || String(a.value || '').trim() || (a.values || []).some(v => v === true || v === false)));
    const solHtml = id => {
        const q = (window.LVSQ || {})[id]; if (!q) return '';
        let h = ''; try { h = buildSolutionInnerHtml(q); } catch (e) { }
        return h + `<button type="button" class="sol-toggle-btn open no-print" style="margin-top:10px" onclick="LVsol('${id}',false)">✖ ẨN HƯỚNG DẪN</button>`;
    };
    function card(q, a, k, h, once, ctx, opt) {
        opt = opt || {}; ctx = ctx || {};
        const t = q.type || qType(q), has = !!k && k.ok !== undefined, nmq = (ctx.nm || {})[q.id] || {}, num = nmq.num || '';
        const who = opt.teacher ? 'Học sinh' : 'Em';
        let frame = 'bg-slate-50/80 rounded-xl p-2.5 border border-slate-200 shadow-sm transition-all', stt = '', tfc = 0;
        if (has) {
            let st = k.ok ? 'ok' : 'bad';
            if (t === 'tf') { const key = k.tf || [], v = (a && a.values) || []; for (let j = 0; j < 4; j++) if ((v[j] === true || v[j] === false) && v[j] === !!key[j]) tfc++; st = tfc === 4 ? 'ok' : tfc === 0 ? 'bad' : 'part'; }
            frame = 'rounded-xl p-2.5 border-2 shadow-sm transition-all ' + ({ ok: 'bg-green-50/60 border-green-400', part: 'bg-amber-50/70 border-amber-400', bad: 'bg-red-50/60 border-red-400' })[st];
            const col = { ok: '#15803d', part: '#b45309', bad: '#dc2626' }[st];
            const tx = t === 'tf' ? (k.ok ? '✔ Đúng cả 4 ý' : (k.a ? '✘ Đúng ' + tfc + '/4 ý' : '✘ Chưa chọn')) : (k.ok ? '✔ Đúng' : (k.a ? '✘ Sai' : (t === 'sa' ? '✘ Chưa trả lời' : '✘ Chưa chọn')));
            stt = `<span class="q-label-bold lv-st" style="color:${col}">${tx} </span>`;
        }
        const grp = nmq.g && (nmq.g.first || ctx.single) ? grpBox(nmq.g) : '';
        let s = `<div class="${frame}" id="c_${q.id}" data-qid="${q.id}">${grp}<div class="q-title-text math-content text-[20px] font-normal text-slate-900 leading-snug mb-2"><strong class="q-label-bold font-bold">${q.gm ? 'Question' : 'Câu'} ${num}. </strong>${stt}<span class="q-stem-normal font-normal">${F(q.text)}</span></div>`;
        if (t === 'mc') {
            const opts = q.options || [], mxl = Math.max(0, ...opts.map(o => estLen(o.text)));
            const lay = mxl <= 14 ? 'q-options-one-row' : mxl <= 38 ? 'q-options-two-rows' : 'q-options-four-rows';
            const done = once && !k && a && a.sel;
            s += `<div class="${lay} grid gap-2">`;
            opts.forEach(o => {
                const me = a && a.sel === o.letter;
                let b = 'bg-white hover:bg-blue-50/60 text-slate-800 border-slate-300', g = 'q-opt-badge--def', lk = '';
                if (k) {
                    if (me) { if (o.letter === k.correct) { b = 'bg-green-600 text-yellow-300 border-green-700 shadow-md'; g = 'q-opt-badge--ok'; } else { b = 'bg-red-600 text-white border-red-700 shadow-md'; g = 'q-opt-badge--bad'; } }
                    else if (o.letter === k.correct) { b = 'bg-green-500 text-white border-green-700 shadow-md ring-2 ring-green-300'; g = 'q-opt-badge--key'; }
                } else if (me) { b = 'bg-blue-600 text-white border-blue-700 shadow-md'; g = 'q-opt-badge--sel'; }
                else if (done) lk = ' lv-lk';
                const can = h && !k && !done;
                s += `<button type="button" class="q-option-btn flex items-center gap-2 px-3 py-1.5 rounded-2xl border text-[20px] font-normal transition-all ${b} ${can ? 'active:scale-95 cursor-pointer' : 'cursor-default'}${lk}" ${can ? `onclick="${h}.pick('${q.id}','${o.letter}')"` : ''}><span class="q-opt-badge flex items-center justify-center shrink-0 ${g}">${E(o.letter)}</span><span class="q-option-text math-content font-normal break-words leading-snug text-left flex-1">${F(o.text)}</span></button>`;
            });
            s += '</div>';
            if (has && !k.a) s += `<div class="lv-note">${who} chưa chọn đáp án câu này</div>`;
        } else if (t === 'tf') {
            const key = (k && k.tf) || [];
            s += '<div class="q-tf-list">';
            (q.options || []).slice(0, 4).forEach((o, j) => {
                const v = a && a.values ? a.values[j] : null, set = v === true || v === false;
                s += `<div class="q-tf-row"><div class="q-tf-text math-content"><span class="q-tf-label">${'abcd'[j]})</span> <span>${F(o.text)}</span></div><div class="q-tf-ctrl">`;
                [true, false].forEach(bv => {
                    let c = 'q-tf-btn';
                    if (k) { if (v === bv) c += bv === !!key[j] ? ' ok' : ' bad'; else if (bv === !!key[j]) c += ' key'; }
                    else if (v === bv) c += ' sel';
                    const can = h && !k && !(once && set);
                    if (!can) c += ' locked';
                    if (!k && once && set && v !== bv) c += ' lv-lk';
                    s += `<button type="button" class="${c}" ${can ? `onclick="${h}.tf('${q.id}',${j},${bv})"` : ''}>${bv ? 'Đúng' : 'Sai'}</button>`;
                });
                s += '</div></div>';
            });
            s += '</div>';
        } else {
            const val = String((a && a.value) || ''), N = Math.max(4, String((k && k.sa) || '').trim().length), lk = !!(a && a.locked);
            const ro = !!k || !h || (once && lk), cls = has ? (k.ok ? ' ok' : ' bad') : '';
            s += `<div class="q-sa-row"><span class="q-sa-label">Trả lời:</span><div class="q-sa-boxes" data-len="${val.length}">`;
            for (let i = 0; i < N; i++) s += `<input type="text" class="q-sa-box${cls}" inputmode="${window.SAKB ? SAKB.mode() : 'decimal'}" enterkeyhint="done" maxlength="1" autocomplete="off" spellcheck="false" autocapitalize="off" autocorrect="off" aria-label="Ô ${i + 1}" value="${E(val[i] || '')}" ${ro ? 'readonly' : `oninput="LVB.inp(this,'${h}','${q.id}')" onkeydown="LVB.key(event,this,'${h}','${q.id}')" onfocus="LVB.foc1(this)" onpaste="LVB.paste(event,this,'${h}','${q.id}')"`}>`;
            s += '</div>';
            if (!ro && window.SAKB) s += SAKB.btnHtml();   // [CODE77]
            if (once && !k && h && !lk) s += `<button type="button" class="lv-ok-btn" onclick="${h}.saOk('${q.id}')">CHỐT</button>`;
            if (k && k.sa !== undefined && !(has && k.ok)) s += `<span class="q-sa-key">Đáp án đúng: ${E(k.sa)}</span>`;
            s += '</div>';
            if (has && !k.ok) s += `<div class="lv-note">${k.a ? who + ' trả lời sai' : who + ' chưa trả lời câu này'}</div>`;
        }
        /* Hướng dẫn giải: học sinh có nút XEM HƯỚNG DẪN / ẨN HƯỚNG DẪN; giáo viên xem bài làm (noSol) thì không hiện */
        if (k && !opt.noSol && (k.sol || (k.tfSol || []).some(Boolean))) {
            (window.LVSQ = window.LVSQ || {})[q.id] = Object.assign({}, q, { type: t, solution: k.sol, tfSol: k.tfSol, tfAnswers: k.tf, correct: k.correct, shortAnswer: k.sa });
            const op = !!(window.LVSO || {})[q.id];
            s += `<button type="button" class="sol-toggle-btn no-print${op ? ' open' : ''}" id="lvsb_${q.id}" onclick="LVsol('${q.id}')">${op ? '✖ ẨN HƯỚNG DẪN' : '💡 XEM HƯỚNG DẪN'}</button><div class="sol-panel no-print" id="lvs_${q.id}" style="display:${op ? 'block' : 'none'}">${op ? solHtml(q.id) : ''}</div>`;
        }
        return s + '</div>';
    }
    window.LVsol = function (id, force) {
        const d = document.getElementById('lvs_' + id), b = document.getElementById('lvsb_' + id); if (!d) return;
        const open = force !== undefined ? !!force : d.style.display === 'none';
        if (open) d.innerHTML = solHtml(id);
        d.style.display = open ? 'block' : 'none';
        if (b) { b.classList.toggle('open', open); b.textContent = open ? '✖ ẨN HƯỚNG DẪN' : '💡 XEM HƯỚNG DẪN'; }
        (window.LVSO = window.LVSO || {})[id] = open;
    };
    /* Ô trả lời ngắn 4 ô (giống làm bài về nhà): nhập từ trái sang phải, Backspace lùi ô, dán nhiều ký tự */
    window.LVB = {
        bx: w => [...w.querySelectorAll('.q-sa-box')],
        val: w => { const bs = window.LVB.bx(w); return bs.map(b => b.value).join('').replace(/\s+/g, '').slice(0, bs.length); },
        put: (w, v) => window.LVB.bx(w).forEach((b, k) => { b.value = v[k] || ''; }),
        idx: el => window.LVB.bx(el.parentNode).indexOf(el),
        foc: (w, k) => { const bs = window.LVB.bx(w), b = bs[Math.max(0, Math.min(bs.length - 1, k))]; if (!b) return; try { b.focus({ preventScroll: true }); } catch (e) { b.focus(); } try { b.select(); } catch (e) { } },
        foc1: el => { const w = el.parentNode, len = window.LVB.val(w).length, i = window.LVB.idx(el); if (i > len) window.LVB.foc(w, len); else { try { el.select(); } catch (e) { } } },
        set: (w, v, h, id) => { window.LVB.put(w, v); w.setAttribute('data-len', v.length); try { window[h].sa(id, v); } catch (e) { } },
        inp: (el, h, id) => { const L = window.LVB, w = el.parentNode, prev = Number(w.getAttribute('data-len') || 0), v = L.val(w); L.set(w, v, h, id); L.foc(w, v.length < prev ? Math.min(L.idx(el), v.length) : v.length); },
        key: (e, el, h, id) => {
            const L = window.LVB, w = el.parentNode, i = L.idx(el);
            if (e.key === 'Enter') { e.preventDefault(); el.blur(); return; }
            if (e.key === 'Backspace' && !el.value && i > 0) { e.preventDefault(); const v = L.val(w); L.set(w, v.slice(0, i - 1) + v.slice(i), h, id); L.foc(w, i - 1); }
        },
        paste: (e, el, h, id) => {
            e.preventDefault(); const L = window.LVB, w = el.parentNode, i = L.idx(el), N = L.bx(w).length;
            const txt = ((e.clipboardData || window.clipboardData).getData('text') || '').replace(/\s+/g, ''), v = L.val(w), nv = (v.slice(0, Math.min(i, v.length)) + txt).slice(0, N);
            L.set(w, nv, h, id); L.foc(w, nv.length);
        }
    };
    function listHtml(qs, ans, keys, h, once, opt) {
        const ctx = { nm: numMap(qs) }; let last = '', s = '';
        qs.forEach(q => {
            const t = q.type || qType(q);
            if (t !== last) { s += partHd(t); last = t; }
            s += card(q, ans && ans[q.id], keys && keys[q.id], h, once, ctx, opt);
        });
        return `<div class="qc-live">${s}</div>`;
    }
    /* [CODE141] Dùng chung giao diện làm bài cho NGÂN HÀNG ĐỀ > Xem câu hỏi */
    window.BKView = { card: card, partHd: partHd, numMap: numMap };

    /* ======================= GIÁO VIÊN ======================= */
    const LV = window.LV = { st: {} };
    function prep(topic) {
        const qs = normalizeQuestionLetters(JSON.parse(JSON.stringify(topic.questions)));
        let per; try { per = computePartPer(qs, topic.scoring || null, topic.subject); } catch (e) { per = { mc: .25, tf: 1, sa: .5 }; }
        return { qs, per, sc: topic.scoring || null, nm: numMap(qs) };
    }
    const mx = q => { try { return maxPointsFor(q, LV.per, LV.sc) || 0; } catch (e) { return 1; } };
    function grade(q, ua) {
        const t = qType(q); if (!ua) return { e: 0, ok: false, a: false };
        if (t === 'tf') {
            const v = ua.values || [], key = q.tfAnswers || []; let k = 0, a = false, e = 0;
            const y = tfYPointsOf(q, LV.sc);
            for (let j = 0; j < 4; j++) if (v[j] === true || v[j] === false) { a = true; if (v[j] === !!key[j]) { k++; if (y) e += y[j]; } }
            if (!y) { const tr = tfTiersOf(LV.sc); e = tr ? (k ? tr[k - 1] : 0) : mx(q) * TF_LADDER[k]; }
            return { e, ok: k === 4, a };
        }
        if (t === 'sa') { const a = String(ua.value || '').trim() !== ''; const ok = a && shortAnswerMatches(ua.value, q.shortAnswer); return { e: ok ? mx(q) : 0, ok, a }; }
        const a = !!ua.sel, ok = a && ua.sel === q.correct; return { e: ok ? mx(q) : 0, ok, a };
    }
    function calc(s) {
        let e = 0, m = 0, ok = 0, wr = 0, bl = 0;
        LV.qs.forEach(q => { const g = grade(q, s.answers[q.id]); m += mx(q); e += g.e; if (g.ok) ok++; else if (g.a) wr++; else bl++; });
        s.sc = m ? Math.round(e / m * 1000) / 100 : 0; s.ok = ok; s.wr = wr; s.bl = bl;
    }
    const all = () => Object.values(LV.st);
    const tkey = s => LV.mode === 'sync' ? (s.tc || 0) : (s.at || 0);
    const better = (x, s) => x.sc > s.sc || (x.sc === s.sc && tkey(x) < tkey(s));
    const rankOf = s => 1 + all().filter(x => better(x, s)).length;
    LV.upTc = function (s) { const q = LV.qs[LV.qi]; (s.okq = s.okq || {})[q.id] = grade(q, s.answers[q.id]).ok; s.tc = LV.qs.reduce((a, x) => a + (s.okq[x.id] ? ((s.qrt || {})[x.id] || 0) : 0), 0); };
    const send = (s, m) => { try { if (s.conn && s.conn.open) s.conn.send(m); } catch (e) { } };
    const bcast = m => all().forEach(s => send(s, m));

    LV.open = function (tid) {
        const topic = savedTopics.find(t => t.id === tid); if (!topic) return;
        if (typeof Peer === 'undefined' && !(window.CloudSync && CloudSync.liveCfg && CloudSync.liveCfg())) { showModal('Chưa tải được thư viện', 'Cần có Internet để dùng Chơi trực tiếp (thư viện PeerJS chưa tải được). Bấm ĐỒNG BỘ (Firebase) để dùng kênh không cần PeerJS.', 'info'); return; }
        let sv = {}; try { sv = JSON.parse(localStorage.getItem('lvTeamCfg') || '{}') || {}; } catch (e) { }
        Object.assign(LV, prep(topic), { topic, mode: 'pace', tabSel: 'pace', team: false, teams: [], nT: Math.max(2, Math.min(12, Number(sv.nT) || 4)), tn: Array.isArray(sv.tn) ? sv.tn.slice(0, 12) : [], phase: 'setup', st: {}, qi: 0, rev: false, desc: true, view: 'podium' });
        LV.draw();
    };
    LV.tab = m => { if (LV.phase === 'setup') { LV.tabSel = m; LV.mode = m === 'pace' ? 'pace' : 'sync'; LV.team = m === 'team'; LV.draw(); } };
    LV.close = function () {
        if (LV.phase !== 'setup' && LV.phase !== 'done' && !confirm('Đóng sẽ ngắt buổi chơi đang diễn ra. Đóng?')) return;
        clearInterval(LV.tm); (LV.pt || []).forEach(clearTimeout); try { LV.peer && LV.peer.destroy(); } catch (e) { } LV.peer = null; LV.phase = 'setup';
        ['lv-t', 'lv-d', 'lv-qb'].forEach(i => { const d = $(i); if (d) d.remove(); });
    };
    LV.draw = function () {
        const head = `<div class="lv-hd"><div style="font-size:22px;font-weight:900">🎮 CHƠI TRỰC TIẾP — ${E(LV.topic.subtitle)}</div><button class="lv-b" style="background:#ffffff33" onclick="LV.close()">✕</button></div>`;
        let body = '';
        if (LV.phase === 'setup') {
            const p = LV.mode === 'pace';
            const sel = LV.tabSel;
            body = `<div style="display:flex;gap:10px;flex-wrap:wrap;padding:4px 2px 0"><button class="lv-tab ${sel === 'pace' ? 'on' : ''}" onclick="LV.tab('pace')">Học sinh chủ động</button><button class="lv-tab ${sel === 'sync' ? 'on' : ''}" onclick="LV.tab('sync')">Giáo viên điều khiển</button><button class="lv-tab ${sel === 'team' ? 'on' : ''}" onclick="LV.tab('team')">👥 Chơi theo đội/nhóm</button></div>
            <div class="lv-c"><p style="margin-bottom:10px;font-weight:600;color:#475569;text-align:justify;text-justify:inter-word">${p ? 'Mỗi học sinh làm bài theo tốc độ riêng, nộp bài khi xong hoặc hết giờ. ⚠ Mỗi câu học sinh chỉ được chọn đáp án 1 lần, không được chọn lại.' : (LV.team ? 'Chia lớp thành các đội/nhóm. Giáo viên điều khiển: cả lớp cùng làm từng câu, giáo viên hiện đáp án sau mỗi câu. Mỗi đội có một mã QR riêng, học sinh quét mã QR của đội mình để vào chơi. Đội xếp hạng theo ĐIỂM TRUNG BÌNH của các thành viên. ⚠ Mỗi câu học sinh chỉ được chọn đáp án 1 lần duy nhất, không được đổi.' : 'Cả lớp cùng làm từng câu theo thứ tự; giáo viên hiện đáp án và thống kê sau mỗi câu. ⚠ Mỗi câu học sinh chỉ được chọn đáp án 1 lần duy nhất, không được đổi.')}</p>
            ${p ? `<label style="font-weight:900">⏱ Giới hạn thời gian làm bài (phút):</label><input id="lv-min" type="number" min="1" value="${Number(LV.topic.timeLimit) || 10}" class="lv-i" style="width:120px;margin:6px 0 12px;display:block">
            <label style="font-weight:900;display:block;margin-bottom:12px"><input id="lv-shuf" type="checkbox" checked> 🔀 Đảo thứ tự câu hỏi (mỗi học sinh một thứ tự khác nhau)</label>`
                    : `<label style="font-weight:900">⏱ Thời gian mỗi câu (giây, 0 = không giới hạn):</label><input id="lv-sec" type="number" min="0" value="60" class="lv-i" style="width:120px;margin:6px 0 12px;display:block">`}
            ${LV.team ? LV.teamCfgHtml() : ''}
            <label style="font-weight:900;display:block;margin:6px 0"><input id="lv-g" type="checkbox" checked> 🛡 Bật chế độ giám sát màn hình (chống gian lận)</label>
            <div style="margin:0 0 14px 24px;font-weight:600;color:#475569;text-align:justify">${p ? 'Tự động nộp bài sau <input id="lv-gm" type="number" min="0" value="3" class="lv-i" style="width:70px;display:inline-block;padding:4px 8px"> lần rời khỏi màn hình (0 = chỉ cảnh báo).' : 'Ghi nhận và cảnh báo học sinh rời khỏi màn hình.'} Giám sát: chuyển tab/thu nhỏ trình duyệt, sao chép - dán, chuột phải, phím tắt, in/chụp màn hình, thoát toàn màn hình.</div>
            <button class="lv-b g" style="font-size:18px" onclick="LV.go()">▶ VÀO CHƠI</button></div>`;
        } else if (LV.phase === 'lobby' && LV.team) {
            body = LV.lobbyTeamHtml();
        } else if (LV.phase === 'lobby') {
            const url = LV.link();
            body = `<div class="lv-c" style="text-align:center"><div style="font-weight:900;font-size:20px">Học sinh quét mã QR hoặc mở liên kết để vào chơi</div><div style="width:260px;margin:10px auto">${qrSvg(url)}</div>
            <input class="lv-i" readonly value="${E(url)}" onclick="this.select()"><div style="margin-top:6px"><button class="lv-b s" onclick="navigator.clipboard&&navigator.clipboard.writeText('${E(url)}')">📋 Sao chép liên kết</button></div>
            ${location.protocol === 'file:' ? '<p style="color:#dc2626;font-weight:900">⚠ Cần mở app từ địa chỉ web (GitHub Pages) thì học sinh mới vào được.</p>' : ''}</div>
            <div class="lv-c"><div style="font-weight:900;font-size:18px">👥 Học sinh đã vào: <span id="lv-n">0</span></div><div id="lv-ls" style="display:flex;flex-wrap:wrap;gap:6px;margin:8px 0"></div><button class="lv-b g" style="font-size:18px" onclick="LV.start()">▶ BẮT ĐẦU</button></div>`;
        } else if (LV.phase === 'run') {
            body = '<div id="lv-run"></div>';
        } else body = '<div id="lv-res"></div>';
        layer('lv-t', head + `<div class="lv-w" ${LV.phase === 'done' ? 'style="max-width:none"' : (LV.phase === 'lobby' && LV.team ? 'style="max-width:1300px"' : '')}>${body}</div>`);
        if (LV.phase === 'lobby') LV.upd();
        if (LV.phase === 'run') LV.upd();
        if (LV.phase === 'done') { if (LV.view === 'table') LV.result(); else LV.podium(); }
    };
    LV.go = function () {
        LV.min = Math.max(1, Number(($('lv-min') || {}).value) || 10);
        LV.shuf = $('lv-shuf') ? $('lv-shuf').checked : false;
        LV.sec = Math.max(0, Number(($('lv-sec') || {}).value) || 0);
        LV.guard = { on: !!($('lv-g') && $('lv-g').checked), max: Math.max(0, Number(($('lv-gm') || {}).value) || 0) };
        if (LV.peer) return;
        if (LV.team) {
            const seen = {};
            LV.teams = Array.from({ length: LV.nT }, (_, i) => { let nm = (String(LV.tn[i] || '').trim() || ('Đội ' + (i + 1))).slice(0, 30); if (seen[nm.toLowerCase()]) nm += ' (' + (i + 1) + ')'; seen[nm.toLowerCase()] = 1; return { name: nm }; });
            try { localStorage.setItem('lvTeamCfg', JSON.stringify({ nT: LV.nT, tn: LV.tn })); } catch (e) { }
        }
        LV.audio(); /* mở khóa âm thanh bằng thao tác bấm của giáo viên để chuông kêu được */
        LV.pid = 'hs' + rid(8);
        let fbc = null; try { fbc = !LV._fbFailed && window.CloudSync && CloudSync.liveCfg ? CloudSync.liveCfg() : null; } catch (e) { }
        LV.fb = fbc;   // [CODE170] đã ĐỒNG BỘ Firebase -> dùng kênh Firebase (vào được mọi mạng); chưa có -> PeerJS
        if (!fbc && typeof Peer === 'undefined') { showModal('Chưa tải được thư viện', 'Cần có Internet để dùng Chơi trực tiếp (thư viện PeerJS chưa tải được). Bấm ĐỒNG BỘ (Firebase) để dùng kênh không cần PeerJS.', 'info'); return; }
        const pr = LV.peer = fbc ? new FbPeer(LV.pid, fbc) : new Peer(LV.pid, PEER_OPTS);
        const openTo = setTimeout(() => { if (LV.peer === pr && LV.phase === 'setup') try { pr.emit('error', { type: 'timeout' }); } catch (e) { } }, 12000);
        pr.on('open', () => { clearTimeout(openTo); LV.phase = 'lobby'; LV.draw(); });
        pr.on('connection', c => { c.on('data', m => LV.msg(c, m)); c.on('close', () => { all().forEach(s => { if (s.conn === c) { s.on = false; LV.upd(); } }); }); });
        pr.on('disconnected', () => { try { if (!pr.destroyed) pr.reconnect(); } catch (e) { } });
        pr.on('error', e => {
            if (LV.phase === 'setup') { try { pr.destroy(); } catch (x) { } if (LV.peer === pr) LV.peer = null; if (LV.fb && !LV._fbFailed && typeof Peer !== 'undefined') { LV._fbFailed = true; LV.go(); return; } showModal('Lỗi kết nối', 'Không tạo được phòng chơi: ' + (e.type || e) + '. Hãy bấm VÀO CHƠI lần nữa.', 'info'); }
        });
    };
    LV.audio = function () {
        try {
            const ac = LV.ac || (LV.ac = new (window.AudioContext || window.webkitAudioContext)());
            if (ac.state === 'suspended' && ac.resume) ac.resume();
            return ac;
        } catch (e) { return null; }
    };
    LV.bell = function (name) {
        try {
            const ac = LV.audio();
            if (ac) {
                [0, 0.5].forEach(off => {
                    [880, 1760, 2640].forEach((f, i) => {
                        const o = ac.createOscillator(), g = ac.createGain(), t0 = ac.currentTime + off;
                        o.type = 'sine'; o.frequency.value = f;
                        g.gain.setValueAtTime(.0001, t0);
                        g.gain.exponentialRampToValueAtTime(.35 / (i + 1), t0 + .01);
                        g.gain.exponentialRampToValueAtTime(.0001, t0 + 1.3);
                        o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + 1.4);
                    });
                });
            }
        } catch (e) { }
        try { if (navigator.vibrate) navigator.vibrate([120, 60, 120]); } catch (e) { }
        try {
            const d = document.createElement('div');
            d.style.cssText = 'position:fixed;top:78px;right:16px;z-index:9600;background:#059669;color:#fff;padding:10px 18px;border-radius:14px;font-weight:900;box-shadow:0 8px 24px #0004;max-width:80%;word-break:break-word';
            d.textContent = '🔔 ' + name + ' vừa vào phòng';
            document.body.appendChild(d);
            setTimeout(() => d.remove(), 3500);
        } catch (e) { }
    };
    LV.msg = function (c, m) {
        if (!m) return;
        if (m.t === 'join') {
            let s = LV.st[m.cid];
            const tv = LV.team && Number.isInteger(m.team) && m.team >= 0 && m.team < LV.teams.length ? m.team : -1;
            if (!s) {
                if (LV.phase !== 'lobby') { try { c.send({ t: 'late' }); } catch (e) { } return; }
                if (LV.team && tv < 0) { try { c.send({ t: 'pick', teams: LV.teams.map(t => t.name), title: LV.topic.subtitle }); } catch (e) { } return; }
                s = LV.st[m.cid] = { cid: m.cid, name: String(m.name || 'Học sinh').slice(0, 40), team: tv, answers: {}, done: false, sc: 0, ok: 0, wr: 0, bl: LV.qs.length, qrt: {}, okq: {}, tc: 0 }; LV.bell(s.name + (LV.team ? ' (' + LV.teams[tv].name + ')' : ''));
            } else if (LV.team && tv >= 0 && LV.phase === 'lobby') s.team = tv;
            s.conn = c; s.on = true; send(s, { t: 'hi', mode: LV.mode, title: LV.topic.subtitle, guard: LV.guard, ver: VER, team: LV.team ? s.team : undefined, tname: LV.team ? LV.teams[s.team].name : '' });
            if (LV.phase === 'run') LV.resend(s); else if (LV.phase === 'done') LV.sendRes(s, true);
            LV.upd(); return;
        }
        const s = Object.values(LV.st).find(x => x.conn === c); if (!s || LV.phase !== 'run') return;
        if (m.t === 'ans' && LV.mode === 'pace' && !s.done) { s.answers = m.answers || {}; calc(s); LV.upd(); }
        if (m.t === 'ans1' && LV.mode === 'sync' && !LV.rev && String(m.qid) === String(LV.qs[LV.qi].id)) {
            const q = LV.qs[LV.qi], t = qType(q), old = s.answers[q.id], ua = m.ua || {}; let nu = ua;
            if (t === 'mc') { if (old && old.sel) return; }
            else if (t === 'tf') { const ov = (old && old.values) || [], nv = (ua.values || []).slice(); for (let j = 0; j < 4; j++) if (ov[j] === true || ov[j] === false) nv[j] = ov[j]; nu = { values: nv }; }
            else if (old && old.locked) return;
            s.answers[q.id] = nu; (s.qrt = s.qrt || {})[q.id] = Date.now() - LV.qStart; LV.upd();
        }
        if (m.t === 'vio') { s.vio = (s.vio || 0) + 1; (s.vlog = s.vlog || []).push({ k: String(m.k).slice(0, 60), at: Date.now() - LV.t0 }); LV.upd(); }
        if (m.t === 'vback') { const l = (s.vlog || []).slice(-1)[0]; if (l) l.sec = Number(m.sec) || 0; LV.upd(); }
        if (m.t === 'submit' && LV.mode === 'pace' && !s.done) { s.answers = m.answers || {}; s.done = true; s.at = Date.now() - LV.t0; calc(s); LV.sendRes(s); LV.upd(); if (all().every(x => x.done)) LV.finish(); }
    };
    LV.resend = function (s) {
        if (LV.mode === 'pace') { if (s.done) LV.sendRes(s); else send(s, { t: 'start', mode: 'pace', qs: LV.qs.map(pub), shuf: LV.shuf, remain: LV.endAt - Date.now(), answers: s.answers, guard: LV.guard, vio: s.vio || 0 }); }
        else { const q = LV.qs[LV.qi]; send(s, { t: 'q', q: pub(q), i: LV.qi, n: LV.qs.length, remain: LV.qEnd ? LV.qEnd - Date.now() : 0, guard: LV.guard, vio: s.vio || 0, a: s.answers[q.id] || null }); if (LV.rev) LV.sendRev(s); }
    };
    LV.keysFor = function (s) {
        const keys = {}; LV.qs.forEach(q => { const g = grade(q, s.answers[q.id]); keys[q.id] = Object.assign(keyOf(q), { ok: g.ok, a: g.a }); });
        return keys;
    };
    LV.sendRes = function (s, fin) {
        const m = { t: 'end', sc: s.sc, ok: s.ok, wr: s.wr, bl: s.bl, keys: LV.keysFor(s), answers: s.answers };
        if (LV.mode === 'sync') m.qs = LV.qs.map(pub);
        if (fin) { if (LV.team) Object.assign(m, LV.tinfo(s)); else { m.rk = rankOf(s); m.nn = all().length; } }
        send(s, m);
    };
    /* [CODE54] ĐẾM NGƯỢC 3-2-1 KÈM ÂM THANH (dùng chung cho màn hình giáo viên & học sinh) */
    window.lvCountdown = function (n, done) {
        const old = document.getElementById('lv-cd'); if (old) { try { old._stop(); } catch (e) { } }
        const ov = document.createElement('div'); ov.id = 'lv-cd';
        ov.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 40%,#7c3aed 0%,#4c1d95 60%,#1e1b4b 100%);color:#fff;font-family:Roboto,Arial,sans-serif;text-align:center;user-select:none';
        ov.innerHTML = '<div style="font-size:clamp(18px,3.2vw,30px);font-weight:900;letter-spacing:2px;opacity:.9;margin-bottom:10px">CHUẨN BỊ — BÀI LÀM BẮT ĐẦU SAU</div><div id="lv-cd-n" style="font-size:clamp(150px,34vw,360px);font-weight:900;line-height:1;text-shadow:0 10px 40px #0008"></div><div id="lv-cd-bar" style="width:min(70vw,520px);height:12px;border-radius:99px;background:#ffffff33;margin-top:26px;overflow:hidden"><i style="display:block;height:100%;width:100%;background:#fde047;border-radius:99px;transition:width 1s linear"></i></div>';
        document.body.appendChild(ov);
        const tone = (f, d, v, type) => {
            try {
                const ac = LV.audio(); if (!ac) return;
                const o = ac.createOscillator(), g = ac.createGain(), t0 = ac.currentTime;
                o.type = type || 'sine'; o.frequency.value = f;
                g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(v || .4, t0 + .02); g.gain.exponentialRampToValueAtTime(.0001, t0 + d);
                o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + d + .05);
            } catch (e) { }
        };
        let k = n, fin = false, tm = null;
        const num = ov.querySelector('#lv-cd-n'), bar = ov.querySelector('#lv-cd-bar i');
        const stop = () => { fin = true; clearTimeout(tm); ov.remove(); };
        ov._stop = stop;
        const tick = () => {
            if (fin) return;
            if (k <= 0) {
                tone(1318, .5, .5, 'triangle'); tone(1760, .6, .35, 'sine');
                num.textContent = 'BẮT ĐẦU!'; num.style.fontSize = 'clamp(60px,14vw,150px)';
                tm = setTimeout(() => { stop(); try { done && done(); } catch (e) { console.error(e); } }, 450);
                return;
            }
            num.textContent = k; num.style.transform = 'scale(1.18)'; num.style.transition = 'none';
            requestAnimationFrame(() => requestAnimationFrame(() => { num.style.transition = 'transform .6s ease-out'; num.style.transform = 'scale(1)'; }));
            bar.style.transition = 'none'; bar.style.width = (k / n * 100) + '%';
            requestAnimationFrame(() => requestAnimationFrame(() => { bar.style.transition = 'width 1s linear'; bar.style.width = ((k - 1) / n * 100) + '%'; }));
            tone(880, .22, .45, 'square');
            k--; tm = setTimeout(tick, 1000);
        };
        tick();
    };
    LV.start = function () {
        if (LV.cding) return;
        if (!all().length) { showModal('Chưa có học sinh', 'Hãy đợi ít nhất một học sinh vào phòng.', 'info'); return; }
        if (LV.team) { const em = LV.teams.filter((t, i) => !all().some(x => x.team === i)); if (em.length && !confirm('Chưa có học sinh ở: ' + em.map(t => t.name).join(', ') + '.\nVẫn bắt đầu?')) return; }
        LV.cding = true; LV.audio();
        bcast({ t: 'cd', n: 3 });
        window.lvCountdown(3, () => { LV.cding = false; LV.begin(); });
    };
    LV.begin = function () {
        LV.phase = 'run'; LV.t0 = Date.now(); LV.qi = 0;
        if (LV.mode === 'pace') {
            LV.endAt = LV.t0 + LV.min * 60000;
            bcast({ t: 'start', mode: 'pace', qs: LV.qs.map(pub), shuf: LV.shuf, remain: LV.min * 60000, answers: {}, guard: LV.guard });
            LV.tm = setInterval(() => { if (Date.now() >= LV.endAt) LV.finish(); else LV.upd(); }, 1000);
        } else LV.showQ();
        LV.draw();
    };
    LV.showQ = function () {
        LV.rev = false; LV.qStart = Date.now(); LV.qEnd = LV.sec ? Date.now() + LV.sec * 1000 : 0; clearInterval(LV.tm);
        bcast({ t: 'q', q: pub(LV.qs[LV.qi]), i: LV.qi, n: LV.qs.length, remain: LV.sec * 1000, guard: LV.guard });
        LV.tm = setInterval(() => { if (LV.qEnd && Date.now() >= LV.qEnd + 1200 && !LV.rev) LV.reveal(); else LV.upd(); }, 1000);
        if (LV.phase === 'run') LV.upd();
    };
    LV.sendRev = function (s) {
        const q = LV.qs[LV.qi], g = grade(q, s.answers[q.id]); LV.upTc(s); calc(s);
        send(s, Object.assign(LV.team ? LV.tinfo(s) : {}, { t: 'rev', qid: q.id, key: Object.assign(keyOf(q), { sol: '', tfSol: [] }), ok: g.ok, e: Math.round(g.e * 1000) / 1000, sc: s.sc, rk: LV.team ? 0 : rankOf(s), nn: all().length }));
    };
    LV.reveal = function () { if (LV.rev) return; LV.rev = true; clearInterval(LV.tm); all().forEach(s => { LV.upTc(s); calc(s); }); all().forEach(s => LV.sendRev(s)); LV.upd(); };
    LV.next = function () { if (LV.qi < LV.qs.length - 1) { LV.qi++; LV.showQ(); } else LV.finish(); };
    LV.finish = function () {
        if (LV.phase === 'done') return; clearInterval(LV.tm);
        all().forEach(s => { if (!s.done) { s.done = true; s.at = Date.now() - LV.t0; } calc(s); });
        all().forEach(s => LV.sendRes(s, true));
        LV.phase = 'done'; LV.view = 'podium'; LV.desc = true; LV.draw();
    };

    /* ======================= [CODE51] CHƠI THEO ĐỘI/NHÓM ======================= */
    LV.tstat = () => LV.teams.map((t, i) => {
        const m = all().filter(x => x.team === i), n = m.length;
        const avg = n ? Math.round(m.reduce((a, x) => a + x.sc, 0) / n * 100) / 100 : 0;
        return { i, name: t.name, n, avg, m, tm: n ? m.reduce((a, x) => a + tkey(x), 0) / n : Infinity };
    });
    /* Điểm trung bình thành viên: cao → thấp; bằng điểm: thời gian trả lời đúng trung bình ngắn hơn xếp trước; đội chưa có thành viên xếp cuối */
    LV.tcmp = (a, b) => ((b.n > 0) - (a.n > 0)) || (b.avg - a.avg) || (a.tm === b.tm ? 0 : a.tm < b.tm ? -1 : 1);
    LV.trank = () => LV.tstat().sort((a, b) => LV.tcmp(a, b) || a.i - b.i);
    LV.trkOf = i => { const st = LV.tstat(), me = st.find(x => x.i === i); return me ? 1 + st.filter(x => LV.tcmp(x, me) < 0).length : 0; };
    LV.tinfo = s => { const me = LV.tstat().find(x => x.i === s.team) || { name: '', avg: 0 }; return { tn: me.name, tavg: me.avg, trk: LV.trkOf(s.team), tnn: LV.teams.length }; };
    LV.namesHtml = () => Array.from({ length: LV.nT }, (_, i) => `<div style="display:flex;align-items:center;gap:8px"><span style="width:14px;height:34px;border-radius:6px;flex-shrink:0;background:${TC[i % TC.length]}"></span><input class="lv-i" maxlength="30" value="${E(LV.tn[i] || '')}" placeholder="Đội ${i + 1}" oninput="LV.tn[${i}]=this.value"></div>`).join('');
    LV.teamCfgHtml = () => `<div style="margin:6px 0 14px;padding:12px;border-radius:14px;background:#faf5ff;border:2px solid #e9d5ff"><label style="font-weight:900">👥 Số đội/nhóm (2 – 12):</label><div style="display:flex;align-items:center;gap:8px;margin:6px 0 10px"><button type="button" class="lv-b s" onclick="LV.setNT(LV.nT-1)">−</button><input id="lv-nt" type="number" min="2" max="12" value="${LV.nT}" class="lv-i" style="width:90px;text-align:center" onchange="LV.setNT(this.value)"><button type="button" class="lv-b s" onclick="LV.setNT(LV.nT+1)">+</button></div><div style="font-weight:900;margin-bottom:6px">✏ Đặt tên đội/nhóm <span style="font-weight:600;color:#64748b">(để trống = “Đội 1”, “Đội 2”…)</span>:</div><div id="lv-tnames" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:8px">${LV.namesHtml()}</div></div>`;
    LV.setNT = v => { LV.nT = Math.max(2, Math.min(12, parseInt(v) || 4)); const i = $('lv-nt'); if (i) i.value = LV.nT; const d = $('lv-tnames'); if (d) d.innerHTML = LV.namesHtml(); };
    LV.link = () => location.origin + location.pathname + '?live=' + LV.pid + (LV.fb ? '&tr=fb&cl=' + encodeURIComponent(CloudSync.liveToken()) : '') + '&v=' + VER;
    LV.url = i => location.origin + location.pathname + '?live=' + LV.pid + (LV.fb ? '&tr=fb&cl=' + encodeURIComponent(CloudSync.liveToken()) : '') + '&team=' + i + '&tn=' + encodeURIComponent(LV.teams[i].name) + '&v=' + VER;
    LV.lobbyTeamHtml = () => {
        const cards = LV.teams.map((t, i) => { const c = TC[i % TC.length]; return `<div class="lv-tq" style="border-color:${c}"><h4 style="background:${c}">👥 ${E(t.name)}</h4><div class="lv-qb" onclick="LV.qrBig(${i})" title="Bấm để phóng to">${qrScal(LV.url(i))}</div><div style="padding:0 8px 10px"><button class="lv-b" style="background:${c};width:100%;margin-bottom:6px" onclick="LV.qrBig(${i})">🔍 PHÓNG TO MÃ QR</button><div style="font-weight:900">Đã vào: <span id="lv-tn${i}">0</span> học sinh</div><div id="lv-tl${i}" class="lv-mem"></div><button class="lv-b s" style="padding:4px 10px;margin-top:6px;font-size:13px" onclick="LV.cp(${i})">📋 Sao chép liên kết</button></div></div>`; }).join('');
        return `<div class="lv-c" style="text-align:center"><div style="font-weight:900;font-size:22px">Học sinh quét mã QR của ĐỘI MÌNH để vào chơi</div><div style="font-weight:600;color:#475569;margin-top:2px">Bấm vào mã QR (hoặc nút “Phóng to”) để chiếu lên màn hình lớn cho cả lớp quét.</div>${location.protocol === 'file:' ? '<p style="color:#dc2626;font-weight:900">⚠ Cần mở app từ địa chỉ web (GitHub Pages) thì học sinh mới vào được.</p>' : ''}<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;margin-top:12px;align-items:start">${cards}</div></div>
        <div class="lv-c" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px"><div style="font-weight:900;font-size:18px">👥 Tổng số học sinh đã vào: <span id="lv-n">0</span></div><button class="lv-b g" style="font-size:18px" onclick="LV.start()">▶ BẮT ĐẦU</button></div>`;
    };
    LV.flash = t => { const d = document.createElement('div'); d.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:9700;background:#059669;color:#fff;padding:10px 18px;border-radius:14px;font-weight:900;box-shadow:0 8px 24px #0004'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 2200); };
    LV.cp = i => { const u = LV.url(i); try { navigator.clipboard.writeText(u).then(() => LV.flash('✅ Đã sao chép liên kết ' + LV.teams[i].name)); } catch (e) { prompt('Sao chép liên kết:', u); } };
    /* Phóng to mã QR của một đội (chiếu lên màn hình lớn); ◀ ▶ chuyển đội, Esc / bấm nền để đóng */
    LV.qrBig = function (i) {
        const n = LV.teams.length; i = (i + n) % n; const c = TC[i % TC.length], old = $('lv-qb'); if (old) old.remove();
        const d = document.createElement('div'); d.id = 'lv-qb'; d.setAttribute('data-i', i);
        d.style.cssText = 'position:fixed;inset:0;z-index:9400;background:rgba(15,23,42,.94);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px;gap:12px;cursor:zoom-out';
        d.onclick = () => d.remove();
        d.innerHTML = `<div style="color:#fff;font-weight:900;font-size:clamp(24px,4.5vw,48px);text-align:center;word-break:break-word"><span style="display:inline-block;width:.6em;height:.6em;border-radius:50%;background:${c};margin-right:.3em"></span>${E(LV.teams[i].name)}</div><div style="background:#fff;padding:14px;border-radius:22px;border:10px solid ${c};width:min(92vw,calc(100vh - 230px),820px);cursor:default" onclick="event.stopPropagation()">${qrScal(LV.url(i))}</div><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center" onclick="event.stopPropagation()"><button class="lv-b s" onclick="LV.qrBig(${i - 1})">◀ Đội trước</button><button class="lv-b r" onclick="document.getElementById('lv-qb').remove()">✕ ĐÓNG</button><button class="lv-b s" onclick="LV.qrBig(${i + 1})">Đội sau ▶</button></div>`;
        document.body.appendChild(d);
    };
    document.addEventListener('keydown', e => {
        const d = $('lv-qb'); if (!d) return; const i = Number(d.getAttribute('data-i')) || 0;
        if (e.key === 'Escape') d.remove(); else if (e.key === 'ArrowRight') LV.qrBig(i + 1); else if (e.key === 'ArrowLeft') LV.qrBig(i - 1);
    });
    const teamRankHtml = () => {
        const r = LV.trank(), q = LV.qs[LV.qi], med = ['🥇', '🥈', '🥉'];
        const rows = r.map(t => {
            const rk = t.n ? LV.trkOf(t.i) : '—', c = TC[t.i % TC.length];
            const ansd = !LV.rev && q ? t.m.filter(x => hasAns(x.answers[q.id])).length : null;
            const mem = t.m.slice().sort((a, b) => b.sc - a.sc).map(x => `${E(x.name)} <b>${fm(x.sc)}</b>`).join(' • ');
            return `<div style="padding:8px 12px;border-radius:12px;background:${c}1f;border-left:8px solid ${c};margin:6px 0"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;font-weight:900;font-size:18px"><span>${t.n && rk <= 3 ? med[rk - 1] : ''} Hạng ${rk} — ${E(t.name)} <small style="font-weight:700;color:#475569">(${t.n} học sinh${ansd !== null ? ' • ✍ ' + ansd + '/' + t.n : ''})</small></span><span style="font-size:24px">${t.n ? fm(t.avg) : '—'}</span></div><div style="height:8px;border-radius:6px;background:#e2e8f0;margin:6px 0"><div style="height:8px;border-radius:6px;background:${c};width:${Math.min(100, t.avg * 10)}%"></div></div><div style="font-size:13px;color:#475569">${mem || '<i>Chưa có thành viên</i>'}</div></div>`;
        }).join('');
        return `<div class="lv-c"><b style="color:#7c3aed;font-size:19px">🏆 Thứ tự các đội/nhóm</b> <small style="color:#475569">(điểm trung bình của các thành viên, cao → thấp; bằng điểm: trả lời đúng nhanh hơn xếp trước)</small>${rows}</div>`;
    };
    const teamTable = () => `<div style="margin-bottom:12px"><b style="font-size:20px;color:#7c3aed">👥 XẾP HẠNG ĐỘI/NHÓM <small style="font-weight:600;color:#475569">(điểm trung bình các thành viên, cao → thấp)</small></b><div style="overflow-x:auto;margin-top:6px"><table class="lv-tb"><tr><th>Hạng</th><th>Đội/nhóm</th><th>Số học sinh</th><th>Điểm TB</th><th>Thành viên (điểm)</th></tr>${LV.trank().map(t => `<tr><td><b>${t.n ? LV.trkOf(t.i) : '—'}</b></td><td><b style="color:${TC[t.i % TC.length]}">${E(t.name)}</b></td><td>${t.n}</td><td><b>${t.n ? fm(t.avg) : '—'}</b></td><td style="text-align:left;white-space:normal">${t.m.slice().sort((a, b) => b.sc - a.sc).map(x => E(x.name) + ' (' + fm(x.sc) + ')').join(', ') || '—'}</td></tr>`).join('')}</table></div></div>`;
    const rank = () => all().sort((a, b) => b.sc - a.sc || (a.at || 0) - (b.at || 0));
    const rankHtml = () => {
        const r = all().slice().sort((a, b) => b.sc - a.sc || tkey(a) - tkey(b)), n = r.length, rk = rankOf;
        const top = r.slice(0, 3), bot = r.slice(3).slice(-3).reverse(), med = ['🥇', '🥈', '🥉'];
        const li = (arr, c, m) => arr.map(s => `<div style="display:flex;justify-content:space-between;gap:8px;padding:6px 10px;border-radius:10px;background:${c};margin:4px 0;font-weight:800"><span>${m ? med[rk(s) - 1] || '' : ''} Hạng ${rk(s)} — ${E(s.name)}</span><span>${fm(s.sc)} <small style="font-weight:600;color:#475569">⏱ ${(tkey(s) / 1000).toFixed(1)}s</small></span></div>`).join('') || '<i>—</i>';
        return `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:10px"><div class="lv-c"><b style="color:#059669">🏆 3 học sinh cao nhất (${n} học sinh)</b> <small style="color:#475569">(bằng điểm: chọn đúng nhanh hơn xếp trước)</small>${li(top, '#d1fae5', true)}</div><div class="lv-c"><b style="color:#dc2626">⚠ 3 học sinh thấp nhất</b>${li(bot, '#fee2e2', false)}</div></div>`;
    };
    const vioHtml = () => {
        if (!LV.guard || !LV.guard.on) return '';
        const v = all().filter(s => s.vio).sort((a, b) => b.vio - a.vio);
        return `<div class="lv-c"><b style="color:#b45309">🛡 Giám sát màn hình: ${v.length} học sinh vi phạm</b>${v.map(s => `<div style="display:flex;justify-content:space-between;gap:8px;padding:5px 10px;margin:4px 0;border-radius:10px;background:#fef3c7;font-weight:700"><span>${E(s.name)}</span><span>⚠ ${s.vio} lần — ${E((s.vlog.slice(-1)[0] || {}).k || '')}</span></div>`).join('') || '<div style="color:#64748b;margin-top:4px">Chưa phát hiện vi phạm.</div>'}</div>`;
    };
    LV.upd = function () {
        const n = all().length;
        if (LV.phase === 'lobby') {
            if ($('lv-n')) $('lv-n').textContent = n;
            if (LV.team) LV.teams.forEach((t, i) => {
                const m = all().filter(x => x.team === i), c = TC[i % TC.length];
                if ($('lv-tn' + i)) $('lv-tn' + i).textContent = m.length;
                if ($('lv-tl' + i)) $('lv-tl' + i).innerHTML = m.map(x => `<span style="background:${x.on ? c + '26' : '#fee2e2'};color:#0f172a">${E(x.name)}</span>`).join('');
            });
            if ($('lv-ls')) $('lv-ls').innerHTML = all().map(s => `<span class="lv-t" style="background:${s.on ? '#d1fae5' : '#fee2e2'}">${E(s.name)}</span>`).join('');
            return;
        }
        const d = $('lv-run'); if (!d || LV.phase !== 'run') return;
        if (LV.mode === 'pace') {
            const rem = Math.max(0, LV.endAt - Date.now()), r = rank(), top = r.slice(0, 5), bot = r.slice(5).slice(-5).reverse();
            const li = (arr, c) => arr.map((s, i) => `<div style="display:flex;justify-content:space-between;padding:6px 10px;border-radius:10px;background:${c};margin:4px 0;font-weight:800"><span>${E(s.name)}</span><span>${fm(s.sc)}</span></div>`).join('') || '<i>—</i>';
            d.innerHTML = `<div class="lv-c" style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;font-weight:900;font-size:20px"><span>⏳ ${Math.floor(rem / 60000)}:${String(Math.floor(rem / 1000) % 60).padStart(2, '0')}</span><span>📨 Đã nộp: ${all().filter(s => s.done).length}/${n}</span><button class="lv-b r" onclick="LV.finish()">KẾT THÚC SỚM</button></div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:10px"><div class="lv-c"><b style="color:#059669">🏆 5 học sinh điểm cao nhất</b>${li(top, '#d1fae5')}</div><div class="lv-c"><b style="color:#dc2626">⚠ 5 học sinh điểm thấp nhất</b>${li(bot, '#fee2e2')}</div></div>${vioHtml()}`;
        } else {
            const q = LV.qs[LV.qi], g = all().map(s => grade(q, s.answers[q.id])), ans = g.filter(x => x.a).length, okc = g.filter(x => x.ok).length;
            const rem = LV.qEnd ? Math.max(0, Math.ceil((LV.qEnd - Date.now()) / 1000)) : '∞';
            let stat = '';
            if (LV.rev) {
                stat = `<div class="lv-c" style="background:#ecfdf5"><b style="font-size:20px">✅ Làm đúng hoàn toàn: ${okc}/${n} học sinh (${n ? Math.round(okc / n * 100) : 0}%)</b>`;
                if (qType(q) === 'mc') stat += (q.options || []).map(o => { const c = all().filter(s => (s.answers[q.id] || {}).sel === o.letter).length; return `<div style="display:flex;align-items:center;gap:8px;margin:4px 0"><b style="width:24px">${o.letter}</b><div style="flex:1;background:#e2e8f0;border-radius:8px"><div style="width:${n ? c / n * 100 : 0}%;background:${o.letter === q.correct ? '#059669' : '#dc2626'};border-radius:8px;color:#fff;padding:2px 8px;min-width:24px">${c}</div></div></div>`; }).join('');
                stat += '</div>';
            }
            d.innerHTML = `<div class="lv-c" style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;font-weight:900;font-size:18px"><span>Câu ${LV.qi + 1}/${LV.qs.length}</span><span>⏱ ${rem}</span><span>✍ Đã trả lời: ${ans}/${n}</span></div>
            <div class="lv-pane" style="margin-top:0"><div class="qc-live">${partHd(qType(q))}${card(q, null, LV.rev ? keyOf(q) : null, null, false, { nm: LV.nm, single: true }, { noSol: true, teacher: true })}</div></div>${stat}${LV.team ? teamRankHtml() : (LV.rev ? rankHtml() : '')}${vioHtml()}
            <div style="display:flex;gap:8px;margin:10px 0">${LV.rev ? `<button class="lv-b g" onclick="LV.next()">${LV.qi < LV.qs.length - 1 ? 'CÂU TIẾP THEO ▶' : '🏁 XEM KẾT QUẢ'}</button>` : '<button class="lv-b" onclick="LV.reveal()">👁 HIỆN ĐÁP ÁN</button>'}<button class="lv-b s" onclick="LV.finish()">Kết thúc</button></div>`;
        }
    };
    const tm = ms => { const t = Math.round((ms || 0) / 1000); return Math.floor(t / 60) + ':' + String(t % 60).padStart(2, '0'); };
    const sorted = () => { const r = all().sort((x, y) => (x.sc - y.sc) || (tkey(y) - tkey(x))); return LV.desc ? r.reverse() : r; };
    LV.fx = function (i) {
        try {
            const ac = LV.ac || (LV.ac = new (window.AudioContext || window.webkitAudioContext)()); ac.resume && ac.resume();
            const notes = i === 0 ? [523, 659, 784, 1047, 1319] : i === 1 ? [523, 659, 784, 1047] : [523, 659, 784];
            notes.forEach((f, k) => { const o = ac.createOscillator(), g = ac.createGain(), t0 = ac.currentTime + k * .15; o.type = 'triangle'; o.frequency.value = f; g.gain.setValueAtTime(.0001, t0); g.gain.exponentialRampToValueAtTime(.25, t0 + .03); g.gain.exponentialRampToValueAtTime(.0001, t0 + .5); o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + .55); });
        } catch (e) { }
        try {
            const end = Date.now() + (i === 0 ? 3500 : 1500), n = i === 0 ? 40 : 20;
            confetti({ particleCount: i === 0 ? 220 : 110, spread: 100, origin: { x: .5, y: .5 }, zIndex: 9500 });
            (function f() { confetti({ particleCount: n, angle: 60, spread: 70, origin: { x: 0, y: .7 }, zIndex: 9500 }); confetti({ particleCount: n, angle: 120, spread: 70, origin: { x: 1, y: .7 }, zIndex: 9500 }); if (Date.now() < end) setTimeout(f, 250); })();
        } catch (e) { }
    };
    LV.podium = function () {
        (LV.pt || []).forEach(clearTimeout); LV.pt = []; LV.view = 'podium';
        const d = $('lv-res'); if (!d) return;
        const top = LV.team ? LV.trank().filter(t => t.n > 0).slice(0, 3).map(t => ({ name: t.name, sc: t.avg, note: '👥 ' + t.n + ' học sinh • điểm trung bình' })) : all().sort((x, y) => (y.sc - x.sc) || ((x.at || 0) - (y.at || 0))).slice(0, 3).map(x => ({ name: x.name, sc: x.sc, note: '⏱ ' + tm(x.at) }));
        const cfg = [{ i: 1, h: 150, c: '#94a3b8', m: '🥈' }, { i: 0, h: 210, c: '#f59e0b', m: '🥇' }, { i: 2, h: 110, c: '#c2763d', m: '🥉' }];
        d.innerHTML = `<div class="lv-c" style="text-align:center;background:linear-gradient(#1e1b4b,#4c1d95);color:#fff;border:0"><div style="font-size:30px;font-weight:900">🏆 BỤC VINH DANH ${LV.team ? 'ĐỘI/NHÓM ' : ''}🏆</div>
        <div style="display:flex;justify-content:center;align-items:flex-end;gap:10px;margin:20px 0;min-height:340px">${cfg.map(c => { const s = top[c.i]; if (!s) return '<div style="flex:1;max-width:220px"></div>'; return `<div id="pd${c.i}" style="flex:1;max-width:220px;opacity:0;transform:translateY(40px);transition:all .8s"><div style="font-size:44px">${c.m}</div><div style="font-weight:900;font-size:20px;word-break:break-word">${E(s.name)}</div><div style="font-weight:900;font-size:24px;color:#fde68a">${fm(s.sc)} điểm</div><div style="font-size:14px;opacity:.8">${s.note}</div><div style="height:${c.h}px;background:${c.c};border-radius:12px 12px 0 0;display:flex;align-items:center;justify-content:center;font-size:56px;font-weight:900;margin-top:6px">${c.i + 1}</div></div>`; }).join('')}</div>
        <button class="lv-b g" style="font-size:18px" onclick="LV.result()">📊 XEM BẢNG KẾT QUẢ ▶</button></div>`;
        [[2, 400], [1, 3000], [0, 5600]].forEach(([i, t]) => LV.pt.push(setTimeout(() => { const e = $('pd' + i); if (!e) return; e.style.opacity = 1; e.style.transform = 'none'; LV.fx(i); }, t)));
    };
    LV.flip = () => { LV.desc = !LV.desc; LV.result(); };
    LV.result = function () {
        (LV.pt || []).forEach(clearTimeout); LV.view = 'table';
        const r = sorted(), d = $('lv-res'); if (!d) return;
        const avg = r.length ? Math.round(r.reduce((a, s) => a + s.sc, 0) / r.length * 100) / 100 : 0;
        d.innerHTML = `<div class="lv-c"><div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px"><b style="font-size:22px">📊 BẢNG KẾT QUẢ (${r.length} học sinh)</b><div style="display:flex;gap:6px"><button class="lv-b" style="background:#f59e0b" onclick="LV.podium()">🏆 Bục vinh danh</button><button class="lv-b s" onclick="LV.flip()">⇅ Đang xếp: ${LV.desc ? 'điểm cao → thấp' : 'điểm thấp → cao'}</button><button class="lv-b g" onclick="LV.xl()">⬇ Xuất Excel</button></div></div>
        <div style="padding:10px 14px;border-radius:12px;background:#ede9fe;font-weight:900;font-size:19px;margin-bottom:8px">⭐ Điểm trung bình cả lớp: ${fm(avg)}</div>${LV.team ? teamTable() : ''}
        <div style="overflow-x:auto"><table class="lv-tb"><tr><th>Hạng</th><th>Họ và tên</th>${LV.team ? '<th>Đội</th>' : ''}<th>Điểm</th><th>Câu đúng</th><th>Câu sai</th><th>Bỏ trống</th><th>Thời gian nộp</th>${LV.guard && LV.guard.on ? '<th>Vi phạm</th>' : ''}<th>Chi tiết</th></tr>${r.map((s, i) => `<tr><td>${rankOf(s)}</td><td><b>${E(s.name)}</b></td>${LV.team ? `<td style="font-weight:700;color:${TC[s.team % TC.length]}">${E((LV.teams[s.team] || {}).name || '')}</td>` : ''}<td><b>${fm(s.sc)}</b></td><td style="color:#059669">${s.ok}</td><td style="color:#dc2626">${s.wr}</td><td>${s.bl}</td><td>${tm(s.at)}</td>${LV.guard && LV.guard.on ? `<td style="font-weight:900;color:${s.vio ? '#dc2626' : '#64748b'}" title="${E((s.vlog || []).map(x => tm(x.at) + ' ' + x.k + (x.sec ? ' (' + x.sec + 's)' : '')).join('; '))}">${s.vio ? '⚠ ' + s.vio : '—'}</td>` : ''}<td><button class="lv-b" style="padding:4px 10px" onclick="LV.detail('${s.cid}')">🔍 Xem bài làm</button></td></tr>`).join('')}</table></div></div>`;
    };
    LV.detail = function (cid) {
        const s = LV.st[cid]; if (!s) return;
        const d = layer('lv-d', `<div class="lv-hd"><div style="font-size:20px;font-weight:900">👤 ${E(s.name)}${LV.team && LV.teams[s.team] ? ' (' + E(LV.teams[s.team].name) + ')' : ''} — ${fm(s.sc)} điểm</div><button class="lv-b" style="background:#ffffff33" onclick="document.getElementById('lv-d').remove()">✕</button></div><div class="lv-w"><div class="lv-c" style="font-weight:900;font-size:18px"><span style="color:#059669">✔ Đúng: ${s.ok}</span> &nbsp; <span style="color:#dc2626">✘ Sai: ${s.wr}</span> &nbsp; <span style="color:#64748b">○ Bỏ trống: ${s.bl}</span> &nbsp; ⏱ ${tm(s.at)}</div>${(s.vlog || []).length ? `<div class="lv-c" style="background:#fef3c7"><b style="color:#b45309">🛡 Vi phạm giám sát (${s.vio}):</b>${s.vlog.map(x => `<div>• ${tm(x.at)} — ${E(x.k)}${x.sec ? ' (' + x.sec + ' giây)' : ''}</div>`).join('')}</div>` : ''}<div class="lv-pane" style="margin-top:0">${listHtml(LV.qs, s.answers, LV.keysFor(s), null, false, { noSol: true, teacher: true })}</div></div>`);
        d.style.zIndex = 9100;
    };
    LV.xl = function () {
        const T = !!LV.team;
        const rows = [['STT', 'Họ và tên'].concat(T ? ['Đội'] : [], ['Điểm', 'Câu đúng', 'Câu sai', 'Bỏ trống', 'Thời gian nộp', 'Vi phạm'])].concat(sorted().map(s => [rankOf(s), s.name].concat(T ? [(LV.teams[s.team] || {}).name || ''] : [], [s.sc, s.ok, s.wr, s.bl, tm(s.at), s.vio || 0])));
        const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows), 'KetQua');
        if (T) XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([['Hạng', 'Đội/nhóm', 'Số học sinh', 'Điểm trung bình']].concat(LV.trank().map(t => [t.n ? LV.trkOf(t.i) : '', t.name, t.n, t.n ? t.avg : '']))), 'XepHangDoi');
        XLSX.writeFile(wb, 'KetQua_ChoiTrucTiep.xlsx');
    };
    window.addEventListener('beforeunload', e => { if (LV.phase === 'lobby' || LV.phase === 'run') { e.preventDefault(); e.returnValue = ''; } });

    /* ======================= HỌC SINH ======================= */
    const LS = window.LS = { a: {} };
    window.liveBootIfNeeded = function () {
        const p = new URLSearchParams(location.search).get('live'); if (!p) return false;
        const l = $('login-modal'); if (l) l.classList.add('hidden');
        document.body.classList.add('live-student'); LS.host = p; { const _tr = new URLSearchParams(location.search); LS.tr = _tr.get('tr') === 'fb'; try { LS.cfg = LS.tr && window.CloudSync && CloudSync.parseToken ? CloudSync.parseToken(_tr.get('cl')) : null; } catch (e) { LS.cfg = null; } } { const tp = new URLSearchParams(location.search).get('team'); LS.team = tp !== null && /^\d{1,2}$/.test(tp) ? parseInt(tp, 10) : null; LS.tname = LS.team !== null ? String(new URLSearchParams(location.search).get('tn') || '').slice(0, 30) : ''; LS.tidx = LS.team || 0; } LS.cid = sessionStorage.lscid || (sessionStorage.lscid = rid(10)); LS.joinUI(sessionStorage.lsname || ''); return true;
    };
    const hdrF = () => '<div class="lv-sh"><div class="lv-sh-in"><div class="lv-sh-t">🎮 ' + E(LS.title || 'CHƠI TRỰC TIẾP') + (LS.tname ? ' <span class="lv-tag" style="background:' + TC[(LS.tidx || 0) % TC.length] + '">👥 ' + E(LS.tname) + '</span>' : '') + '</div><div id="ls-tm"></div></div></div>';
    const msg = (t, sub) => layer('lv-s', hdrF() + `<div class="lv-w" style="text-align:center;padding-top:60px"><div style="font-size:26px;font-weight:900">${t}</div><div style="margin-top:8px;font-weight:600;color:#475569">${sub || ''}</div></div>`);
    LS.joinUI = function (nm) {
        layer('lv-s', hdrF() + `<div class="lv-w"><div class="lv-c" style="margin-top:40px"><div style="font-size:22px;font-weight:900;margin-bottom:10px">Nhập họ và tên để vào chơi</div>${LS.team != null ? '<div style="margin:-2px 0 10px;font-weight:900;font-size:20px;color:' + TC[LS.team % TC.length] + '">👥 Em vào đội: ' + E(LS.tname || ('ĐỘI SỐ ' + (LS.team + 1))) + '</div>' : ''}<input id="ls-name" class="lv-i" maxlength="40" value="${E(nm)}" placeholder="Họ và tên..." onkeydown="if(event.key==='Enter')LS.join()"><button class="lv-b g" style="margin-top:12px;font-size:18px" onclick="LS.join()">VÀO CHƠI</button></div></div>`);
    };
    LS.join = function () {
        const n = ($('ls-name').value || '').trim(); if (!n) { $('ls-name').focus(); return; }
        LS.name = n; sessionStorage.lsname = n; LS.connect();
    };
    LS.connect = function () {
        msg('Đang kết nối...', 'Vui lòng đợi trong giây lát');
        try { LS.peer && LS.peer.destroy(); } catch (e) { }
        clearTimeout(LS.to); LS.to = setTimeout(() => { if (!LS.ok) { msg('Không kết nối được', 'Kiểm tra mạng hoặc nhờ giáo viên kiểm tra phòng còn mở không.<br><br><button class="lv-b" onclick="LS.connect()">Thử lại</button>'); } }, 15000);
        LS.ok = false; LS.peer = (LS.tr && LS.cfg) ? new FbStudent(LS.cfg) : new Peer(undefined, PEER_OPTS);
        LS.peer.on('open', () => {
            const c = LS.conn = LS.peer.connect(LS.host, { reliable: true });
            c.on('open', () => { LS.ok = true; LS.retry = 0; clearTimeout(LS.to); c.send({ t: 'join', cid: LS.cid, name: LS.name, team: LS.team }); });
            c.on('data', LS.msg);
            c.on('close', () => { if (!LS.fin) { LS.ok = false; msg('Mất kết nối', 'Đang kết nối lại...'); setTimeout(() => { if (!LS.fin) LS.connect(); }, 2000); } });
        });
        LS.peer.on('error', e => {   // [CODE170] báo đúng nguyên nhân + tự thử lại thay vì im lặng
            const t = e && e.type;
            if (t === 'peer-unavailable') { clearTimeout(LS.to); msg('Phòng chơi không còn mở', 'Em nhờ giáo viên kiểm tra lại phòng, rồi bấm Thử lại.<br><br><button class="lv-b" onclick="LS.connect()">Thử lại</button>'); return; }
            if (!LS.ok && !LS.fin) { LS.retry = (LS.retry || 0) + 1; if (LS.retry <= 4) setTimeout(() => { if (!LS.ok && !LS.fin) LS.connect(); }, 1500 * LS.retry); else { clearTimeout(LS.to); msg('Không kết nối được', 'Lỗi: ' + E(t || 'mạng') + '. Em kiểm tra Wi-Fi/4G rồi bấm Thử lại.<br><br><button class="lv-b" onclick="LS.retry=0;LS.connect()">Thử lại</button>'); } }
        });
    };
    const tick = () => { const e = $('ls-tm'); if (!e || !LS.endAt) { if (e) e.textContent = ''; return; } const r = Math.max(0, LS.endAt - Date.now()); const tt = '⏳ ' + Math.floor(r / 60000) + ':' + String(Math.floor(r / 1000) % 60).padStart(2, '0'); if (e.textContent !== tt) e.textContent = tt; if (r <= 0 && LS.mode === 'pace' && !LS.sub) LS.submit(true); };
    setInterval(tick, 500);
    function shufQ(qs) {
        if (window.CODE121EN && qs.some(q => q.gm)) {   // [CODE121] đề English
            const sh = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0;[a[i], a[j]] = [a[j], a[i]]; } return a; };
            return [].concat(...['mc', 'tf', 'sa'].map(t => CODE121EN.shuffleList(qs.filter(q => q.type === t), sh)));
        }
        const by = { mc: [], tf: [], sa: [] }, g = {};
        qs.forEach(q => { if (q.gid) { if (!g[q.gid]) { g[q.gid] = []; by[q.type].push(g[q.gid]); } g[q.gid].push(q); } else by[q.type].push([q]); });
        return [].concat(...['mc', 'tf', 'sa'].map(t => { const a = by[t]; for (let i = a.length - 1; i > 0; i--) { const j = Math.random() * (i + 1) | 0;[a[i], a[j]] = [a[j], a[i]]; } return [].concat(...a); }));
    }
    LS.msg = function (m) {
        if (m.t === 'hi' && m.ver && m.ver !== VER) {
            if (sessionStorage.lsrel !== m.ver) { sessionStorage.lsrel = m.ver; LS.fin = true; { const q = new URLSearchParams(location.search); q.set('v', m.ver); q.set('r', Date.now()); location.replace(location.pathname + '?' + q.toString()); } return; }
            LS.toast('⚠ Phiên bản app của em khác với giáo viên. Hãy tải lại trang hoặc xóa bộ nhớ đệm trình duyệt.');
        }
        if (m.t === 'hi') { if (m.title) LS.title = m.title; LS.mode = m.mode; LS.guard = m.guard; LS.tname = m.tname || ''; LS.tidx = m.team || 0; if (!LS.started) msg('✅ Đã vào phòng: ' + E(LS.name) + (LS.tname ? ' — 👥 ' + E(LS.tname) : ''), 'Đang chờ giáo viên bấm BẮT ĐẦU...' + (true ? '<div style="margin:16px auto;max-width:520px;padding:12px;border-radius:12px;background:#fef3c7;color:#92400e;font-weight:900;text-align:justify;text-justify:inter-word">⚠ LƯU Ý: Mỗi câu hỏi em chỉ được chọn đáp án 1 LẦN, không được chọn lại lần 2. Hãy suy nghĩ kĩ trước khi chọn!</div>' : '') + (m.guard && m.guard.on ? '<div style="margin:10px auto;max-width:520px;padding:12px;border-radius:12px;background:#fee2e2;color:#991b1b;font-weight:900;text-align:justify;text-justify:inter-word">🛡 Bài thi có giám sát màn hình: chuyển tab, thu nhỏ trình duyệt, sao chép - dán, chuột phải, in/chụp màn hình sẽ bị ghi nhận và báo cho giáo viên' + (m.guard.max && m.mode === 'pace' ? '. Vi phạm ' + m.guard.max + ' lần sẽ bị tự động nộp bài' : '') + '.' + (document.documentElement.requestFullscreen ? '<br><br><button class="lv-b" onclick="LS.fs()">⛶ Bật toàn màn hình</button>' : '') + '</div>' : '')); }
        else if (m.t === 'pick') { if (m.title) LS.title = m.title; LS.pickUI(m.teams || []); }
        else if (m.t === 'cd') { try { LV.audio(); } catch (e) { } window.lvCountdown(m.n || 3, null); }
        else if (m.t === 'late') { LS.fin = true; msg('Buổi chơi đã bắt đầu', 'Em không thể vào thêm lúc này.'); }
        else if (m.t === 'start') {
            { const c = document.getElementById('lv-cd'); if (c && c._stop) c._stop(); }
            LS.started = true; LS.sub = false; LS.mode = 'pace'; LS.guard = m.guard; if (m.vio != null) LS.vio = Math.max(LS.vio, m.vio); LS.a = m.answers || {}; LS.endAt = Date.now() + m.remain;
            if (!LS.qs) LS.qs = m.shuf ? shufQ(m.qs) : m.qs;
            LS.nm = numMap(LS.qs);
            LS.paceUI();
        }
        else if (m.t === 'q') { { const c = document.getElementById('lv-cd'); if (c && c._stop) c._stop(); } LS.started = true; LS.mode = 'sync'; LS.guard = m.guard; if (m.vio != null) LS.vio = Math.max(LS.vio, m.vio); LS.q = m.q; LS.i = m.i; LS.n = m.n; LS.rv = null; LS.a1 = m.a || null; LS.tmp = {}; LS.autoSa = false; LS.endAt = m.remain ? Date.now() + m.remain : 0; LS.syncUI(); }
        else if (m.t === 'rev') { LS.rv = m; LS.endAt = 0; LS.syncUI(); }
        else if (m.t === 'end') { LS.fin = true; LS.endAt = 0; LS.endUI(m); }
    };
    LS.pickUI = function (teams) {
        layer('lv-s', hdrF() + `<div class="lv-w"><div class="lv-c" style="margin-top:30px"><div style="font-size:22px;font-weight:900;margin-bottom:10px">Em thuộc đội nào? Hãy chọn đội của mình:</div>${teams.map((n, i) => `<button class="lv-b" style="display:block;width:100%;margin:8px 0;font-size:18px;background:${TC[i % TC.length]}" onclick="LS.chooseTeam(${i})">👥 ${E(n)}</button>`).join('')}</div></div>`);
    };
    LS.chooseTeam = i => { LS.team = i; LS.send({ t: 'join', cid: LS.cid, name: LS.name, team: i }); };
    LS.act = () => !!(LS.guard && LS.guard.on && LS.started && !LS.fin && !LS.sub);
    LS.toast = function (t) { const d = document.createElement('div'); d.style.cssText = 'position:fixed;top:70px;left:50%;transform:translateX(-50%);z-index:9800;background:#dc2626;color:#fff;padding:12px 18px;border-radius:14px;font-weight:900;max-width:92%;text-align:center;box-shadow:0 8px 24px #0005'; d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 4500); };
    LS.viol = function (k) {
        if (!LS.act()) return; const now = Date.now(); if (now - (LS.vt || 0) < 1500) return; LS.vt = now;
        LS.vio++; LS.send({ t: 'vio', k }); const e = $('ls-vio'); if (e) e.textContent = LS.vio;
        const g = LS.guard; LS.toast(`⚠ Cảnh báo ${LS.vio}${g.max && LS.mode === 'pace' ? '/' + g.max : ''}: ${k}. Giáo viên đã được thông báo!`);
        if (g.max && LS.vio >= g.max && LS.mode === 'pace') LS.submit(true, 'vio');
    };
    LS.back = function () { if (LS.away) { const sec = Math.round((Date.now() - LS.away) / 1000); LS.away = 0; if (sec >= 1) LS.send({ t: 'vback', sec }); } };
    LS.fs = function () { const e = document.documentElement; try { (e.requestFullscreen || e.webkitRequestFullscreen).call(e); LS.wasFs = true; } catch (x) { } };
    LS.guardBar = function () {
        const g = LS.guard; if (!g || !g.on) return '';
        return `<div style="padding:8px 14px;border-radius:12px;background:#fee2e2;color:#991b1b;font-weight:800;margin-bottom:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:space-between"><span style="flex:1;min-width:200px;text-align:justify;text-justify:inter-word">🛡 Bài thi đang được giám sát: rời khỏi màn hình sẽ bị ghi nhận và báo giáo viên${g.max && LS.mode === 'pace' ? ` (tự nộp bài sau ${g.max} lần)` : ''}. Đã vi phạm: <span id="ls-vio">${LS.vio}</span></span>${document.documentElement.requestFullscreen && !document.fullscreenElement ? '<button class="lv-b s" style="padding:4px 10px" onclick="LS.fs()">⛶ Toàn màn hình</button>' : ''}</div>`;
    };
    const away = () => { if (LS.act()) LS.away = LS.away || Date.now(); LS.viol('Rời khỏi màn hình bài thi'); };
    document.addEventListener('visibilitychange', () => { if (document.hidden) away(); else LS.back(); });
    window.addEventListener('blur', () => {   /* [CODE77] điện thoại: blur do bàn phím -> bỏ qua, đã có visibilitychange */
        if (LS.mute) return;
        let touch = false; try { touch = navigator.maxTouchPoints > 0 || /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || ''); } catch (x) { }
        if (touch) return;
        setTimeout(() => { if (!document.hasFocus() && !LS.mute) away(); }, 700);
    });
    window.addEventListener('focus', () => LS.back());
    ['copy', 'cut', 'paste'].forEach(ev => document.addEventListener(ev, e => { if (LS.act()) { e.preventDefault(); LS.viol('Thao tác ' + ({ copy: 'sao chép', cut: 'cắt', paste: 'dán' })[ev]); } }, true));
    document.addEventListener('contextmenu', e => { if (LS.act()) { e.preventDefault(); LS.viol('Mở menu chuột phải'); } }, true);
    document.addEventListener('keydown', e => {
        if (!LS.act()) return; const k = String(e.key).toLowerCase(), c = e.ctrlKey || e.metaKey;
        if (e.key === 'F12' || (c && ['c', 'v', 'x', 'u', 's', 'p'].includes(k)) || (c && e.shiftKey && ['i', 'j', 'c'].includes(k))) { e.preventDefault(); LS.viol('Dùng phím tắt bị cấm'); }
        if (e.key === 'PrintScreen') { LS.viol('Chụp màn hình (PrintScreen)'); try { navigator.clipboard.writeText(''); } catch (x) { } }
    }, true);
    window.addEventListener('beforeprint', () => LS.viol('In trang'));
    document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && LS.wasFs) { LS.wasFs = false; LS.viol('Thoát chế độ toàn màn hình'); } });
    LS.vio = 0;
    LS.send = m => { try { LS.conn.send(m); } catch (e) { } };
    LS.tmp = {};
    LS.set = function (qid, ua) {
        if (LS.mode === 'sync') { if (LS.rv || (LS.endAt && Date.now() > LS.endAt + 1000)) return; LS.a1 = ua; LS.send({ t: 'ans1', qid, ua }); LS.syncUI(); }
        else { if (LS.sub) return; LS.a[qid] = ua; LS.send({ t: 'ans', answers: LS.a }); LS.refresh(qid); }
    };
    const find = id => (LS.mode === 'sync' ? LS.q : (LS.qs || []).find(q => String(q.id) === String(id)));
    const cur = id => LS.mode === 'sync' ? LS.a1 : LS.a[id];
    LS.pick = (id, L) => { const c = cur(id); if (c && c.sel) return; LS.set(id, { sel: L }); };
    LS.tf = (id, j, v) => {
        const c = cur(id), vals = c && c.values ? c.values.slice() : [null, null, null, null];
        if (vals[j] === true || vals[j] === false) return; vals[j] = v;
        LS.set(id, { values: vals });
    };
    LS.sa = (id, v) => { LS.tmp[id] = v; };
    LS.saOk = id => { const v = String(LS.tmp[id] || '').trim(); const c = cur(id); if (!v || LS.sub || (c && c.locked)) return; LS.set(id, { value: v, locked: true }); };
    LS.refresh = function (id) {
        const q = find(id), el = $('c_' + id); if (!q || !el) return;
        const t = document.createElement('div'); t.innerHTML = card(q, LS.a[id], null, 'LS', true, { nm: LS.nm });
        const nc = t.firstChild, og = el.querySelector('[class*="q-options-"]'), ng = nc.querySelector('[class*="q-options-"]');
        if (og && ng) { ng.className = og.className; ng.setAttribute('data-f', '1'); }
        el.replaceWith(nc); LS.nav();
    };
    LS.nav = function () { const e = $('ls-prog'); if (e) e.textContent = `Đã trả lời ${LS.qs.filter(q => { const g = LS.a[q.id]; return g && (g.sel || (g.values && g.values.some(v => v === true || v === false)) || String(g.value || '').trim()); }).length}/${LS.qs.length} câu`; };
    LS.paceUI = function () {
        layer('lv-s', hdrF() + `<div class="lv-w"><div class="lv-pane" style="margin-bottom:40px"><div style="font-weight:900;font-size:17px;color:#334155;margin-bottom:10px">👤 ${E(LS.name)}</div>${listHtml(LS.qs, LS.a, null, 'LS', true)}<div class="lv-bar"><span id="ls-prog" style="font-size:14px;font-weight:900;color:#475569"></span><button type="button" class="lv-submit" onclick="LS.submit(false)">NỘP BÀI</button></div></div></div>`);
        LS.nav(); tick();
    };
    LS.submit = function (auto, why) {
        if (LS.sub) return;
        if (!auto) { LS.mute = true; const okc = confirm('Em chắc chắn muốn nộp bài?'); setTimeout(() => { LS.mute = false; }, 600); if (!okc) return; }
        Object.keys(LS.tmp).forEach(id => { const v = String(LS.tmp[id] || '').trim(); if (v && !LS.a[id]) LS.a[id] = { value: v, locked: true }; });
        LS.sub = true; LS.send({ t: 'submit', answers: LS.a }); msg(why === 'vio' ? '🚫 Đã tự động nộp bài do rời khỏi màn hình quá số lần cho phép' : auto ? '⏰ Hết giờ — đã tự nộp bài' : '✅ Đã nộp bài', 'Đang chờ kết quả...');
    };
    const WARN1 = '<div style="padding:10px 14px;border-radius:12px;background:#fef3c7;color:#92400e;font-weight:900;margin-bottom:8px;text-align:justify;text-justify:inter-word">⚠ Mỗi câu chỉ được chọn đáp án 1 LẦN duy nhất, không được đổi! Xếp hạng dựa vào điểm và tốc độ chọn đúng.</div>';
    setInterval(() => { if (LS.mode === 'sync' && LS.q && LS.endAt && !LS.rv && !LS.autoSa && Date.now() >= LS.endAt - 200) { LS.autoSa = true; if (LS.q.type === 'sa') LS.saOk(LS.q.id); } }, 300);
    LS.syncUI = function () {
        const old = $('lv-s'), y = old ? old.scrollTop : 0, q = LS.q;
        const k = LS.rv ? Object.assign({}, LS.rv.key, { ok: LS.rv.ok, a: hasAns(LS.a1) }) : null;
        const ctx = { nm: { [q.id]: { t: q.type, num: q.num || (LS.i + 1), g: q.gid ? { first: true, from: q.gf, to: q.gt, info: q.ginfo } : null } }, single: true };
        layer('lv-s', hdrF() + `<div class="lv-w"><div class="lv-pane"><div class="qc-live">${partHd(q.type)}${card(q, LS.a1, k, 'LS', true, ctx, { noSol: true })}</div>
        ${LS.rv ? `<div style="margin-top:12px;padding:12px;border-radius:12px;text-align:center;font-weight:900;font-size:20px;background:${LS.rv.ok ? '#d1fae5' : '#fee2e2'}">${LS.rv.ok ? '🎉 Chính xác!' : '❌ Chưa chính xác'} &nbsp; +${fm(LS.rv.e)} điểm &nbsp;•&nbsp; Tổng: ${fm(LS.rv.sc)}${LS.rv.rk ? ` &nbsp;•&nbsp; 🏅 Hạng ${LS.rv.rk}/${LS.rv.nn}` : ''}${LS.rv.trk ? `<div style="font-size:17px;margin-top:4px;color:#5b21b6">👥 ${E(LS.rv.tn)}: hạng ${LS.rv.trk}/${LS.rv.tnn} • điểm trung bình đội ${fm(LS.rv.tavg)}</div>` : ''}</div><div style="text-align:center;font-weight:600;color:#475569;margin-top:8px">Chờ giáo viên chuyển sang câu tiếp theo...</div>` : ''}</div></div>`);
        $('lv-s').scrollTop = y; tick();
    };
    LS.endUI = function (m) {
        const qs = LS.qs || m.qs || (LS.q ? [LS.q] : []);
        layer('lv-s', hdrF() + `<div class="lv-w"><div class="lv-pane" style="text-align:center"><div style="font-weight:900;font-size:19px;color:#334155">👤 ${E(LS.name)}</div><div style="font-size:84px;font-weight:900;color:#2563eb;line-height:1.1">${fm(m.sc)}<span style="font-size:30px;color:#64748b">/10</span></div><div style="font-weight:900;font-size:18px"><span style="color:#059669">✔ Đúng: ${m.ok}</span> &nbsp; <span style="color:#dc2626">✘ Sai: ${m.wr}</span> &nbsp; <span style="color:#64748b">○ Bỏ trống: ${m.bl}</span></div>${m.rk ? `<div style="font-weight:900;font-size:20px;margin-top:6px;color:#7c3aed">🏅 Xếp hạng: ${m.rk}/${m.nn}</div>` : ''}${m.trk ? `<div style="font-weight:900;font-size:20px;margin-top:6px;color:#7c3aed">👥 ${E(m.tn)}: hạng ${m.trk}/${m.tnn} • điểm trung bình đội ${fm(m.tavg)}</div>` : ''}</div>
        ${qs.length ? `<div class="lv-pane" style="margin-bottom:40px">${listHtml(qs, m.answers || LS.a, m.keys, 'LS')}</div>` : ''}</div>`);
    };
})();
    