
/* ======================================================================
   [CODE60] ĐỒNG BỘ ĐÁM MÂY & HỢP NHẤT KẾT QUẢ ĐA THIẾT BỊ TRIỆT ĐỂ
   - Sửa triệt để lỗi: Máy tính báo kết quả tức thì nhưng GitHub báo 0 lượt nộp / "(đề không có trong Thư viện này)".
   - Tự động đối chiếu & gộp kết quả theo Tên chủ đề chuẩn hóa (subtitle + subject + grade) khi mã đề (topic.id) bị lệch giữa Máy tính và GitHub.
   - Tự động đồng bộ đề thi từ cả nhánh s/pub (đề đã giao) về Thư viện Giáo viên trên GitHub.
   - Cho phép trang GitHub đọc ngay đề & kết quả thông qua cấu hình nhúng sẵn (__CLOUD_CONFIG__) ngay cả trước khi nhập mã MQT1.
   - Hiển thị rõ Họ tên học sinh + Lớp + Giờ nộp của các nhánh kết quả khác mã trên máy chủ kèm nút [📥 Gộp vào đề này] chỉ 1 cú nhấp chuột.
   ====================================================================== */
(function () {
    'use strict';
    var LS_CFG = 'matrix_cloud_cfg_v1';
    var LS_STU = 'matrix_cloud_student_cfg_v1';
    var LS_META = 'matrix_cloud_meta_v1';
    var SV = { '.sv': 'timestamp' };
    var DEFAULT_TOPIC = 'topic_default_kim_loai';

    var S = {
        cfg: null,        // { u, t, p }  (giáo viên đầy đủ)
        stu: null,        // { u, p }     (học sinh / cấu hình nhúng trên GitHub)
        meta: null,
        pubTopics: {},    // bộ nhớ đệm đề thi trên s/pub (theo enc(id))
        tTopics: {},      // bộ nhớ đệm đề thi trên t/topics (theo enc(id))
        orphanCache: {},  // bộ nhớ đệm các kết quả khác mã trên máy chủ
        busy: false, again: false, timer: null, poll: null,
        lastOk: 0, lastErr: '', lastInfo: '',
        forcePub: new Set(), installed: false, applying: false, lastPullTs: 0
    };

    /* ---------------- tiện ích ---------------- */
    function $(id) { return document.getElementById(id); }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function normStr(s) { return String(s == null ? '' : s).normalize('NFC').toLowerCase().replace(/\s+/g, ' ').trim(); }
    function topicTitleKey(t) { return t ? normStr(t.subtitle || t.topicTitle || t.title || '') : ''; }
    function topicFullKey(t) {
        if (!t) return '';
        var sub = topicTitleKey(t);
        if (!sub) return '';
        return sub + '||' + normStr(t.subject || t.topicSubject || '') + '||' + normStr(t.grade || t.topicGrade || '');
    }
    function hash(str) {
        var h = 0x811c9dc5;
        for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
        return (h >>> 0).toString(36) + '.' + str.length.toString(36);
    }
    function enc(k) { return String(k).replace(/[.$#\[\]\/\u0000-\u001f\u007f]/g, '_'); }
    function rnd(n) {
        var a = 'abcdefghijkmnpqrstuvwxyz23456789', out = '';
        try { var b = new Uint8Array(n); crypto.getRandomValues(b); for (var i = 0; i < n; i++) out += a[b[i] % a.length]; }
        catch (e) { for (var j = 0; j < n; j++) out += a[Math.floor(Math.random() * a.length)]; }
        return out;
    }
    function normUrl(u) {
        u = String(u || '').trim().replace(/\.json.*$/i, '').replace(/\/+$/, '');
        if (!u) return '';
        if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
        try { var p = new URL(u); if (p.protocol !== 'https:' && p.protocol !== 'http:') return ''; return p.origin; } catch (e) { return ''; }
    }
    function lsGet(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
    function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
    function b64e(s) { return btoa(unescape(encodeURIComponent(s))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
    function b64d(s) { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return decodeURIComponent(escape(atob(s))); }
    function g(name) { try { return (0, eval)(name); } catch (e) { return undefined; } }
    function isStu() { return g('isStudentMode') === true; }

    /* ---------------- cấu hình ---------------- */
    function loadCfg() {
        var c = lsGet(LS_CFG);
        S.cfg = (c && c.u && c.t && c.p) ? c : null;
        if (!S.cfg && window.__CLOUD_TEACHER_CONFIG__ && window.__CLOUD_TEACHER_CONFIG__.u && window.__CLOUD_TEACHER_CONFIG__.t && window.__CLOUD_TEACHER_CONFIG__.p) {
            S.cfg = { u: normUrl(window.__CLOUD_TEACHER_CONFIG__.u), t: String(window.__CLOUD_TEACHER_CONFIG__.t), p: String(window.__CLOUD_TEACHER_CONFIG__.p) };
            lsSet(LS_CFG, S.cfg);
        }
        var s = lsGet(LS_STU);
        S.stu = (s && s.u && s.p) ? s : null;
        /* [CODE75] Cấu hình nhúng trong index.html (mới hơn) phải thay được cấu hình CŨ còn lưu trong bộ nhớ trình duyệt,
           nếu không máy học sinh bị kẹt ở kho cũ và không thấy đề/lớp mới. Cấu hình có dấu thời gian (do mở link/QR mới hơn bản build) vẫn được ưu tiên. */
        var ec = window.__CLOUD_CONFIG__;
        if (ec && ec.u && ec.p) {
            var bts = Number(String(window.__PRELOADED_BUILD_ID__ || '').replace(/\D/g, '')) || 0;
            var ecu = normUrl(ec.u), ecp = String(ec.p);
            var same = !!S.stu && ecu === S.stu.u && ecp === S.stu.p;
            if (!S.stu || (!same && (Number(S.stu.ts) || 0) < bts)) {
                S.stu = { u: ecu, p: ecp, ts: bts || Date.now(), src: 'embed' };
                lsSet(LS_STU, S.stu);
            }
        }
        var m = lsGet(LS_META);
        S.meta = (m && typeof m === 'object') ? m : {};
        var id = S.cfg ? hash(S.cfg.u + '|' + S.cfg.t + '|' + S.cfg.p) : (S.stu ? hash(S.stu.u + '|' + S.stu.p) : '');
        var bid = String(window.__PRELOADED_BUILD_ID__ || '');
        if (S.meta.cfgId !== id || S.meta.buildId !== bid) { S.meta = { cfgId: id, buildId: bid }; }
        if (!S.meta.rev) S.meta.rev = {};
    }
    function saveMeta() { lsSet(LS_META, S.meta); }
    function effStu() {
        if (S.cfg) return { u: S.cfg.u, p: S.cfg.p };
        if (S.stu) return S.stu;
        return null;
    }
    function teacherFullReady() { return !!S.cfg && !isStu(); }
    function teacherReady() { return !isStu() && !!(S.cfg || effStu()); }
    function studentReady() { return isStu() && !!effStu(); }
    function token() {
        var c = effStu();
        if (!c) return '';
        return 'MQC1.' + b64e(c.u.replace(/^https:\/\//, '') + '|' + c.p);
    }
    function parseStuToken(tok) {
        try {
            var raw = b64d(String(tok).replace(/^MQC1\./, '')); var i = raw.lastIndexOf('|');
            if (i < 1) return null;
            var u = normUrl(raw.slice(0, i)), p = raw.slice(i + 1);
            return (u && p.length >= 12) ? { u: u, p: p } : null;
        } catch (e) { return null; }
    }
    function fullCode() {
        if (!S.cfg) return '';
        return 'MQT1.' + b64e(JSON.stringify({ u: S.cfg.u, t: S.cfg.t, p: S.cfg.p }));
    }
    function parseFullCode(code) {
        try {
            var o = JSON.parse(b64d(String(code).trim().replace(/^MQT1\./, '')));
            var u = normUrl(o.u);
            if (u && o.t && String(o.t).length >= 16 && o.p && String(o.p).length >= 12) return { u: u, t: String(o.t), p: String(o.p) };
        } catch (e) { }
        return null;
    }

    (function captureLink() {
        try {
            var p = new URLSearchParams(location.search);
            var cl = p.get('cl');
            if (cl) { var c = parseStuToken(cl); if (c) { c.ts = Date.now(); c.src = 'link'; lsSet(LS_STU, c); } }
            var ct = p.get('ct');
            if (ct) { var tc = parseFullCode(ct); if (tc) lsSet(LS_CFG, tc); }
        } catch (e) { }
    })();

    /* ---------------- mạng ---------------- */
    function base(b) {
        if (b === 't') {
            if (!S.cfg) throw new Error('Chưa có Mã giáo viên (MQT1) trên trình duyệt này.');
            return S.cfg.u + '/t/' + S.cfg.t;
        }
        var c = effStu();
        if (!c) throw new Error('Chưa có kết nối máy chủ.');
        return c.u + '/s/' + c.p;
    }
    function req(method, b, path, body) {
        var q = ''; if (path && path.indexOf('?') >= 0) { q = path.slice(path.indexOf('?')); path = path.slice(0, path.indexOf('?')); }
        var url;
        try { url = base(b) + (path ? '/' + path : '') + '.json' + q; }
        catch (err) { return Promise.reject(err); }
        var opt = { method: method, cache: 'no-store' };
        if (body !== undefined) { opt.body = JSON.stringify(body); opt.headers = { 'Content-Type': 'application/json' }; }
        return fetch(url, opt).then(function (r) {
            if (r.ok) return r.status === 204 ? null : r.json();   /* [CODE157] print=silent -> 204 không có nội dung */
            return r.text().then(function (t) {
                var msg = 'Lỗi máy chủ ' + r.status;
                if (r.status === 401 || r.status === 403) msg = 'Máy chủ từ chối truy cập (kiểm tra lại Rules của Firebase).';
                else if (r.status === 404) msg = 'Không tìm thấy Database (kiểm tra lại URL).';
                throw new Error(msg + (t ? ' ' + t.slice(0, 80) : ''));
            });
        }, function () { throw new Error('Không kết nối được mạng/máy chủ.'); });
    }

    /* ---------------- dữ liệu cục bộ & gắn nhãn tên đề vào kết quả ---------------- */
    function arr(name) { var v = g(name); return Array.isArray(v) ? v : []; }
    function enrichLocalResults() {
        try {
            var R = g('studentResultsByTopic') || {}, T = arr('savedTopics'), byId = {};
            T.forEach(function (t) { if (t && t.id) byId[t.id] = t; });
            var curId = g('currentTopicId'), curSub = ($('quiz-subtitle') && $('quiz-subtitle').textContent || '').trim();
            Object.keys(R).forEach(function (tid) {
                var list = Array.isArray(R[tid]) ? R[tid] : [];
                var tp = byId[tid] || S.pubTopics[enc(tid)] || S.tTopics[enc(tid)];
                list.forEach(function (r) {
                    if (!r) return;
                    if (!r.topicId) r.topicId = tid;
                    if (tp) {
                        if (!r.topicTitle && tp.subtitle) r.topicTitle = tp.subtitle;
                        if (!r.topicSubject && tp.subject) r.topicSubject = tp.subject;
                        if (!r.topicGrade && tp.grade) r.topicGrade = tp.grade;
                    } else if (tid === curId && curSub && curSub !== 'CHƯA CHỌN ĐỀ THI') {
                        if (!r.topicTitle) r.topicTitle = curSub;
                        if (!r.topicSubject) r.topicSubject = g('currentSubject') || '';
                        if (!r.topicGrade) r.topicGrade = g('currentGrade') || '';
                    }
                });
            });
        } catch (e) { }
    }
    function localMap(kind) {
        var m = new Map();
        if (kind === 'topics') arr('savedTopics').forEach(function (t) { if (t && t.id && t.id !== DEFAULT_TOPIC) m.set(t.id, t); });
        else if (kind === 'folders') arr('libraryFolders').forEach(function (f) { if (f && f.id) m.set(f.id, f); });
        else if (kind === 'classes') arr('classesData').forEach(function (c) { if (c && c.id) m.set(c.id, c); });
        else if (kind === 'results') {
            enrichLocalResults();
            var R = g('studentResultsByTopic') || {};
            Object.keys(R).forEach(function (tid) { (Array.isArray(R[tid]) ? R[tid] : []).forEach(function (r) { if (r && r.id) m.set(tid + '|' + r.id, r); }); });
        }
        return m;
    }
    function pubDesired() {
        var m = new Map(), pm = (S.meta.pub || {}), asg = {};
        /* [CODE67] Đề đã giao cho lớp học luôn được đưa lên máy chủ để học sinh mở được */
        arr('classesData').forEach(function (c) { ((c && c.assignments) || []).forEach(function (x) { if (x && x.topicId) asg[x.topicId] = 1; }); });
        arr('savedTopics').forEach(function (t) {
            if (!t || !t.id || t.id === DEFAULT_TOPIC) return;
            if (t.isPublished || pm[t.id] || S.forcePub.has(t.id) || asg[t.id]) m.set(t.id, t);
        });
        return m;
    }
    /* [CODE75] Thư mục chứa đề đã xuất bản/đã giao (kể cả thư mục cha) -> đưa lên s/pubfolders để học sinh thấy đề đúng thư mục */
    function pubFoldersDesired() {
        var m = new Map(), F = arr('libraryFolders'), T = arr('savedTopics'), byId = {}, need = {};
        F.forEach(function (f) { if (f && f.id) byId[f.id] = f; });
        var pd = pubDesired();
        T.forEach(function (t) {
            if (!t || !t.id || !pd.has(t.id)) return;
            var fid = t.folderId, guard = 0;
            while (fid && byId[fid] && !need[fid] && guard++ < 30) { need[fid] = 1; fid = byId[fid].parentId; }
        });
        Object.keys(need).forEach(function (id) { m.set(id, byId[id]); });
        F.forEach(function (f) { if (f && f.id && f.parentId === '__subjmeta') m.set(f.id, f); });   /* [CODE76] thứ tự các môn học */
        return m;
    }
    function deletedHas(kind, key) {
        if (kind === 'topics') return arr('deletedTopicIds').indexOf(key) >= 0;
        if (kind === 'folders') return arr('deletedFolderIds').indexOf(key) >= 0;
        return false;
    }

    /* ---------------- HỢP NHẤT KẾT QUẢ CỦA CÁC ĐỀ CÙNG TÊN ---------------- */
    function resultSig(r) {
        if (!r) return '';
        return normStr(r.studentName || r.name || '') + '|' + normStr(r.studentClass || r.className || '') + '|' + String(r.submittedTs || r.submittedAt || r.score || '');
    }
    function mergeResultRecordIntoTopic(tid, rec, topicObj) {
        if (!tid || !rec || !rec.id) return false;
        var R = g('studentResultsByTopic');
        if (!R) return false;
        if (!Array.isArray(R[tid])) R[tid] = [];
        var list = R[tid];
        var sig = resultSig(rec);
        var exists = list.some(function (x) {
            if (!x) return false;
            if (x.id === rec.id) return true;
            if (sig && resultSig(x) === sig && Math.abs((x.submittedTs || 0) - (rec.submittedTs || 0)) < 2000) return true;
            return false;
        });
        if (exists) {
            var idx = list.findIndex(function (x) { return x && x.id === rec.id; });
            if (idx >= 0 && !list[idx].detail && rec.detail) { list[idx] = Object.assign({}, rec, { topicId: tid }); return true; }
            return false;
        }
        var copy = Object.assign({}, rec, { topicId: tid });
        if (topicObj) {
            copy.topicTitle = copy.topicTitle || topicObj.subtitle || '';
            copy.topicSubject = copy.topicSubject || topicObj.subject || '';
            copy.topicGrade = copy.topicGrade || topicObj.grade || '';
        }
        list.push(copy);
        list.sort(function (a, b) { return (b.submittedTs || 0) - (a.submittedTs || 0); });
        return true;
    }

    /* Tự động ánh xạ các kết quả bị lệch mã đề (nhưng cùng tên chủ đề) về đúng đề trong Thư viện hiện tại */
    function unifySameTitleResults(ch) {
        var R = g('studentResultsByTopic') || {}, T = arr('savedTopics');
        if (!T.length) return 0;
        var byId = {}, byFull = {}, byTitle = {};
        T.forEach(function (t) {
            if (!t || !t.id) return;
            byId[t.id] = t;
            var fk = topicFullKey(t), tk = topicTitleKey(t);
            if (fk) (byFull[fk] = byFull[fk] || []).push(t);
            if (tk) (byTitle[tk] = byTitle[tk] || []).push(t);
        });
        var moved = 0;
        Object.keys(R).forEach(function (srcTid) {
            var list = Array.isArray(R[srcTid]) ? R[srcTid] : [];
            if (!list.length) return;
            var srcTopic = byId[srcTid] || S.pubTopics[enc(srcTid)] || S.tTopics[enc(srcTid)];
            var sample = list.find(function (r) { return r && r.topicTitle; });
            var fakeTopic = srcTopic || (sample ? { subtitle: sample.topicTitle, subject: sample.topicSubject, grade: sample.topicGrade } : null);
            if (!fakeTopic) return;
            var fk = topicFullKey(fakeTopic), tk = topicTitleKey(fakeTopic);
            var targets = (fk && byFull[fk] && byFull[fk].length) ? byFull[fk] : ((tk && byTitle[tk]) ? byTitle[tk] : []);
            targets.forEach(function (targetTopic) {
                if (!targetTopic || targetTopic.id === srcTid) return;
                list.forEach(function (rec) {
                    if (mergeResultRecordIntoTopic(targetTopic.id, rec, targetTopic)) {
                        moved++;
                        if (ch) { ch.results = true; ch.newRes = (ch.newRes || 0) + 1; }
                    }
                });
            });
        });
        if (moved > 0) S.dirty = true;
        return moved;
    }

    /* ---------------- ĐẨY LÊN ---------------- */
    var BASEOF = { topics: 't', folders: 't', classes: 't', results: 's', pub: 's', pubfolders: 's' };
    function resPath(key) { var i = key.indexOf('|'); return enc(key.slice(0, i)) + '/' + enc(key.slice(i + 1)); }
    function dataPath(kind, key) { return (kind === 'results') ? 'results/' + resPath(key) : kind + '/' + enc(key); }
    function tombPath(kind, key) { return 'del/' + kind + '/' + enc(key); }

    function collect(kind, desired, entries, allowDelete) {
        if (BASEOF[kind] === 't' && !S.cfg) return;
        var meta = S.meta[kind] || (S.meta[kind] = {});
        desired.forEach(function (obj, key) {
            var d = JSON.stringify(obj), h = hash(d), m = meta[key];
            if (m && m.h === h) return;
            if (kind === 'results' && m && m.h) return;
            var up = {}, size = d.length;
            up[dataPath(kind, key)] = { k: key, h: h, ts: SV, d: d };
            if (kind !== 'pub' && kind !== 'pubfolders') up[tombPath(kind, key)] = null;
            entries.push({ b: BASEOF[kind], up: up, size: size, kind: kind, key: key, rev: kind, tid: kind === 'results' ? key.slice(0, key.indexOf('|')) : null, tomb: false, commit: function () { meta[key] = { h: h, rh: h }; } });
        });
        if (!allowDelete) return;
        var keys = Object.keys(meta);
        if (kind === 'classes' && desired.size === 0 && keys.length >= 3) { S.meta[kind] = {}; delete S.meta.rev['t:classes']; S.again = true; return; }
        keys.forEach(function (key) {
            if (desired.has(key)) return;
            if (kind === 'classes' && meta[key] && meta[key].alias) return;   /* [CODE72] bản đã gộp: không xóa lớp của máy khác trên máy chủ */
            if ((kind === 'topics' || kind === 'folders') && !deletedHas(kind, key)) return;
            if (kind === 'results' && !resDeleted(key)) return;
            var up = {};
            up[dataPath(kind, key)] = null;
            if (kind !== 'pub' && kind !== 'pubfolders') up[tombPath(kind, key)] = { k: key, ts: SV };
            entries.push({ b: BASEOF[kind], up: up, size: 100, kind: kind, key: key, rev: kind, tid: kind === 'results' ? key.slice(0, key.indexOf('|')) : null, tomb: (kind !== 'pub' && kind !== 'pubfolders'), commit: function () { delete meta[key]; unmarkResDeleted(key); } });
        });
    }

    function sendEntries(entries) {
        if (!entries.length) return Promise.resolve(0);
        var byBase = { s: [], t: [] };
        entries.forEach(function (e) { if (byBase[e.b]) byBase[e.b].push(e); });
        var chain = Promise.resolve(), n = 0;
        /* [CODE60] Ưu tiên đẩy nhánh 's' (kết quả & đề giao học sinh) trước, và giảm kích thước mỗi gói xuống 800KB để không bị nghẽn */
        ['s', 't'].forEach(function (b) {
            var list = byBase[b]; if (!list.length) return;
            if (b === 't' && !S.cfg) return;
            var batches = [], cur = [], sz = 0;
            list.forEach(function (e) { if (cur.length && sz + e.size > 800000) { batches.push(cur); cur = []; sz = 0; } cur.push(e); sz += e.size; });
            if (cur.length) batches.push(cur);
            batches.forEach(function (batch, bi) {
                chain = chain.then(function () {
                    var body = {};
                    batch.forEach(function (e) { Object.keys(e.up).forEach(function (p) { body[p] = e.up[p]; }); });
                    if (bi === batches.length - 1) {
                        batch.forEach(function (e) {
                            if (e.rev === 'results') body['rev/results/' + enc(e.tid)] = SV; else body['rev/' + e.rev] = SV;
                            if (e.tomb) body['rev/del'] = SV;
                        });
                    }
                    return req('PATCH', b, '', body).then(function () { batch.forEach(function (e) { e.commit(); n++; }); });
                });
            });
        });
        return chain.then(function () { saveMeta(); return n; });
    }

    function pushTeacher() {
        var entries = [];
        collect('results', localMap('results'), entries, true);
        collect('pub', pubDesired(), entries, true);
        collect('pubfolders', pubFoldersDesired(), entries, true);
        if (S.cfg) {
            collect('topics', localMap('topics'), entries, true);
            collect('folders', localMap('folders'), entries, true);
            collect('classes', localMap('classes'), entries, true);
        }
        return sendEntries(entries);
    }
    function pushStudent() {
        var entries = [];
        collect('results', localMap('results'), entries, false);
        return sendEntries(entries);
    }

    /* ---------------- KÉO VỀ ---------------- */
    function parseEnv(env) { try { return JSON.parse(env.d); } catch (e) { return null; } }
    function revChanged(name, val) { return val !== undefined && val !== null && S.meta.rev[name] !== val; }

    function mergeClass(a, b) {
        var out = Object.assign({}, b);
        if (!out.subject && a && a.subject) out.subject = a.subject;   /* [CODE82] giữ môn học của lớp khi gộp */
        function nm(s) { return String(s && s.name || '').normalize('NFC').toLowerCase().replace(/\s+/g, ' ').trim(); }
        /* [CODE79] Học sinh đã bị xóa / đã rời lớp (dấu vết "removed") không được gộp ngược lại từ máy khác.
           Lọc TRƯỚC khi gộp để học sinh được thêm lại sau đó (id mới, addedAt mới hơn) vẫn được giữ. */
        var rmAll = [], rmSeen = {};
        (b.removed || []).concat(a.removed || []).forEach(function (t) {
            if (!t) return; var kk = (t.id || '') + '|' + (t.nm || '');
            if (rmSeen[kk] === undefined) { rmSeen[kk] = rmAll.length; rmAll.push(t); }
            else if ((t.ts || 0) > (rmAll[rmSeen[kk]].ts || 0)) rmAll[rmSeen[kk]] = t;
        });
        function stTs(s) { if (s && s.addedAt) return s.addedAt; var mm = /^st_([0-9a-z]{8})/.exec(String(s && s.id || '')); return mm ? (parseInt(mm[1], 36) || 0) : 0; }
        function alive(s) { var n0 = nm(s), t0 = stTs(s); return !rmAll.some(function (t) { return (t.id === s.id || (t.nm && t.nm === n0)) && (t.ts || 0) >= t0; }); }
        var st = (b.students || []).filter(alive), seenId = new Set(st.map(function (s) { return s.id; })), seenNm = new Set(st.map(nm));
        (a.students || []).filter(alive).forEach(function (s) { if (!seenId.has(s.id) && !seenNm.has(nm(s))) st.push(s); });
        if (rmAll.length) out.removed = rmAll.slice(-200);
        var as = (b.assignments || []).slice(), seenA = new Set(as.map(function (x) { return x.id; }));
        (a.assignments || []).forEach(function (x) { if (!seenA.has(x.id)) as.push(x); });
        /* [CODE72] Cùng một đề giao ở hai máy (khác mã) -> chỉ giữ bản giao mới nhất */
        var byT = {}, as2 = [];
        as.forEach(function (x) {
            var t = x && x.topicId; if (!t) { as2.push(x); return; }
            var p = byT[t];
            if (!p) { byT[t] = x; as2.push(x); }
            else if ((x.assignedAt || 0) > (p.assignedAt || 0)) { as2[as2.indexOf(p)] = x; byT[t] = x; }
        });
        out.students = st; out.assignments = as2;
        return out;
    }
    function resolve(kind, local, remote) {
        if (kind === 'classes') return mergeClass(local, remote);
        if ((local.updatedAt || 0) > (remote.updatedAt || 0)) return local;
        return remote;
    }

    function applyItem(kind, key, obj, ch) {
        if (kind === 'topics') {
            S.tTopics[enc(key)] = obj;
            var T = g('savedTopics'), i = T.findIndex(function (t) { return t && t.id === key; });
            if (i >= 0) T[i] = obj;
            else {
                var fk = topicFullKey(obj);
                var sameIdx = fk ? T.findIndex(function (t) { return t && topicFullKey(t) === fk; }) : -1;
                if (sameIdx < 0) T.push(obj);
                else if ((obj.updatedAt || 0) > (T[sameIdx].updatedAt || 0)) {
                    /* Giữ đề hiện tại nhưng nhớ đề cùng tên để gộp kết quả */
                    T[sameIdx].questions = obj.questions || T[sameIdx].questions;
                }
            }
            try { markTopicLocallyModified(key); } catch (e) { }
            var D = g('deletedTopicIds'); if (Array.isArray(D) && D.indexOf(key) >= 0) { (0, eval)('deletedTopicIds = deletedTopicIds.filter(function(x){return x!==' + JSON.stringify(key) + '})'); }
        } else if (kind === 'folders') {
            var F = g('libraryFolders'), j = F.findIndex(function (f) { return f && f.id === key; });
            if (j >= 0) F[j] = obj; else F.push(obj);
            var DF = g('deletedFolderIds'); if (Array.isArray(DF) && DF.indexOf(key) >= 0) { (0, eval)('deletedFolderIds = deletedFolderIds.filter(function(x){return x!==' + JSON.stringify(key) + '})'); }
        } else if (kind === 'classes') {
            var C = g('classesData'), k = C.findIndex(function (c) { return c && c.id === key; });
            if (!Array.isArray(obj.students)) obj.students = []; if (!Array.isArray(obj.assignments)) obj.assignments = [];
            if (k >= 0) C[k] = obj;
            else {
                /* [CODE72] Lớp cùng tên (tạo riêng ở máy khác / trang GitHub) -> gộp vào lớp hiện có thay vì tạo lớp trùng */
                var kk = C.findIndex(function (c) {
                    if (!c || c.id === key || normStr(c.name) !== normStr(obj.name)) return false;
                    var g1 = normStr(c.grade), g2 = normStr(obj.grade);
                    return !g1 || !g2 || g1 === g2;
                });
                if (kk >= 0) {
                    var mg = mergeClass(C[kk], obj); mg.id = C[kk].id; C[kk] = mg;
                    S.lastAlias = mg.id; S.dirty = true; ch[kind] = true; return;
                }
                C.push(obj);
            }
        } else if (kind === 'results') {
            var tid = key.slice(0, key.indexOf('|')), R = g('studentResultsByTopic');
            if (!Array.isArray(R[tid])) R[tid] = [];
            var x = R[tid].findIndex(function (r) { return r && r.id === obj.id; });
            if (x >= 0) R[tid][x] = obj; else { R[tid].push(obj); ch.newRes = (ch.newRes || 0) + 1; }
            R[tid].sort(function (a, b) { return (b.submittedTs || 0) - (a.submittedTs || 0); });
        }
        ch[kind] = true;
    }
    function removeItem(kind, key, ch) {
        if (kind === 'topics') {
            var T = g('savedTopics'); var i = T.findIndex(function (t) { return t && t.id === key; }); if (i >= 0) T.splice(i, 1);
            (0, eval)('deletedTopicIds = Array.from(new Set(deletedTopicIds.concat([' + JSON.stringify(key) + '])))');
        } else if (kind === 'folders') {
            var F = g('libraryFolders'); var j = F.findIndex(function (f) { return f && f.id === key; }); if (j >= 0) F.splice(j, 1);
            (0, eval)('deletedFolderIds = Array.from(new Set(deletedFolderIds.concat([' + JSON.stringify(key) + '])))');
        } else if (kind === 'classes') {
            var C = g('classesData'); var k = C.findIndex(function (c) { return c && c.id === key; }); if (k >= 0) C.splice(k, 1);
        } else if (kind === 'results') {
            var tid = key.slice(0, key.indexOf('|')), rid = key.slice(key.indexOf('|') + 1), R = g('studentResultsByTopic');
            if (Array.isArray(R[tid])) R[tid] = R[tid].filter(function (r) { return !(r && r.id === rid); });
        }
        ch[kind] = true;
    }

    function processKind(kind, remote, tomb, ch) {
        var meta = S.meta[kind] || (S.meta[kind] = {});
        var local = localMap(kind);
        Object.keys(remote || {}).forEach(function (ek) {
            var env = remote[ek]; if (!env || !env.k || typeof env.d !== 'string') return;
            var key = env.k, lo = local.get(key), m = meta[key];
            if (!lo) {
                if (deletedHas(kind, key)) return;
                if (kind === 'classes' && m && m.alias) {
                    /* [CODE72] Lớp này đã được gộp vào lớp cùng tên ở máy này: mỗi lần bản kia thay đổi thì gộp lại */
                    if (m.rh === env.h) return;
                    var oa = parseEnv(env); if (!oa) return;
                    if (!local.get(m.alias)) { delete meta[key]; return; }
                    S.lastAlias = null; applyItem(kind, key, oa, ch);
                    meta[key] = { h: m.h, rh: env.h, alias: m.alias }; return;
                }
                if (m && kind !== 'topics' && kind !== 'folders' && !(kind === 'results' && !resDeleted(key))) return;
                var o = parseEnv(env); if (!o) return;
                S.lastAlias = null;
                applyItem(kind, key, o, ch);
                meta[key] = { h: hash(JSON.stringify(o)), rh: env.h };
                if (kind === 'classes' && S.lastAlias) meta[key].alias = S.lastAlias;
                return;
            }
            if (kind === 'results' && lo && !lo.detail) {
                S.detailTried = S.detailTried || {};
                if (!S.detailTried[key]) { S.detailTried[key] = 1; var ro0 = parseEnv(env); if (ro0 && ro0.detail) { applyItem(kind, key, ro0, ch); meta[key] = { h: hash(JSON.stringify(ro0)), rh: env.h }; return; } }
            }
            if (m && m.rh === env.h) return;
            var lh = hash(JSON.stringify(lo));
            if (lh === env.h) { meta[key] = { h: lh, rh: env.h }; return; }
            var ro = parseEnv(env); if (!ro) return;
            var localChanged = !m || lh !== m.h;
            if (!localChanged) { applyItem(kind, key, ro, ch); meta[key] = { h: hash(JSON.stringify(ro)), rh: env.h }; return; }
            var win = resolve(kind, lo, ro);
            S.dirty = true;
            if (win === ro) { applyItem(kind, key, ro, ch); meta[key] = { h: hash(JSON.stringify(ro)), rh: env.h }; }
            else {
                if (win !== lo) applyItem(kind, key, win, ch);
                meta[key] = { h: '', rh: env.h };
            }
        });
        Object.keys(tomb || {}).forEach(function (ek) {
            var tb = tomb[ek]; if (!tb || !tb.k) return;
            var key = tb.k, lo = local.get(key), m = meta[key];
            if (!lo) { delete meta[key]; return; }
            if (!m) {
                if ((kind === 'topics' || kind === 'folders') && (lo.updatedAt || 0) <= (tb.ts || 0)) { removeItem(kind, key, ch); }
                return;
            }
            if (hash(JSON.stringify(lo)) === m.h) { removeItem(kind, key, ch); delete meta[key]; }
        });
    }

    function pullTeacher() {
        var ch = {};
        S.pullErr = null;
        var pT = S.cfg ? req('GET', 't', 'rev').catch(function () { return {}; }) : Promise.resolve({});
        var pS = req('GET', 's', 'rev').catch(function () { return {}; });
        return Promise.all([pT, pS]).then(function (revs) {
            var rt = revs[0] || {}, rs = revs[1] || {};
            var needDelT = S.cfg && revChanged('t:del', rt.del), needDelS = revChanged('s:del', rs.del);
            var delT = null, delS = null;
            var p0 = needDelT ? req('GET', 't', 'del').then(function (d) { delT = d || {}; }, function () { }) : Promise.resolve();
            var p1 = needDelS ? req('GET', 's', 'del').then(function (d) { delS = d || {}; }, function () { }) : Promise.resolve();
            return Promise.all([p0, p1]).then(function () {
                var jobs = [];
                if (S.cfg) {
                    ['topics', 'folders', 'classes'].forEach(function (kind) {
                        /* [CODE74] Phục hồi khi localStorage bị xóa/không đầy đủ nhưng metadata đồng bộ cũ vẫn còn.
                           Trước đây chỉ nhìn revision Firebase; nếu revision không đổi, máy mới hoặc máy bị mất
                           dữ liệu sẽ bỏ qua GET và tiếp tục hiển thị danh sách rỗng. */
                        var localCount = localMap(kind).size;
                        var expectedCount = Number((S.meta.localCount || {})[kind] || 0);
                        var recoveryRev = (S.meta.recoveryRev || {})[kind];
                        var needsRecovery = localCount < expectedCount ||
                            (localCount === 0 && rt[kind] !== undefined && recoveryRev !== rt[kind]);
                        if (revChanged('t:' + kind, rt[kind]) || needDelT || needsRecovery) {
                            jobs.push(function () {
                                return req('GET', 't', kind).then(function (remote) {
                                    var tomb = delT ? (delT[kind] || {}) : {};
                                    processKind(kind, remote || {}, tomb, ch);
                                    if (rt[kind] !== undefined) S.meta.rev['t:' + kind] = rt[kind];
                                    S.meta.localCount = S.meta.localCount || {};
                                    S.meta.recoveryRev = S.meta.recoveryRev || {};
                                    S.meta.localCount[kind] = localMap(kind).size;
                                    if (rt[kind] !== undefined) S.meta.recoveryRev[kind] = rt[kind];
                                }, function (e) {
                                    /* [CODE75] Không cập nhật revision khi GET thất bại, nhưng KHÔNG chặn các nhánh khác và việc đẩy đề/kết quả lên máy chủ */
                                    S.pullErr = S.pullErr || e;
                                });
                            });
                        }
                    });
                }
                /* [CODE60] Luôn đọc s/pub để vừa nạp đề đã giao về máy GitHub, vừa biết tên các đề tương ứng với kết quả */
                if (revChanged('s:pub', rs.pub) || S.meta.pub === undefined || !Object.keys(S.pubTopics).length) {
                    jobs.push(function () {
                        return req('GET', 's', 'pub').then(function (pub) {
                            var old = S.meta.pub || {}, pm = {}, T = g('savedTopics');
                            Object.keys(pub || {}).forEach(function (e) {
                                var env = pub[e]; if (!env || !env.k) return;
                                pm[env.k] = old[env.k] || { h: env.h, rh: env.h };
                                var o = parseEnv(env);
                                if (o && o.id) {
                                    S.pubTopics[enc(o.id)] = o;
                                    if (!deletedHas('topics', o.id) && Array.isArray(T)) {
                                        var idx = T.findIndex(function (t) { return t && t.id === o.id; });
                                        var fk = topicFullKey(o);
                                        var sameIdx = fk ? T.findIndex(function (t) { return t && topicFullKey(t) === fk; }) : -1;
                                        if (idx < 0 && sameIdx < 0) { T.push(o); ch.topics = true; }
                                    }
                                }
                            });
                            S.meta.pub = pm;
                            if (rs.pub !== undefined) S.meta.rev['s:pub'] = rs.pub;
                        }, function () { });
                    });
                }
                var resRev = rs.results || {};
                Object.keys(resRev).forEach(function (etid) {
                    if (revChanged('s:results:' + etid, resRev[etid]) || needDelS) {
                        jobs.push(function () {
                            return req('GET', 's', 'results/' + etid).then(function (remote) {
                                var flat = {};
                                Object.keys(remote || {}).forEach(function (er) { var env = remote[er]; if (env && env.k) flat[er] = env; });
                                var tomb = {};
                                if (delS && delS.results) Object.keys(delS.results).forEach(function (ek) { var tb = delS.results[ek]; if (tb && tb.k && tb.k.slice(0, tb.k.indexOf('|')) && enc(tb.k.slice(0, tb.k.indexOf('|'))) === etid) tomb[ek] = tb; });
                                processKind('results', flat, tomb, ch);
                                S.meta.rev['s:results:' + etid] = resRev[etid];
                            }, function () { });
                        });
                    }
                });
                if (delS && delS.results) {
                    jobs.push(function () { processKind('results', {}, delS.results, ch); return Promise.resolve(); });
                }
                var chain = Promise.resolve();
                jobs.forEach(function (j) { chain = chain.then(j); });
                return chain;
            }).then(function () {
                if (needDelT && rt.del !== undefined) S.meta.rev['t:del'] = rt.del;
                if (needDelS && rs.del !== undefined) S.meta.rev['s:del'] = rs.del;
                unifySameTitleResults(ch);
            });
        }).then(function () { return ch; });
    }

    function pullStudent() {
        var ch = {};
        return req('GET', 's', 'rev').then(function (rs) {
            rs = rs || {};
            var T0 = g('savedTopics') || [], seen0 = S.meta.stuPubSeen || {};
            /* [CODE75] Nếu bộ nhớ máy bị thiếu đề đã tải trước đó thì tải lại, không chỉ nhìn số hiệu phiên bản */
            var missing = Object.keys(seen0).some(function (id) { return !T0.some(function (t) { return t && t.id === id; }); });
            var F0 = g('libraryFolders') || [], fseen0 = S.meta.stuFolSeen || {};
            var fmissing = Object.keys(fseen0).some(function (id) { return !F0.some(function (f) { return f && f.id === id; }); });
            var chain = Promise.resolve();
            if (revChanged('s:pub', rs.pub) || !S.meta.stuPubSeen || missing) {
                chain = chain.then(function () {
                    return req('GET', 's', 'pub?cb=' + Date.now()).then(function (pub) {
                        pub = pub || {};
                        var T = g('savedTopics'), seen = {};
                        Object.keys(pub).forEach(function (e) {
                            var env = pub[e]; if (!env || !env.k) return;
                            var o = parseEnv(env); if (!o || !o.id) return;
                            seen[o.id] = true;
                            S.pubTopics[enc(o.id)] = o;
                            var i = T.findIndex(function (t) { return t && t.id === o.id; });
                            if (i < 0) { T.push(o); ch.topics = true; }
                            else if ((o.updatedAt || 0) >= (T[i].updatedAt || 0) && JSON.stringify(T[i]) !== env.d) { T[i] = o; ch.topics = true; }
                        });
                        var prev = S.meta.stuPubSeen || {};
                        Object.keys(prev).forEach(function (id) {
                            if (!seen[id]) {
                                var i = T.findIndex(function (t) { return t && t.id === id; });
                                if (i >= 0 && !(S.meta.topics && S.meta.topics[id])) { T.splice(i, 1); ch.topics = true; }
                            }
                        });
                        S.meta.stuPubSeen = seen;
                        if (rs.pub !== undefined) S.meta.rev['s:pub'] = rs.pub;
                    });
                });
            }
            if (revChanged('s:pubfolders', rs.pubfolders) || !S.meta.stuFolSeen || fmissing) {
                chain = chain.then(function () {
                    return req('GET', 's', 'pubfolders?cb=' + Date.now()).then(function (data) {
                        data = data || {};
                        var F = g('libraryFolders'), seen = {};
                        Object.keys(data).forEach(function (e) {
                            var env = data[e]; if (!env || !env.k) return;
                            var o = parseEnv(env); if (!o || !o.id) return;
                            seen[o.id] = true;
                            var i = F.findIndex(function (f) { return f && f.id === o.id; });
                            if (i < 0) { F.push(o); ch.folders = true; }
                            else if (JSON.stringify(F[i]) !== JSON.stringify(o)) { F[i] = o; ch.folders = true; }
                        });
                        var prev = S.meta.stuFolSeen || {};
                        Object.keys(prev).forEach(function (id) {
                            if (!seen[id]) { var i = F.findIndex(function (f) { return f && f.id === id; }); if (i >= 0) { F.splice(i, 1); ch.folders = true; } }
                        });
                        S.meta.stuFolSeen = seen;
                        if (rs.pubfolders !== undefined) S.meta.rev['s:pubfolders'] = rs.pubfolders;
                    });
                });
            }
            return chain;
        }).then(function () { return ch; });
    }

    /* [CODE75] Thanh trạng thái của học sinh trong Thư viện: số đề, giờ cập nhật, mã kho; nút cập nhật; ô dán mã khi chưa kết nối */
    function storeId() { var c = effStu(); return c ? hash(c.u + '|' + c.p).slice(0, 6) : ''; }
    function stuLine() {
        var i = S.stuInfo || {};
        if (i.err) return '⚠️ Chưa cập nhật được (' + esc(i.err) + '). Bấm “Cập nhật đề” để thử lại. • kho ' + storeId();
        if (!i.ts) return '⏳ Đang tải đề từ máy chủ... • kho ' + storeId();
        return '☁️ Đã cập nhật lúc ' + fmtTime(i.ts) + ' • ' + (i.topics || 0) + ' đề đã xuất bản • kho ' + storeId();
    }
    function updateStuLine() { var el = $('stu-sync-line'); if (el) el.innerHTML = stuLine(); }
    function studentBannerHtml() {
        if (!isStu()) return '';
        var box = 'margin:0 0 12px 0;padding:10px 14px;border-radius:14px;font-weight:800;font-size:14px;line-height:1.5;';
        if (!effStu()) {
            return '<div style="' + box + 'background:#fffbeb;border:2px solid #f59e0b;color:#92400e">⚠️ Máy này chưa kết nối với giáo viên nên có thể <u>không thấy đề mới</u>. Hãy mở link/QR giáo viên gửi, hoặc dán link/mã (bắt đầu bằng <b>MQC1.</b>) vào ô dưới:' +
                '<textarea id="stu-code" rows="2" style="width:100%;margin-top:6px;border:2px solid #fbbf24;border-radius:10px;padding:6px 10px;font-weight:700;font-size:13px" placeholder="Dán link hoặc mã MQC1..."></textarea>' +
                '<button type="button" onclick="CloudSync.studentConnect()" style="margin-top:6px;padding:8px 20px;border-radius:10px;font-weight:900;color:#fff;background:#059669">Kết nối</button><span id="stu-conn-msg" style="margin-left:10px;color:#b91c1c"></span></div>';
        }
        /* [CODE77] Đã kết nối: không hiện thanh trạng thái nữa (máy tự đồng bộ nền). Chỉ cảnh báo khi chưa kết nối. */
        return '';
    }
    function studentRefresh() {
        S.meta.rev = {}; delete S.meta.stuPubSeen; delete S.meta.stuFolSeen;
        S.stuInfo = {}; updateStuLine();
        S.remoteCfgBusy = false; fetchRemoteConfig();
        clearTimeout(S.timer); S.dirty = true; sync();
    }
    function studentConnect() {
        var el = $('stu-code'), v = el ? el.value : '';
        if (setStudentToken(v)) { try { if (typeof window.renderLibraryList === 'function') window.renderLibraryList(); } catch (e) { } }
        else { var m = $('stu-conn-msg'); if (m) m.textContent = 'Mã/link không hợp lệ.'; }
    }

    /* ---------------- áp dụng & vẽ lại giao diện ---------------- */
    var orig = {};
    function persist(ch) {
        S.applying = true;
        try {
            if (ch.topics && orig.saveToStorage) orig.saveToStorage();
            if (ch.folders && orig.saveFolders) orig.saveFolders();
            if (ch.classes && orig.cmSave) orig.cmSave();
            if (ch.results && orig.saveStudentResultsToStorage) orig.saveStudentResultsToStorage();
        } catch (e) { }
        S.applying = false;
    }
    function refreshUI(ch) {
        try {
            if (typeof window.renderLibraryList === 'function' && (ch.topics || ch.folders || ch.results)) window.renderLibraryList();
            var cm = $('class-modal');
            if ((ch.classes || ch.results) && typeof window.cmRender === 'function' && cm && !cm.classList.contains('hidden')) window.cmRender();
            var rm = $('results-modal');
            if (ch.results && typeof window.renderResultsModalContent === 'function' && rm && !rm.classList.contains('hidden')) repaintResults();
            if (typeof window.updateLibraryCountersUI === 'function') window.updateLibraryCountersUI();
        } catch (e) { }
    }

    /* ---------------- vòng đồng bộ ---------------- */
    function schedule(fast, noDirty) {
        if (!noDirty) S.dirty = true;
        if (!(teacherReady() || studentReady())) return;
        if (S.applying) return;
        clearTimeout(S.timer);
        S.timer = setTimeout(function () { sync(); }, fast ? 400 : 1500);
        updateBtn();
    }
    function resDeleted(key) { return ((S.meta && S.meta.delRes) || []).indexOf(key) >= 0; }
    function unmarkResDeleted(key) { var a = (S.meta && S.meta.delRes) || [], i = a.indexOf(key); if (i >= 0) a.splice(i, 1); }
    function noteResultDeleted(tid, rid) {
        if (!S.meta) return;
        if (!S.meta.delRes) S.meta.delRes = [];
        var k = tid + '|' + rid; if (S.meta.delRes.indexOf(k) < 0) S.meta.delRes.push(k);
        saveMeta(); S.dirty = true; schedule(true);
    }

    function repaintResults() {
        try {
            var rm = $('results-modal');
            if (rm && !rm.classList.contains('hidden') && typeof window.renderResultsModalContent === 'function') {
                window.renderResultsModalContent();
                var container = $('results-list-container');
                if (container && S.hint && S.hint.showBanner && !$('cloud-results-banner')) {
                    var div = document.createElement('div');
                    div.id = 'cloud-results-banner';
                    div.innerHTML = hintHtml();
                    container.insertBefore(div, container.firstChild);
                }
            }
        } catch (e) { }
    }

    function hintHtml() {
        if (isStu()) return '';
        var box = function (c, inner, isRaw) {
            return '<div id="cloud-results-banner" style="margin:12px auto;max-width:780px;padding:12px 16px;border-radius:14px;text-align:left;font-weight:700;font-size:14px;line-height:1.55;white-space:pre-wrap;' + c + '">' + (isRaw ? inner : esc(inner)) + '</div>';
        };
        var where = (location.protocol === 'file:') ? 'file trên máy tính' : location.host;
        if (!teacherReady()) return box('background:#fef2f2;color:#b91c1c;border:2px solid #fca5a5', '⚠️ Nơi này (' + where + ') CHƯA bật ĐỒNG BỘ nên không nhận được kết quả của học sinh.\nHãy vào: Thư viện → ☁️ ĐỒNG BỘ → dán "Mã kết nối" lấy từ máy đã bật đồng bộ.');
        if (S.hintBusy) return box('background:#eff6ff;color:#1d4ed8;border:2px solid #93c5fd', '⏳ Đang hỏi máy chủ & đối chiếu kết quả...');
        if (S.hint) {
            var st = S.hint.ok ? 'background:#ecfdf5;color:#047857;border:2px solid #6ee7b7' : 'background:#fffbeb;color:#92400e;border:2px solid #fcd34d';
            if (S.hint.rawHtml) return box(st, S.hint.rawHtml, true);
            return box(st, S.hint.text, false);
        }
        return '';
    }

    /* [CODE60] Gộp kết quả từ 1 nhánh khác mã (etid) trên máy chủ vào đề hiện tại (targetTid) chỉ với 1 cú bấm */
    function adoptOrphanResults(etid, targetTid) {
        if (!etid || !targetTid) return;
        var T = arr('savedTopics'), curTopic = T.find(function (t) { return t && t.id === targetTid; });
        var cached = S.orphanCache[etid];
        var p = cached ? Promise.resolve(cached) : req('GET', 's', 'results/' + etid).then(function (remote) {
            var recs = [];
            Object.keys(remote || {}).forEach(function (er) { var env = remote[er]; if (env && env.d) { var o = parseEnv(env); if (o) recs.push(o); } });
            return recs;
        });
        p.then(function (recs) {
            var added = 0;
            (recs || []).forEach(function (r) {
                if (mergeResultRecordIntoTopic(targetTid, r, curTopic)) added++;
            });
            var ch = { results: true, newRes: added };
            persist(ch); saveMeta(); S.dirty = true;
            S.hint = { ok: true, text: '✅ Đã gộp thành công ' + recs.length + ' kết quả vào đề "' + (curTopic ? curTopic.subtitle : targetTid) + '"!' };
            repaintResults(); refreshUI(ch);
            schedule(true);
            toast('✅ Đã gộp ' + recs.length + ' kết quả học sinh vào đề này!');
        }).catch(function (e) {
            toast('⚠️ Lỗi khi gộp kết quả: ' + msgOf(e));
        });
    }

    /* [CODE60] Hỏi máy chủ NGAY về kết quả của đề đang mở + Tự động tìm & gộp kết quả từ các bản sao cùng tên của đề */
    function refreshResultsNow(tid) {
        if (!tid || isStu()) return Promise.resolve();
        if (!teacherReady()) { S.hint = null; repaintResults(); return Promise.resolve(); }
        S.hintBusy = true; S.hint = null; repaintResults();
        var etid = enc(tid), T = arr('savedTopics');
        var curTopic = T.find(function (x) { return x && x.id === tid; });
        var curTitleKey = topicTitleKey(curTopic);

        /* Đảm bảo đã có danh sách đề trên s/pub và t/topics để đối chiếu tên đề chính xác */
        var prepPub = Object.keys(S.pubTopics).length ? Promise.resolve() : req('GET', 's', 'pub').then(function (pub) {
            Object.keys(pub || {}).forEach(function (k) { var o = pub[k] && parseEnv(pub[k]); if (o && o.id) S.pubTopics[enc(o.id)] = o; });
        }, function () { });
        var prepT = (S.cfg && !Object.keys(S.tTopics).length) ? req('GET', 't', 'topics').then(function (tp) {
            Object.keys(tp || {}).forEach(function (k) { var o = tp[k] && parseEnv(tp[k]); if (o && o.id) S.tTopics[enc(o.id)] = o; });
        }, function () { }) : Promise.resolve();

        return Promise.all([prepPub, prepT]).then(function () {
            return req('GET', 's', 'results?shallow=true');
        }).then(function (tops) {
            var allEtids = Object.keys(tops || {});
            if (allEtids.indexOf(etid) < 0) allEtids.unshift(etid);
            var autoMerged = 0, directCount = 0, otherBranches = [];

            return allEtids.reduce(function (chain, e) {
                return chain.then(function () {
                    return req('GET', 's', 'results/' + e).then(function (remote) {
                        var flat = {}, recs = [];
                        Object.keys(remote || {}).forEach(function (er) {
                            var env = remote[er];
                            if (env && env.k) {
                                flat[er] = env;
                                var o = parseEnv(env);
                                if (o) recs.push(o);
                            }
                        });
                        if (!recs.length) return;
                        var ch = {};
                        processKind('results', flat, {}, ch);

                        if (e === etid) {
                            directCount += recs.length;
                            return;
                        }

                        /* Kiểm tra xem nhánh e có cùng tên chủ đề với đề đang mở (curTopic) không */
                        var knownTopic = T.find(function (x) { return x && enc(x.id) === e; }) || S.pubTopics[e] || S.tTopics[e];
                        var sampleWithTitle = recs.find(function (r) { return r && r.topicTitle; });
                        var branchTitle = knownTopic ? knownTopic.subtitle : (sampleWithTitle ? sampleWithTitle.topicTitle : '');
                        var branchTitleKey = normStr(branchTitle);

                        if (curTitleKey && branchTitleKey && curTitleKey === branchTitleKey) {
                            /* TRÙNG TÊN ĐỀ -> Tự động gộp ngay vào đề đang mở! */
                            recs.forEach(function (r) {
                                if (mergeResultRecordIntoTopic(tid, r, curTopic)) autoMerged++;
                            });
                            directCount += recs.length;
                            return;
                        }

                        S.orphanCache[e] = recs;
                        otherBranches.push({
                            etid: e,
                            title: branchTitle,
                            inLib: !!T.find(function (x) { return x && enc(x.id) === e; }),
                            count: recs.length,
                            recs: recs
                        });
                    }, function () { });
                });
            }, Promise.resolve()).then(function () {
                var chAll = { results: true };
                unifySameTitleResults(chAll);
                persist(chAll); saveMeta(); refreshUI(chAll);
                if (autoMerged > 0) S.dirty = true;

                var localList = (g('studentResultsByTopic') || {})[tid] || [];
                if (localList.length > 0 && autoMerged > 0) {
                    S.hint = { ok: true, showBanner: true, text: '☁️ Đã tự động đồng bộ & hợp nhất ' + localList.length + ' kết quả của đề "' + (curTopic ? curTopic.subtitle : tid) + '" từ máy chủ!' };
                    schedule(true);
                    return;
                }
                if (localList.length > 0 && !otherBranches.length) {
                    S.hint = { ok: true, text: '☁️ Máy chủ có ' + localList.length + ' kết quả của đề này.' };
                    return;
                }
                if (!otherBranches.length && localList.length === 0) {
                    S.hint = { ok: false, text: 'Máy chủ CHƯA nhận được kết quả nào của học sinh.\nKiểm tra: học sinh phải mở đề bằng link/QR do giáo viên tạo SAU KHI bật ĐỒNG BỘ; nộp bài xong màn hình điểm báo "Đã gửi kết quả cho giáo viên".' };
                    return;
                }

                /* Xây dựng giao diện cho phép gộp 1 chạm đối với các nhánh khác mã đề */
                var orphanFirst = otherBranches.filter(function (b) { return !b.inLib; });
                var inLibBranches = otherBranches.filter(function (b) { return b.inLib; });
                var html = '<div style="font-weight:900;font-size:15px;margin-bottom:6px;color:#92400e">🔍 Phát hiện kết quả học sinh trên máy chủ (nếu có bài của đề này bị lệch mã đề, bấm "📥 Gộp vào đề này" để đưa vào bảng):</div>';
                var renderRow = function (b) {
                    var names = b.recs.slice(0, 3).map(function (r) {
                        return esc((r.studentName || 'HS') + (r.studentClass ? ' (' + r.studentClass + ')' : ''));
                    }).join(', ');
                    if (b.recs.length > 3) names += ' (+' + (b.recs.length - 3) + ' HS)';
                    var latest = b.recs[0] && b.recs[0].submittedAt ? ' • ' + esc(b.recs[0].submittedAt) : '';
                    var label = b.title ? ('<b>' + esc(b.title) + '</b>') : '<b style="color:#dc2626">(Đề khác mã trên máy chủ)</b>';
                    return '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:7px 10px;margin:5px 0;background:#fff;border:1.5px solid #fde68a;border-radius:10px">' +
                        '<div style="flex:1;min-width:220px;font-size:13.5px;line-height:1.4">• ' + label + ': <b>' + b.count + ' kết quả</b><br><span style="color:#475569;font-weight:600">👤 ' + names + latest + '</span></div>' +
                        '<button type="button" onclick="CloudSync.adoptOrphanResults(\'' + esc(b.etid) + '\',\'' + esc(tid) + '\')" style="padding:6px 12px;border-radius:9px;background:linear-gradient(90deg,#059669,#0d9488);color:#fff;font-weight:900;font-size:12.5px;border:0;cursor:pointer;white-space:nowrap">📥 Gộp ' + b.count + ' kết quả vào đề này</button>' +
                        '</div>';
                };
                orphanFirst.forEach(function (b) { html += renderRow(b); });
                if (inLibBranches.length) {
                    html += '<details style="margin-top:6px"><summary style="cursor:pointer;font-weight:800;font-size:13px;color:#b45309">📂 Xem thêm ' + inLibBranches.length + ' đề khác đã có trong Thư viện</summary>';
                    inLibBranches.forEach(function (b) { html += renderRow(b); });
                    html += '</details>';
                }
                S.hint = { ok: false, showBanner: localList.length === 0, rawHtml: html };
            });
        }).catch(function (e) { S.hint = { ok: false, text: '⚠️ ' + msgOf(e) }; }).then(function () { S.hintBusy = false; repaintResults(); });
    }

    function checkServer() {
        if (!teacherReady()) return Promise.resolve();
        S.diag = 'Đang kiểm tra máy chủ...'; renderModal();
        return req('GET', 's', 'results?shallow=true').then(function (tops) {
            tops = tops || {};
            var ids = Object.keys(tops), local = localMap('results'), lc = {}, lines = [], total = 0, miss = 0;
            local.forEach(function (v, k) { var e = enc(k.slice(0, k.indexOf('|'))); lc[e] = (lc[e] || 0) + 1; });
            var T = arr('savedTopics'), title = function (e) {
                var f = T.filter(function (x) { return x && enc(x.id) === e; })[0] || S.pubTopics[e] || S.tTopics[e];
                return f ? f.subtitle : ('Mã đề: ' + e);
            };
            return ids.reduce(function (p, e) {
                return p.then(function () {
                    return req('GET', 's', 'results/' + e + '?shallow=true').then(function (r) {
                        var n = Object.keys(r || {}).length, l = lc[e] || 0; total += n; if (n > l) miss += n - l;
                        lines.push('• ' + title(e) + ': máy chủ ' + n + ' | máy này ' + l);
                    });
                });
            }, Promise.resolve()).then(function () {
                var head = total === 0
                    ? 'Máy chủ CHƯA nhận được kết quả nào của học sinh.'
                    : (miss > 0 ? 'Máy chủ có ' + total + ' kết quả, còn ' + miss + ' kết quả CHƯA gộp về máy này → bấm "Tải & Gộp tất cả kết quả về máy".' : 'Máy chủ có ' + total + ' kết quả, máy này đã đồng bộ đủ.');
                S.diag = head + (lines.length ? '\n' + lines.join('\n') : '');
                renderModal();
            });
        }).catch(function (e) { S.diag = '⚠️ ' + msgOf(e); renderModal(); });
    }
    function pullAllResults() {
        if (!teacherReady()) return;
        S.meta.rev = {}; S.meta.results = {}; S.detailTried = {}; saveMeta();
        S.diag = 'Đang tải & hợp nhất toàn bộ kết quả về máy...'; renderModal();
        req('GET', 's', 'results?shallow=true').then(function (tops) {
            var ids = Object.keys(tops || {}), ch = {};
            return ids.reduce(function (p, e) {
                return p.then(function () {
                    return req('GET', 's', 'results/' + e).then(function (remote) {
                        var flat = {};
                        Object.keys(remote || {}).forEach(function (er) { var env = remote[er]; if (env && env.k) flat[er] = env; });
                        processKind('results', flat, {}, ch);
                    }, function () { });
                });
            }, Promise.resolve()).then(function () {
                unifySameTitleResults(ch);
                persist(ch); saveMeta(); refreshUI(ch);
                return checkServer();
            });
        });
    }

    function msgOf(e) { return (e && e.message) || String(e || 'Lỗi không xác định'); }
    function sync() {
        if (!(teacherReady() || studentReady())) { updateBtn(); return Promise.resolve(); }
        if (S.busy) { S.again = true; return Promise.resolve(); }
        S.busy = true; updateBtn();
        var p = isStu() ? syncStudent() : syncTeacher();
        return p.then(function () {
            S.busy = false; updateBtn(); refreshModal();
            try { if (!isStu() && window.ClassNet && ClassNet.onSyncDone) ClassNet.onSyncDone(); } catch (e) { }
            if (S.again) { S.again = false; schedule(true, true); }
        });
    }
    function syncStudent() {
        var doPush = S.dirty; S.dirty = false;
        var step1 = Promise.resolve();
        if (doPush) {
            step1 = pushStudent().then(function (n) {
                S.lastOk = Date.now(); S.lastErr = '';
                if (S.res.state === 'sending' || S.res.state === 'error') resultState('sent');
                if (n > 0) toast('☁️ Đã gửi kết quả bài làm cho giáo viên');
            }, function (e) {
                S.dirty = true; S.lastErr = msgOf(e);
                resultState('error', (navigator.onLine === false) ? 'Máy đang không có mạng.' : msgOf(e));
            });
        }
        return step1.then(function () {
            return pullStudent().then(function (ch) {
                persist(ch); refreshUI(ch); saveMeta();
                var T = g('savedTopics') || [];
                S.stuInfo = { ts: Date.now(), topics: T.filter(function (t) { return t && t.isPublished; }).length, err: '' };
                S.lastPullTs = Date.now();
                updateStuLine();
            }, function (e) { S.stuInfo = Object.assign({}, S.stuInfo || {}, { err: msgOf(e) }); updateStuLine(); });
        }).then(function () { saveMeta(); });
    }
    function syncTeacher() {
        var doPush = false;
        return waitLocal()
            .then(function () { return pullTeacher(); })
            .then(function (ch) {
                persist(ch); refreshUI(ch); saveMeta();
                if (ch.newRes && S.lastOk) toast('📥 Có ' + ch.newRes + ' kết quả mới từ học sinh');
                doPush = S.dirty; S.dirty = false;
                if (!doPush) return 0;
                return pushTeacher();
            })
            .then(function () {
                if (S.pullErr) { var pe = S.pullErr; S.pullErr = null; throw pe; }
                S.lastOk = Date.now(); S.lastErr = '';
            })
            .catch(function (e) {
                S.lastErr = msgOf(e);
                if (doPush || S.dirty === false) S.dirty = true;
            });
    }

    S.res = { state: 'idle', msg: '', ts: 0 };
    function resInner() {
        var st = S.res.state, b = function (t) { return '<div style="font-weight:800;font-size:14px;line-height:1.45">' + t + '</div>'; };
        if (st === 'sending') return b('⏳ Đang gửi kết quả cho giáo viên...');
        if (st === 'sent') return b('✅ Đã gửi kết quả cho giáo viên (' + fmtTime(S.res.ts) + ')');
        if (st === 'nolink') return b('⚠️ Thiết bị này chưa có liên kết gửi kết quả (hãy mở đề bằng link / QR do giáo viên gửi). Em hãy gửi <u>Mã nộp bài</u> bên dưới cho giáo viên.');
        if (st === 'error') return b('⚠️ Chưa gửi được: ' + esc(S.res.msg) + ' Máy sẽ tự gửi lại. ') +
            '<button type="button" onclick="CloudSync.retry()" style="margin-top:6px;padding:7px 16px;border-radius:12px;font-weight:900;font-size:13px;color:#fff;background:#dc2626;text-transform:uppercase">Gửi lại ngay</button>' +
            b('<span style="font-weight:700">Nếu vẫn lỗi, em gửi <u>Mã nộp bài</u> bên dưới cho giáo viên.</span>');
        return '';
    }
    function resColor() { var s = S.res.state; return s === 'sent' ? 'background:#ecfdf5;color:#047857;border:2px solid #6ee7b7' : (s === 'sending' ? 'background:#eff6ff;color:#1d4ed8;border:2px solid #93c5fd' : 'background:#fef2f2;color:#b91c1c;border:2px solid #fca5a5'); }
    function paintStatus() { var el = $('cloud-send-status'); if (!el) return; el.innerHTML = resInner(); el.style.cssText = S.res.state === 'idle' ? 'display:none' : 'margin-top:12px;max-width:560px;width:100%;padding:10px 14px;border-radius:14px;text-align:center;' + resColor(); }
    function resultState(st, msg) { S.res.state = st; S.res.msg = msg || ''; if (st === 'sent') S.res.ts = Date.now(); paintStatus(); }
    function statusHtml() {
        if (!isStu()) return '';
        return '<div id="cloud-send-status" style="' + (S.res.state === 'idle' ? 'display:none' : 'margin-top:12px;max-width:560px;width:100%;padding:10px 14px;border-radius:14px;text-align:center;' + resColor()) + '">' + resInner() + '</div>';
    }
    function retry() { resultState('sending'); S.dirty = true; clearTimeout(S.timer); sync(); }

    function flushBeacon() {
        try {
            if (!studentReady()) return;
            var mp = localMap('results'), meta = S.meta.results || {}, body = {}, any = false;
            mp.forEach(function (obj, key) {
                var d = JSON.stringify(obj), h = hash(d);
                if (meta[key] && meta[key].h === h) return;
                if (d.length > 30000) { d = JSON.stringify(Object.assign({}, obj, { detail: null })); h = hash(d); }
                body[dataPath('results', key)] = { k: key, h: h, ts: SV, d: d };
                body['rev/results/' + enc(key.slice(0, key.indexOf('|')))] = SV;
                any = true;
            });
            if (!any) return;
            fetch(base('s') + '.json', { method: 'PATCH', keepalive: true, cache: 'no-store', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).catch(function () { });
        } catch (e) { }
    }

    var localWaited = false;
    function waitLocal() {
        if (localWaited) return Promise.resolve();
        localWaited = true;
        if (typeof window.loadFromIndexedDB !== 'function') return Promise.resolve();
        return window.loadFromIndexedDB().then(function (r) {
            if (!r) return;
            try {
                if (Array.isArray(r.deletedIds)) (0, eval)('deletedTopicIds = mergeDeletedIds(deletedTopicIds, ' + JSON.stringify(r.deletedIds) + ')');
                if (Array.isArray(r.topics)) {
                    window.__cloudIdbTopics = r.topics;
                    (0, eval)('savedTopics = mergeTopicLists(savedTopics, window.__cloudIdbTopics, deletedTopicIds)');
                    window.__cloudIdbTopics = null;
                }
            } catch (e) { }
        }, function () { });
    }
    function startPolling() {
        clearInterval(S.poll);
        S.poll = setInterval(function () {
            if (document.hidden || !teacherReady()) return;
            sync();
        }, 12000);   /* [CODE158] giáo viên: 12 giây/lần */
    }

    function toast(msg) {
        try {
            var el = $('cloud-toast');
            if (!el) {
                el = document.createElement('div'); el.id = 'cloud-toast';
                el.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:10px 18px;border-radius:14px;font:800 15px/1.3 Roboto,Arial,sans-serif;z-index:100000;box-shadow:0 8px 24px rgba(0,0,0,.35);max-width:90vw;text-align:center;opacity:0;transition:opacity .25s;pointer-events:none';
                document.body.appendChild(el);
            }
            el.textContent = msg; el.style.opacity = '1';
            clearTimeout(el._t); el._t = setTimeout(function () { el.style.opacity = '0'; }, 4200);
        } catch (e) { }
    }

    /* ---------------- giao diện cấu hình ---------------- */
    var RULES = '{\n  "rules": {\n    ".read": false,\n    ".write": false,\n    "t": { "$code": { ".read": "$code.length >= 16", ".write": "$code.length >= 16" } },\n    "s": { "$code": { ".read": "$code.length >= 12", ".write": "$code.length >= 12" } }\n  }\n}';
    function fmtTime(ts) { if (!ts) return '—'; var d = new Date(ts), p = function (n) { return String(n).padStart(2, '0'); }; return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()); }
    function updateBtn() {
        var t;
        if (!teacherReady()) t = '☁️ ĐỒNG BỘ (chưa bật)';
        else if (S.busy) t = '☁️ Đang đồng bộ...';
        else if (S.lastErr) t = '⚠️ Lỗi đồng bộ';
        else if (S.lastOk) t = '☁️ Đã đồng bộ ' + fmtTime(S.lastOk);
        else t = '☁️ ĐỒNG BỘ';
        var bg = S.lastErr ? 'linear-gradient(90deg,#dc2626,#ea580c)' : (teacherReady() ? 'linear-gradient(90deg,#059669,#0d9488)' : 'linear-gradient(90deg,#64748b,#475569)');
        ['btn-cloud-sync', 'btn-class-cloud'].forEach(function (id) {
            var b = $(id); if (!b) return;
            b.textContent = t; b.style.background = bg;
        });
        /* [CODE72] Quản lí lớp học cần Mã giáo viên MQT1 mới đồng bộ được danh sách học sinh/đề giao giữa các máy */
        var cb = $('btn-class-cloud');
        if (cb && teacherReady() && !S.cfg && !S.lastErr) { cb.textContent = '⚠️ LỚP CHƯA ĐỒNG BỘ • NHẬP MÃ GV'; cb.style.background = 'linear-gradient(90deg,#d97706,#ea580c)'; }
        var lb = $('btn-cloud-sync');
        if (lb && teacherReady() && !S.cfg && !S.lastErr) { lb.textContent = '⚠️ THIẾU MÃ GV (MQT1) • đề/thư mục/lớp chưa đồng bộ'; lb.style.background = 'linear-gradient(90deg,#d97706,#ea580c)'; }
    }
    function copyText(t) {
        try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t); return; } } catch (e) { }
        var a = document.createElement('textarea'); a.value = t; a.style.cssText = 'position:fixed;left:-9999px'; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (e) { } document.body.removeChild(a);
    }
    var modalMsg = { text: '', ok: true };
    function setMsg(text, ok) { modalMsg = { text: text, ok: ok !== false }; var m = $('cloud-msg'); if (m) { m.textContent = text; m.style.color = ok === false ? '#dc2626' : '#047857'; } }
    function openUI() {
        var el = $('cloud-modal'); if (el) el.remove();
        el = document.createElement('div'); el.id = 'cloud-modal';
        el.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:99999;display:flex;align-items:center;justify-content:center;padding:12px;font-family:Roboto,Arial,sans-serif';
        el.innerHTML = '<div style="background:#fff;border-radius:20px;max-width:720px;width:100%;max-height:94vh;overflow:auto;padding:22px;box-shadow:0 20px 60px rgba(0,0,0,.5)">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px"><div style="font-size:21px;font-weight:900;color:#0f172a">☁️ ĐỒNG BỘ NHIỀU THIẾT BỊ <span style="font-size:12px;font-weight:800;color:#059669">(CODE67 - có cả Lớp học)</span></div><button type="button" onclick="CloudSync.closeUI()" style="font-size:22px;font-weight:900;color:#475569;padding:2px 12px;border-radius:10px;background:#e2e8f0">✕</button></div>' +
            '<div id="cloud-body"></div></div>';
        document.body.appendChild(el);
        renderModal();
    }
    function closeUI() { var el = $('cloud-modal'); if (el) el.remove(); }
    function refreshModal() { if ($('cloud-modal')) renderModal(); }
    function renderModal() {
        var body = $('cloud-body'); if (!body) return;
        var c = S.cfg, hasStuOnly = !c && !!effStu(), h = '';
        var keep = { u: ($('cloud-url') || {}).value, t: ($('cloud-t') || {}).value, p: ($('cloud-p') || {}).value };
        if (!S.defT) { S.defT = rnd(24); S.defP = rnd(16); }
        var inp = 'width:100%;border:2px solid #cbd5e1;border-radius:12px;padding:9px 12px;font-weight:700;font-size:15px;margin-top:4px';
        var btn = function (bg) { return 'padding:9px 16px;border-radius:12px;font-weight:900;color:#fff;background:' + bg + ';font-size:14px;text-transform:uppercase'; };
        h += '<div style="margin-top:12px;padding:12px 14px;border-radius:14px;font-weight:800;font-size:15px;background:' + (teacherReady() ? (S.lastErr ? '#fef2f2;color:#b91c1c' : '#ecfdf5;color:#047857') : '#f1f5f9;color:#475569') + '">';
        if (!teacherReady()) h += 'Chưa bật đồng bộ. Dữ liệu hiện chỉ lưu trên thiết bị này.';
        else if (S.lastErr) h += '⚠️ ' + esc(S.lastErr);
        else if (S.busy) h += '⏳ Đang đồng bộ...';
        else if (hasStuOnly) h += '✅ Đang nhận kết quả học sinh & đề giao qua cấu hình nhúng sẵn (' + (S.lastOk ? 'lần cuối ' + fmtTime(S.lastOk) : 'sẵn sàng') + '). Dán thêm Mã kết nối MQT1 bên dưới nếu muốn đồng bộ toàn bộ thư mục riêng của Giáo viên.';
        else h += '✅ Đã bật đồng bộ đầy đủ' + (S.lastOk ? ' • lần cuối ' + fmtTime(S.lastOk) : '') + '. Tự động gộp kết quả học sinh theo cả Mã đề lẫn Tên đề.';
        h += '</div>';
        h += '<div id="cloud-msg" style="margin-top:8px;font-weight:800;font-size:14px;min-height:18px;color:' + (modalMsg.ok ? '#047857' : '#dc2626') + '">' + esc(modalMsg.text) + '</div>';
        if (effStu()) h += '<div style="margin-top:6px;font-weight:800;font-size:13.5px;color:#334155">🗄️ Mã kho dữ liệu: <b style="font-size:16px;color:#0f766e">' + storeId() + '</b> — mọi máy giáo viên và học sinh phải hiện CÙNG mã này (học sinh xem ở thanh trạng thái trong Thư viện). Khác mã = đang dùng kho khác, sẽ không thấy đề/lớp của nhau.</div>';

        if (teacherReady()) {
            h += '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap">' +
                '<button type="button" onclick="CloudSync.syncNow()" style="' + btn('linear-gradient(90deg,#059669,#0d9488)') + '">🔄 Đồng bộ ngay</button>' +
                '<button type="button" onclick="CloudSync.checkServer()" style="' + btn('#2563eb') + '">🔍 Kiểm tra kết quả học sinh</button>' +
                '<button type="button" onclick="CloudSync.pullAllResults()" style="' + btn('#7c3aed') + '">⬇️ Tải &amp; Gộp tất cả kết quả về máy</button>' +
                '<button type="button" onclick="CloudSync.downloadConfigJson()" style="' + btn('#0369a1') + '" title="Đặt cạnh index.html trên GitHub để mọi máy tự nhận đúng kho">📄 Tải cloud-config.json</button>' +
                (c ? '<button type="button" onclick="CloudSync.disconnect()" style="' + btn('#dc2626') + '">Ngắt kết nối</button>' : '') +
                '</div>';
            if (S.diag) h += '<div style="margin-top:8px;padding:10px 14px;border-radius:12px;background:#f1f5f9;font-weight:700;font-size:13.5px;line-height:1.55;color:#0f172a;white-space:pre-wrap">' + esc(S.diag) + '</div>';
        }

        if (!c) {
            h += '<div style="margin-top:16px;padding-top:12px;border-top:2px dashed #cbd5e1"><label style="font-weight:900;font-size:14px">Dán <b>Mã kết nối (MQT1...)</b> lấy từ máy tính vào đây:</label><textarea id="cloud-code" rows="2" style="' + inp + ';font-size:13px" placeholder="MQT1...."></textarea><button type="button" onclick="CloudSync.connectCode()" style="' + btn('linear-gradient(90deg,#2563eb,#4f46e5)') + ';margin-top:8px">📥 Nhập mã &amp; đồng bộ</button></div>';
            h += '<details style="margin-top:12px;background:#eff6ff;border-radius:14px;padding:10px 14px"><summary style="cursor:pointer;font-weight:900;color:#1d4ed8">⚙️ Hoặc thiết lập kho Firebase mới từ đầu</summary>' +
                '<div style="margin-top:8px;padding:8px 12px;border-radius:10px;background:#fef2f2;color:#b91c1c;font-weight:800;font-size:13px;line-height:1.5">⚠️ CHỈ dùng ở lần đầu tiên, trên MỘT máy duy nhất. Nếu đã có kho ở máy khác thì phải dán <b>Mã MQT1</b> ở trên. Mỗi lần tạo “kho mới” là một nơi lưu dữ liệu RIÊNG nên đề, lớp và học sinh sẽ không thấy nhau.</div>' +
                '<div style="margin-top:10px"><label style="font-weight:900;font-size:14px">1) Địa chỉ Realtime Database (URL)</label><input id="cloud-url" style="' + inp + '" placeholder="https://ten-du-an-default-rtdb.asia-southeast1.firebasedatabase.app" autocomplete="off" value="' + esc(keep.u || '') + '"></div>' +
                '<div style="display:flex;gap:10px;margin-top:10px;flex-wrap:wrap"><div style="flex:1;min-width:230px"><label style="font-weight:900;font-size:14px">2) Mã giáo viên (bí mật)</label><input id="cloud-t" style="' + inp + '" value="' + esc(keep.t || S.defT) + '"></div>' +
                '<div style="flex:1;min-width:200px"><label style="font-weight:900;font-size:14px">3) Mã học sinh</label><input id="cloud-p" style="' + inp + '" value="' + esc(keep.p || S.defP) + '"></div></div>' +
                '<div style="margin-top:12px"><button type="button" onclick="CloudSync.connect()" style="' + btn('linear-gradient(90deg,#059669,#0d9488)') + '">🔗 Kết nối &amp; đồng bộ</button></div></details>';
        } else {
            h += '<div style="margin-top:16px;padding:12px 14px;border-radius:14px;background:#fffbeb;border:2px solid #fcd34d"><div style="font-weight:900;color:#92400e">📱 Mã kết nối dành cho trang GitHub / thiết bị giáo viên khác</div><div style="font-weight:600;font-size:13.5px;color:#78350f;margin:4px 0 8px">Sao chép mã này dán vào mục ĐỒNG BỘ trên trang GitHub (hoặc xuất file index.html mới đẩy lên GitHub):</div>' +
                '<textarea id="cloud-fullcode" readonly rows="3" style="' + inp + ';font-size:12px">' + esc(fullCode()) + '</textarea>' +
                '<button type="button" onclick="CloudSync.copyFull()" style="' + btn('#d97706') + ';margin-top:8px">📋 Sao chép Mã kết nối</button></div>';
        }
        h += '<details style="margin-top:14px"><summary style="cursor:pointer;font-weight:900;color:#334155">🔐 Rules cần dán trong Firebase (bấm để xem)</summary><textarea id="cloud-rules" readonly rows="9" style="' + inp + ';font-family:monospace;font-size:12.5px">' + esc(RULES) + '</textarea><button type="button" onclick="CloudSync.copyRules()" style="' + btn('#475569') + ';margin-top:6px">📋 Sao chép Rules</button></details>';
        body.innerHTML = h;
    }

    /* ---------------- hành động ---------------- */
    function testAndStart(cfg) {
        S.cfg = cfg; lsSet(LS_CFG, cfg);
        S.stu = { u: cfg.u, p: cfg.p }; lsSet(LS_STU, S.stu);
        S.meta = { cfgId: hash(cfg.u + '|' + cfg.t + '|' + cfg.p), rev: {} }; saveMeta();
        localWaited = false;
        setMsg('Đang kiểm tra kết nối...', true); renderModal();
        return req('PATCH', 't', '', { 'info/created': SV, 'info/app': 'matrix-quiz' }).then(function () {
            return req('PATCH', 's', '', { 'info/created': SV });
        }).then(function () {
            setMsg('✓ Kết nối thành công. Đang đồng bộ & hợp nhất dữ liệu...', true);
            installBtn(); updateBtn(); startPolling(); S.dirty = true;
            return sync().then(function () {
                if (S.lastErr) setMsg('⚠️ ' + S.lastErr, false);
                else setMsg('✓ Đồng bộ xong lúc ' + fmtTime(S.lastOk) + '.', true);
                renderModal();
            });
        }).catch(function (e) {
            S.cfg = null; localStorage.removeItem(LS_CFG);
            setMsg('⚠️ ' + (e.message || e), false); renderModal(); updateBtn();
        });
    }
    function connect() {
        var u = normUrl(($('cloud-url') || {}).value), t = String(($('cloud-t') || {}).value || '').trim(), p = String(($('cloud-p') || {}).value || '').trim();
        if (!u) return setMsg('⚠️ Hãy nhập địa chỉ Realtime Database (bắt đầu bằng https://).', false);
        if (t.length < 16) return setMsg('⚠️ Mã giáo viên phải có ít nhất 16 ký tự.', false);
        if (p.length < 12) return setMsg('⚠️ Mã học sinh phải có ít nhất 12 ký tự.', false);
        if (!/^[A-Za-z0-9_\-]+$/.test(t) || !/^[A-Za-z0-9_\-]+$/.test(p)) return setMsg('⚠️ Mã chỉ gồm chữ cái, số, gạch ngang, gạch dưới.', false);
        testAndStart({ u: u, t: t, p: p });
    }
    function connectCode() {
        var c = parseFullCode(($('cloud-code') || {}).value);
        if (!c) return setMsg('⚠️ Mã kết nối không hợp lệ. Hãy sao chép đầy đủ từ máy đầu tiên.', false);
        testAndStart(c);
    }
    function disconnect() {
        if (!confirm('Ngắt kết nối đồng bộ trên thiết bị này?')) return;
        S.cfg = null; localStorage.removeItem(LS_CFG); localStorage.removeItem(LS_META);
        S.meta = { rev: {} }; S.lastErr = ''; S.lastOk = 0; clearInterval(S.poll);
        setMsg('Đã ngắt kết nối.', true); updateBtn(); renderModal();
    }
    function syncNow() {
        /* Làm mới cưỡng bức revision để tải lại đề, thư mục, lớp và kết quả từ Firebase. */
        S.meta.rev = {}; S.meta.recoveryRev = {}; S.dirty = true;
        setMsg('Đang tải dữ liệu mới nhất từ máy chủ...', true);
        sync().then(function () {
            setMsg(S.lastErr ? '⚠️ ' + S.lastErr + ' — dữ liệu chưa được xác nhận đồng bộ.' : '✓ Đã kiểm tra và đồng bộ dữ liệu lúc ' + fmtTime(S.lastOk) + '.', !S.lastErr);
            renderModal();
        });
    }
    function copyFull() { copyText(fullCode()); setMsg('✓ Đã sao chép Mã kết nối.', true); }
    function copyRules() { copyText(RULES); setMsg('✓ Đã sao chép Rules.', true); }

    /* ---------------- gắn vào app ---------------- */
    function installBtn() {
        var ex = $('btn-cloud-sync');
        if (ex) { ex.onclick = openUI; updateBtn(); return; }
        var host = $('library-footer-teacher-actions'); if (!host) return;
        var b = document.createElement('button');
        b.type = 'button'; b.id = 'btn-cloud-sync'; b.onclick = openUI;
        b.className = 'px-4 py-2 rounded-xl font-black text-white shadow-sm text-[15px] uppercase';
        host.appendChild(b); updateBtn();
    }
    function wrap(name) {
        var f = window[name];
        if (typeof f !== 'function' || orig[name]) return;
        orig[name] = f;
        window[name] = function () {
            if (name === 'saveStudentResultsToStorage') enrichLocalResults();
            var r = f.apply(this, arguments);
            var stuRes = (name === 'saveStudentResultsToStorage' && isStu());
            if (stuRes) {
                S.dirty = true;
                if (!effStu()) resultState('nolink');
                else {
                    resultState('sending');
                    flushBeacon();
                    clearTimeout(S.timer); setTimeout(function () { sync(); }, 0);
                }
            } else if (!S.applying) schedule(false);
            return r;
        };
    }
    function wrapOpen(name) {
        var f = window[name];
        if (typeof f !== 'function' || orig[name]) return;
        orig[name] = f;
        window[name] = function () {
            var r = f.apply(this, arguments);
            if (teacherReady()) {
                schedule(true, true);
                if (name === 'openResultsModal') refreshResultsNow(arguments[0]);
            } else if (name === 'openResultsModal') {
                S.hint = null; repaintResults();
            }
            return r;
        };
    }
    /* [CODE75] Tệp cloud-config.json đặt cạnh index.html trên GitHub = nơi duy nhất báo cho MỌI máy biết đang dùng kho nào. */
    function fetchRemoteConfig() {
        try {
            if (S.cfg || S.remoteCfgBusy || location.protocol === 'file:') return;
            S.remoteCfgBusy = true;
            var u = location.href.split('#')[0].split('?')[0].replace(/[^\/]*$/, '') + 'cloud-config.json?cb=' + Date.now();
            fetch(u, { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : null; }).then(function (o) {
                S.remoteCfgBusy = false;
                if (!o || typeof o !== 'object') return;
                var c = o.token ? parseStuToken(o.token) : ((o.u && o.p) ? { u: normUrl(o.u), p: String(o.p) } : null);
                if (!c || !c.u || String(c.p).length < 12) return;
                if (S.stu && S.stu.u === c.u && S.stu.p === c.p) return;
                S.stu = { u: c.u, p: c.p, ts: Date.now(), src: 'json' }; lsSet(LS_STU, S.stu);
                S.meta = { cfgId: hash(c.u + '|' + c.p), buildId: String(window.__PRELOADED_BUILD_ID__ || ''), rev: {} }; saveMeta();
                S.stuInfo = {};
                schedule(true, true);
                try { if (typeof window.renderLibraryList === 'function') window.renderLibraryList(); } catch (e) { }
            }).catch(function () { S.remoteCfgBusy = false; });
        } catch (e) { S.remoteCfgBusy = false; }
    }
    function downloadConfigJson() {
        var c = effStu();
        if (!c) { setMsg('Chưa có kết nối máy chủ để tạo cloud-config.json.', false); return; }
        var data = JSON.stringify({ u: c.u, p: c.p, note: 'Đặt tệp này cùng thư mục với index.html trên GitHub. Mọi máy học sinh/giáo viên mở trang sẽ tự nhận đúng kho dữ liệu này.' }, null, 2);
        var a = document.createElement('a');
        a.href = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
        a.download = 'cloud-config.json';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setMsg('✓ Đã tải cloud-config.json. Hãy tải tệp này lên GitHub, cùng thư mục với index.html.', true);
    }

    function install() {
        if (S.installed) return; S.installed = true;
        loadCfg();
        fetchRemoteConfig();
        ['saveToStorage', 'saveFolders', 'cmSave', 'saveStudentResultsToStorage'].forEach(wrap);
        ['openResultsModal', 'openClassManager'].forEach(wrapOpen);
        document.addEventListener('visibilitychange', function () { if (document.hidden) flushBeacon(); });
        window.addEventListener('pagehide', flushBeacon);
        var bsu = window.buildStudentShareUrl;
        if (typeof bsu === 'function') {
            window.buildStudentShareUrl = function (topic) {
                if (topic && teacherReady()) {
                    S.forcePub.add(topic.id); schedule(true);
                    var baseUrl = (typeof window.getEffectiveBaseUrl === 'function') ? window.getEffectiveBaseUrl() : (location.href.split('#')[0].split('?')[0]);
                    return baseUrl + '?id=' + encodeURIComponent(topic.id) + '&mode=hs&cl=' + token();
                }
                return bsu.apply(this, arguments);
            };
        }
        var esm = window.enableStudentModeUI;
        if (typeof esm === 'function') {
            window.enableStudentModeUI = function () {
                var r = esm.apply(this, arguments);
                try { S.stuInfo = {}; S.dirty = true; fetchRemoteConfig(); setTimeout(function () { schedule(true, true); }, 50); } catch (e) { }
                return r;
            };
        }
        installBtn(); updateBtn();
        window.addEventListener('online', function () { schedule(true, true); });
        document.addEventListener('visibilitychange', function () { if (!document.hidden) schedule(true, true); });
        window.addEventListener('focus', function () { if (Date.now() - S.lastPullTs > 4000) { S.lastPullTs = Date.now(); schedule(true, true); } });
        if (teacherReady()) { startPolling(); }
        S.dirty = true;
        setTimeout(function () { schedule(true); }, 900);
        setInterval(function () {
            if (studentReady() && !S.busy && (S.dirty || !S.lastOk || (!document.hidden && Date.now() - S.lastPullTs > 30000))) { S.lastPullTs = Date.now(); schedule(true, true); }   /* [CODE158] học sinh: 30 giây/lần (vẫn tải ngay khi mở lại tab / có mạng) */
        }, 8000);
    }

    function bootStudentLink() {
        try {
            if (!S.installed) install();
            var p = new URLSearchParams(location.search), id = p.get('id');
            if (!id || p.get('mode') !== 'hs') return false;
            var c = effStu(); if (!c) return false;
            window.enableStudentModeUI(); window.checkSavedLoginSession(true);
            var st = $('status-message'); if (st) st.textContent = '⏳ Đang tải đề thi từ máy chủ...';
            var cached = function () { var T = g('savedTopics'); return T.find(function (t) { return t && t.id === id; }) || null; };
            req('GET', 's', 'pub/' + enc(id)).then(function (env) {
                var o = env && typeof env.d === 'string' ? parseEnv(env) : null;
                if (!o) {
                    var c0 = cached(); if (c0) { window.applyTopic(c0); schedule(true); return; }
                    throw new Error('Đề thi này chưa được giáo viên xuất bản hoặc đã bị xóa.');
                }
                S.pubTopics[enc(o.id)] = o;
                var T = g('savedTopics'), i = T.findIndex(function (t) { return t && t.id === o.id; });
                if (i >= 0) T[i] = o; else T.push(o);
                S.applying = true; try { orig.saveToStorage ? orig.saveToStorage() : window.saveToStorage(); } catch (e) { } S.applying = false;
                window.applyTopic(o);
                schedule(true, true);
            }).catch(function (e) {
                var c1 = cached();
                if (c1) { window.applyTopic(c1); return; }
                window.showModal('Không tải được đề', (e && e.message ? e.message : 'Lỗi không xác định') + '\nHãy kiểm tra mạng rồi tải lại trang (hoặc nhờ giáo viên gửi lại link).', 'info');
            });
            return true;
        } catch (e) { return false; }
    }

    /* [CODE67] Học sinh dán link / mã MQC1 do giáo viên gửi để kết nối khi chưa mở bằng link */
    function setStudentToken(v) {
        v = String(v || '').trim();
        var m = v.match(/[?&]cl=([^&#\s]+)/);
        if (m) { try { v = decodeURIComponent(m[1]); } catch (e) { v = m[1]; } }
        var c = parseStuToken(v);
        if (!c) return false;
        c.ts = Date.now(); c.src = 'link'; S.stu = c; lsSet(LS_STU, c);
        S.meta = { cfgId: hash(c.u + '|' + c.p), buildId: String(window.__PRELOADED_BUILD_ID__ || ''), rev: {} }; saveMeta();
        schedule(true, true);
        return true;
    }

    window.CloudSync = {
        setStudentToken: setStudentToken,
        liveCfg: function () { var c = effStu(); return c ? { u: c.u, p: c.p } : null; }, liveToken: token, parseToken: parseStuToken,
        install: install, bootStudentLink: bootStudentLink, openUI: openUI, closeUI: closeUI,
        connect: connect, connectCode: connectCode, disconnect: disconnect, syncNow: syncNow,
        copyFull: copyFull, copyRules: copyRules, schedule: schedule, sync: sync, retry: retry,
        statusHtml: statusHtml, checkServer: checkServer, refreshResultsNow: refreshResultsNow,
        hintHtml: hintHtml, studentBannerHtml: studentBannerHtml, studentRefresh: studentRefresh, studentConnect: studentConnect, downloadConfigJson: downloadConfigJson, pullAllResults: pullAllResults, noteResultDeleted: noteResultDeleted,
        adoptOrphanResults: adoptOrphanResults, unifySameTitleResults: unifySameTitleResults,
        linkSuffix: function () { var t = (S.cfg || effStu()) ? token() : ''; return t ? '&cl=' + t : ''; },
        embedSnippet: function () {
            var c = effStu();
            return c ? 'window.__CLOUD_CONFIG__ = ' + JSON.stringify(c).replace(/</g, '\\u003c') + '; ' : '';
        },
        _state: S, _hash: hash, _enc: enc,
        api: { req: req, enc: enc, effStu: effStu, teacherReady: teacherReady, teacherFull: teacherFullReady, fullCode: fullCode, isStu: isStu, hash: hash, token: token,
                status: function () { return { lastOk: S.lastOk, lastErr: S.lastErr, busy: S.busy }; } }
    };
})();
    