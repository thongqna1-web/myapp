
(function () {
    const FOLDER_ICONS = ['📁', '📄', '☆', '★', '☆', '★', '☑', '🎓', '❐'];

    function buildSubjectTabsBar() {
        const sidebar = document.getElementById('left-sidebar');
        if (!sidebar || !sidebar.parentNode) return;

        let bar = document.getElementById('subject-tabs-bar');
        if (!bar) {
            bar = document.createElement('nav');
            bar.id = 'subject-tabs-bar';
            bar.className = 'no-print';
            sidebar.parentNode.insertBefore(bar, sidebar.nextSibling);
        }

        const subjects = (typeof getLibSubjects === 'function'
            ? getLibSubjects()
            : ['Toán lớp 6', 'Toán lớp 7', 'Toán lớp 8', 'Toán lớp 9', 'Toán lớp 10', 'Toán lớp 11', 'Toán lớp 12'])
            .filter(subj => /^Toán lớp \d+$/i.test(String(subj || '').trim()));
        const grade12Index = subjects.indexOf('Toán lớp 12');
        subjects.splice(grade12Index < 0 ? subjects.length : grade12Index + 1, 0, 'Đề thi THPT Quốc gia');

        bar.innerHTML = '';

        subjects.forEach((subj) => {
            const item = document.createElement('div');
            item.className = 'subj-tab-item';

            const isTHPT = subj === 'Đề thi THPT Quốc gia';
            const shortLabel = isTHPT ? 'ĐỀ THI THPT QUỐC GIA' : subj.replace(/^Toán lớp\s+/i, 'TOÁN ');
            if (isTHPT) item.classList.add('subj-tab-thpt');
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'subj-tab-btn';
            btn.innerHTML = `<span>📘</span><span>${shortLabel}</span><span style="font-size:11px;opacity:.85">▾</span>`;
            btn.onclick = (e) => {
                e.stopPropagation();
                const wasOpen = item.classList.contains('open');
                document.querySelectorAll('.subj-tab-item.open').forEach(el => el.classList.remove('open'));
                if (!wasOpen) item.classList.add('open');
            };

            const dropdown = document.createElement('div');
            dropdown.className = 'subj-tab-dropdown';

            const roots = isTHPT ? [0,1,2].map((n) => {
                const id = 'folder_thptqg_sub_' + n;
                return (typeof getFolderById === 'function' && getFolderById(id)) || (window.__PRELOADED_FOLDERS__ || []).find(f => f.id === id);
            }).filter(Boolean) : (typeof childFolders === 'function')
                ? childFolders(subj, null)
                : (window.__PRELOADED_FOLDERS__ || []).filter(f => f.subject === subj && !f.parentId);

            // Mục mở tất cả môn học
            const allLink = document.createElement('button');
            allLink.type = 'button';
            allLink.className = 'subj-drop-link';
            allLink.innerHTML = `<span class="subj-drop-ico">📚</span><span>TẤT CẢ ${shortLabel}</span>`;
            allLink.onclick = () => {
                item.classList.remove('open');
                if (typeof openLibrary === 'function') {
                    libCurrentFolderId = null;
                    openLibrary();
                    const sel = document.getElementById('lib-filter-subject');
                    if (sel) { sel.value = subj; renderLibraryList(); }
                }
            };
            if (!isTHPT) dropdown.appendChild(allLink);

            // Các thư mục con (Tài liệu học tập, Đề ôn thi giữa kỳ 1, cuối kỳ 1,...)
            roots.forEach((folder, idx) => {
                const link = document.createElement('button');
                link.type = 'button';
                link.className = 'subj-drop-link';
                const ico = FOLDER_ICONS[idx % FOLDER_ICONS.length];
                link.innerHTML = `<span class="subj-drop-ico">${ico}</span><span>${folder.name}</span>`;
                link.onclick = () => {
                    item.classList.remove('open');
                    if (typeof openLibrary === 'function') {
                        openLibrary();
                        if (typeof openLibFolder === 'function') openLibFolder(folder.id);
                    }
                };
                dropdown.appendChild(link);
            });

            item.appendChild(btn);
            item.appendChild(dropdown);
            bar.appendChild(item);
        });
    }

    document.addEventListener('click', () => {
        document.querySelectorAll('.subj-tab-item.open').forEach(el => el.classList.remove('open'));
    });

    window.addEventListener('load', () => {
        setTimeout(buildSubjectTabsBar, 300);
    });
})();
