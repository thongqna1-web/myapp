
/* [CODE77] SAKB: chuyển bàn phím ô trả lời ngắn giữa SỐ (decimal) và CHỮ/KÝ HIỆU (text) để nhập dấu trừ (–) */
window.SAKB = {
    text: false,
    mode: function () { return this.text ? 'text' : 'decimal'; },
    label: function () { return this.text ? '🔢 Bàn phím số' : '⌨ Nhập dấu (–) / chữ'; },
    btnHtml: function () {
        return '<button type="button" class="sa-kb-btn' + (this.text ? ' is-text' : '') + '" tabindex="-1" onmousedown="event.preventDefault()" onclick="SAKB.toggle(this)">' + this.label() + '</button>';
    },
    makeBtn: function () {
        var t = document.createElement('div'); t.innerHTML = this.btnHtml(); return t.firstChild;
    },
    toggle: function (btn) {
        this.text = !this.text;
        var m = this.mode(), row = btn && btn.closest ? btn.closest('.q-sa-row') : null;
        var ae = document.activeElement;
        document.querySelectorAll('.q-sa-box').forEach(function (b) { if (!b.readOnly) b.setAttribute('inputmode', m); });
        var self = this;
        document.querySelectorAll('.sa-kb-btn').forEach(function (b) { b.textContent = self.label(); b.classList.toggle('is-text', self.text); });
        // Mở lại bàn phím đúng loại: blur -> focus ngay trong cử chỉ bấm của người dùng (iOS yêu cầu)
        var target = (ae && ae.classList && ae.classList.contains('q-sa-box') && (!row || row.contains(ae))) ? ae : null;
        if (!target && row) {
            var boxes = Array.prototype.slice.call(row.querySelectorAll('.q-sa-box'));
            target = boxes.filter(function (b) { return !b.value; })[0] || boxes[boxes.length - 1];
        }
        if (target) {
            try { target.blur(); } catch (e) {}
            try { target.focus({ preventScroll: true }); } catch (e) { try { target.focus(); } catch (e2) {} }
        }
    }
};
