
    (function () {
        var FB = [
            ['katex', ['https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js', 'https://unpkg.com/katex@0.16.9/dist/katex.min.js']],
            ['XLSX', ['https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js', 'https://unpkg.com/xlsx@0.18.5/dist/xlsx.full.min.js']],
            ['qrcode', ['https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js', 'https://unpkg.com/qrcode-generator@1.4.4/qrcode.js']],
            ['Peer', ['https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js', 'https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js']],
            ['confetti', ['https://cdnjs.cloudflare.com/ajax/libs/canvas-confetti/1.6.0/confetti.browser.min.js', 'https://unpkg.com/canvas-confetti@1.6.0/dist/confetti.browser.min.js']]
        ];
        function check() {
            if (!window.__code98LoadLib) return;
            FB.forEach(function (f) { if (!window[f[0]]) { try { window.__code98LoadLib(f[0], f[1]).catch(function () {}); } catch (e) {} } });
            if (!window.katex && !document.querySelector('link[data-kx-fb]')) {
                var l = document.createElement('link'); l.rel = 'stylesheet'; l.setAttribute('data-kx-fb', '1');
                l.href = 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.css'; document.head.appendChild(l);
            }
        }
        window.addEventListener('load', function () { setTimeout(check, 1200); });
    })();
    