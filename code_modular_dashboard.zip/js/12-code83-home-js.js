
/* [CODE85] Trang chủ dạng dashboard cho GIÁO VIÊN và HỌC SINH (học sinh: Vinh danh Top 5 + nút truy cập nhanh Lớp học của tôi).
   [CODE83] Trang chủ dạng dashboard cho giáo viên: Thư viện đề thi, Lớp học, Học sinh tiêu biểu,
   Đề thi được đề xuất, Hoạt động gần đây, Khu vực tạo đề nhanh. Chỉ đọc dữ liệu sẵn có (không ghi/sửa dữ liệu). */
(function () {
    'use strict';
    var DAY = 864e5;
    var H = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    var N = function (n) { try { return Number(n || 0).toLocaleString('vi-VN'); } catch (e) { return String(n || 0); } };
    var F1 = function (n) { return (Math.round(n * 10) / 10).toString().replace('.', ','); };
    var el = null, lastSig = '', timer = 0, tick = 0, uid = 0;
    /* [CODE85] ---- Phần dành cho HỌC SINH ---- */
    var LS_CACHE85 = 'matrix_classnet_mycache_v1', LS_BOARD85 = 'matrix_c85_board_v1';
    var boardMode = 'all', cloud = { ts: 0, busy: false, recs: {} }, cloudTried = 0;
    function isStu() { return typeof isStudentMode !== 'undefined' && isStudentMode === true; }
    function lsGet85(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
    function myClasses() { var c = lsGet85(LS_CACHE85); return Array.isArray(c) ? c : []; }
    function myName() { try { return String(document.getElementById('main-fullname-input').value || '').normalize('NFC').toLowerCase().replace(/\s+/g, ' ').trim(); } catch (e) { return ''; } }
    function loadCloudCache() { var o = lsGet85(LS_BOARD85); if (o && o.recs && typeof o.recs === 'object') { cloud.recs = o.recs; cloud.ts = o.ts || 0; } }
    function slim(o) {
        return { id: o.id, studentName: o.studentName || o.name || '', studentClass: o.studentClass || '', className: o.className || '', classIds: o.classIds,
            score10: o.score10, scorePercent: o.scorePercent, submittedTs: o.submittedTs || o.submittedAt || 0 };
    }
    /* Học sinh: tải kết quả của các bạn trong lớp (chỉ các đề được giao cho lớp mình), lưu nhớ 2 phút, bỏ phần chi tiết bài làm cho nhẹ */
    function fetchCloud(force) {
        var api = window.CloudSync && CloudSync.api;
        if (cloud.busy || document.hidden || !api) return;
        if (!force && Date.now() - cloud.ts < 120000) return;
        var ok = false; try { ok = !!api.effStu(); } catch (e) {}
        if (!ok) return;
        var tids = [];
        myClasses().forEach(function (c) { arr(c.t).forEach(function (t) { if (t && tids.indexOf(t) < 0) tids.push(t); }); });
        if (!tids.length) {
            if (Date.now() - cloudTried > 60000 && window.ClassNet && ClassNet.refreshS) { cloudTried = Date.now(); try { Promise.resolve(ClassNet.refreshS()).then(function () { lastSig = ''; schedule(); }); } catch (e) {} }
            return;
        }
        tids = tids.slice(0, 12);
        cloud.busy = true;
        Promise.all(tids.map(function (tid) {
            return api.req('GET', 's', 'results/' + api.enc(tid)).then(function (remote) {
                var out = [];
                Object.keys(remote || {}).forEach(function (k) {
                    var env = remote[k]; if (!env || typeof env.d !== 'string') return;
                    var o = null; try { o = JSON.parse(env.d); } catch (e) {}
                    if (o && o.id) out.push(slim(o));
                });
                return [tid, out];
            }, function () { return [tid, null]; });
        })).then(function (parts) {
            var recs = {};
            parts.forEach(function (p) { if (p[1]) recs[p[0]] = p[1]; else if (cloud.recs[p[0]]) recs[p[0]] = cloud.recs[p[0]]; });
            cloud.recs = recs; cloud.ts = Date.now(); cloud.busy = false;
            try { localStorage.setItem(LS_BOARD85, JSON.stringify({ ts: cloud.ts, recs: recs })); } catch (e) {}
            lastSig = ''; schedule();
        }, function () { cloud.busy = false; cloud.ts = Date.now() - 90000; });
    }
    function kick() { if (isStu()) { try { fetchCloud(false); } catch (e) {} } }
    function wrapHtml(d) { return '<div id="code83-home"' + (d.stu ? ' class="c85-stu"' : '') + '>' + html(d) + '</div>'; }

    var IC = {
        lib: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v16H4z"/><path d="M9 9v7M12 12v4M15 7v9"/></svg>',
        users: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 5.2a3.2 3.2 0 0 1 0 5.6M18 14.4c1.8.8 3 2.6 3 4.6"/></svg>',
        trophy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/></svg>',
        school: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10l9-6 9 6-9 6z"/><path d="M7 12.5V17c0 1.4 2.2 3 5 3s5-1.6 5-3v-4.5"/></svg>',
        medal: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 2h4l1 5-3 1zM17 2h-4l-1 5 3 1z" opacity=".55"/><circle cx="12" cy="15" r="6.5"/><path d="M12 11.5l1.1 2.2 2.4.35-1.75 1.7.42 2.4L12 17l-2.17 1.15.42-2.4-1.75-1.7 2.4-.35z" fill="#fff6d6"/></svg>',
        q: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 6h12M8 12h12M8 18h12"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/></svg>',
        clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
        plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
        word: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M12 17v-6M9.5 13.5 12 11l2.5 2.5"/></svg>',
        folder: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>'
    };

    function arr(v) { return Array.isArray(v) ? v : []; }
    function startOfDay(ts) { var d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); }
    function norm(s) { return String(s || '').normalize('NFC').toLowerCase().replace(/\s+/g, ' ').trim(); }
    function score10(r) {
        var v = r.score10;
        if (v !== null && v !== undefined && v !== '') { var n = parseFloat(String(v).replace(',', '.')); if (isFinite(n)) return n; }
        if (r.scorePercent !== null && r.scorePercent !== undefined) { var p = parseFloat(r.scorePercent); if (isFinite(p)) return p / 10; }
        return null;
    }
    function createdTs(t) { var m = /^topic_(\d{10,})_/.exec(t.id || ''); return m ? +m[1] : (t.updatedAt || 0); }
    function initials(name) {
        var p = String(name || '?').trim().split(/\s+/);
        var a = p[p.length - 1] || '?', b = p.length > 1 ? p[0] : '';
        return (b.charAt(0) + a.charAt(0)).toUpperCase() || '?';
    }
    function hue(name) { var h = 0, s = String(name || ''); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360; return h; }
    /* [CODE117] Ảnh đại diện thật của học sinh (đồng bộ từ máy chủ, dùng chung kho với nút ảnh tròn ở góc); chưa có ảnh thì hiện chữ cái đầu như cũ */
    var AKEY = 'matrix_avatar_v2:', amem = {}, achk = {}, aq = [], arun = 0;
    function afold(t) { return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[đĐ]/g, 'd').toLowerCase().replace(/[^a-z0-9]+/g, ''); }
    function akey(name, cls) { var n = afold(name); return n ? 'hs_' + n + '_' + afold(cls) : ''; }
    function aok(d) { return typeof d === 'string' && d.length < 400000 && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(d); }
    function aget(k) {
        if (amem[k] !== undefined) return amem[k];
        var d = '';
        try { var o = JSON.parse(localStorage.getItem(AKEY + k) || 'null'); if (o && aok(o.d)) d = o.d; } catch (e) {}
        return (amem[k] = d);
    }
    function avatar(name, size, cls) {
        var h = hue(name), k = akey(name, cls), d = k ? aget(k) : '';
        return '<span class="c83-ava" aria-hidden="true"' + (k ? ' data-ak="' + k + '"' : '') + ' style="' + (size ? '--s:' + size + 'px;' : '') + 'background:linear-gradient(135deg,hsl(' + h + ' 70% 55%),hsl(' + ((h + 40) % 360) + ' 70% 42%))">' +
            (d ? '<img src="' + d + '" alt="" decoding="async">' : H(initials(name))) + '</span>';
    }
    function apaint(k, d) {
        var list = document.querySelectorAll('.c83-ava[data-ak="' + k + '"]');
        for (var i = 0; i < list.length; i++) list[i].innerHTML = '<img src="' + d + '" alt="" decoding="async">';
    }
    function apull() {
        var api = window.CloudSync && CloudSync.api;
        while (arun < 3 && aq.length) {
            var k = aq.shift(); arun++;
            (function (k) {
                var done = function () { arun--; apull(); };
                try {
                    api.req('GET', 's', 'avatars/' + api.enc(k) + '?cb=' + Date.now()).then(function (r) {
                        if (r && aok(r.d)) {
                            var l = 0; try { var o = JSON.parse(localStorage.getItem(AKEY + k) || 'null'); l = (o && +o.ts) || 0; } catch (e) {}
                            if ((+r.ts || 0) >= l || !aget(k)) { amem[k] = r.d; try { localStorage.setItem(AKEY + k, JSON.stringify({ d: r.d, ts: +r.ts || Date.now() })); } catch (e) {} }
                            apaint(k, amem[k]);
                        }
                        done();
                    }, done);
                } catch (e) { done(); }
            })(k);
        }
    }
    function hydrate(root) {
        try {
            var api = window.CloudSync && CloudSync.api;
            if (!root || !api || !api.effStu()) return;
            var nodes = root.querySelectorAll('.c83-ava[data-ak]'), now = Date.now();
            for (var i = 0; i < nodes.length; i++) {
                var k = nodes[i].getAttribute('data-ak');
                if (!k || (achk[k] && now - achk[k] < 600000) || aq.indexOf(k) >= 0) continue;
                achk[k] = now; aq.push(k);
            }
            apull();
        } catch (e) {}
    }
    function ago(ts) {
        var d = Date.now() - ts;
        if (d < 60e3) return 'Vừa xong';
        if (d < 3600e3) return Math.floor(d / 60e3) + ' phút trước';
        if (d < DAY) return Math.floor(d / 3600e3) + ' giờ trước';
        if (d < 30 * DAY) return Math.floor(d / DAY) + ' ngày trước';
        return new Date(ts).toLocaleDateString('vi-VN');
    }

    function collect() {
        var topics = (typeof savedTopics !== 'undefined') ? arr(savedTopics).filter(publicationAllowed) : [];
        var stu = isStu(), classes, myCls = [], asgSet = {}, mineIds = {}, me = '';
        if (stu) {
            myCls = myClasses(); classes = myCls; me = myName();
            myCls.forEach(function (c) { arr(c.t).forEach(function (t) { asgSet[t] = 1; }); arr(c.ids || [c.id]).forEach(function (i) { mineIds[i] = 1; }); });
        } else {
            classes = (typeof classesData !== 'undefined') ? arr(classesData) : [];
            if (!classes.length) {
                try { var raw = localStorage.getItem('matrix_classes_v1'); if (raw) classes = arr(JSON.parse(raw)); } catch (e) {}
            }
        }
        var resMap = (typeof studentResultsByTopic !== 'undefined' && studentResultsByTopic) ? studentResultsByTopic : {};
        function mine(r) { return !stu || norm(r.studentName || r.name) === me; }
        if (stu) {   /* gộp kết quả của máy này + kết quả các bạn cùng lớp lấy từ máy chủ (không trùng mã) */
            var merged = {};
            Object.keys(resMap).forEach(function (k) { merged[k] = arr(resMap[k]).slice(); });
            Object.keys(cloud.recs).forEach(function (k) {
                var have = {}; (merged[k] = merged[k] || []).forEach(function (r) { if (r && r.id) have[r.id] = 1; });
                arr(cloud.recs[k]).forEach(function (r) {
                    if (!r || have[r.id]) return;
                    if (Array.isArray(r.classIds) && r.classIds.length && !r.classIds.some(function (i) { return mineIds[i]; })) return;
                    merged[k].push(r);
                });
            });
            resMap = merged;
        }
        var now = Date.now(), today = startOfDay(now), weekAgo = now - 7 * DAY;
        var byId = {}; topics.forEach(function (t) { byId[t.id] = t; });

        // Đề thi
        var subj = {}, newDaily = [0, 0, 0, 0, 0, 0, 0], newCount = 0;
        topics.forEach(function (t) {
            var s = t.subject || 'Khác'; subj[s] = (subj[s] || 0) + 1;
            var c = createdTs(t);
            if (c >= weekAgo) newCount++;
            var idx = Math.floor((today - startOfDay(c)) / DAY);
            if (idx >= 0 && idx < 7) newDaily[6 - idx]++;
        });
        var subjList = Object.keys(subj).map(function (k) { return [k, subj[k]]; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 6);

        // Kết quả
        var all = [], attempts = {}, daily = [0, 0, 0, 0, 0, 0, 0], week = 0;
        Object.keys(resMap).forEach(function (k) {
            arr(resMap[k]).forEach(function (r) {
                if (!r) return;
                var ts = +r.submittedTs || 0;
                attempts[k] = (attempts[k] || 0) + 1;
                all.push({ k: k, r: r, ts: ts, sc: score10(r) });
                if (ts >= weekAgo && mine(r)) {
                    week++;
                    var idx = Math.floor((today - startOfDay(ts)) / DAY);
                    if (idx >= 0 && idx < 7) daily[6 - idx]++;
                }
            });
        });
        all.sort(function (a, b) { return b.ts - a.ts; });

        // Học sinh tiêu biểu: điểm TB cao nhất (ưu tiên 7 ngày qua)
        function best(list) {
            var m = {};
            list.forEach(function (x) {
                if (x.sc === null) return;
                var nm = (x.r.studentName || '').trim(); if (!nm) return;
                var key = norm(nm) + '|' + norm(x.r.className || x.r.studentClass);
                var o = m[key] || (m[key] = { name: nm, cls: x.r.className || x.r.studentClass || '', sum: 0, n: 0, subj: {} });
                o.sum += x.sc; o.n++;
                var tp = byId[x.k], sj = tp && tp.subject; if (sj) o.subj[sj] = (o.subj[sj] || 0) + 1;
            });
            var out = Object.keys(m).map(function (k) { var o = m[k]; o.avg = o.sum / o.n; var ks = Object.keys(o.subj).sort(function (a, b) { return o.subj[b] - o.subj[a]; }); o.sj = ks[0] || ''; return o; });
            out.sort(function (a, b) { return (b.avg - a.avg) || (b.n - a.n); });
            return out;
        }
        /* [CODE99] Bảng xếp hạng: ít nhất Top 3 (tối đa 10). Tuần này nếu đủ 3 học sinh, nếu không thì lấy cả thời gian */
        var starsW = best(all.filter(function (x) { return x.ts >= weekAgo; })), starsA = best(all);
        var starWeek = starsW.length >= 3 || (starsW.length > 0 && starsW.length >= starsA.length);
        var stars = (starWeek ? starsW : starsA).slice(0, 10), star = stars[0] || null;

        // [CODE85] Vinh danh học sinh tích cực: điểm trung bình (mỗi đề lấy điểm cao nhất) + chuyên cần (số lần làm bài)
        function leaders(list) {
            var m = {};
            list.forEach(function (x) {
                if (x.sc === null) return;
                var nm = (x.r.studentName || '').trim(); if (!nm) return;
                var cl = x.r.className || x.r.studentClass || '';
                var key = norm(nm) + '|' + norm(cl);
                var o = m[key] || (m[key] = { name: nm, cls: cl, n: 0, top: {} });
                o.n++;
                if (o.top[x.k] === undefined || x.sc > o.top[x.k]) o.top[x.k] = x.sc;
            });
            var out = Object.keys(m).map(function (k) {
                var o = m[k], ks = Object.keys(o.top), sum = 0;
                ks.forEach(function (t) { sum += o.top[t]; });
                o.avg = ks.length ? sum / ks.length : 0;
                o.pts = o.avg + Math.min(o.n, 10) * 0.15;
                o.self = !!me && norm(o.name) === me;
                return o;
            });
            out.sort(function (a, b) { return (b.pts - a.pts) || (b.avg - a.avg) || (b.n - a.n); });
            return out.slice(0, 5);
        }
        var lbAll = stu ? leaders(all) : [], lbWeek = stu ? leaders(all.filter(function (x) { return x.ts >= weekAgo; })) : [];

        // Đề được đề xuất
        /* [CODE97] Chỉ đề ĐÃ XUẤT BẢN mới được đề xuất; đề chưa xuất bản (bản nháp) không xuất hiện */
        var scored = topics.filter(function (t) { return t && Boolean(t.isPublished); }).map(function (t) {
            return { t: t, c: createdTs(t), a: attempts[t.id] || 0, u: t.updatedAt || 0 };
        });
        var picked = [], seen = {};
        function take(list, tag) { list.forEach(function (o) { if (picked.length < 4 && !seen[o.t.id]) { seen[o.t.id] = 1; picked.push({ t: o.t, a: o.a, tag: tag(o) }); } }); }
        if (stu) take(scored.filter(function (o) { return asgSet[o.t.id]; }).sort(function (a, b) { return b.c - a.c; }), function () { return 'asg'; });
        take(scored.filter(function (o) { return o.c >= weekAgo; }).sort(function (a, b) { return b.c - a.c; }), function () { return 'new'; });
        take(scored.filter(function (o) { return o.a >= 3; }).sort(function (a, b) { return b.a - a.a; }), function () { return 'hot'; });
        take(scored.slice().sort(function (a, b) { return (b.a - a.a) || (b.u - a.u); }), function () { return 'pub'; });

        var studentsPerClass = classes.map(function (c) { return arr(c.students).length; });
        var studentsTotal = studentsPerClass.reduce(function (a, b) { return a + b; }, 0);

        var classSubj = []; classes.forEach(function (c) { if (c.subject && classSubj.indexOf(c.subject) < 0) classSubj.push(c.subject); });
        var cap = '';
        if (stu) {
            studentsPerClass = myCls.map(function (c) { return arr(c.t).length; });
            cap = myCls.length ? myCls.slice(0, 2).map(function (c) { return c.name; }).join(', ') + (myCls.length > 2 ? '…' : '') : 'Chưa vào lớp nào';
            classSubj = [];
        }
        var assignedCount = 0; for (var ak in asgSet) assignedCount++;

        return {
            stu: stu, cap: cap, assignedCount: assignedCount, lbAll: lbAll, lbWeek: lbWeek, myCount: myCls.length,
            sigExtra: cloud.ts + '|' + boardMode + '|' + myCls.length + '|' + assignedCount + '|' + lbAll.length + '|' + lbWeek.length + '|' + me,
            classSubj: classSubj, topics: topics, byId: byId, subjList: subjList, newDaily: newDaily, newCount: newCount,
            classes: classes, studentsPerClass: studentsPerClass, studentsTotal: studentsTotal,
            week: week, daily: daily, star: star, stars: stars, starWeek: starWeek, picked: picked,
            recent: all.slice(0, 4), totalResults: all.length, latestTs: all.length ? all[0].ts : 0
        };
    }

    function bars(vals, soft, labels) {
        var max = Math.max.apply(null, vals.concat([1])), hi = vals.indexOf(Math.max.apply(null, vals));
        var out = '<div class="c83-bars' + (soft ? ' soft' : '') + '" role="img" aria-label="Biểu đồ cột">';
        vals.forEach(function (v, i) {
            var h = Math.max(14, Math.round(v / max * 100));
            out += '<i' + (v > 0 && i === hi ? ' class="hi"' : '') + ' style="height:' + h + '%" title="' + H((labels && labels[i] ? labels[i] + ': ' : '') + v) + '"></i>';
        });
        return out + '</div>';
    }

    function spark(vals) {
        var v = vals.length > 1 ? vals.slice() : (vals.length ? [vals[0], vals[0]] : [0, 0]);
        var W = 200, Hh = 50, n = v.length, max = Math.max.apply(null, v.concat([1]));
        var p = v.map(function (y, i) { return [i * W / (n - 1), Hh - 4 - (y / max) * (Hh - 12)]; });
        var d = 'M' + p[0][0] + ',' + p[0][1];
        for (var i = 0; i < n - 1; i++) {
            var p0 = p[i - 1] || p[i], p1 = p[i], p2 = p[i + 1], p3 = p[i + 2] || p2;
            d += ' C' + (p1[0] + (p2[0] - p0[0]) / 6).toFixed(1) + ',' + (p1[1] + (p2[1] - p0[1]) / 6).toFixed(1) + ' ' +
                (p2[0] - (p3[0] - p1[0]) / 6).toFixed(1) + ',' + (p2[1] - (p3[1] - p1[1]) / 6).toFixed(1) + ' ' + p2[0].toFixed(1) + ',' + p2[1].toFixed(1);
        }
        var id = 'c83g' + (++uid);
        return '<svg class="c83-spark" viewBox="0 0 ' + W + ' ' + Hh + '" preserveAspectRatio="none" role="img" aria-label="Biểu đồ đường"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2f6fed" stop-opacity=".28"/><stop offset="1" stop-color="#2f6fed" stop-opacity="0"/></linearGradient></defs>' +
            '<path d="' + d + ' L' + W + ',' + Hh + ' L0,' + Hh + ' Z" fill="url(#' + id + ')"/><path d="' + d + '" fill="none" stroke="#2f6fed" stroke-width="2.4" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>';
    }

    /* [CODE85] Khung "Vinh danh" Top 5 học sinh tích cực / điểm cao (thay cho Khu vực tạo đề nhanh) */
    function honorHtml(d) {
        var list = boardMode === 'week' ? d.lbWeek : d.lbAll, medals = ['🥇', '🥈', '🥉'];
        var s = '<section class="c83-col" aria-label="Vinh danh học sinh tích cực"><h3>Vinh Danh Học Sinh Tích Cực</h3><div class="c85-honor">' +
            '<div class="c85-tabs" role="tablist"><button type="button" role="tab" aria-selected="' + (boardMode === 'week') + '" class="' + (boardMode === 'week' ? 'on' : '') + '" data-c83="bw">Tuần này</button>' +
            '<button type="button" role="tab" aria-selected="' + (boardMode !== 'week') + '" class="' + (boardMode !== 'week' ? 'on' : '') + '" data-c83="ba">Tất cả</button></div>';
        if (list.length) {
            s += '<ol class="c85-rank">';
            list.forEach(function (o, i) {
                s += '<li class="c85-row r' + (i + 1) + (o.self ? ' me' : '') + '"><span class="c85-pos">' + (medals[i] || (i + 1)) + '</span>' + avatar(o.name, 42, o.cls) +
                    '<span class="c85-who"><b>' + H(o.name) + (o.self ? ' <em>(Bạn)</em>' : '') + '</b><small>' + (o.cls ? 'Lớp ' + H(o.cls) + ' • ' : '') + o.n + ' lượt làm bài</small></span>' +
                    '<span class="c85-pts"><b>' + F1(o.avg) + '</b><small>điểm TB</small></span></li>';
            });
            s += '</ol><p class="c85-note">Xếp hạng theo điểm trung bình, ưu tiên bạn làm nhiều bài. Cố lên, mỗi bài làm đều giúp em tiến gần bảng vàng!</p>';
        } else {
            s += '<div class="c85-empty"><span class="c85-cup">' + IC.trophy + '</span><b>' + (boardMode === 'week' ? 'Tuần này chưa có bài nộp nào' : 'Chưa có dữ liệu vinh danh') + '</b>' +
                '<span>Hãy làm bài được giao để trở thành học sinh đầu tiên lên bảng vàng!</span></div>';
        }
        return s + '</div></section>';
    }

    function html(d) {
        var days = [];
        for (var i = 6; i >= 0; i--) { var x = new Date(Date.now() - i * DAY); days.push(x.getDate() + '/' + (x.getMonth() + 1)); }
        var s = '';
        if (d.stu) {   /* [CODE85] nút truy cập nhanh */
            s += '<button type="button" class="c85-quick" data-c83="myclasses" aria-label="Truy cập nhanh lớp học của tôi"><span class="c85-quick-ic">' + IC.school + '</span>' +
                '<span class="c85-quick-tx"><b>TRUY CẬP NHANH LỚP HỌC CỦA TÔI</b><small>' + (d.myCount ? N(d.myCount) + ' lớp • ' + N(d.assignedCount) + ' bài được giao — bấm để làm bài ngay' : 'Bấm để tìm lớp và xin vào lớp') + '</small></span><span class="c85-quick-go" aria-hidden="true">›</span></button>';
        }
        s += '<div class="c83-top">';

        // 1. Thư viện đề thi
        s += '<section class="c83-card" aria-label="Thư viện đề thi"><div class="c83-card-head"><h3>Thư Viện Đề Thi</h3>' +
            '<button type="button" class="c83-ico" data-c83="lib" aria-label="Mở Thư viện" title="Mở Thư viện">' + IC.lib + '</button></div>' +
            '<div class="c83-pair"><div><div class="c83-lbl">Tổng số đề thi:</div><div class="c83-num">' + N(d.topics.length) + '</div>' +
            bars(d.subjList.length ? d.subjList.map(function (x) { return x[1]; }) : [0, 0, 0, 0, 0], false, d.subjList.map(function (x) { return x[0]; })) +
            '<div class="c83-cap" title="Số đề theo môn học">' + (d.subjList.length ? d.subjList.slice(0, 3).map(function (x) { return H(x[0]) + ' ' + x[1]; }).join(' • ') + (d.subjList.length > 3 ? ' …' : '') : 'Chưa có môn học') + '</div></div>' +
            '<div><div class="c83-lbl">Đề thi mới tạo:</div><div class="c83-num">' + N(d.newCount) + '</div>' + bars(d.newDaily, true, days) + '</div></div></section>';

        // 2. Lớp học của tôi
        s += '<section class="c83-card" aria-label="Lớp học của tôi"><div class="c83-card-head"><h3>Lớp Học Của Tôi</h3>' +
            '<button type="button" class="c83-ico" data-c83="' + (d.stu ? 'myclasses' : 'classes') + '" aria-label="' + (d.stu ? 'Mở Lớp học của tôi' : 'Mở Quản lí lớp học') + '" title="' + (d.stu ? 'Mở Lớp học của tôi' : 'Mở Quản lí lớp học') + '">' + IC.users + '</button></div>' +
            '<div class="c83-pair"><div><div class="c83-lbl">Tổng số Lớp:</div><div class="c83-num">' + N(d.classes.length) + '</div>' + spark(d.studentsPerClass.slice(0, 8)) + '<div class="c83-cap" title="Môn học của các lớp">' + (d.cap ? H(d.cap) : (d.classSubj.length ? 'Môn: ' + d.classSubj.slice(0, 3).map(H).join(', ') : N(d.studentsTotal) + ' học sinh')) + '</div></div>' +
            '<div><div class="c83-lbl">' + (d.stu ? 'Bài em làm tuần qua:' : 'Lượt học tuần qua:') + '</div><div class="c83-num">' + N(d.week) + '</div>' + spark(d.daily) + '</div></div></section>';

        // 3. Học sinh tiêu biểu
        s += '<section class="c83-card" aria-label="Học sinh tiêu biểu"><div class="c83-card-head"><h3>Học Sinh Tiêu Biểu</h3><span class="c83-medal" aria-hidden="true">' + IC.medal + '</span></div>';
        if (d.stars && d.stars.length) {
            s += '<div class="c99-rank" role="list" aria-label="Xếp hạng học sinh tiêu biểu">';
            d.stars.forEach(function (st, i) {
                s += '<div class="c99-row r' + (i < 3 ? i + 1 : 0) + '" role="listitem"><span class="c99-no">' + (i < 3 ? ['🥇', '🥈', '🥉'][i] : (i + 1)) + '</span>' + avatar(st.name, 44, st.cls) +
                    '<div style="min-width:0;flex:1"><div class="c99-name">' + H(st.name) + '</div>' +
                    '<div class="c83-star-sub" style="margin:0">' + (st.cls ? 'Lớp ' + H(st.cls) + ' • ' : '') + (st.sj ? H(st.sj) + ' • ' : '') + st.n + ' bài' + (d.starWeek ? ' trong tuần' : '') + '</div></div>' +
                    '<b class="c99-sc">' + F1(st.avg) + '</b></div>';
            });
            s += '</div>';
        } else {
            s += '<div class="c83-star">' + avatar('?', 78).replace('>?<', '>–<').replace(/background:linear-gradient\([^)]*\)\)/, 'background:#b9cdf3') + '<div class="c83-star-sub" style="margin:0">Chưa có bài nộp nào.<br>' + (d.stu ? 'Hãy làm bài để lên bảng vinh danh nhé!' : 'Giao đề cho lớp để xem học sinh nổi bật.') + '</div></div>';
        }
        s += '</section></div>';

        // Hàng dưới
        s += '<div class="c83-main">';
        // Đề đề xuất
        s += '<section class="c83-col" aria-label="Đề thi được đề xuất"><h3>Đề Thi Được Đề Xuất</h3>';
        if (d.picked.length) {
            var tagTxt = { 'new': 'Mới', hot: 'Đã Phổ Biến', pub: 'Đã Xuất Bản', draft: 'Bản Nháp', asg: 'Được Giao' };
            s += '<div class="c83-recs">';
            d.picked.forEach(function (p) {
                var t = p.t, nq = arr(t.questions).length;
                s += '<button type="button" class="c83-rec" data-c83="topic" data-id="' + H(t.id) + '" title="Mở đề này">' +
                    '<span class="c83-tag ' + p.tag + '">' + tagTxt[p.tag] + '</span>' +
                    '<span class="c83-rec-title">' + H(t.subtitle || t.title || 'Đề chưa đặt tên') + '</span>' +
                    '<span class="c83-subj">' + H([t.subject, t.grade].filter(Boolean).join(' – ') || 'Chưa chọn môn') + '</span>' +
                    '<span class="c83-rec-meta"><span>' + IC.q + nq + ' câu hỏi</span><span>' + IC.clock + (Number(t.timeLimit) || 50) + ' phút</span></span></button>';
            });
            s += '</div>';
        } else {
            s += '<div class="c83-empty">' + (d.stu ? 'Chưa có đề nào được giao.<br>Bấm “TRUY CẬP NHANH LỚP HỌC CỦA TÔI” để xem bài của lớp.' : 'Thư viện chưa có đề nào.<br>Nhấn dấu + ở khung bên phải để soạn đề đầu tiên.') + '</div>';
        }
        s += '</section>';

        // Hoạt động gần đây
        s += '<section class="c83-col" aria-label="Hoạt động gần đây"><h3>Hoạt Động Gần Đây</h3>';
        if (d.recent.length) {
            s += '<div class="c83-acts">';
            d.recent.forEach(function (x) {
                var r = x.r, tp = d.byId[x.k], nm = r.studentName || 'Học sinh', cls = r.className || r.studentClass || '';
                s += (d.stu ? '<div class="c83-act">' : '<button type="button" class="c83-act" data-c83="result" data-id="' + H(x.k) + '" title="Xem kết quả của đề này">') + avatar(nm, 36, cls) +
                    '<span class="c83-act-body"><span class="c83-act-name" style="display:block">' + H(nm) + '</span><span class="c83-act-sub" style="display:block">' + H(tp ? ((tp.subject ? tp.subject + ': ' : '') + (tp.subtitle || tp.title)) : 'Đề đã xóa') + '</span></span>' +
                    '<span class="c83-act-right"><span class="c83-act-score" style="display:block">' + (x.sc === null ? '—' : F1(x.sc) + '/10') + '</span><span class="c83-act-time" style="display:block">' + (cls ? 'Lớp ' + H(cls) : (x.ts ? ago(x.ts) : '')) + '</span></span>' + (d.stu ? '</div>' : '</button>');
            });
            s += '</div>';
        } else {
            s += '<div class="c83-empty">Chưa có học sinh nào nộp bài.</div>';
        }
        s += '</section>';

        // Tạo đề nhanh
        s += d.stu ? honorHtml(d) : '<section class="c83-col" aria-label="Khu vực tạo đề nhanh"><h3>Khu Vực Tạo Đề Nhanh</h3><div class="c83-quickbox">' +
            '<div class="c83-orbit"><span class="c83-ring" aria-hidden="true"></span>' +
            '<button type="button" class="c83-plus" data-c83="new" aria-label="Tạo nhanh đề thi" title="Tạo nhanh đề thi">' + IC.plus + '</button>' +
            '<div class="c83-mini"><button type="button" class="c83-o-word" data-c83="word">' + IC.word + 'NHẬP TỪ WORD</button><button type="button" class="c83-o-lib" data-c83="lib">' + IC.folder + 'MỞ THƯ VIỆN</button><button type="button" class="c83-o-bank" data-c83="bank" title="Mở Ngân hàng đề">📚 NGÂN HÀNG ĐỀ</button></div>' +
            '<button type="button" class="c83-mixbtn c83-o-mix" data-c83="mix" title="Trộn đề thi thành nhiều mã đề">🔀 TRỘN ĐỀ THI</button></div>' +
            '<p class="c83-quick-t">Soạn đề mới trong vài bước</p>' +
            '<p class="c83-quick-p">Nhấn dấu <b>+</b> để tạo nhanh đề thi, hoặc chọn một nút xung quanh.</p></div></section>';
        s += '</div>';
        s += '<div class="c164-credit">🎨 ' + H(window.CODE164Designer ? window.CODE164Designer.line() : 'Design: ThS Trần Thông') + '</div>';   /* [CODE164] */
        return s;
    }

    function signature(d) {
        return (d.stu ? d.sigExtra : '') + '#' + [d.topics.length, d.newCount, d.classes.length, d.studentsTotal, d.week, d.totalResults, d.latestTs, Math.floor(Date.now() / 60000),
            d.topics.reduce(function (m, t) { return Math.max(m, t.updatedAt || 0); }, 0), d.topics.filter(function (t) { return t && t.isPublished; }).length, (window.CODE164Designer ? window.CODE164Designer.line() : '')].join('|');
    }

    function onClick(e) {
        var b = e.target.closest ? e.target.closest('[data-c83]') : null; if (!b) return;
        var a = b.getAttribute('data-c83'), id = b.getAttribute('data-id');
        try {
            if (a === 'myclasses') openStudentClasses();
            else if (a === 'bw' || a === 'ba') { boardMode = a === 'bw' ? 'week' : 'all'; lastSig = ''; refresh(); }
            else if (a === 'lib') openLibrary();
            else if (a === 'bank') { if (window.CODE126Bank) CODE126Bank.open(); }   /* [CODE165] */
            else if (a === 'classes') openClassManager();
            else if (a === 'new') openEditor(null);
            else if (a === 'word') { openEditor(null); setTimeout(function () { if (typeof openWordImportModal === 'function') openWordImportModal(); }, 350); }
            else if (a === 'mix') { if (window.CODE93Mix) CODE93Mix.open(); }
            else if (a === 'topic') loadTopic(id);
            else if (a === 'result') openResultsModal(id);
        } catch (err) { console.warn('[CODE83] ' + a, err); }
    }

    function render(container) {
        if (!container) return false;
        if (isStu()) { if (!cloud.ts) loadCloudCache(); }
        var d = collect();
        container.innerHTML = wrapHtml(d);
        el = container.firstChild;
        el.addEventListener('click', onClick);
        lastSig = signature(d);
        kick();
        hydrate(el);
        return true;
    }

    // Làm mới nhẹ nhàng: chỉ vẽ lại khi dữ liệu thật sự thay đổi (không giật, không mất vị trí cuộn)
    function refresh() {
        timer = 0;
        kick();
        if (!el || !document.body.contains(el)) { el = null; return; }
        if (document.hidden) return;
        var d = collect();
        var sig = signature(d);
        if (sig === lastSig) { hydrate(el); return; }
        var host = el.parentNode, top = host ? host.scrollTop : 0;
        el.removeEventListener('click', onClick);
        host.innerHTML = wrapHtml(d);
        el = host.firstChild; el.addEventListener('click', onClick);
        host.scrollTop = top; lastSig = sig; hydrate(el);
    }
    function schedule() { if (el && !timer) timer = setTimeout(refresh, 400); }

    function wrap(name) {
        var orig = window[name];
        if (typeof orig !== 'function' || orig.__c83) return;
        var w = function () { var r = orig.apply(this, arguments); schedule(); return r; };
        w.__c83 = true; window[name] = w;
    }
    function init() {
        ['saveToStorage', 'saveStudentResultsToStorage', 'cmSave', 'loadStudentResultsFromStorage', 'cmLoad', 'closeStudentClasses'].forEach(wrap);
        tick = setInterval(function () { if (el) schedule(); }, 30000);
        document.addEventListener('visibilitychange', function () { if (!document.hidden) schedule(); });
    }
    window.CODE83Home = { render: render, refresh: refresh };
    window.CODE85Home = window.CODE83Home;
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
