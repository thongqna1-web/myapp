
        // [CODE28] Điện thoại: thu gọn mục chia điểm mặc định để thấy câu hỏi ngay (bấm tiêu đề để mở rộng)
        (function(){
            function collapse(){ try { var d=document.getElementById('editor-settings-panel'); if(d && window.innerWidth<=820) d.removeAttribute('open'); } catch(e){} }
            if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', collapse); else collapse();
        })();
    