
/* [CODE153] TẠO VÀ CHỈNH SỬA ĐỀ THI <-> NGÂN HÀNG ĐỀ
   (1) Nút "NHẬP TỪ NGÂN HÀNG ĐỀ": chọn Môn > Khối > Chương / Bài, lấy toàn bộ hoặc theo số câu từng mức độ (NB/TH/VD/VDC).
   (2) Ô "Chủ đề bài học" đồng bộ tên bài từ NGÂN HÀNG ĐỀ theo Môn học + Khối lớp đang chọn; vẫn sửa tự do.
   Dữ liệu đọc từ CODE129Bank (localStorage / đồng bộ Firebase) nên chạy tốt trên GitHub Pages. */
(function () {
    'use strict';
    var MAP = { 'Toán học': 'Toán lớp 12', 'Toán': 'Toán lớp 12' };
    var LV = ['NB', 'TH', 'VD', 'VDC'];
    var S = { sj: '', g: 0, sel: {}, col: {}, pickKey: '', man: {} };

    function $(id) { return document.getElementById(id); }
    function bank() { return window.CODE129Bank && window.CODE129Bank.lessonsOf ? window.CODE129Bank : null; }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
    function norm(s) { s = String(s || '').toLowerCase(); try { s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (e) {} return s.replace(/đ/g, 'd'); }
    function show(id) { var m = $(id); if (!m) return; m.classList.remove('hidden'); setTimeout(function () { m.classList.remove('opacity-0'); }, 10); }
    function hide(id) { var m = $(id); if (!m) return; m.classList.add('opacity-0'); setTimeout(function () { m.classList.add('hidden'); }, 300); }
    function alertBox(t, msg, type) { try { showModal(t, msg, type || 'info'); } catch (e) { alert(msg); } }

    function edSubject() { var el = $('edit-subject'), v = el ? el.value : ''; return MAP[v] || v; }
    function edGrade() { var el = $('edit-grade'), m = el && /(\d+)/.exec(el.value || ''); return m ? parseInt(m[1], 10) : 0; }

    /* Cây dữ liệu: [{id, n, items:[{id, n, key, cnt, lv}]}] */
    function tree(sj, g) {
        var B = bank(), out = [], cur = null;
        if (!B || !sj || !g) return out;
        B.lessonsOf(sj, g).forEach(function (x) {
            if (x.h) { cur = { id: x.id, n: x.n, items: [] }; out.push(cur); return; }
            if (!cur) { cur = { id: '_0', n: '', items: [] }; out.push(cur); }
            var key = sj + '|' + g + '|' + x.id, m = B.meta(key);
            cur.items.push({ id: x.id, n: x.n, key: key, cnt: m.n || 0, lv: m.m || {} });
        });
        return out;
    }
    function lvText(lv) {
        var t = [];
        LV.forEach(function (k) { if (lv && lv[k]) t.push(k + ' ' + lv[k]); });
        return t.join(' • ');
    }

    /* ===================== (2) CHỦ ĐỀ BÀI HỌC đồng bộ với Ngân hàng đề ===================== */
    function refresh() {
        var dl = $('edit-subtitle-list'), hint = $('ed-subtitle-hint'), btn = $('ed-subtitle-pick');
        if (!dl && !hint) return;
        var sj = edSubject(), g = edGrade(), names = [], chapters = 0;
        try { tree(sj, g).forEach(function (c) { if (c.n) chapters++; c.items.forEach(function (it) { names.push(it.n); }); }); } catch (e) {}
        if (dl) dl.innerHTML = names.map(function (n) { return '<option value="' + esc(n) + '"></option>'; }).join('');
        if (btn) btn.classList.toggle('ib-has', names.length > 0);
        if (hint) {
            if (!bank()) hint.textContent = '';
            else if (names.length) hint.innerHTML = '📚 Ngân hàng đề có <b>' + names.length + ' bài</b> cho ' + esc(sj) + ' • Lớp ' + g + '. Bấm <b>📚 Chọn bài</b> hoặc gõ để chọn tên bài; vẫn sửa tên tự do.';
            else hint.innerHTML = 'Ngân hàng đề chưa có bài cho ' + esc(sj || 'môn này') + (g ? ' • Lớp ' + g : '') + '. Bạn vẫn nhập tên chủ đề tự do.';
        }
    }
    function onSubjGrade() { refresh(); var el = $('edit-subtitle'); if (el) el.dataset.bankKey = ''; }

    function openPick() {
        if (!bank()) { alertBox('Chưa có Ngân hàng đề', 'Không đọc được dữ liệu Ngân hàng đề. Hãy tải lại trang rồi thử lại.'); return; }
        var sj = edSubject(), g = edGrade();
        var sub = $('ib-pick-sub'); if (sub) sub.textContent = (sj || '—') + ' • Lớp ' + (g || '—');
        var se = $('ib-pick-search'); if (se) se.value = '';
        renderPick(); show('ib-pick-modal');
        setTimeout(function () { try { if (se && window.innerWidth > 700) se.focus(); } catch (e) {} }, 60);
    }
    function closePick() { hide('ib-pick-modal'); }
    function renderPick() {
        var box = $('ib-pick-list'); if (!box) return;
        var q = norm(($('ib-pick-search') || {}).value || ''), data = tree(edSubject(), edGrade()), h = '', shown = 0;
        data.forEach(function (c) {
            var items = c.items.filter(function (it) { return !q || norm(it.n).indexOf(q) >= 0 || norm(c.n).indexOf(q) >= 0; });
            var chHit = c.n && (!q || norm(c.n).indexOf(q) >= 0);
            if (!items.length && !chHit) return;
            if (c.n) h += '<button type="button" class="ib-chap" data-pick="' + esc(c.n) + '" data-k="">📁 ' + esc(c.n) + '<span class="ib-tag">chọn cả chương</span></button>';
            items.forEach(function (it) {
                shown++;
                h += '<button type="button" class="ib-lesson" data-pick="' + esc(it.n) + '" data-k="' + esc(it.key) + '"><span class="ib-ln">' + esc(it.n) + '</span>' +
                    (it.cnt ? '<span class="ib-badge">' + it.cnt + ' câu</span>' : '<span class="ib-badge ib-zero">chưa có câu</span>') + '</button>';
            });
        });
        if (!h) h = '<div class="ib-empty">' + (data.length ? 'Không tìm thấy bài phù hợp.' : 'Ngân hàng đề chưa có bài cho Môn học / Khối lớp này.<br>Vào <b>NGÂN HÀNG ĐỀ</b> để thêm danh sách bài, hoặc nhập tên chủ đề tự do.') + '</div>';
        box.innerHTML = h;
    }
    function pickValue(name, key) {
        var el = $('edit-subtitle'); if (!el) return;
        el.value = name; el.dataset.bankKey = key || '';
        try { syncTopicTitleLive(name); } catch (e) {}
        closePick();
        setTimeout(function () { try { el.focus(); } catch (e) {} }, 320);
    }

    /* ===================== (1) NHẬP TỪ NGÂN HÀNG ĐỀ ===================== */
    function subjectsWithData() { var B = bank(); return B ? B.subjectNames() : []; }
    function fillSubjects(selected) {
        var sel = $('ib-subject'), B = bank(); if (!sel || !B) return;
        sel.innerHTML = B.subjectNames().map(function (n) { return '<option value="' + esc(n) + '"' + (n === selected ? ' selected' : '') + '>' + esc(n) + '</option>'; }).join('');
    }
    function fillGrades(sj, wantG) {
        var sel = $('ib-grade'), B = bank(); if (!sel || !B) return;
        var gs = B.gradesOf(sj); if (!gs.length) gs = [];
        if (gs.indexOf(wantG) < 0) {   // chọn khối đầu tiên đã có bài nếu khối mong muốn chưa có
            var pick = gs.filter(function (x) { return B.lessonsOf(sj, x).length; })[0];
            wantG = pick || gs[gs.length - 1] || 0;
        }
        sel.innerHTML = gs.slice().sort(function (a, b) { return b - a; }).map(function (x) { return '<option value="' + x + '"' + (x === wantG ? ' selected' : '') + '>Lớp ' + x + '</option>'; }).join('');
        S.g = wantG;
    }
    function openImport() {
        if (window.__bankCtx) return;
        var B = bank();
        if (!B) { alertBox('Chưa có Ngân hàng đề', 'Không đọc được dữ liệu Ngân hàng đề. Hãy tải lại trang rồi thử lại.'); return; }
        var names = B.subjectNames(), sj = edSubject(), g = edGrade();
        if (names.indexOf(sj) < 0) sj = names.filter(function (n) { return B.gradesOf(n).some(function (x) { return B.lessonsOf(n, x).length; }); })[0] || names[0];
        S.sj = sj; S.sel = {}; S.man = {}; S.col = {};
        fillSubjects(sj); fillGrades(sj, g); S.g = parseInt(($('ib-grade') || {}).value, 10) || 0;
        // nếu chủ đề đang chọn từ ngân hàng thì tick sẵn bài đó
        var el = $('edit-subtitle'), tk = el && el.dataset.bankKey;
        if (tk && tk.indexOf(sj + '|' + S.g + '|') === 0) S.sel[tk] = true;
        var ft = $('ib-fill-title'); if (ft) ft.checked = !(el && el.value.trim());
        var sr = $('ib-search'); if (sr) sr.value = '';
        var al = $('ib-all'); if (al) al.checked = false;
        ['mc', 'tf', 'sa'].forEach(function (k) { var e = $('ib-p-' + k); if (e) e.value = 0; });
        var md = document.querySelector('input[name="ib-mode"][value="append"]'); if (md) md.checked = true;
        renderTree(); show('ib-modal');
    }
    function closeImport() { hide('ib-modal'); }
    function onSubject() {
        var sel = $('ib-subject'); if (!sel) return;
        S.sj = sel.value; S.sel = {}; S.man = {}; S.col = {};
        fillGrades(S.sj, S.g); S.g = parseInt(($('ib-grade') || {}).value, 10) || 0;
        var al = $('ib-all'); if (al) al.checked = false;
        renderTree();
    }
    function onGrade() { S.g = parseInt(($('ib-grade') || {}).value, 10) || 0; S.sel = {}; S.man = {}; S.col = {}; var al = $('ib-all'); if (al) al.checked = false; renderTree(); }

    function renderTree() {
        var box = $('ib-tree'); if (!box) return;
        var q = norm(($('ib-search') || {}).value || ''), data = tree(S.sj, S.g), h = '', any = false;
        data.forEach(function (c, ci) {
            var items = c.items.filter(function (it) { return !q || norm(it.n).indexOf(q) >= 0 || norm(c.n).indexOf(q) >= 0; });
            if (!items.length) return;
            any = true;
            var tot = 0, sel = 0, selable = 0;
            items.forEach(function (it) { tot += it.cnt; if (it.cnt) { selable++; if (S.sel[it.key]) sel++; } });
            var open = q ? true : !S.col[c.id];
            if (c.n) {
                h += '<div class="ib-chap-row"><input type="checkbox" class="ib-cb" data-ch="' + ci + '"' + (selable && sel === selable ? ' checked' : '') + (selable ? '' : ' disabled') + '>' +
                    '<button type="button" class="ib-chap-name" data-tg="' + esc(c.id) + '"><span class="ib-arrow">' + (open ? '▾' : '▸') + '</span> ' + esc(c.n) + '</button>' +
                    '<span class="ib-badge">' + tot + ' câu</span></div>';
            }
            if (open) {
                items.forEach(function (it) {
                    h += '<label class="ib-ls' + (it.cnt ? '' : ' ib-off') + (c.n ? ' ib-indent' : '') + '"><input type="checkbox" class="ib-cb" data-ls="' + esc(it.key) + '"' + (S.sel[it.key] ? ' checked' : '') + (it.cnt ? '' : ' disabled') + '>' +
                        '<span class="ib-ln">' + esc(it.n) + '</span>' +
                        (it.cnt ? '<span class="ib-badge">' + it.cnt + ' câu' + (lvText(it.lv) ? ' • ' + lvText(it.lv) : '') + '</span>' : '<span class="ib-badge ib-zero">chưa có câu</span>') + (it.cnt ? manBtn(it) : '') + '</label>';
                });
            }
        });
        if (!any) h = '<div class="ib-empty">' + (data.length ? 'Không tìm thấy bài phù hợp.' : 'Ngân hàng đề chưa có bài cho <b>' + esc(S.sj) + ' • Lớp ' + S.g + '</b>.<br>Vào mục <b>NGÂN HÀNG ĐỀ</b> để thêm danh sách bài và tạo câu hỏi.') + '</div>';
        box.innerHTML = h;
        updateSummary();
    }
    function chapterItems(ci) {
        var data = tree(S.sj, S.g), q = norm(($('ib-search') || {}).value || ''), c = data[ci];
        if (!c) return [];
        return c.items.filter(function (it) { return !q || norm(it.n).indexOf(q) >= 0 || norm(c.n).indexOf(q) >= 0; });
    }
    function toggleAll(on) {
        tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { if (it.cnt) { if (on) S.sel[it.key] = true; else delete S.sel[it.key]; } }); });
        renderTree();
    }
    function expandAll(on) { tree(S.sj, S.g).forEach(function (c) { S.col[c.id] = !on; }); renderTree(); }

    function selectedItems() {
        var out = [];
        tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { if (S.sel[it.key] && it.cnt) out.push({ it: it, chap: c }); }); });
        return out;
    }
    function takeMode() { var t = 0; PART.forEach(function (p) { t += Math.max(0, parseInt(($('ib-p-' + p[0]) || {}).value, 10) || 0); }); return t > 0 ? 'part' : 'all'; }   /* chỉ còn lấy theo phần: để 0 cả 3 phần = lấy toàn bộ */
    /* [CODE161] Phần I = trắc nghiệm nhiều lựa chọn (mc), Phần II = đúng/sai (tf), Phần III = trả lời ngắn (sa) */
    var PART = [['mc', 'Phần I'], ['tf', 'Phần II'], ['sa', 'Phần III']];
    function partOf(q) { return q && q.type === 'tf' ? 'tf' : (q && q.type === 'sa' ? 'sa' : 'mc'); }
    function selTake() { updateSummary(); }
    function updateSummary() {
        var box = $('ib-summary'), sl = selectedItems(), tot = 0, lv = { NB: 0, TH: 0, VD: 0, VDC: 0 };
        sl.forEach(function (x) { tot += x.it.cnt; LV.forEach(function (k) { lv[k] += (x.it.lv && x.it.lv[k]) || 0; }); });
        var withLv = lv.NB + lv.TH + lv.VD + lv.VDC;
        var pc = { mc: 0, tf: 0, sa: 0 };   /* [CODE161] số câu có sẵn theo Phần I / II / III */
        try { if (sl.length) bank().getMany(sl.map(function (x) { return x.it.key; })).forEach(function (arr) { (arr || []).forEach(function (q) { pc[partOf(q)]++; }); }); } catch (e) {}
        PART.forEach(function (p) { var a = $('ib-pv-' + p[0]); if (a) a.textContent = 'có ' + pc[p[0]]; });
        if (box) {
            if (!sl.length) box.innerHTML = '👉 Tích chọn <b>bài</b> hoặc cả <b>chương</b> ở bên trái để lấy câu hỏi.';
            else {
                var needP = PART.reduce(function (a, p) { return a + Math.max(0, parseInt(($('ib-p-' + p[0]) || {}).value, 10) || 0); }, 0);
                box.innerHTML = 'Đã chọn <b>' + sl.length + ' bài</b> • có sẵn <b>' + tot + ' câu</b>' + (withLv ? '<br><span class="text-slate-600">' + lvText(lv) + (tot > withLv ? ' • chưa phân mức ' + (tot - withLv) : '') + '</span>' : '') +
                    '<br><span class="text-slate-600">Phần I: ' + pc.mc + ' • Phần II: ' + pc.tf + ' • Phần III: ' + pc.sa + '</span>' +
                    (takeMode() === 'part' ? '<br>Sẽ lấy: <b>' + needP + ' câu</b> theo phần' : '<br>Sẽ lấy: <b>' + tot + ' câu</b>');
            }
        }
    }

    function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
    function rid() { return 'g_' + Math.random().toString(36).slice(2, 8); }

    /* [CODE163] Lấy theo phần: mức độ tự động theo Bộ GD&ĐT (mỗi phần 4 : 3 : 3 = Nhận biết : Thông hiểu : Vận dụng; VDC tính vào Vận dụng; thiếu thì bù mức khác);
       chia đều: các chương đã chọn nhận số câu bằng nhau, trong mỗi chương các bài đã chọn nhận số câu bằng nhau (bài hết câu thì bài khác bù). */
    var TIERS = ['NB', 'TH', 'VD'], RATIO = { NB: 4, TH: 3, VD: 3 };
    function tierOf(q) { var l = q && q.level; return l === 'NB' ? 'NB' : l === 'TH' ? 'TH' : (l === 'VD' || l === 'VDC') ? 'VD' : 'NO'; }
    function balancedTake(P, k, T) {
        var out = [], rem = k;
        while (rem > 0) {
            var bi = -1, bc = 0, bl = 0;
            for (var i = 0; i < P.length; i++) {
                var u = P[i]; if (u.length > rem) continue;
                var c = T.c[u.c] || 0, l = T.l[u.l] || 0;
                if (bi < 0 || c < bc || (c === bc && l < bl)) { bi = i; bc = c; bl = l; }
            }
            if (bi < 0) break;
            var u2 = P.splice(bi, 1)[0];
            T.c[u2.c] = (T.c[u2.c] || 0) + u2.length; T.l[u2.l] = (T.l[u2.l] || 0) + u2.length;
            rem -= u2.length; out.push(u2);
        }
        return out;
    }
    function pickByPart(pool) {
        var need = {}, rnd = ($('ib-rand') || {}).checked, lack = [], units = [], gm = {}, T = { c: {}, l: {} }, picked = [];
        PART.forEach(function (p) { need[p[0]] = Math.max(0, parseInt(($('ib-p-' + p[0]) || {}).value, 10) || 0); });
        pool.forEach(function (q) {
            if (q.gid) { var k = q.__k + '#' + q.gid; if (!gm[k]) { gm[k] = []; units.push(gm[k]); } gm[k].push(q); } else units.push([q]);
        });
        units.forEach(function (u) { u.c = u[0].__c; u.l = u[0].__l; u.t = tierOf(u[0]); u.p = partOf(u[0]); });
        PART.forEach(function (p) {
            var n = need[p[0]]; if (!n) return;
            var cells = { NB: [], TH: [], VD: [], NO: [] };
            units.forEach(function (u) { if (u.p === p[0]) cells[u.t].push(u); });
            if (rnd) Object.keys(cells).forEach(function (t) { shuffle(cells[t]); });
            var raw = TIERS.map(function (l) { return n * RATIO[l] / 10; }), tg = raw.map(Math.floor), rest = n - tg.reduce(function (a, b) { return a + b; }, 0);
            raw.map(function (v, i) { return [v - Math.floor(v), i]; }).sort(function (a, b) { return b[0] - a[0]; }).forEach(function (x) { if (rest > 0) { tg[x[1]]++; rest--; } });
            var left = n, got = 0;
            var take = function (t, k) {
                if (!(k > 0) || left <= 0) return;
                balancedTake(cells[t], Math.min(k, left), T).forEach(function (u) { picked.push(u); left -= u.length; got += u.length; });
            };
            TIERS.forEach(function (l, i) { take(l, tg[i]); });
            ['TH', 'NB', 'VD', 'NO'].forEach(function (l) { take(l, left); });
            if (got < n) lack.push(p[1] + ': cần ' + n + ', chỉ có ' + got);
        });
        return { chosen: [].concat.apply([], picked), lack: lack };
    }

    function doImport() {
        var B = bank(), sl = selectedItems(), msl = manualItems();
        if (!B) return;
        if (!sl.length && !msl.length) { alertBox('Chưa chọn bài', 'Hãy tích chọn ít nhất 1 bài (hoặc cả chương) có câu hỏi trong Ngân hàng đề.'); return; }
        try { if (window.__bankEnsure) window.__bankEnsure(sl.concat(msl).map(function (x) { return x.it.key; })); } catch (e) {}
        var all = B.getMany(sl.map(function (x) { return x.it.key; })), pool = [];
        var cIdx = {}, cn = 0;
        sl.forEach(function (x, i) { if (!(x.chap.id in cIdx)) cIdx[x.chap.id] = cn++; (all[i] || []).forEach(function (q) { var c = JSON.parse(JSON.stringify(q)); c.__k = x.it.key; c.bankKey = x.it.key; c.__c = cIdx[x.chap.id]; c.__l = i; c.__i = pool.length; pool.push(c); }); });
        if (!pool.length && !msl.length) { alertBox('Không có câu hỏi', 'Các bài đã chọn chưa có câu hỏi nào trong Ngân hàng đề.'); return; }

        var chosen = pool;
        window.__ibLack = null;
        if (takeMode() === 'part' && pool.length) {
            var res = pickByPart(pool);
            chosen = res.chosen; window.__ibLack = res.lack;
            if (!chosen.length) { alertBox('Không đủ câu', 'Các bài đã chọn không có câu hỏi ở phần bạn yêu cầu.'); return; }
            chosen.sort(function (a, b) { return a.__i - b.__i; });
        }

                var forced = [];   // [CODE164] câu giáo viên chọn tay: luôn được lấy
        msl.forEach(function (x) { var arr = B.getQuestions(x.it.key); Object.keys(S.man[x.it.key]).map(Number).sort(function (p, q) { return p - q; }).forEach(function (i) { if (arr[i]) { var c = JSON.parse(JSON.stringify(arr[i])); c.__k = x.it.key; c.bankKey = x.it.key; forced.push(c); } }); });
        chosen = forced.concat(chosen); pool = pool.concat(forced); sl = sl.concat(msl);
        if (!chosen.length) { alertBox('Không có câu hỏi', 'Chưa có câu hỏi nào được chọn.'); return; }

        // Nhóm câu (đoạn văn / dữ kiện chung): tạo mã nhóm mới, giữ dữ kiện ở câu đầu nhóm được chọn
        var info = {}, remap = {}, seen = {};
        pool.forEach(function (q) { var k = q.__k + '#' + q.gid; if (q.gid && q.ginfo && !info[k]) info[k] = q.ginfo; });
        chosen.forEach(function (q) {
            if (!q.gid) return;
            var k = q.__k + '#' + q.gid;
            if (!remap[k]) remap[k] = rid();
            var first = !seen[k]; seen[k] = 1; q.gid = remap[k];
            if (first && info[k]) q.ginfo = info[k]; else delete q.ginfo;
        });

        var drafts = chosen.map(function (q) { delete q.__k; delete q.__i; delete q.__c; delete q.__l; return topicQuestionToDraft(q); });
        try { syncEditorDOMToDraft(); } catch (e) {}
        var mode = (document.querySelector('input[name="ib-mode"]:checked') || {}).value || 'append', merged;
        if (mode === 'append') {
            var keep = editorDraftQuestions.filter(function (q) { return String(q.text || '').trim() || String(q.answer || '').trim() || (q.options || []).some(function (o) { return String((o && o.text) || '').trim(); }); });
            merged = keep.concat(drafts);
        } else merged = drafts;
        editorDraftQuestions = sortDraftsByType(normalizeDraftGroups(merged));

        // Môn học / Khối lớp / Chủ đề
        var sjSel = $('edit-subject'), grSel = $('edit-grade'), titleEl = $('edit-subtitle');
        if (($('ib-fill-sg') || {}).checked) {
            try {
                var v = bankSubjectToEditorValue(S.sj);
                if (sjSel && v && !sjSel.disabled && sjSel.value !== v) { sjSel.value = v; try { refreshScoringSummary(); } catch (e) {} }
                if (grSel && !grSel.disabled) { var gv = 'Lớp ' + S.g; if (Array.prototype.some.call(grSel.options, function (o) { return o.value === gv; })) grSel.value = gv; }
            } catch (e) {}
            refresh();
        }
        if (($('ib-fill-title') || {}).checked && titleEl) {
            var nm = titleName(sl);
            titleEl.value = nm; titleEl.dataset.bankKey = sl.length === 1 ? sl[0].it.key : '';
            try { syncTopicTitleLive(nm); } catch (e) {}
        }

        try { syncPaletteAndPatternToCount(editorDraftQuestions.length); } catch (e) {}
        renderEditorForm();
        closeImport();
        var c = countByType(editorDraftQuestions), lc = { NB: 0, TH: 0, VD: 0, VDC: 0 };
        chosen.forEach(function (q) { if (lc[q.level] != null) lc[q.level]++; });
        var lt = lvText(lc);
        var lackTxt = (window.__ibLack && window.__ibLack.length) ? ' Lưu ý - không đủ câu: ' + window.__ibLack.join('; ') + '.' : ''; window.__ibLack = null;
        setTimeout(function () {
            alertBox('Thành công!', 'Đã nhập ' + chosen.length + ' câu hỏi từ Ngân hàng đề (' + sl.length + ' bài' + (lt ? ' • ' + lt : '') + '). Tổng đề hiện có ' + editorDraftQuestions.length + ' câu: Phần I = ' + c.mc + ', Phần II = ' + c.tf + ', Phần III = ' + c.sa + '.' + lackTxt, 'success');
        }, 340);
    }
    function titleName(sl) {
        if (sl.length === 1) return sl[0].it.n;
        var ch = sl[0].chap;
        if (ch.n && sl.every(function (x) { return x.chap === ch; })) return ch.n;
        var ns = sl.slice(0, 3).map(function (x) { return x.it.n; }).join('; ');
        return sl.length > 3 ? ns + ' (+' + (sl.length - 3) + ' bài)' : ns;
    }

    /* ===================== Sự kiện ===================== */
    document.addEventListener('click', function (e) {
        var t = e.target; if (!t || !t.closest) return;
        var vw = t.closest('[data-view]'); if (vw) { e.preventDefault(); openView(vw.getAttribute('data-view')); return; }
        var p = t.closest('[data-pick]');
        if (p && $('ib-pick-list') && $('ib-pick-list').contains(p)) { pickValue(p.getAttribute('data-pick'), p.getAttribute('data-k')); return; }
        var tg = t.closest('[data-tg]');
        if (tg && $('ib-tree') && $('ib-tree').contains(tg)) { var id = tg.getAttribute('data-tg'); S.col[id] = !S.col[id]; renderTree(); }
    });
    document.addEventListener('change', function (e) {
        var t = e.target; if (!t || !$('ib-tree') || !$('ib-tree').contains(t)) return;
        if (t.hasAttribute('data-ls')) { var k = t.getAttribute('data-ls'); if (t.checked) { S.sel[k] = true; delete S.man[k]; } else delete S.sel[k]; renderTree(); syncAll(); }
        else if (t.hasAttribute('data-ch')) {
            var its = chapterItems(parseInt(t.getAttribute('data-ch'), 10));
            its.forEach(function (it) { if (it.cnt) { if (t.checked) { S.sel[it.key] = true; delete S.man[it.key]; } else delete S.sel[it.key]; } });
            renderTree(); syncAll();
        }
    });
    function syncAll() {   // cập nhật ô "Chọn tất cả"
        var al = $('ib-all'); if (!al) return;
        var n = 0, s = 0; tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { if (it.cnt) { n++; if (S.sel[it.key]) s++; } }); });
        al.checked = n > 0 && n === s;
    }
    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        var pk = $('ib-pick-modal'), im = $('ib-modal');
        if (pk && !pk.classList.contains('hidden')) closePick(); else if (im && !im.classList.contains('hidden')) closeImport();
    });


    /* [CODE164] Nút "Xem câu": giáo viên xem từng câu trong bài và tự tích chọn câu cần lấy */
    function manualItems() { var out = []; tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (it) { var m = S.man[it.key]; if (m && Object.keys(m).length && it.cnt) out.push({ it: it, chap: c }); }); }); return out; }
    function manBtn(it) { var n = S.man[it.key] ? Object.keys(S.man[it.key]).length : 0; return '<button type="button" class="ib-vw" data-view="' + esc(it.key) + '" style="margin-left:6px;padding:2px 9px;border-radius:999px;font-size:11px;font-weight:900;color:#5b21b6;background:#ede9fe;border:1px solid #c4b5fd;white-space:nowrap">👁 Xem câu' + (n ? ' • ✋' + n : '') + '</button>'; }
    var V = { key: '', sel: {} };
    function vwText(h, n) { var t = String(h || '').replace(/<img[^>]*>/gi, ' [Hình] ').replace(/<table[\s\S]*?<\/table>/gi, ' [Bảng] ').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n) + '…' : t; }
    function vwEnsure() {
        var m = $('ib-view-modal'); if (m) return m;
        m = document.createElement('div'); m.id = 'ib-view-modal'; m.className = 'absolute inset-0 bg-black/70 z-[80] hidden flex justify-center items-center opacity-0 transition-opacity duration-300';
        m.innerHTML = '<div class="bg-white w-full h-full md:max-w-4xl md:h-[92%] md:rounded-2xl flex flex-col overflow-hidden shadow-2xl"><div class="px-4 py-3 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white flex items-center gap-3 shrink-0"><div class="flex-1 min-w-0"><div class="font-black uppercase text-sm truncate" id="ib-vw-title"></div><div class="text-xs font-bold opacity-90" id="ib-vw-count"></div></div><button type="button" onclick="CODE153.vwClose()" class="text-2xl font-black px-2">✕</button></div>' +
            '<div class="px-4 py-2 bg-slate-100 border-b flex flex-wrap gap-2 shrink-0"><button type="button" onclick="CODE153.vwAll(true)" class="px-3 py-1 rounded-full text-xs font-black bg-white border border-violet-300 text-violet-800">Chọn tất cả</button><button type="button" onclick="CODE153.vwAll(false)" class="px-3 py-1 rounded-full text-xs font-black bg-white border border-violet-300 text-violet-800">Bỏ chọn</button><span class="text-[11px] font-bold text-slate-600 self-center">Các câu tích chọn ở đây luôn được lấy vào đề.</span></div>' +
            '<div id="ib-vw-list" class="flex-1 overflow-y-auto p-3 space-y-2 bg-slate-50"></div><div class="px-4 py-3 bg-slate-100 border-t flex justify-end gap-2 shrink-0"><button type="button" onclick="CODE153.vwClose()" class="px-5 py-2 rounded-full font-black text-slate-700 bg-white border border-slate-300 text-sm uppercase">Hủy</button><button type="button" onclick="CODE153.vwSave()" class="px-6 py-2 rounded-full font-black text-white bg-gradient-to-r from-violet-600 to-fuchsia-600 text-sm uppercase">✔ Dùng các câu đã chọn</button></div></div>';
        ($('ib-modal').parentNode || document.body).appendChild(m);
        m.addEventListener('change', function (e) { var t = e.target; if (t && t.hasAttribute && t.hasAttribute('data-qi')) { var i = t.getAttribute('data-qi'); if (t.checked) V.sel[i] = true; else delete V.sel[i]; vwCount(); } });
        return m;
    }
    function vwQs() { var B = bank(); return B ? B.getQuestions(V.key) : []; }
    function vwCount() { var e = $('ib-vw-count'); if (e) e.textContent = 'Đã chọn ' + Object.keys(V.sel).length + ' / ' + vwQs().length + ' câu'; }
    function vwRender() {
        var h = '';
        vwQs().forEach(function (q, i) {
            var p = partOf(q), pn = p === 'mc' ? 'Phần I' : p === 'tf' ? 'Phần II' : 'Phần III', body;
            if (p === 'sa') body = '<div class="text-xs font-black text-emerald-700 mt-1">Đáp án: ' + esc(q.shortAnswer) + '</div>';
            else body = (q.options || []).map(function (o, j) {
                var ok = p === 'tf' ? !!(q.tfAnswers && q.tfAnswers[j]) : o.letter === q.correct;
                return '<div class="text-xs ' + (p === 'mc' && ok ? 'font-black text-emerald-700' : 'text-slate-700') + '">' + (p === 'tf' ? 'abcd'[j] + ') ' : esc(o.letter) + '. ') + esc(vwText(o.text, 160)) + (p === 'tf' ? (ok ? ' <b class="text-emerald-700">[Đúng]</b>' : ' <b class="text-rose-600">[Sai]</b>') : (ok ? ' ✔' : '')) + '</div>';
            }).join('');
            h += '<label class="block bg-white rounded-xl border border-slate-200 p-3 cursor-pointer"><div class="flex items-start gap-2"><input type="checkbox" data-qi="' + i + '" class="mt-1 w-4 h-4 accent-violet-600"' + (V.sel[i] ? ' checked' : '') + '><div class="min-w-0 flex-1"><div class="text-[11px] font-black text-violet-700">Câu ' + (i + 1) + ' • ' + pn + (q.level ? ' • ' + esc(q.level) : '') + (q.gid ? ' • câu chùm' : '') + '</div><div class="text-sm font-bold text-slate-900 break-words">' + esc(vwText(q.text, 400)) + '</div>' + body + '</div></div></label>';
        });
        $('ib-vw-list').innerHTML = h || '<div class="p-6 text-center font-bold text-slate-500">Bài này chưa có câu hỏi.</div>';
        vwCount();
    }
    function openView(key) {
        var it = null; tree(S.sj, S.g).forEach(function (c) { c.items.forEach(function (x) { if (x.key === key) it = x; }); });
        vwEnsure(); V.key = key; V.sel = JSON.parse(JSON.stringify(S.man[key] || {}));
        $('ib-vw-title').textContent = '👁 ' + (it ? it.n : key); vwRender(); show('ib-view-modal');
    }
    function vwAll(on) { V.sel = {}; if (on) vwQs().forEach(function (q, i) { V.sel[i] = true; }); vwRender(); }
    function vwClose() { hide('ib-view-modal'); }
    function vwSave() {
        if (Object.keys(V.sel).length) { S.man[V.key] = JSON.parse(JSON.stringify(V.sel)); delete S.sel[V.key]; } else delete S.man[V.key];
        vwClose(); renderTree(); syncAll();
    }
    var _us = updateSummary;
    updateSummary = function () {
        _us();
        var m = manualItems(), n = 0, box = $('ib-summary'); m.forEach(function (x) { n += Object.keys(S.man[x.it.key]).length; });
        if (box && n) box.innerHTML = (box.innerHTML.indexOf('Tích chọn') >= 0 ? '' : box.innerHTML + '<br>') + '✋ Chọn tay: <b>' + n + ' câu</b> từ ' + m.length + ' bài (luôn được lấy, không tính vào số câu theo phần)';
    };

    window.CODE153 = { openView: openView, vwAll: vwAll, vwClose: vwClose, vwSave: vwSave, refresh: refresh, onSubjGrade: onSubjGrade, openPick: openPick, closePick: closePick, renderPick: renderPick,
        openImport: openImport, closeImport: closeImport, onSubject: onSubject, onGrade: onGrade, renderTree: renderTree,
        toggleAll: toggleAll, expandAll: expandAll, updateSummary: updateSummary, doImport: doImport, selTake: selTake };
    setTimeout(refresh, 0);
})();
